// swift-tools-version: 6.2
import PackageDescription
let package = Package(
    name: "SonoPlayerMacOS",
    platforms: [.macOS("26.0")],
    products: [.executable(name: "SonoPlayer", targets: ["SonoPlayer"])],
    targets: [.executableTarget(name: "SonoPlayer", exclude: ["Resources"])]
)
