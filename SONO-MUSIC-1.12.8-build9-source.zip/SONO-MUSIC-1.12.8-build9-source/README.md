# SONO MUSIC 1.12.8 preview

Apple Silicon, macOS 26.0 or later. Build 9.

Use an Apple Silicon Mac with Swift 6.4, the macOS 26.5 SDK and Python 3.
From this directory, run:

    SONO_CANDIDATE_OUTPUT="$PWD/output" zsh scripts/build.sh --candidate

The command prints the path to the locally signed application. Git history
and developer credentials are unnecessary. The output is intended for preview
testing. See THIRD_PARTY_NOTICES.txt and licenses/ for upstream provenance.

## License

SONO MUSIC 1.12.8 (build 9), including the complete program and its corresponding source, is distributed under the GNU General Public License version 3 only (`GPL-3.0-only`). You may run, copy, modify and redistribute the program, including commercially, under those terms. When redistributing a binary, provide its complete corresponding source as required by section 6. The program is provided without warranty to the extent permitted by applicable law.

The icons and default cover art are original works by the project author and are distributed as part of this release. Upstream copyright and license notices are in `THIRD_PARTY_NOTICES.txt` and `licenses/`. See `LICENSE` for the full terms.
