#!/bin/zsh
set -euo pipefail
cd "${0:A:h}/.."
MODE="${1:-development}"
if [[ "$MODE" != development && "$MODE" != --sandbox && "$MODE" != --candidate ]]; then
    print -u2 'Usage: zsh scripts/build.sh [--sandbox | --candidate]'
    exit 2
fi
CONFIGURATION="${SONO_BUILD_CONFIGURATION:-release}"
if [[ "$CONFIGURATION" != release && "$CONFIGURATION" != debug ]]; then
    print -u2 'SONO_BUILD_CONFIGURATION must be release or debug'
    exit 2
fi
SDK_PATH="$(xcrun --sdk macosx26.5 --show-sdk-path)"
python3 scripts/generate-desktop-tokens.py
python3 scripts/generate-colors.py --check
# The native backend preserves SDKROOT for Swift's clang linker driver.
BUILD_DIRECTORY=.build
BUILD_FLAGS=()
if [[ "$MODE" == --candidate ]]; then
    if [[ "$CONFIGURATION" != release ]]; then
        print -u2 'Candidate builds require release optimization'
        exit 2
    fi
    BUILD_DIRECTORY=.build/candidate
    BUILD_FLAGS=(-Xswiftc -DSONO_RELEASE_CANDIDATE -Xswiftc -file-prefix-map -Xswiftc "$PWD=.")
fi
SDKROOT="$SDK_PATH" swift build --build-system native --scratch-path "$BUILD_DIRECTORY" -c "$CONFIGURATION" --sdk "$SDK_PATH" "${BUILD_FLAGS[@]}"
APP="$PWD/build/SONO MUSIC.app"
if [[ "$MODE" == --sandbox ]]; then APP="$PWD/build/SONO MUSIC Sandbox.app"; fi
if [[ "$MODE" == --candidate ]]; then
    CANDIDATES="${SONO_CANDIDATE_OUTPUT:-$PWD/../Sono-Player-macOS-Files/temporary/release-candidates}"
    mkdir -p "$CANDIDATES"
    OUTPUT="$(mktemp -d "$CANDIDATES/candidate.XXXXXXXX")"
    APP="$OUTPUT/SONO MUSIC.app"
fi
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
cp "$BUILD_DIRECTORY/$CONFIGURATION/SonoPlayer" "$APP/Contents/MacOS/SonoPlayer"
mkdir -p "$APP/Contents/Resources/SonoAssets"
if [[ "$MODE" == --candidate ]]; then
    if [[ -f scripts/release-assets.txt ]]; then
        ASSETS=("${(@f)$(< scripts/release-assets.txt)}")
    else
        ASSETS=("${(@f)$(git ls-files -- 'Sources/SonoPlayer/Resources/*.svg')}")
    fi
    if (( ${#ASSETS} == 0 )); then
        print -u2 'No candidate assets listed'
        exit 1
    fi
    for resource in "${ASSETS[@]}"; do
        if [[ -L "$resource" || ! -f "$resource" || "${resource:h}" != Sources/SonoPlayer/Resources || "$resource" != *.svg ]]; then
            print -u2 'Unexpected candidate asset'
            exit 1
        fi
        cp "$resource" "$APP/Contents/Resources/SonoAssets/"
    done
    xcrun strip -S -x "$APP/Contents/MacOS/SonoPlayer"
else
    cp -R Sources/SonoPlayer/Resources/. "$APP/Contents/Resources/SonoAssets/"
fi
cp Info.plist "$APP/Contents/Info.plist"
cp AppIcon.icns "$APP/Contents/Resources/AppIcon.icns"
mkdir -p "$APP/Contents/Resources/Licenses"
cp THIRD_PARTY_NOTICES.txt "$APP/Contents/Resources/THIRD_PARTY_NOTICES.txt"
# Existing development bundles may still contain this obsolete resource.
if [[ -f "$APP/Contents/Resources/Licenses/Folia-AGPL-3.0.txt" ]]; then
    rm "$APP/Contents/Resources/Licenses/Folia-AGPL-3.0.txt"
fi
cp licenses/NeteaseCloudMusicApi-MIT.txt "$APP/Contents/Resources/Licenses/NeteaseCloudMusicApi-MIT.txt"
cp licenses/LDDC-GPL-3.0.txt "$APP/Contents/Resources/Licenses/LDDC-GPL-3.0.txt"
cp licenses/QQMusicDecoder-MIT.txt "$APP/Contents/Resources/Licenses/QQMusicDecoder-MIT.txt"
if [[ "$MODE" == --sandbox ]]; then
    /usr/libexec/PlistBuddy -c 'Set :CFBundleIdentifier app.sono.native.sandbox' "$APP/Contents/Info.plist"
    /usr/libexec/PlistBuddy -c 'Set :CFBundleName SONO MUSIC Sandbox' "$APP/Contents/Info.plist"
    /usr/libexec/PlistBuddy -c 'Set :CFBundleDisplayName SONO MUSIC Sandbox' "$APP/Contents/Info.plist"
    codesign --force --sign - --entitlements Sandbox.entitlements "$APP"
else
    codesign --force --sign - "$APP"
fi
codesign --verify "$APP"
if [[ "$MODE" == --candidate ]]; then
    python3 scripts/check-candidate.py "$APP"
    python3 - "$BUILD_DIRECTORY/$CONFIGURATION/SonoPlayer" "$APP" <<'PYTHON'
from pathlib import Path
import sys

unstripped, app = map(Path, sys.argv[1:])
print(f"Unstripped candidate executable: {unstripped.stat().st_size} bytes")
print(f"Candidate executable: {(app / 'Contents/MacOS/SonoPlayer').stat().st_size} bytes")
print(f"Candidate application: {sum(path.stat().st_size for path in app.rglob('*') if path.is_file())} bytes")
PYTHON
fi
if [[ "$MODE" == development ]]; then
    # Only a successful main-app update resets workbench adjustment markers.
    python3 - <<'PY'
import json
import uuid
from pathlib import Path
Path('docs/design-system/native-update.js').write_text(
    'window.SONO_NATIVE_UPDATE = ' + json.dumps(str(uuid.uuid4())) + ';\n')
PY
fi
printf 'Built app: %s\n' "$APP"
