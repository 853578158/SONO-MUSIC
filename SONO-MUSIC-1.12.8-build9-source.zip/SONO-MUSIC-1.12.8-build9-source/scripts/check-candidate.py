"""Check packaged bytes without displaying matched values."""
import os
from pathlib import Path
import re
import sys


app = Path(sys.argv[1])
contents = app / "Contents"
resources = contents / "Resources"
assets = resources / "SonoAssets"
required = {
    resources / "Licenses/LDDC-GPL-3.0.txt",
    resources / "Licenses/QQMusicDecoder-MIT.txt",
    contents / "Info.plist",
    contents / "MacOS/SonoPlayer",
    contents / "_CodeSignature/CodeResources",
    resources / "AppIcon.icns",
    resources / "THIRD_PARTY_NOTICES.txt",
    resources / "Licenses/NeteaseCloudMusicApi-MIT.txt",
}
allowed_directories = {contents, *[path.parent for path in required], assets}
patterns = {
    "user directory": rb"/Users/[^/\s\x00]+/",
    "temporary build directory": rb"/(?:private/)?var/folders/",
    "private key": rb"-----BEGIN (?:[A-Z0-9]+ )*PRIVATE KEY-----",
    "access token": rb"(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}|AKIA[A-Z0-9]{16}|sk-(?:proj-)?[A-Za-z0-9_-]{24,})",
    "session cookie": rb"(?:MUSIC_U|MUSIC_A|__csrf)=[A-Za-z0-9%_-]{24,}",
}
home = os.fsencode(str(Path.home()) + "/")
failed = False
for path in sorted(app.rglob("*")):
    relative = path.relative_to(app)
    if path.is_symlink():
        print("Unexpected symbolic link in candidate")
        failed = True
        continue
    if path.is_dir() and path in allowed_directories:
        continue
    if not path.is_file() or not (path in required or path.parent == assets and path.suffix == ".svg"):
        print("Unexpected item in candidate")
        failed = True
        continue
    data = path.read_bytes()
    required.discard(path)
    for kind, pattern in patterns.items():
        if re.search(pattern, data) or (kind == "user directory" and home in data):
            print(f"{kind}: {relative}")
            failed = True
if required:
    print("Missing required candidate files")
    failed = True
if failed:
    sys.exit(1)
print("Candidate file inventory and sensitive-pattern checks passed")
