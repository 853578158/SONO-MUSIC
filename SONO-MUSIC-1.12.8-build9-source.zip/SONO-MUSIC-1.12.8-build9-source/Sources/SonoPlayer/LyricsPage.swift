import AppKit
import SwiftUI
import UniformTypeIdentifiers
import QuartzCore
import CoreText

enum LyricsDockMetrics {
    static let progressHeight: CGFloat = 2
    static let progressTargetHeight: CGFloat = 16
    static let controlsHeight: CGFloat = 72
    static let height = progressTargetHeight + controlsHeight
    // Leave only the visible track at the window edge when the dock is collapsed.
    static let expandedProgressTop = controlsHeight + (progressTargetHeight + progressHeight) / 2
    static let collapsedOffset = controlsHeight + (progressTargetHeight - progressHeight) / 2
}

enum LyricsPageMode: String, CaseIterable {
    case standard, classic, lyrics

    var title: String {
        switch self {
        case .standard: "标准"
        case .classic: "经典"
        case .lyrics: "歌词"
        }
    }

    func isAvailable(narrow: Bool) -> Bool {
        !narrow || self != .standard
    }

    func displayed(narrow: Bool) -> Self {
        isAvailable(narrow: narrow) ? self : .classic
    }
}

struct LyricsPageLayout {
    static let contentInset = 2 * SonoChromeMetrics.horizontalInset + SonoChromeMetrics.buttonSize

    static func centeredLyricsWidth(for width: CGFloat) -> CGFloat {
        min(800, max(0, width - 2 * contentInset))
    }

    static func queueScale(for width: CGFloat) -> CGFloat { min(1, width / 1100) }

    static func metadataSizes(height: CGFloat, classicProgress: CGFloat) -> (title: CGFloat, artist: CGFloat) {
        let compactness = min(1, max(0, (900 - height) / (900 - 650))) * classicProgress
        return (blend(SonoDesktopTokens.FontSize.display, 22, compactness),
                blend(SonoDesktopTokens.FontSize.sectionTitle, 14, compactness))
    }

    @MainActor static func metadataLineHeight(size: CGFloat, weight: Font.Weight = SonoDesktopTokens.FontWeight.regular) -> CGFloat {
        let font = SonoTypography.native(size: size, weight: weight)
        return ceil(CTFontGetAscent(font) + CTFontGetDescent(font))
    }

    static func isStacked(size: CGSize, previous: Bool) -> Bool {
        previous ? size.height > size.width : size.height * 20 >= size.width * 21
    }

    let stacked: Bool
    let artwork: CGRect
    let textCentering: CGFloat
    let textLeft: CGFloat
    let textWidth: CGFloat
    let textTop: CGFloat
    let queueHeight: CGFloat
    let queueTop: CGFloat
    let coverReveal: CGFloat
    var coverRadius: CGFloat { SonoDesktopTokens.Radius.medium * coverReveal }

    static func blend(_ start: CGFloat, _ end: CGFloat, _ progress: CGFloat) -> CGFloat {
        start + (end - start) * progress
    }

    @MainActor init(size: CGSize, contentTop: CGFloat = 0, queueProgress: CGFloat = 0, stacked previous: Bool = false, fill: Bool = false, layoutProgress: CGFloat? = nil) {
        let width = size.width, height = size.height
        stacked = Self.isStacked(size: size, previous: previous)
        let portrait = layoutProgress ?? (stacked ? 1 : 0)
        let wide = CGFloat(LyricsArtworkProcessor.smooth(1.8, 2.2, Double(width / max(1, height))))
        let normalSide = min(width * SonoDesktopTokens.LyricsCover.widthFraction,
                             height * SonoDesktopTokens.LyricsCover.heightFraction)
        let wideSide = Self.blend(normalSide, height, wide)
        let inset = Self.contentInset
        let columnGap = max(18, min(48, width * 0.035))
        let column = max(0, (width - 2 * inset - columnGap) / 2)
        let rightLeft = inset + column + columnGap
        let fillsWindow = stacked && fill
        let sizes = Self.metadataSizes(height: height, classicProgress: 1)
        let metadataHeight = Self.metadataLineHeight(size: sizes.title, weight: SonoDesktopTokens.FontWeight.semibold)
            + Self.metadataLineHeight(size: sizes.artist) + SonoDesktopTokens.Spacing.s8
        let coverToTextGap: CGFloat = 32
        let coverBudget = height - LyricsDockMetrics.expandedProgressTop - coverToTextGap
            - metadataHeight - LyricsTimeline.compactViewportHeight
        let widthLimit = stacked && !fillsWindow ? width - 48 : width
        let portraitHeight = max(0, min(height * 2 / 3, widthLimit, coverBudget))
        let portraitWidth = fillsWindow ? width : portraitHeight
        textCentering = portrait
        textLeft = Self.blend(rightLeft, inset, portrait)
        textWidth = Self.blend(column, width - inset * 2, portrait)
        textTop = Self.blend(contentTop, portraitHeight + coverToTextGap, portrait)

        queueHeight = height * 0.60
        queueTop = height - LyricsDockMetrics.expandedProgressTop - queueHeight
        let smallSide = max(0, min(portraitHeight, queueTop - contentTop - 16))
        let portraitCoverWidth = Self.blend(portraitWidth, smallSide, queueProgress)
        let portraitCoverHeight = Self.blend(portraitHeight, smallSide, queueProgress)
        coverReveal = portrait * queueProgress
        artwork = CGRect(x: Self.blend(0, (width - portraitCoverWidth) / 2, portrait),
                         y: Self.blend((height - wideSide) / 2, contentTop * queueProgress, portrait),
                         width: Self.blend(wideSide, portraitCoverWidth, portrait),
                         height: Self.blend(wideSide, portraitCoverHeight, portrait))
    }
}

private struct LyricsPageMotion<Content: View>: View, Animatable {
    nonisolated var queue: CGFloat
    nonisolated var dock: CGFloat
    nonisolated var portrait: CGFloat
    nonisolated var lyricsOnly: CGFloat
    @ViewBuilder let content: (CGFloat, CGFloat, CGFloat, CGFloat) -> Content

    nonisolated var animatableData: AnimatablePair<AnimatablePair<CGFloat, CGFloat>, AnimatablePair<CGFloat, CGFloat>> {
        get { AnimatablePair(AnimatablePair(queue, dock), AnimatablePair(portrait, lyricsOnly)) }
        set { queue = newValue.first.first; dock = newValue.first.second; portrait = newValue.second.first; lyricsOnly = newValue.second.second }
    }

    var body: some View { content(queue, dock, portrait, lyricsOnly) }
}

struct LyricsPage<Controls: View>: View {
    @ObservedObject var session: PlayerSession
    @ObservedObject var lyrics: LyricsState
    @ObservedObject var queueState: QueuePresentationState
    let backgroundCanStart: Bool

    let controlsPinned: Bool
    let controls: (Bool) -> Controls
    let openAlbum: (LocalTrack) -> Void
    let openArtist: (OnlineArtist) -> Void
    let close: () -> Void
    @StateObject private var artwork = LyricsArtworkModel()
    @State private var wasStacked = false
    @AppStorage("lyricsPageMode", store: PerformanceEnvironment.defaults) private var preferredMode = LyricsPageMode.standard
    #if SONO_RELEASE_CANDIDATE
    private let coverFill = true
    private func selectedEdges(stacked: Bool) -> LyricsCoverEdges {
        stacked ? .portrait : .standard
    }
    #else
    @AppStorage("lyricsCoverFill", store: PerformanceEnvironment.defaults) private var coverFill = false

    private func selectedEdges(stacked: Bool) -> LyricsCoverEdges {
        session.lyricsCoverCustomEdges ?? (stacked ? .portrait : .standard)
    }
    #endif

    @State private var dockCollapsed = false
    @State private var presentedLight: Float = 0
    @AppStorage("lyricsTextureStyle", store: PerformanceEnvironment.defaults) private var textureStyle = LyricsTextureStyle.clear.rawValue
    @AppStorage("lyricsBackgroundAutoMatch", store: PerformanceEnvironment.defaults) private var autoMatch = true
    @AppStorage("lyricsBackgroundDynamic", store: PerformanceEnvironment.defaults) private var backgroundDynamic = true
    private var textureAppearance: LyricsTextureStyle {
        autoMatch ? .clear : (LyricsTextureStyle(rawValue:textureStyle) ?? .clear)
    }
    @AppStorage("lyricsDarkWebBackground", store: PerformanceEnvironment.defaults) private var darkWebBackground = false
    @AppStorage("lyricsLightPaletteStyle", store: PerformanceEnvironment.defaults) private var paletteStyle = LyricsLightPaletteStyle.artwork.rawValue
    private var lightPalette: LyricsLightPaletteStyle { LyricsLightPaletteStyle(rawValue: paletteStyle) ?? .artwork }
    private var ink: LyricsInk { LyricsInk(light: presentedLight >= 0.5, contentAdaptive: true) }
    private var textOpacity: Double {
        LyricsArtworkProcessor.smooth(0.17, 0.45, abs(Double(presentedLight)-0.5))
    }
    @State private var choosing = false
    @State private var settings = false
    @AppStorage("lyricsMusicMotion", store: PerformanceEnvironment.defaults) private var musicMotion = false
    #if SONO_RELEASE_CANDIDATE
    private let motionStyle = LyricsMusicMotionStyle.balanced.rawValue
    private let motionStrength = 0.5
    #else
    @AppStorage("lyricsMusicMotionStyle", store: PerformanceEnvironment.defaults) private var motionStyle = LyricsMusicMotionStyle.balanced.rawValue
    @AppStorage("lyricsMusicMotionStrength", store: PerformanceEnvironment.defaults) private var motionStrength = 0.5
    #endif
    @Environment(\.accessibilityReduceMotion) private var reduced
    @Environment(\.colorSchemeContrast) private var accessibilityContrast
    @Environment(\.displayScale) private var displayScale
    private var track: LocalTrack? { session.audio.current }
    var body: some View {
        GeometryReader { geometry in
            let size = geometry.size
            let contentTop = SonoChromeMetrics.topInset + SonoChromeMetrics.buttonSize + 24 - 5
            let narrow = LyricsPageLayout.isStacked(size: size, previous: wasStacked)
            let mode = preferredMode.displayed(narrow: narrow)
            let classic = mode == .classic
            let lyricsOnly = mode == .lyrics
            let queueOpen = session.queueOpen
            let collapsed = dockCollapsed && !(classic && queueOpen)
            LyricsPageMotion(queue: queueOpen ? 1 : 0, dock: collapsed ? 1 : 0, portrait: classic ? 1 : 0, lyricsOnly: lyricsOnly ? 1 : 0) { queue, dock, portrait, lyricsBlend in
                let layout = LyricsPageLayout(size:size, contentTop:contentTop, queueProgress:reduced ? (queueOpen ? 1 : 0) : queue, stacked: narrow, fill: coverFill, layoutProgress: portrait)
                #if SONO_RELEASE_CANDIDATE
                let feather = LyricsCoverFeather(landscape: selectedEdges(stacked: false), portrait: selectedEdges(stacked: true), layoutProgress: portrait, reveal: layout.coverReveal)
                #else
                let feather = LyricsCoverFeather(landscape: session.lyricsCoverFade ? selectedEdges(stacked: false) : [],
                                                portrait: session.lyricsCoverFade ? selectedEdges(stacked: true) : [],
                                                layoutProgress: portrait, reveal: layout.coverReveal)
                #endif
                let artworkRect = layout.artwork
                let centeredWidth = LyricsPageLayout.centeredLyricsWidth(for: size.width)
                let textWidth = LyricsPageLayout.blend(layout.textWidth, centeredWidth, lyricsBlend)
                let textLeft = LyricsPageLayout.blend(layout.textLeft, (size.width - centeredWidth) / 2, lyricsBlend)
                let textTop = LyricsPageLayout.blend(layout.textTop, contentTop, lyricsBlend)
                let centering = LyricsPageLayout.blend(layout.textCentering, 1, lyricsBlend)
                let contentOpacity = 1 - 2 * min(lyricsBlend, 1 - lyricsBlend)
                let progressInset = LyricsDockMetrics.expandedProgressTop - dock * LyricsDockMetrics.collapsedOffset
                let dockHeight = LyricsPageLayout.blend(LyricsDockMetrics.height, progressInset, layout.textCentering)
                let (titleSize, artistSize) = LyricsPageLayout.metadataSizes(height: size.height, classicProgress: portrait)
                let isLightCover = artwork.analysis?.profile.light == 1
                ZStack(alignment:.topLeading) {
                    LyricsMetalBackground(analysis:artwork.analysis,artworkRect:lyricsOnly ? .zero : artworkRect, feather:feather.strengths, reduced:reduced, contrast:accessibilityContrast == .increased, backgroundDynamic:backgroundDynamic, musicMotion:.init(enabled:musicMotion,style:LyricsMusicMotionStyle(rawValue:motionStyle) ?? .balanced,strength:motionStrength), audio:session.audio, paletteStyle: lightPalette, textureStyle: textureAppearance, darkWebBackground: darkWebBackground, backgroundCanStart: backgroundCanStart) { light in
                        presentedLight = light
                    }
                    .frame(width:size.width,height:size.height)
                    .animation(nil, value: size)
                    LyricsArtworkView(model:artwork, size:artworkRect.size, feather:feather, cornerRadius:layout.coverRadius)
                        .frame(width:artworkRect.width,height:artworkRect.height)
                        .offset(x:artworkRect.minX,y:artworkRect.minY)
                        .opacity(1 - lyricsBlend)
                        .allowsHitTesting(false)
                    if session.queueOpen {
                        Color.clear.contentShape(Rectangle())
                            .onTapGesture { session.queueOpen = false }
                    }
                    VStack(alignment:.leading,spacing:SonoDesktopTokens.Spacing.s0) {
                        VStack(alignment:.leading,spacing:SonoDesktopTokens.Spacing.s8) {
                            GeometryReader { titleGeometry in
                                let title = track?.title ?? "选择一首音乐"
                                let titleWidth = ceil(SonoTypography.width(title, size:titleSize, weight:SonoDesktopTokens.FontWeight.semibold))
                                ConsoleReadingText(text:title,size:titleSize,weight:SonoDesktopTokens.FontWeight.semibold,color:ink.titleTransport)
                                    .offset(x:max(0, titleGeometry.size.width - titleWidth) * centering / 2)
                            }.frame(height:LyricsPageLayout.metadataLineHeight(size: titleSize, weight: SonoDesktopTokens.FontWeight.semibold))
                            LyricsSongMetadata(track: track, size: artistSize, ink: ink, openAlbum: openAlbum, openArtist: openArtist, centering: centering)
                                .frame(height:LyricsPageLayout.metadataLineHeight(size: artistSize))
                        }.frame(maxWidth:.infinity,alignment:.leading).zIndex(1)
                        NativeLyricsView(document:lyrics.document,revision:lyrics.documentRevision,status:lyrics.status,audio:session.audio,reduced:reduced,contrast:accessibilityContrast == .increased, ink:ink,presented: queue < 0.99, centering: centering, centerCurrentLine: mode != .standard, layoutMoving: portrait != (classic ? 1 : 0) || lyricsBlend != (lyricsOnly ? 1 : 0))
                            .frame(maxHeight:.infinity)
                        if let error = lyrics.error {
                            Text(error).font(.caption).foregroundStyle(Color(nsColor:ink.secondary))
                        }
                    }
                    .frame(width: textWidth, height: max(0, size.height - textTop - dockHeight))
                    .offset(x: textLeft, y: textTop)
                    .opacity((1 - queue) * textOpacity * contentOpacity)
                    .allowsHitTesting(!queueOpen).accessibilityHidden(queueOpen)

                    if session.queueEditingAllowed {
                        let queueTop = LyricsPageLayout.blend(contentTop, layout.queueTop, portrait * (1 - lyricsBlend))
                        let queueHeight = LyricsPageLayout.blend(max(0, size.height - contentTop - dockHeight), layout.queueHeight, portrait * (1 - lyricsBlend))
                        ZStack(alignment:.topLeading) {
                            QueueContent(session:session,state:queueState,scale:LyricsPageLayout.queueScale(for: size.width),embedded:true,visible:queueOpen)
                                .frame(width:textWidth + 2 * QueueContent.rowContentInset,height:queueHeight,alignment:.top)
                                .offset(x:textLeft - QueueContent.rowContentInset,y:queueTop + (!reduced ? (size.height - layout.queueTop) * (1 - queue) * portrait : 0))
                        }
                        .frame(width:size.width,height:max(0,size.height - dockHeight),alignment:.topLeading)
                        .clipped()
                        .opacity((!reduced && queue > 0 ? LyricsPageLayout.blend(queue, 1, portrait) : queue) * textOpacity * contentOpacity)
                        .allowsHitTesting(queueOpen).accessibilityHidden(!queueOpen)
                    }

                    LyricsPlaybackDock(isPlaying:session.audio.isPlaying,pinned:controlsPinned || (classic && queueOpen),
                                       collapsed:$dockCollapsed, collapseProgress:dock, controls:controls)
                        .opacity(textOpacity)
                        .frame(width:size.width,height:LyricsDockMetrics.height)
                        .offset(y:max(0,size.height - LyricsDockMetrics.height))
                        .animation(nil, value: size)
                    HStack {
                        LyricsChromeButton(label: "退出歌词页", action: close) {
                            SonoIcon(name: "icon-chevron-down", size: SonoDesktopTokens.SvgSize.s24)
                        }
                        Spacer()
                        LyricsChromeButton(label: "歌词设置", action: { settings.toggle() }) {
                            Image(systemName: "slider.horizontal.3")
                                .font(.system(size: SonoDesktopTokens.SymbolSize.control))
                                .foregroundStyle(Color(nsColor: ink.primary))
                        }
                            .popover(isPresented:$settings,arrowEdge:.bottom) {
                                VStack(alignment:.leading,spacing:SonoDesktopTokens.Spacing.s16) {
                                    SonoThemeSegments("模式", selection: Binding(
                                        get: { mode },
                                        set: { preferredMode = $0 }
                                    ), options: LyricsPageMode.allCases, disabledReason: {
                                        $0.isAvailable(narrow: narrow) ? nil : "当前尺寸无法使用该布局"
                                    }) {
                                        $0.title
                                    }
                                    .zIndex(1)
                                    Divider()
                                    Button { settings = false; choosing = true } label: {
                                        HStack {
                                            VStack(alignment:.leading,spacing:SonoDesktopTokens.Spacing.s4) {
                                                Text("选择歌词")
                                                Text(lyrics.source + (lyrics.document.wordTimed ? " · 逐字" : lyrics.document.lines.isEmpty ? "" : " · 逐句"))
                                                    .font(.caption).foregroundStyle(.secondary)
                                            }
                                            Spacer()
                                            Image(systemName:"chevron.right").foregroundStyle(.secondary)
                                        }.contentShape(Rectangle())
                                    }.buttonStyle(.plain)
                                    Divider()
                                    #if !SONO_RELEASE_CANDIDATE
                                    if !lyricsOnly {
                                        VStack(alignment: .leading, spacing: SonoDesktopTokens.Spacing.s8) {
                                            Text("封面")
                                            SonoThemeSegments("边缘效果", selection: $session.lyricsCoverFade, options: [false, true]) {
                                                $0 ? "淡出边缘" : "硬边"
                                            }
                                            if session.lyricsCoverFade {
                                                HStack {
                                                    ForEach(LyricsCoverEdges.directions, id: \.self) { direction in
                                                        Toggle(direction.title, isOn: Binding(
                                                            get: { selectedEdges(stacked: classic).contains(direction) },
                                                            set: { enabled in
                                                                var edges = selectedEdges(stacked: classic)
                                                                if enabled { edges.insert(direction) }
                                                                else { edges.remove(direction) }
                                                                session.lyricsCoverCustomEdges = edges
                                                            }
                                                        )).toggleStyle(.checkbox)
                                                    }
                                                }
                                                if session.lyricsCoverCustomEdges != nil {
                                                    Button("按布局自动") {
                                                        session.lyricsCoverCustomEdges = nil
                                                    }
                                                    .font(.caption)
                                                }
                                            }
                                            SonoThemeSegments("竖排封面尺寸", selection: $coverFill, options: [false, true]) {
                                                $0 ? "填充到左右边缘" : "保持现状"
                                            }
                                        }
                                        Divider()
                                    }
                                    #endif
                                    if isLightCover || artwork.analysis?.textureArtwork != nil {
                                        VStack(alignment: .leading, spacing: SonoDesktopTokens.Spacing.s8) {
                                            Text("背景色")
                                            HStack(spacing: SonoDesktopTokens.Spacing.s8) {
                                                SonoThemeSegments("背景色", selection: Binding(
                                                    get: { isLightCover ? lightPalette : (darkWebBackground ? .texture : .artwork) },
                                                    set: { style in
                                                        if isLightCover { paletteStyle = style.rawValue }
                                                        else { darkWebBackground = style == .texture }
                                                    }
                                                ), options: LyricsLightPaletteStyle.allCases, showsLabel: false, title: \.title)
                                                Toggle("自动匹配",isOn:$autoMatch).toggleStyle(.checkbox)
                                            }
                                            if isLightCover && lightPalette == .texture {
                                                SonoThemeSegments("纹理效果", selection: Binding(
                                                    get: { textureAppearance }, set: { textureStyle = $0.rawValue }
                                                ), options: LyricsTextureStyle.allCases, showsLabel: false, title: \.title)
                                                    .disabled(autoMatch)
                                            }
                                        }
                                    }
                                    SonoThemeSegments("背景动效", selection: $backgroundDynamic, options: [false, true]) { $0 ? "动态" : "静态" }
                                    Toggle("随音乐律动",isOn:$musicMotion).toggleStyle(.switch).disabled(!backgroundDynamic)
                                    #if !SONO_RELEASE_CANDIDATE
                                    if backgroundDynamic && musicMotion {
                                        SonoThemeSegments("律动风格", selection: $motionStyle, options: LyricsMusicMotionStyle.allCases.map(\.rawValue)) {
                                            (LyricsMusicMotionStyle(rawValue: $0) ?? .balanced).title
                                        }
                                        VStack(alignment:.leading,spacing:SonoDesktopTokens.Spacing.s8) {
                                            Text("律动强度")
                                            Slider(value:$motionStrength,in:0...1).accessibilityLabel("律动强度")
                                            HStack { Text("轻微"); Spacer(); Text("明显") }.font(.caption).foregroundStyle(.secondary)
                                        }
                                        Button("恢复默认") { motionStyle = LyricsMusicMotionStyle.balanced.rawValue; motionStrength = 0.5 }
                                            .font(.caption)
                                    }
                                    #endif
                                }.padding(SonoDesktopTokens.Spacing.s20).frame(width:320)
                                    .transaction { $0.animation = nil }
                            }
                    }
                    .environment(\.lyricsInk, ink)
                    .padding(.horizontal, SonoChromeMetrics.horizontalInset)
                    .padding(.top, SonoChromeMetrics.topInset)
                }
                .frame(width:size.width,height:size.height,alignment:.topLeading)
                .environment(\.lyricsInk,ink)
            }
            .animation(reduced ? .easeOut(duration:0.12) : .easeOut(duration:0.32),value:queueOpen)
            .animation(reduced ? nil : .timingCurve(0.25,0.1,0.25,1,duration:0.28),value:collapsed)
            .animation(reduced ? nil : .easeOut(duration:0.32),value:mode)
            .onChange(of: narrow, initial: true) { _, value in wasStacked = value }
            .onChange(of: track?.coverURL, initial: true) { _, url in artwork.load(url) }
        }
        .onAppear { lyrics.load(track,online:session.online) }
        .onChange(of:track?.id) { _,_ in lyrics.load(track,online:session.online) }
        .onDisappear { session.audio.setAnalysisEnabled(false); artwork.stop() }
        .sheet(isPresented:$choosing) { LyricsChooser(lyrics:lyrics,session:session).frame(width:820,height:620) }
        .onDrop(of:[UTType.fileURL],isTargeted:nil) { providers in
            guard let provider = providers.first else { return false }
            _ = provider.loadObject(ofClass:URL.self) { url,_ in
                guard let url else { return }; Task { @MainActor in importFile(url) }
            }; return true
        }
    }
    private func importFile(_ url:URL) {
        guard let track else { return }
        let scoped = url.startAccessingSecurityScopedResource(); defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        do { try lyrics.select(text:(url.pathExtension.lowercased() == "krc" ? try LyricProviders.krc(Data(contentsOf:url)) : try String(contentsOf:url,encoding:.utf8)),format:url.pathExtension.lowercased(),source:url.lastPathComponent,track:track) } catch { lyrics.error = error.localizedDescription }
    }
}

private struct LyricsChromeButton<Icon: View>: View {
    let label: String
    let action: () -> Void
    @ViewBuilder let icon: () -> Icon
    var body: some View {
        Button(action: action) {
            icon()
                .frame(width: SonoChromeMetrics.buttonSize, height: SonoChromeMetrics.buttonSize)
                .contentShape(Circle())
        }
        .buttonStyle(LyricsChromeButtonStyle())
        .help(label)
        .accessibilityLabel(label)
        .environment(\.sonoGlassDensity, .clear)
    }
}

private struct LyricsChromeButtonStyle: ButtonStyle {
    @State private var hovered = false

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .opacity(configuration.isPressed ? 0.8 : 1)
            .background {
                if hovered && !configuration.isPressed {
                    Color.clear.chromeSurface().allowsHitTesting(false)
                }
            }
            .onHover { inside in
                hovered = inside
                (inside ? NSCursor.pointingHand : NSCursor.arrow).set()
            }
    }
}

private struct LyricsPlaybackDock<Controls: View>: View {
    static var height: CGFloat { LyricsDockMetrics.height }
    let isPlaying: Bool
    let pinned: Bool
    @Binding var collapsed: Bool
    let collapseProgress: CGFloat
    let controls: (Bool) -> Controls
    @State private var hovering = false
    private var shouldAutoHide: Bool { isPlaying && !hovering && !pinned }

    var body: some View {
        ZStack(alignment:.top) {
            LyricsDockHoverRegion { hovering = $0 }
            controls(collapseProgress < 0.99)
                .frame(height:Self.height)
                .offset(y:collapseProgress * LyricsDockMetrics.collapsedOffset)
        }
            .frame(height:Self.height)
            .contentShape(Rectangle())
            .task(id:shouldAutoHide) {
                guard shouldAutoHide else { collapsed = false; return }
                // SwiftUI cancels the pending hide on hover, pause, a pinned
                // interaction or when the lyrics page leaves the hierarchy.
                do { try await Task.sleep(for:.seconds(3)) }
                catch { return }
                collapsed = true
            }
    }
}

private struct LyricsDockHoverRegion: NSViewRepresentable {
    let changed: (Bool) -> Void
    func makeNSView(context: Context) -> Region { Region(changed:changed) }
    func updateNSView(_ view: Region, context: Context) { view.changed = changed }

    final class Region: NSView {
        var changed: (Bool) -> Void
        private var area: NSTrackingArea?
        private var inside = false
        init(changed: @escaping (Bool) -> Void) { self.changed = changed; super.init(frame:.zero) }
        required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
        override func hitTest(_ point: NSPoint) -> NSView? { nil }
        override func updateTrackingAreas() {
            if let area { removeTrackingArea(area) }
            let next = NSTrackingArea(rect:.zero,options:[.mouseEnteredAndExited,.mouseMoved,.activeAlways,.inVisibleRect,.enabledDuringMouseDrag],owner:self,userInfo:nil)
            addTrackingArea(next); area = next
            super.updateTrackingAreas()
            updatePointer()
        }
        override func layout() { super.layout(); updatePointer() }
        override func mouseEntered(with event: NSEvent) { report(true) }
        override func mouseExited(with event: NSEvent) { report(false) }
        override func mouseMoved(with event: NSEvent) { updatePointer() }
        private func updatePointer() {
            guard let window else { return }
            report(bounds.contains(convert(window.mouseLocationOutsideOfEventStream,from:nil)))
        }
        private func report(_ value: Bool) {
            guard value != inside else { return }
            inside = value
            DispatchQueue.main.async { [weak self] in self?.changed(value) }
        }
    }
}

private struct LyricsChooser: View {
    @ObservedObject var lyrics:LyricsState; @ObservedObject var session:PlayerSession
    @Environment(\.dismiss) private var dismiss
    @State private var boundTrackID: String?
    @State private var requestID = UUID()
    @State private var requestTask: Task<Void,Never>?
    @State private var selectedSource = LyricSource.qq
    @FocusState private var queryFocused: Bool
    @State private var query = ""; @State private var results:[LyricCandidate] = []; @State private var preview:LyricDocument?; @State private var page = 1; @State private var more = false; @State private var busy = false; @State private var failure:String?
    var body: some View {
        VStack(alignment:.leading,spacing:SonoDesktopTokens.Spacing.s16) {
            HStack { Text("选择歌词").font(.title2); Spacer(); Button("完成") { dismiss() } }
            SonoThemeSegments("歌词来源", selection: $selectedSource, options: LyricSource.allCases, title: \.title)
                .onChange(of: selectedSource) { _, _ in search(reset: true) }
            HStack {
                TextField("搜索曲名、歌手或歌词", text: $query)
                    .textFieldStyle(.plain)
                    .focused($queryFocused)
                    .focusEffectDisabled()
                    .onSubmit { search(reset: true) }
                    .padding(.horizontal, SonoDesktopTokens.Spacing.s12)
                    .frame(height: SonoDesktopTokens.Component.control)
                    .background(Color(nsColor: .textBackgroundColor), in: Capsule())
                    .overlay { Capsule().strokeBorder(Color(nsColor: SonoGeneratedColors.interfaceBorder), lineWidth: SonoDesktopTokens.Border.standard) }
                    .overlay { SonoSearchFocusRing(focused: queryFocused) }
                Button("搜索") { search(reset: true) }.disabled(busy)
            }
            HStack { Button("导入歌词文件") { importFile() }; Button("恢复自动选择") { if let track = session.audio.current { do { try lyrics.reset(track,online:session.online); dismiss() } catch { failure = error.localizedDescription } } } }
            HStack {
                Button("导入翻译 LRC") { importAuxiliary(roman:false) }
                Button("导入音译 LRC") { importAuxiliary(roman:true) }
                Button("移除翻译") { removeAuxiliary(roman:false) }
                Button("移除音译") { removeAuxiliary(roman:true) }
            }.font(.caption)
            if busy { ProgressView().controlSize(.small) }
            if let failure { Text(failure).foregroundStyle(Color(nsColor: SonoGeneratedColors.interfaceError)).font(.caption) }
            HSplitView {
                List(results) { item in Button { fetch(item) } label: { VStack(alignment:.leading) { Text(item.title + " · \(item.score)%"); Text(item.artist + " · " + item.album).font(.caption).foregroundStyle(.secondary); Text(item.duration > 0 ? "\(Int(item.duration)) 秒" : "社区歌词").font(.caption2).foregroundStyle(.secondary) }.frame(maxWidth:.infinity,alignment:.leading).contentShape(Rectangle()) }.buttonStyle(.plain) }
                ScrollView { Text(previewText).font(.system(size:SonoDesktopTokens.FontSize.body)).frame(maxWidth:.infinity,alignment:.leading).padding() }.frame(minWidth:230)
            }
            HStack { if more { Button("下一页") { search(reset:false) } }; Spacer(); Button("使用这份歌词") { apply() }.disabled(preview == nil) }
        }.padding(SonoDesktopTokens.Spacing.s24).onAppear { query = session.audio.current?.title ?? ""; boundTrackID = session.audio.current?.id }.onChange(of:session.audio.current?.id) { _,_ in requestTask?.cancel(); requestID = UUID(); preview = nil; dismiss() }.onDisappear { requestTask?.cancel(); requestID = UUID() }
    }
    private var previewText:String { guard let parsed = preview else { return "选择结果预览歌词" }; return (parsed.wordTimed ? "逐字歌词\n\n" : "逐句歌词\n\n") + parsed.lines.map { $0.text + ($0.translation.isEmpty ? "" : "\n"+$0.translation) + ($0.romanization.isEmpty ? "" : "\n"+$0.romanization) }.joined(separator:"\n\n") }
    private func search(reset:Bool) {
        guard let track=session.audio.current else { return }
        requestTask?.cancel(); busy=true; failure=nil; if reset { page=1; results=[] }; let q=query,p=page,token=UUID(),source=selectedSource; requestID=token; preview=nil
        requestTask = Task { do { let items=try await lyrics.providers.search(source,query:q,page:p,track:track,online:session.online); if requestID==token { results=items; more=items.count==20; page=p+1 } } catch { if requestID==token { failure=error.localizedDescription } }; if requestID==token { busy=false } }
    }
    private func fetch(_ item:LyricCandidate) {
        requestTask?.cancel(); busy=true; preview=nil; let token=UUID(); requestID=token
        requestTask = Task { do { let doc=try await lyrics.providers.fetch(item,online:session.online); if requestID==token { preview=doc } } catch { if requestID==token { failure=error.localizedDescription } }; if requestID==token { busy=false } }
    }
    private func importAuxiliary(roman:Bool) {
        let panel = NSOpenPanel(); panel.allowedContentTypes = [UTType(filenameExtension:"lrc") ?? .plainText]
        guard panel.runModal() == .OK, let url = panel.url, let track = session.audio.current, track.id == boundTrackID else { return }
        let access = url.startAccessingSecurityScopedResource(); defer { if access { url.stopAccessingSecurityScopedResource() } }
        do { try lyrics.auxiliary(text:(url.pathExtension.lowercased() == "krc" ? try LyricProviders.krc(Data(contentsOf:url)) : try String(contentsOf:url,encoding:.utf8)),romanization:roman,track:track) } catch { failure = error.localizedDescription }
    }
    private func removeAuxiliary(roman:Bool) {
        guard let track = session.audio.current, track.id == boundTrackID else { return }
        do { try lyrics.auxiliary(text:"",romanization:roman,track:track) } catch { failure = error.localizedDescription }
    }
    private func apply() { guard let preview, let track=session.audio.current,track.id==boundTrackID else { return }; do { try lyrics.select(document:preview,source:selectedSource.title,track:track); dismiss() } catch { failure=error.localizedDescription } }
    private func importFile() { let panel = NSOpenPanel(); panel.allowedContentTypes = LyricsParser.formats.compactMap { UTType(filenameExtension:$0) }; guard panel.runModal() == .OK, let url = panel.url, let track = session.audio.current else { return }; let scope = url.startAccessingSecurityScopedResource(); defer { if scope { url.stopAccessingSecurityScopedResource() } }; do { try lyrics.select(text:(url.pathExtension.lowercased() == "krc" ? try LyricProviders.krc(Data(contentsOf:url)) : try String(contentsOf:url,encoding:.utf8)),format:url.pathExtension.lowercased(),source:url.lastPathComponent,track:track); dismiss() } catch { failure = error.localizedDescription } }
}

/// Allocate the available line to artist and album without leaving unused artist slots.
struct LyricsSongMetadata: View {
    let track: LocalTrack?
    let size: CGFloat
    let ink: LyricsInk
    let openAlbum: (LocalTrack) -> Void
    let openArtist: (OnlineArtist) -> Void
    var centering: CGFloat = 0

    var body: some View {
        GeometryReader { geometry in
            let artist = track?.artist ?? ""
            let album = track?.album ?? ""
            let artistMeasured = ceil(SonoTypography.width(artist, size: size))
            let albumMeasured = ceil(SonoTypography.width(album, size: size))
            let showsSeparator = !artist.isEmpty && !album.isEmpty
            let dotDiameter = size * 0.16
            let separatorWidth = showsSeparator ? dotDiameter + 2 * SonoDesktopTokens.Spacing.s12 : 0
            let textBudget = max(0, geometry.size.width - separatorWidth)
            let artistWidth = min(artistMeasured, max(0, textBudget - min(albumMeasured, textBudget * 0.4)))
            let albumWidth = min(albumMeasured, max(0, textBudget - artistWidth))
            HStack(spacing: SonoDesktopTokens.Spacing.s0) {
                LyricsArtistNames(track: track, size: size, ink: ink, select: openArtist)
                    .frame(width: artistWidth, alignment: .leading)
                if showsSeparator {
                    Circle().fill(Color(nsColor: ink.secondary))
                        .frame(width: dotDiameter, height: dotDiameter)
                        .padding(.horizontal, SonoDesktopTokens.Spacing.s12)
                        .accessibilityHidden(true)
                }
                if !album.isEmpty {
                    ConsoleReadingText(text: album, size: size, weight: SonoDesktopTokens.FontWeight.regular, color: ink.secondary,
                                       action: track?.online?.albumID.isEmpty == false ? { if let track { openAlbum(track) } } : nil,
                                       highlightsOnHover: true, hoverColor: ink.primary)
                        .frame(width: albumWidth, alignment: .leading)
                }
            }.frame(height: geometry.size.height)
                .offset(x:max(0, geometry.size.width - artistWidth - albumWidth - separatorWidth) * centering / 2)
        }
    }
}

struct LyricsArtistNames: View {
    let track: LocalTrack?
    let size: CGFloat
    let ink: LyricsInk
    var opensUpward = false
    let select: (OnlineArtist) -> Void
    @ViewState private var expanded = false
    private var artists: [OnlineArtist] {
        guard let track, let info = track.online else { return [] }
        if let artists = info.artists, !artists.isEmpty { return artists }
        return info.artistID.isEmpty ? [] : [OnlineArtist(id: info.artistID, name: track.artist)]
    }
    var body: some View {
        GeometryReader { geometry in
            let names = artists
            let rowHeight = geometry.size.height
            let text = names.isEmpty ? (track?.artist ?? "") : names.map(\.name).joined(separator: " / ")
            Group {
                if names.count > 1 && SonoTypography.width(text, size: size) <= geometry.size.width {
                    HStack(spacing: SonoDesktopTokens.Spacing.s0) {
                        ForEach(Array(names.enumerated()), id: \.offset) { index, artist in
                            if index > 0 { Text(" / ").font(SonoTypography.font(size: size)).foregroundStyle(Color(nsColor: ink.secondary)) }
                            ConsoleReadingText(text: artist.name, size: size, weight: SonoDesktopTokens.FontWeight.regular, color: ink.secondary,
                                               action: { select(artist) }, highlightsOnHover: true, hoverColor: ink.primary)
                                .frame(width: ceil(SonoTypography.width(artist.name, size: size)), alignment: .leading)
                        }
                    }
                } else {
                    ConsoleReadingText(text: text, size: size, weight: SonoDesktopTokens.FontWeight.regular, color: ink.secondary,
                                       action: names.isEmpty ? nil : {
                                           if names.count > 1 { expanded.toggle() }
                                           else if let artist = names.first { select(artist) }
                                       }, highlightsOnHover: !names.isEmpty, hoverColor: ink.primary)
                }
            }.overlay(alignment: .topLeading) {
                if expanded {
                    VStack(alignment: .leading, spacing: SonoDesktopTokens.Spacing.s12) {
                        HStack {
                            Text("选择歌手").font(.headline)
                            Spacer()
                            Button { expanded = false } label: { Image(systemName: "xmark") }.accessibilityLabel("关闭歌手选择")
                        }
                        ForEach(names) { artist in
                            Button(artist.name) { expanded = false; select(artist) }
                                .frame(maxWidth: .infinity, alignment: .leading)
                        }
                    }.buttonStyle(.plain).padding(SonoDesktopTokens.Spacing.s20).frame(width: opensUpward ? 260 : min(300, geometry.size.width))
                        .background(Color(nsColor: SonoGeneratedColors.lyricsPanel), in: RoundedRectangle(cornerRadius: 20))
                        .foregroundStyle(Color(nsColor: SonoGeneratedColors.primaryText)).shadow(color: Color(nsColor: SonoGeneratedColors.lyricsShadow), radius: SonoGeneratedColors.lyricsPanelShadowBlur / 2, x: SonoGeneratedColors.lyricsPanelShadowX, y: SonoGeneratedColors.lyricsPanelShadowY)
                        .alignmentGuide(.top) { dimensions in
                            opensUpward ? dimensions.height + 8 : -rowHeight - 8
                        }
                }
            }
        }.onChange(of: track?.id) { _, _ in expanded = false }
    }
}
