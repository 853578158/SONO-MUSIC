import Combine
import Foundation

struct ChorusRange: Equatable, Sendable {
    let start: Double
    let end: Double

    static func parse(_ json: OnlineJSON, songID: String) -> [Self] {
        let rows = json["chorus"].isNull ? json["data"].array : json["chorus"].array
        return rows.compactMap { row in
            guard row["id"].string == songID,
                  let start = Double(row["startTime"].string),
                  let end = Double(row["endTime"].string),
                  start.isFinite, end.isFinite, start >= 0, end > start else { return nil }
            return Self(start: start / 1000, end: end / 1000)
        }.sorted { $0.start < $1.start }
    }

    func startFraction(duration: Double) -> Double? {
        guard duration > 0, start < duration else { return nil }
        return start / duration
    }

    static func jumpTarget(in ranges: [Self], seconds: Double, tolerance: Double, duration: Double) -> Double? {
        ranges.filter { $0.startFraction(duration: duration) != nil && abs($0.start - seconds) <= tolerance }
            .min { abs($0.start - seconds) < abs($1.start - seconds) }?.start
    }
}

@MainActor
final class ChorusState: ObservableObject {
    @Published private(set) var ranges: [ChorusRange] = []
    private var request: Task<Void, Never>?

    func load(songID: String?, fetch: @escaping @MainActor (String) async throws -> [ChorusRange]) {
        request?.cancel()
        ranges = []
        guard let songID else { request = nil; return }
        request = Task { [weak self] in
            do {
                let ranges = try await fetch(songID)
                try Task.checkCancellation()
                self?.ranges = ranges
            } catch {
                // Optional metadata must not interrupt playback or publish another song's ranges.
                if !Task.isCancelled { NSLog("Chorus metadata unavailable: %@", error.localizedDescription) }
            }
        }
    }

    func cancel() { request?.cancel(); request = nil }
}
