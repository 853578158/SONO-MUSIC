import Foundation
import CryptoKit
import CommonCrypto
import zlib

enum LyricSource: String, CaseIterable, Codable, Sendable {
    case qq, netease, amll, kugou
    var title: String { switch self { case .qq: "QQ 音乐"; case .netease: "网易云"; case .amll: "AMLL TTML DB"; case .kugou: "酷狗音乐" } }
}
struct LyricCandidate: Identifiable, Sendable {
    var source: LyricSource; var key: String; var title: String; var artist: String; var album: String; var duration: Double
    var hash = ""; var cover: URL?; var score = 0
    var id: String { source.rawValue + "/" + key }
    func reliable(for track: LocalTrack) -> Bool {
        let markers = ["live", "现场", "remix", "伴奏", "cover", "翻唱", "8d", "slowed", "sped", "变速"]
        return score >= 75 && duration > 0 && track.duration > 0 && abs(duration-track.duration) <= 3 && LyricProviders.normalize(title) == LyricProviders.normalize(track.title) && LyricProviders.normalize(artist).contains(LyricProviders.normalize(track.artist)) && !["", "本地音频"].contains(track.artist) && markers.allSatisfy { title.lowercased().contains($0) == track.title.lowercased().contains($0) }
    }
}
actor LyricProviders {
    let community = CommunityLyrics.shared
    private let session: URLSession

    init(session: URLSession? = nil) {
        if let session {
            self.session = session
            return
        }
        let c = URLSessionConfiguration.ephemeral; c.timeoutIntervalForRequest = 5; c.timeoutIntervalForResource = 8
        self.session = URLSession(configuration:c)
    }
    static func normalize(_ s: String) -> String {
        s.applyingTransform(StringTransform("Traditional-Simplified"),reverse:false)!.folding(options:[.caseInsensitive,.diacriticInsensitive,.widthInsensitive],locale:Locale(identifier:"en_US_POSIX")).filter { $0.isLetter || $0.isNumber }
    }
    static func score(_ candidate: LyricCandidate, track: LocalTrack) -> Int {
        let title = normalize(candidate.title) == normalize(track.title)
        let artist = !["", "本地音频"].contains(track.artist) && normalize(candidate.artist).contains(normalize(track.artist))
        let album = track.album == "未知专辑" || track.album.isEmpty || normalize(candidate.album) == normalize(track.album)
        let base = (title ? 45 : 0) + (artist ? 25 : 0) + (album ? 30 : 0)
        return Int(Double(base) * (candidate.duration > 0 && track.duration > 0 ? (abs(candidate.duration-track.duration) <= 3 ? 1 : 0.35) : 0.9))
    }
    private func json(_ url: String, query: [String:String] = [:], body: [String:Any]? = nil) async throws -> OnlineJSON {
        var u = URLComponents(string:url)!; u.queryItems = query.map { URLQueryItem(name:$0.key,value:$0.value) }
        var r = URLRequest(url:u.url!); r.setValue("Mozilla/5.0",forHTTPHeaderField:"User-Agent"); r.setValue("https://y.qq.com/",forHTTPHeaderField:"Referer")
        if let body { r.httpMethod = "POST"; r.httpBody = try JSONSerialization.data(withJSONObject:body); r.setValue("application/json",forHTTPHeaderField:"Content-Type"); r.setValue("tmeLoginType=-1;",forHTTPHeaderField:"Cookie") }
        let (d,res) = try await session.data(for:r); try Task.checkCancellation()
        guard (res as? HTTPURLResponse)?.statusCode == 200 else { throw URLError(.badServerResponse) }
        return try OnlineJSON(data:d)
    }
    // Lyric request parameters adapted from the pinned LDDC revision in
    // THIRD_PARTY_NOTICES.txt. Sono uses the anonymous lyric-only profile.
    private func qqLyrics(_ song: LyricCandidate) async throws -> OnlineJSON {
        let metadata = ["albumName": song.album, "singerName": song.artist, "songName": song.title]
            .mapValues { Data($0.utf8).base64EncodedString() }
        var flags: [String: Any] = metadata
        flags.merge([
            "crypt": 1, "ct": 19, "cv": 2111, "interval": Int(song.duration),
            "lrc_t": 0, "qrc": 1, "qrc_t": 0, "roma": 1, "roma_t": 0,
            "songID": Int(song.key) ?? 0, "trans": 1, "trans_t": 0, "type": 0
        ]) { _, supplied in supplied }
        let envelope: [String: Any] = [
            "comm": ["ct": 11, "cv": "1003006", "v": "1003006", "tmeAppID": "qqmusiclight", "uid": "0"],
            "request": ["method": "GetPlayLyricInfo", "module": "music.musichallSong.PlayLyricInfo", "param": flags]
        ]
        let reply = try await json("https://u.y.qq.com/cgi-bin/musicu.fcg", body: envelope)
        let result = reply["request"]
        guard reply["code"].int == 0, result["code"].int == 0 else {
            throw URLError(.badServerResponse)
        }
        return result["data"]
    }

    private func kugouLyrics(_ path: String, fields: [String: String]) async throws -> OnlineJSON {
        var query = ["appid": "3116", "clientver": "11070"]
        query.merge(fields) { _, supplied in supplied }
        let salt = "LnT6xpN3khm36zse0QzvmgTZ3waWdRSA"
        let canonical = query.sorted { $0.key < $1.key }.map { "\($0.key)=\($0.value)" }.joined()
        let digest = Insecure.MD5.hash(data: Data((salt + canonical + salt).utf8))
        query["signature"] = digest.map { String(format: "%02x", $0) }.joined()
        return try await json("https://lyrics.kugou.com/" + path, query: query)
    }

    func search(_ source:LyricSource, query:String, page:Int, track:LocalTrack, online:OnlineSession) async throws -> [LyricCandidate] {
        var items:[LyricCandidate] = []
        switch source {
        case .qq:
            let r = try await json("https://c.y.qq.com/soso/fcgi-bin/client_search_cp",query:["w":query,"format":"json","p":String(page),"n":"20"])
            guard r["code"].string == "0", case .array(let rows) = r["data"]["song"]["list"] else {
                throw URLError(.badServerResponse)
            }
            items = rows.compactMap { row in
                guard let song = QQCatalogSong(row), let id = song.numericID else { return nil }
                return LyricCandidate(
                    source: .qq, key: id, title: song.title,
                    artist: song.artists.map(\.name).joined(separator: " / "),
                    album: song.album, duration: song.duration, hash: song.mid
                )
            }
        case .netease:
            let r = try await online.client.request("/api/cloudsearch/pc",["s":query,"type":"1","limit":"20","offset":String((page-1)*20)])
            items = r["result"]["songs"].array.map { let s = OnlineSong($0); return .init(source:source,key:s.id,title:s.title,artist:s.artist,album:s.album,duration:s.duration,cover:s.cover) }
        case .amll:
            let r = try await community.search(query,page:page)
            items = r.items.map { .init(source:source,key:String($0.id),title:$0.musicNames.first ?? "",artist:$0.artistNames.joined(separator:" / "),album:"",duration:0) }
        case .kugou:
            let r = try await json("https://mobiles.kugou.com/api/v3/search/song",query:["keyword":query,"page":String(page),"pagesize":"20","format":"json"])
            items = r["data"]["info"].array.map { .init(source:source,key:$0["hash"].string,title:$0["songname"].string,artist:$0["singername"].string,album:$0["album_name"].string,duration:Double($0["duration"].int)) }
        }
        return items.map { var c = $0; c.score = Self.score(c,track:track); return c }.sorted { $0.score > $1.score }
    }
    func fetch(_ c:LyricCandidate, online:OnlineSession) async throws -> LyricDocument {
        switch c.source {
        case .amll:
            let r = try await community.get(["id":c.key]); return try LyricsParser.parse(r.lyrics ?? "",format:"ttml")
        case .netease:
            let r = try await online.lyrics(c.key)
            let y = try LyricsParser.parse(r["yrc"]["lyric"].string,format:"yrc")
            return y.wordTimed ? y : try LyricsParser.parse(r["lrc"]["lyric"].string,format:"lrc")
        case .qq:
            let r = try await qqLyrics(c)
            let text = try Self.qrc(r["lyric"].string)
            var doc = try LyricsParser.parse(text,format: text.contains(",") && text.contains("(") ? "qrc" : "lrc")
            for (key,roman) in [("trans",false),("roma",true)] where !r[key].string.isEmpty {
                let text = try Self.qrc(r[key].string)
                let aux = try LyricsParser.parse(text,format:text.contains("(") ? "qrc":"lrc")
                for i in doc.lines.indices { let t = aux.lines.first { abs($0.start-doc.lines[i].start)<0.2 }?.text ?? ""; if roman { doc.lines[i].romanization=t } else { doc.lines[i].translation=t } }
            }
            return doc
        case .kugou:
            let r = try await kugouLyrics("v1/search",fields:["hash":c.key,"duration":String(Int(c.duration*1000)),"keyword":c.artist+" - "+c.title,"lrctxt":"1","man":"no"])
            guard let first = r["candidates"].array.first else { return .init() }
            let d = try await kugouLyrics("download",fields:["id":first["id"].string,"accesskey":first["accesskey"].string,"charset":"utf8","client":"mobi","fmt":"krc","ver":"1"])
            guard let bytes = Data(base64Encoded:d["content"].string) else { throw CocoaError(.fileReadCorruptFile) }
            return try LyricsParser.parse(Self.krc(bytes),format:"krc")
        }
    }
    func amllQQ(_ candidate:LyricCandidate) async throws -> LyricDocument? { try await community.platform("qq",id:candidate.key) }
    static func krc(_ data:Data) throws -> String {
        guard data.starts(with:Data("krc1".utf8)) else { return String(decoding:data,as:UTF8.self) }
        let compressed = KRCCipher.compressedPayload(data)
        return String(decoding: try NeteaseCrypto.gunzip(compressed), as: UTF8.self)
    }
    static func qrc(_ hex:String) throws -> String {
        guard hex.count % 2 == 0, !hex.isEmpty, hex.allSatisfy({ $0.isHexDigit }) else { throw CocoaError(.fileReadCorruptFile) }
        return String(decoding:try NeteaseCrypto.gunzip(QRCCipher.decrypt(Data(hex:hex))),as:UTF8.self)
    }
}
