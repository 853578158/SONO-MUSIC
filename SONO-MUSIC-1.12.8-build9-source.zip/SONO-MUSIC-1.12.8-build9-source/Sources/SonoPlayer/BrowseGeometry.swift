import Foundation
import QuartzCore

struct BrowseMetrics: Equatable {
    let viewport: CGSize
    var count = 30
    var source = "local"
    static let collectionTitleBottom: CGFloat = 108
    static let carouselHeaderOffset: CGFloat = 40
    static let carouselCaptionDepth: CGFloat = 63.6
    var consoleTop: CGFloat { viewport.height - 16 - 64 * scale }
    var categoryCenterY: CGFloat {
        let regular = 152 * scale
        return source.hasPrefix("artist/") ? max(regular, Self.collectionTitleBottom + 8 + 18 * scale) : regular
    }
    var carouselCounterTop: CGFloat {
        centerRect.minY - SonoDesktopTokens.Spacing.s16 - 18
    }
    var carouselCategoryCenterY: CGFloat {
        carouselCounterTop - SonoDesktopTokens.Spacing.s24 - 18 * scale
    }
    var headerBottom: CGFloat {
        let controls = SonoChromeMetrics.topCenterY + SonoChromeMetrics.buttonSize / 2
        if source.hasPrefix("artist/") || source.hasPrefix("search/") {
            return max(controls, categoryCenterY + 18 * scale)
        }
        if source.hasPrefix("daily-recommendations") { return max(controls, categoryCenterY + 22 * scale) }
        if source.hasPrefix("album/") { return max(controls, Self.collectionTitleBottom) }
        return controls
    }
    var wallViewport: CGRect {
        let top = max(88, headerBottom + 8)
        let horizontalInset: CGFloat = 68
        return CGRect(x: horizontalInset, y: top, width: max(0, viewport.width - 2 * horizontalInset),
                      height: max(0, consoleTop - 12 - top))
    }
    var scale: CGFloat { max(0.72, min(1.25, viewport.width / 1440, viewport.height / 900)) }
    var dimensionScale: CGFloat {
        let cellScale = count <= WallTemplates.capacity ? min(scale, (viewport.width - 48) / 864, max(120, viewport.height - 250 * scale) / 576) : scale
        let available = consoleTop - headerBottom - Self.carouselHeaderOffset - Self.carouselCaptionDepth - 20
        return min(cellScale * 163.0 / 161, max(1, available) / 424)
    }
    var gap: CGFloat { 8 * dimensionScale }
    var pitch: CGFloat { 72 * dimensionScale }
    private var carouselHeaderBottom: CGFloat {
        SonoChromeMetrics.topCenterY + SonoChromeMetrics.buttonSize / 2
    }
    var side: CGFloat {
        let available = consoleTop - carouselHeaderBottom - Self.carouselHeaderOffset - Self.carouselCaptionDepth - 20
        return min(424 * scale * 163 / 161, max(1, available))
    }
    var consoleWidth: CGFloat { (side / 2).rounded() * 2 }
    var anchor: CGPoint {
        let top = carouselHeaderBottom + Self.carouselHeaderOffset + 8 + side / 2
        let bottom = consoleTop - Self.carouselCaptionDepth - 12 - side / 2
        // Retain the standard window's optical offset, within the available space.
        let preferred = (top + bottom) / 2 + 16.2223602484472
        let y = min(max(top, preferred), max(top, bottom))
        return CGPoint(x: viewport.width / 2, y: y)
    }
    var centerRect: CGRect { CGRect(x: anchor.x - side / 2, y: anchor.y - side / 2, width: side, height: side) }
    var captionY: CGFloat { centerRect.maxY + 16 + 24 }
}

/// Slot assignment is the mainline algorithm, including UTF-16 FNV-1a hashing.
/// Directory identities remain native; equal identities produce equal assignments.
enum WallAssignment {
    static let version = 2
    // Online sources place the newest songs around the initial resting anchor.
    // Resolve seats once per publication, independently of the current camera.
    private struct OnlineSeat { let slot: Int; let width: CGFloat; let distance: Double }
    @MainActor private static var onlineSeats: [Int: [OnlineSeat]] = [:]
    @MainActor static func online(_ tracks: [LocalTrack], count: Int, identity: String, previous: (tracks: [LocalTrack], slots: [Int])? = nil) -> [Int] {
        guard count > 0 else { return [] }
        let seats: [OnlineSeat]
        if let cached = onlineSeats[count] { seats = cached }
        else {
            let field = WallGeometry(count: count, viewport: CGSize(width: 1440, height: 900))
            let center = field.rect(field.initialIndex), pitch = field.metrics.pitch
            seats = (0..<count).map { slot in
                let rect = field.rect(slot)
                let distance = ((pow(rect.midX - center.midX, 2) + pow(rect.midY - center.midY, 2)) / (pitch * pitch) * 1_000_000).rounded() / 1_000_000
                return OnlineSeat(slot: slot, width: rect.width, distance: Double(distance))
            }.sorted { $0.distance == $1.distance ? $0.slot < $1.slot : $0.distance < $1.distance }
            if onlineSeats.count >= 8, let first = onlineSeats.keys.first { onlineSeats[first] = nil }
            onlineSeats[count] = seats
        }
        var result = previous?.slots ?? Array(repeating: 0, count: count)
        if previous == nil { result[seats[0].slot] = 0 }
        let previousSeats = previous.map { Dictionary(uniqueKeysWithValues: $0.slots.enumerated().map { ($0.element, $0.offset) }) }
        let seatsBySlot = Dictionary(uniqueKeysWithValues: seats.map { ($0.slot, $0) })
        for start in stride(from: 1, to: count, by: 12) {
            let end = min(start + 12, count)
            if let previous, start < previous.tracks.count { continue }
            // Refresh only an unpublished song group in its existing seats.
            // Geometry may have changed since that permutation was saved.
            let group = previousSeats.map { inverse in
                (start..<end).map { seatsBySlot[inverse[$0]!]! }.sorted { $0.distance == $1.distance ? $0.slot < $1.slot : $0.distance < $1.distance }
            } ?? Array(seats[start..<end])
            var order = Array(start..<start + group.count)
            if start + group.count <= tracks.count {
                let seed = identity + ":radial:" + group.map { String($0.slot) }.joined(separator: ",")
                func random(_ kind: String, _ value: String) -> Double { Double(hash(seed + ":" + kind + ":" + value)) / 4294967296 }
                let widths = order.map { titleWidth(tracks[$0].title) }
                var songs: [(index: Int, score: Double)] = []
                for offset in order.indices {
                    let index = order[offset], width = widths[offset]
                    let less: Int = widths.filter { $0 < width }.count
                    let equal: Int = widths.filter { $0 == width }.count
                    let middle: Double = Double(less) + Double(equal - 1) / 2.0
                    let rank: Double = middle / Double(max(1, group.count - 1))
                    let track = tracks[index]
                    let fingerprint: String = json(["netease", track.online?.songID ?? track.id, track.title])
                    let noise: Double = random("song", fingerprint)
                    songs.append((index: index, score: 0.6 * rank + 0.4 * noise))
                }
                songs.sort { a, b in a.score == b.score ? a.index < b.index : a.score > b.score }
                let positions = group.indices.sorted { a, b in
                    if group[a].width != group[b].width { return group[a].width > group[b].width }
                    let ra = random("slot", String(group[a].slot)), rb = random("slot", String(group[b].slot))
                    return ra == rb ? a < b : ra < rb
                }
                for (rank, position) in positions.enumerated() { order[position] = songs[rank].index }
            }
            for (offset, seat) in group.enumerated() { result[seat.slot] = order[offset] }
        }
        return result
    }
    static func json(_ strings: [String]) -> String {
        String(data: try! JSONSerialization.data(withJSONObject: strings, options: [.fragmentsAllowed, .withoutEscapingSlashes]), encoding: .utf8)!
    }
    static func hash(_ value: String) -> UInt32 { value.utf16.reduce(UInt32(2166136261)) { ($0 ^ UInt32($1)) &* 16777619 } }
    private static let pictographic = try! NSRegularExpression(pattern: "\\p{Extended_Pictographic}")
    static func titleWidth(_ title: String) -> Double {
        title.unicodeScalars.reduce(0) { width, char in
            if CharacterSet.nonBaseCharacters.contains(char) || char.value == 0x200d || char.value == 0xfe0f { return width }
            return width + (char.value >= 0x2e80 || pictographic.firstMatch(in: String(char), range: NSRange(location: 0, length: String(char).utf16.count)) != nil ? 1 : "ilI.,'!| :;".unicodeScalars.contains(char) ? 0.3 : "MW@%".unicodeScalars.contains(char) ? 0.85 : 0.55)
        }
    }
    static func indices(_ tracks: [LocalTrack], mediaIDs: [String]? = nil, totalCount: Int? = nil, sourceIdentity: String? = nil) -> [Int] {
        let measurement = BrowseDiagnostics.shared.start(); defer { BrowseDiagnostics.shared.end("geometry.assignment", measurement) }
        let count = tracks.count
        guard count > 0 else { return [] }
        let blocks = ((totalCount ?? count) + WallTemplates.capacity - 1) / WallTemplates.capacity
        let columns = blocks == 1 ? 1 : max(1, Int(sqrt(2.2 * Double(blocks) * Double(WallTemplates.rows) / Double(WallTemplates.columns)).rounded()))
        var result = Array(0..<count)
        for block in 0..<((count + WallTemplates.capacity - 1) / WallTemplates.capacity) {
            let start = block * WallTemplates.capacity
            guard start + WallTemplates.capacity <= count else { continue }
            let seed = String(data: try! JSONSerialization.data(withJSONObject: [sourceIdentity.map { json([$0.components(separatedBy: "|").first ?? "guest", $0.components(separatedBy: "|").last ?? $0]) } ?? json(["local", "local-library"]), 1, block], options: [.withoutEscapingSlashes]), encoding: .utf8)!
            func random(_ kind: String, _ id: String) -> Double { Double(hash(seed + ":" + kind + ":" + id)) / 4294967296 }
            let widths = (0..<WallTemplates.capacity).map { titleWidth(tracks[start + $0].title) }
            var songs: [(index: Int, score: Double)] = []
            for offset in 0..<WallTemplates.capacity {
                let width = widths[offset]
                let less = widths.filter { $0 < width }.count
                let equal = widths.filter { $0 == width }.count
                let rank = (Double(less) + Double(equal - 1) / 2.0) / Double(WallTemplates.capacity - 1)
                let index = start + offset
                let identity = mediaIDs?[index] ?? tracks[index].id
                let noise = random("song", json([tracks[index].online == nil ? "local" : "netease", tracks[index].online?.songID ?? identity, tracks[index].title]))
                songs.append((index, 0.6 * rank + 0.4 * noise))
            }
            songs.sort { $0.score == $1.score ? $0.index < $1.index : $0.score > $1.score }
            let template = WallTemplates.slots(column: block % columns, row: block / columns, expanded: nil)
            let slots = (0..<WallTemplates.capacity).sorted { a, b in
                if template[a].cols != template[b].cols { return template[a].cols > template[b].cols }
                let ra = random("slot", String(a)), rb = random("slot", String(b))
                return ra == rb ? a < b : ra < rb
            }
            for (order, slot) in slots.enumerated() { result[start + slot] = songs[order].index }
        }
        return result
    }
}

final class WallGeometry {
    let count: Int
    let viewport: CGSize
    let expanded: Int?
    let assignment: [Int]?
    let search: Bool
    let source: String
    init(count: Int, viewport: CGSize, expanded: Int? = nil, assignment: [Int]? = nil, search: Bool = false, source: String = "local") {
        BrowseDiagnostics.shared.count("geometry.created")
        self.count = count; self.viewport = viewport; self.expanded = expanded; self.assignment = assignment; self.search = search; self.source = source
    }
    private lazy var inverse: [Int: Int] = Dictionary(uniqueKeysWithValues: (assignment ?? Array(0..<count)).enumerated().map { ($0.element, $0.offset) })
    var metrics: BrowseMetrics { BrowseMetrics(viewport: viewport, count: count, source: source) }
    var blockColumns: Int {
        let blocks = max(1, (count + WallTemplates.capacity - 1) / WallTemplates.capacity)
        return blocks == 1 ? 1 : max(1, Int(sqrt(2.2 * Double(blocks) * Double(WallTemplates.rows) / Double(WallTemplates.columns)).rounded()))
    }
    var blockRows: Int { max(1, ((count + WallTemplates.capacity - 1) / WallTemplates.capacity + blockColumns - 1) / blockColumns) }
    private func slot(_ index: Int) -> Int { inverse[index] ?? index }
    private lazy var restingLayouts: [[WallSlot]] = (0..<((count + WallTemplates.capacity - 1) / WallTemplates.capacity)).map { block in
        let occupied = min(WallTemplates.capacity, count - block * WallTemplates.capacity)
        return occupied == WallTemplates.capacity ? WallTemplates.slots(column: block % blockColumns, row: block / blockColumns, expanded: nil) : WallTemplates.partialSlots(occupied: occupied, expanded: nil)
    }
    private func restingTiles(_ block: Int) -> [WallSlot] { restingLayouts[block] }
    private func tileRect(_ tile: WallSlot, column: Int, row: Int, origin: CGPoint = .zero) -> CGRect {
        CGRect(x: (CGFloat(column * WallTemplates.columns + tile.x) - origin.x) * metrics.pitch,
               y: (CGFloat(row * WallTemplates.rows + tile.y) - origin.y) * metrics.pitch,
               width: CGFloat(tile.cols) * metrics.pitch - metrics.gap, height: CGFloat(tile.rows) * metrics.pitch - metrics.gap)
    }
    private lazy var restingRectangles: [CGRect] = (0..<count).map { index in
        let seat = slot(index), block = seat / WallTemplates.capacity
        return tileRect(restingTiles(block)[seat % WallTemplates.capacity], column: block % blockColumns, row: block / blockColumns)
    }
    private lazy var radial: [(column: Int, row: Int, slot: Int)] = {
        guard search && count > 0 else { return [] }
        let originSlot = WallTemplates.slots(column: 0, row: 0, expanded: nil).first { $0.cols == 4 && $0.rows == 4 }!
        let ox = Double(originSlot.x) + 2, oy = Double(originSlot.y) + 2
        let radius = max(24, sqrt(Double(count) * 8))
        let columns = Int(ceil((radius + Double(WallTemplates.columns)) / Double(WallTemplates.columns))), rows = Int(ceil((radius + Double(WallTemplates.rows)) / Double(WallTemplates.rows)))
        var candidates: [(Int, Int, Int, Double, Double)] = []
        for row in -rows...rows { for column in -columns...columns {
            for (slot, tile) in WallTemplates.slots(column: column, row: row, expanded: nil).enumerated() {
                let x = Double(column * WallTemplates.columns + tile.x) + Double(tile.cols) / 2 - ox
                let y = Double(row * WallTemplates.rows + tile.y) + Double(tile.rows) / 2 - oy
                let distance = hypot(x, y)
                if distance <= radius { candidates.append((column, row, slot, distance, (atan2(x, -y) + .pi * 2).truncatingRemainder(dividingBy: .pi * 2))) }
            }
        } }
        candidates.sort { a, b in
            if a.3 != b.3 { return a.3 < b.3 }; if a.4 != b.4 { return a.4 < b.4 }
            if a.1 != b.1 { return a.1 < b.1 }; if a.0 != b.0 { return a.0 < b.0 }; return a.2 < b.2
        }
        return candidates.prefix(count).map { ($0.0, $0.1, $0.2) }
    }()
    private lazy var expandedSlots: [WallSlot]? = {
        guard let expanded, !search else { return nil }
        let seat = slot(expanded), block = seat / WallTemplates.capacity
        let column = block % blockColumns, row = block / blockColumns, selected = seat % WallTemplates.capacity
        let occupied = min(WallTemplates.capacity, count - block * WallTemplates.capacity)
        if occupied < WallTemplates.capacity {
            var tiles = WallTemplates.partialSlots(occupied: occupied, expanded: selected)
            if count > WallTemplates.capacity {
                let rect = tileRect(tiles[selected], column: column, row: row)
                let desired = CGPoint(x: metrics.anchor.x - rect.midX, y: metrics.anchor.y - rect.midY)
                let camera = clampForExpansion(desired)
                tiles = tiles.map { tile in
                    var tile = tile
                    if abs(desired.x - camera.x) > 0.001 { tile.x = WallTemplates.columns - tile.x - tile.cols }
                    if abs(desired.y - camera.y) > 0.001 { tile.y = WallTemplates.rows - tile.y - tile.rows }
                    return tile
                }
            }
            return tiles
        }
        let tiles = WallTemplates.slots(column: column, row: row, expanded: selected)
        guard count > WallTemplates.capacity else { return tiles }
        let rect = tileRect(tiles[selected], column: column, row: row)
        let desired = CGPoint(x: metrics.anchor.x - rect.midX, y: metrics.anchor.y - rect.midY)
        let camera = clampForExpansion(desired)
        let target = CGPoint(x: CGFloat(tiles[selected].x) + (desired.x - camera.x) / metrics.pitch,
                             y: CGFloat(tiles[selected].y) + (desired.y - camera.y) / metrics.pitch)
        return WallTemplates.slots(column: column, row: row, expanded: selected, targetOrigin: target)
    }()
    private lazy var rectangles: [CGRect] = {
        var layouts: [Block: [WallSlot]] = [:]
        return (0..<count).map { index in
        if search {
            let location = radial[index]
            let center = WallTemplates.slots(column: 0, row: 0, expanded: nil).first { $0.cols == 4 && $0.rows == 4 }!
            let selected = expanded.flatMap { other -> Int? in
                let other = radial[other]
                return other.column == location.column && other.row == location.row ? other.slot : nil
            }
            let key = Block(x: location.column, y: location.row)
            if layouts[key] == nil { layouts[key] = WallTemplates.slots(column: location.column, row: location.row, expanded: selected) }
            let tile = layouts[key]![location.slot]
            return tileRect(tile, column: location.column, row: location.row, origin: CGPoint(x: center.x + 2, y: center.y + 2))
        }
        let seat = slot(index), block = seat / WallTemplates.capacity
        let isSelectedBlock = expanded.map { slot($0) / WallTemplates.capacity == block } ?? false
        let tiles = isSelectedBlock ? expandedSlots! : restingTiles(block)
        return tileRect(tiles[seat % WallTemplates.capacity], column: block % blockColumns, row: block / blockColumns)
        }
    }()
    func rect(_ index: Int) -> CGRect { rectangles[index] }
    lazy var bounds: CGRect = count == 0 ? .zero : rectangles.reduce(CGRect.null) { $0.union($1) }
    lazy var initialIndex: Int = {
        guard count > 0 else { return 0 }
        let source = search ? rectangles : restingRectangles
        let box = source.reduce(CGRect.null) { $0.union($1) }
        let large = 4 * metrics.pitch - metrics.gap
        return source.indices.filter { abs(source[$0].width - large) < 0.001 && abs(source[$0].height - large) < 0.001 }.min {
            hypot(source[$0].midX - box.midX, source[$0].midY - box.midY) < hypot(source[$1].midX - box.midX, source[$1].midY - box.midY)
        } ?? 0
    }()
    func centered(on index: Int) -> CGPoint {
        let rect = rect(index)
        let target = CGPoint(x: metrics.anchor.x - rect.midX, y: metrics.anchor.y - rect.midY)
        return expanded == index ? target : clamp(target)
    }
    func cameraAfterResize(from old: WallGeometry, camera: CGPoint) -> CGPoint {
        let previous = old.metrics
        if let selected = expanded {
            let rect = old.rect(selected).offsetBy(dx: camera.x, dy: camera.y)
            if hypot(rect.midX - previous.anchor.x, rect.midY - previous.anchor.y) < 1 {
                return centered(on: selected)
            }
        }
        let ratio = metrics.pitch / previous.pitch
        return clamp(CGPoint(x: metrics.anchor.x - (previous.anchor.x - camera.x) * ratio,
                             y: metrics.anchor.y - (previous.anchor.y - camera.y) * ratio))
    }

    // Erode the real search-card convex hull by the central reference square,
    // matching searchCamera.ts instead of allowing empty corners of its AABB.
    private lazy var searchRegion: [CGPoint] = {
        guard search, count > 0 else { return [] }
        var points: [CGPoint] = []
        for r in rectangles {
            points.append(CGPoint(x: r.minX, y: r.minY)); points.append(CGPoint(x: r.maxX, y: r.minY))
            points.append(CGPoint(x: r.minX, y: r.maxY)); points.append(CGPoint(x: r.maxX, y: r.maxY))
        }
        points.sort { $0.x == $1.x ? $0.y < $1.y : $0.x < $1.x }
        func chain(_ items: [CGPoint]) -> [CGPoint] {
            var result: [CGPoint] = []
            for p in items {
                while result.count > 1 && Self.cross(result[result.count - 2], result[result.count - 1], p) <= 0 { result.removeLast() }
                result.append(p)
            }
            return Array(result.dropLast())
        }
        let hull = chain(points) + chain(Array(points.reversed()))
        var region = hull
        let half = metrics.side / 2
        for i in hull.indices where !region.isEmpty {
            let a = hull[i], b = hull[(i + 1) % hull.count]
            let inset = half * (abs(b.x - a.x) + abs(b.y - a.y))
            var clipped: [CGPoint] = []
            for j in region.indices {
                let p = region[j], q = region[(j + 1) % region.count]
                let dp = Self.cross(a, b, p) - inset, dq = Self.cross(a, b, q) - inset
                if dp >= 0 { clipped.append(p) }
                if (dp >= 0) != (dq >= 0) {
                    let t = dp / (dp - dq)
                    clipped.append(CGPoint(x: p.x + (q.x - p.x) * t, y: p.y + (q.y - p.y) * t))
                }
            }
            region = clipped
        }
        return region
    }()
    private static func cross(_ a: CGPoint, _ b: CGPoint, _ c: CGPoint) -> CGFloat {
        (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x)
    }
    private var blockCameraRange: CGRect? {
        guard !search, count > WallTemplates.capacity else { return nil }
        let c = metrics.centerRect, p = metrics.pitch, gap = metrics.gap
        let left = blockColumns > 1 ? c.minX - CGFloat(blockColumns - 1) * 12 * p : c.maxX - (12 * p - gap)
        let right = blockColumns > 1 ? c.maxX - (12 * p - gap) : c.minX
        let top = blockRows > 1 ? c.minY - CGFloat(blockRows - 1) * 8 * p : c.maxY - (8 * p - gap)
        let bottom = blockRows > 1 ? c.maxY - (8 * p - gap) : c.minY
        return CGRect(x: left, y: top, width: right - left, height: bottom - top)
    }
    func clamp(_ point: CGPoint, from current: CGPoint? = nil) -> CGPoint {
        guard count > 0 else { return .zero }
        if search {
            // Keep the round wall's diagonal limits while allowing a focused
            // card to start a drag from outside those limits.
            let projected = clampSearch(point)
            if let current, let projected, let start = clampSearch(current) {
                let distance = hypot(point.x - projected.x, point.y - projected.y)
                let allowance = hypot(current.x - start.x, current.y - start.y)
                if distance > allowance, distance > 0 {
                    return CGPoint(x: projected.x + (point.x - projected.x) * allowance / distance,
                                   y: projected.y + (point.y - projected.y) * allowance / distance)
                }
                return point
            }
            if let projected { return projected }
        }
        let frame = metrics.wallViewport
        let content = bounds
        func axis(_ value: CGFloat, _ current: CGFloat?, _ low: CGFloat, _ high: CGFloat) -> CGFloat {
            let lower = low > high ? (low + high) / 2 : low
            let upper = low > high ? lower : high
            return min(max(value, min(lower, current ?? lower)), max(upper, current ?? upper))
        }
        return CGPoint(x: axis(point.x, current?.x, frame.maxX - content.maxX, frame.minX - content.minX),
                       y: axis(point.y, current?.y, frame.maxY - content.maxY, frame.minY - content.minY))
    }

    private func clampSearch(_ point: CGPoint) -> CGPoint? {
        if !searchRegion.isEmpty {
            let p = CGPoint(x: metrics.anchor.x - point.x, y: metrics.anchor.y - point.y)
            let region = searchRegion
            var area: CGFloat = 0
            for i in region.indices { let q = region[(i + 1) % region.count]; area += region[i].x * q.y - region[i].y * q.x }
            if area > 1e-7 && region.indices.allSatisfy({ Self.cross(region[$0], region[($0 + 1) % region.count], p) >= -1e-7 }) { return point }
            var nearest = region[0], best = CGFloat.infinity
            for i in region.indices {
                let a = region[i], b = region[(i + 1) % region.count], dx = b.x - a.x, dy = b.y - a.y
                let length = dx * dx + dy * dy
                let t = max(0, min(1, ((p.x - a.x) * dx + (p.y - a.y) * dy) / (length == 0 ? 1 : length)))
                let candidate = CGPoint(x: a.x + dx * t, y: a.y + dy * t)
                let distance = pow(p.x - candidate.x, 2) + pow(p.y - candidate.y, 2)
                if distance < best { best = distance; nearest = candidate }
            }
            return CGPoint(x: metrics.anchor.x - nearest.x, y: metrics.anchor.y - nearest.y)
        }
        return nil
    }

    private func clampForExpansion(_ point: CGPoint) -> CGPoint {
        guard let range = blockCameraRange else { return point }
        return CGPoint(x: min(max(point.x, range.minX), range.maxX), y: min(max(point.y, range.minY), range.maxY))
    }

    private struct Block: Hashable { let x: Int; let y: Int }
    // Index actual rectangles, including reflowed tiles crossing a template boundary.
    private lazy var spatialBlocks: [Block: [Int]] = {
        var blocks: [Block: [Int]] = [:]
        let width = CGFloat(WallTemplates.columns) * metrics.pitch, height = CGFloat(WallTemplates.rows) * metrics.pitch
        for index in 0..<count {
            let rect = rectangles[index]
            for y in Int(floor(rect.minY / height))...Int(floor(rect.maxY / height)) {
                for x in Int(floor(rect.minX / width))...Int(floor(rect.maxX / width)) {
                    blocks[Block(x: x, y: y), default: []].append(index)
                }
            }
        }
        return blocks
    }()
    func visibleIndices(camera: CGPoint, margin: CGFloat = 32) -> [Int] {
        guard count > 0 else { return [] }
        let visible = CGRect(x: -camera.x, y: -camera.y, width: viewport.width, height: viewport.height).insetBy(dx: -margin, dy: -margin)
        let width = CGFloat(WallTemplates.columns) * metrics.pitch, height = CGFloat(WallTemplates.rows) * metrics.pitch
        var seen: Set<Int> = [], result: [Int] = []
        for y in Int(floor(visible.minY / height))...Int(floor(visible.maxY / height)) {
            for x in Int(floor(visible.minX / width))...Int(floor(visible.maxX / width)) {
                for index in spatialBlocks[Block(x: x, y: y)] ?? [] where seen.insert(index).inserted {
                    if rectangles[index].intersects(visible) { result.append(index) }
                }
            }
        }
        return result
    }
    func nearest(to point: CGPoint) -> Int? {
        guard count > 0 else { return nil }
        return (0..<count).min { hypot(rect($0).midX - point.x, rect($0).midY - point.y) < hypot(rect($1).midX - point.x, rect($1).midY - point.y) }
    }
}

struct CarouselGeometry {
    struct Preparation {
        let metrics: BrowseMetrics
        let spacing: CGFloat
        let radius: Int
        let centerRect: CGRect
        let baseSide: CGFloat
        init(metrics: BrowseMetrics) {
            self.metrics = metrics
            // Reference ratios use a 1.06 center scale. Normalize the unit so
            // the existing native center remains exactly the same size.
            baseSide = metrics.side / 1.06
            spacing = baseSide * 0.38
            radius = Int(ceil((metrics.viewport.width / 2 + metrics.side) / spacing)) + 1
            centerRect = metrics.centerRect
        }
    }
    let count: Int
    let viewport: CGSize
    let position: CGFloat
    let preparation: Preparation
    init(count: Int, viewport: CGSize, position: CGFloat, preparation: Preparation? = nil) {
        self.count = count; self.viewport = viewport; self.position = position
        self.preparation = preparation ?? Preparation(metrics: BrowseMetrics(viewport: viewport, count: count))
    }
    var metrics: BrowseMetrics { preparation.metrics }
    var spacing: CGFloat { preparation.spacing }
    var center: Int { min(max(0, Int(position.rounded())), max(0, count - 1)) }
    var indices: [Int] {
        guard count > 0 else { return [] }
        let radius = preparation.radius
        return Array(max(0, center - radius)..<min(count, center + radius + 1))
    }
    func rect(_ index: Int) -> CGRect {
        let distance = CGFloat(index) - position
        let d = abs(distance)
        let offset = preparation.baseSide * (d <= 1 ? d * 0.70 : 0.70 + (d - 1) * 0.38)
        return preparation.centerRect.offsetBy(dx: (distance < 0 ? -offset : offset), dy: 0)
    }
    func transform(_ index: Int) -> CATransform3D {
        let delta = CGFloat(index) - position, d = abs(delta)
        let referenceScale = d <= 1 ? 1.06 - d * 0.16 : max(0.58, 0.90 - (d - 1) * 0.08)
        var projected = CATransform3DIdentity
        projected.m34 = -0.0009
        projected = CATransform3DRotate(projected, -min(1, max(-1, delta)) * 1.02, 0, 1, 0)
        projected = CATransform3DScale(projected, referenceScale / 1.06, referenceScale / 1.06, 1)
        // Keep the perspective silhouette, but flatten each card's projected
        // surface. Distance sorting then orders whole cards without 3D slices
        // intersecting when the incoming card takes the front.
        projected.m13 = 0; projected.m23 = 0; projected.m31 = 0; projected.m32 = 0
        projected.m33 = 1; projected.m34 = 0; projected.m43 = 0
        return projected
    }
    func depth(_ index: Int) -> CGFloat { 1000 - abs(CGFloat(index) - position) * 100 }
    func clamped(_ value: CGFloat) -> CGFloat { min(max(0, value), CGFloat(max(0, count - 1))) }
    func opacity(_ index: Int) -> Float {
        return abs(rect(index).midX - metrics.anchor.x) < viewport.width / 2 + preparation.baseSide / 2 ? 1 : 0
    }
    func brightness(_ index: Int) -> Float {
        let d = abs(CGFloat(index) - position)
        var value = min(1, max(0.55, 1 - (d - 1) * 0.05))
        let visible = CGRect(origin: .zero, size: viewport)
        let x = abs(rect(index).midX - visible.midX)
        let edgeInset = 80 * visible.width / viewport.width
        let start = visible.width / 2 - edgeInset, end = visible.width / 2 + preparation.baseSide / 2
        if x > start {
            let fade = min(1, max(0, (end - x) / (end - start)))
            value *= fade * fade
        }

        return Float(value)
    }
}
