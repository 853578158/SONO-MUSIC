import AppKit
import SwiftUI

/// Sono reconstruction defaults; screenshot geometry is normalized to row height.
/// Springs and deletion timing are authored values, not recovered Music constants. Units: pt, s.
struct QueueRowMotion {
    enum Mode { case closed, dragging, settling, open, deleting, removed }
    var width: Double
    var cover: Double
    var rowHeight: Double
    var x = 0.0, v = 0.0, side = 0.0, anchor = 0.0
    var mode: Mode = .closed
    var buttonX = 0.0, buttonV = 0.0, buttonTarget = 0.0
    var buttonRevealed = false, reverse = false
    var iconTravel = 0.0
    var pinLineElapsed: Double?
    var elapsed = 0.0, raw = 0.0
    private var kind = "close"
    private var start = 0.0, startSide = 0.0, delta = 0.0, lastInput = 0.0
    private var samples: [(Double, Double)] = []
    private var deleteStart = 0.0
    static let rowInset: Double = 14
    static let moreIconSize: CGFloat = 20
    static let leadingOverflow: CGFloat = 0
    static let chromeLeadingMargin: CGFloat = 8
    static let chromeCornerRadius = SonoDesktopTokens.Radius.small
    var distance: Double { cover + Self.rowInset }
    var edgeGap: Double { Self.rowInset }
    var deleteCapsuleFrame: CGRect {
        // Keep the same gap to the moving row, even while the capsule stretches.
        let leading = side > 0 ? Self.chromeLeadingMargin : 0
        let capsuleWidth = min(max(0, width - leading), max(0, x * side - edgeGap))
        return CGRect(x: side <= 0 ? width - capsuleWidth : leading, y: (rowHeight - cover) / 2,
                      width: capsuleWidth, height: cover)
    }
    var deletionThreshold: Double { width * 0.7 }
    var buttonAnimating: Bool { buttonRevealed && (abs(buttonX - buttonTarget) > 0.003 || abs(buttonV) > 0.02) }
    var iconTarget: Double { !reverse && (mode == .deleting || mode == .dragging && raw >= deletionThreshold * 0.8) ? 1 : 0 }
    var animating: Bool { pinLineElapsed != nil || mode == .settling || mode == .deleting || buttonAnimating || abs(iconTravel-iconTarget) > 0.001 }
    mutating func syncButton() {
        let amount = max(0, x * side)
        let visible = !reverse && (mode == .open || mode == .deleting || (mode == .settling && anchor != 0) || amount >= edgeGap + cover * 0.5)
        buttonTarget = visible ? 1 : 0
        if visible && !buttonRevealed { buttonX = 0; buttonV = 0; buttonRevealed = true }
    }
    mutating func begin(_ time: Double) -> Bool {
        guard mode != .deleting && mode != .removed else { return false }
        start = x; startSide = anchor == 0 ? 0 : (anchor > 0 ? 1 : -1)
        side = startSide; delta = 0; lastInput = time
        mode = .dragging; reverse = false; v = 0; samples = [(time, x)]; raw = abs(x)
        return true
    }
    mutating func update(_ dx: Double, at time: Double) {
        guard mode == .dragging else { return }
        delta += dx * 0.6; lastInput = time
        if side == 0 && abs(delta) >= 1 { side = delta > 0 ? 1 : -1 }
        if startSide != 0 && delta * startSide < -2 { reverse = true }
        // delta already includes the 0.6 gain; reversing therefore follows at 0.3.
        x = reverse ? start + delta * 0.5 : side * max(0, (start + delta) * side)
        raw = abs(x); syncButton(); samples.append((time, x))
        while samples.count > 2 && time - samples[0].0 > 0.07 { samples.removeFirst() }
        v = velocity
    }
    private var velocity: Double {
        guard let a = samples.first, let b = samples.last, b.0 > a.0 else { return 0 }
        return max(-12000, min(12000, (b.1 - a.1) / (b.0 - a.0)))
    }
    mutating func end(_ time: Double) {
        guard mode == .dragging else { return }
        if !reverse && raw >= deletionThreshold { commit(); return }
        let opened = !reverse && raw >= edgeGap + cover * 0.5
        anchor = opened ? side * distance : 0
        kind = !opened ? "close" : raw > distance ? "stretch" : "open"
        v = (time - lastInput > 0.09 ? 0 : velocity) * 1.15
        if !opened && v * side > 0 { v = 0 }
        mode = .settling; elapsed = 0; samples = []; syncButton()
    }
    mutating func commit() {
        guard mode != .deleting && mode != .removed else { return }
        if side == 0 { side = -1 }
        mode = .deleting; deleteStart = x; elapsed = 0; v = 0; anchor = 0
    }
    mutating func close() {
        guard mode != .removed && mode != .deleting else { return }
        anchor = 0; mode = .settling; kind = "close"; v = 0; elapsed = 0
    }
    mutating func reveal() {
        guard mode != .deleting && mode != .removed else { return }
        reverse = false; side = -1; anchor = -distance; kind = "open"; mode = .settling; elapsed = 0; v = 0; syncButton()
    }
    static func integrate(_ x: inout Double, _ v: inout Double, target: Double, k: Double, c: Double, dt: Double) {
        var rest = min(dt, 0.05)
        while rest > 0 {
            let h = min(rest, 1.0 / 360)
            func acceleration(_ p: Double, _ velocity: Double) -> Double { -k * (p - target) - c * velocity }
            let k1x = v, k1v = acceleration(x, v)
            let k2x = v + k1v * h / 2, k2v = acceleration(x + k1x * h / 2, v + k1v * h / 2)
            let k3x = v + k2v * h / 2, k3v = acceleration(x + k2x * h / 2, v + k2v * h / 2)
            let k4x = v + k3v * h, k4v = acceleration(x + k3x * h, v + k3v * h)
            x += h * (k1x + 2 * k2x + 2 * k3x + k4x) / 6
            v += h * (k1v + 2 * k2v + 2 * k3v + k4v) / 6
            rest -= h
        }
    }
    static func ease(_ t: Double) -> Double { 1 - pow(1 - min(1, max(0, t)), 3) }
    mutating func advance(_ dt: Double) {
        if let time = pinLineElapsed { pinLineElapsed = time + dt >= 0.8 ? nil : time + dt }
        elapsed += dt; syncButton()
        let step = max(0,dt) / 0.15
        iconTravel += max(-step,min(step,iconTarget-iconTravel))
        if buttonRevealed {
            Self.integrate(&buttonX, &buttonV, target: buttonTarget, k: 420, c: 24, dt: dt)
            if !buttonAnimating { buttonX = buttonTarget; buttonV = 0; if buttonTarget == 0 { buttonRevealed = false } }
        }
        if mode == .settling {
            let k = kind == "open" ? 300.0 : kind == "stretch" ? 170 : 280
            let c = kind == "open" ? 23.0 : kind == "stretch" ? 19 : 24
            Self.integrate(&x, &v, target: anchor, k: k, c: c, dt: dt)
            if abs(x) > width + 100 { x = (x > 0 ? 1 : -1) * (width + 100); if v * x > 0 { v = 0 } }
            if (abs(x - anchor) < 0.12 && abs(v) < 1 && (!buttonRevealed || abs(buttonX - buttonTarget) < 0.004)) || elapsed > 8 {
                x = anchor; v = 0; buttonX = buttonTarget; mode = anchor == 0 ? .closed : .open
                if anchor == 0 { side = 0 }
            }
        }
        if mode == .deleting {
            let exitDistance = width + edgeGap
            x = side * (abs(deleteStart) + (exitDistance - abs(deleteStart)) * Self.ease(elapsed / 0.15))
            if elapsed >= 0.8 { mode = .removed }
        }
    }
    var height: Double { mode == .deleting || mode == .removed ? max(1, rowHeight * (1 - Self.ease((elapsed - 0.35) / 0.25))) : rowHeight }
    var opacity: Double { mode == .deleting || mode == .removed ? 1 - Self.ease((elapsed - 0.25) / 0.1) : 1 }
    static func boundaryOpacity(_ time: Double) -> Double {
        time < 0.6 ? min(1, time / 0.035) : 1 - Self.ease((time - 0.6) / 0.2)
    }
    var lineOpacity: Double {
        if let time = pinLineElapsed { return Self.boundaryOpacity(time) }
        return mode == .deleting || mode == .removed ? Self.boundaryOpacity(elapsed) : 0
    }

}

@MainActor
final class QueueSwipeDriver: NSObject, ObservableObject {
    @Published var motion = QueueRowMotion(width: 300, cover: 44, rowHeight: 72)
    var remove: () -> Void = {}
    var moveToFront: () -> Void = {}
    var onBegin: () -> Void = {}
    var feedback: () -> Void = { NSHapticFeedbackManager.defaultPerformer.perform(.alignment, performanceTime: .now) }
    var reduced = false
    private var link: CADisplayLink?
    private var lastFrame = 0.0
    private(set) var gesture = false
    private var feedbackSent = false
    private var removalDelivered = false
    weak var view: NSView?
    func wake() {
        if reduced {
            while motion.animating { motion.advance(1.0 / 60) }
            deliverRemoval(); return
        }
        guard link == nil, let view else { return }
        lastFrame = CACurrentMediaTime()
        let display = view.displayLink(target: self, selector: #selector(frame(_:)))
        link = display; display.add(to: .main, forMode: .common)
    }
    @objc private func frame(_ display: CADisplayLink) {
        motion.advance(max(0, min(0.035, display.targetTimestamp - lastFrame))); lastFrame = display.targetTimestamp
        if motion.mode == .removed { stop(); deliverRemoval() }
        else if !motion.animating { display.invalidate(); link = nil }
    }
    private func deliverRemoval() {
        if motion.mode == .removed && !removalDelivered {
            removalDelivered = true
            remove()
        }
    }
    func begin(at time: Double = CACurrentMediaTime()) {
        guard !gesture, motion.begin(time) else { return }
        gesture = true; feedbackSent = false; onBegin()
    }
    func update(_ delta: Double, at time: Double = CACurrentMediaTime()) {
        guard gesture else { return }
        motion.update(delta, at: time)
        if !feedbackSent && !motion.reverse && motion.raw >= motion.deletionThreshold * 0.8 {
            feedbackSent = true; feedback()
        }
        wake()
    }
    func commit() {
        guard motion.mode != .deleting && motion.mode != .removed else { return }
        if !feedbackSent { feedbackSent = true; feedback() }
        gesture = false
        if motion.side > 0 {
            motion.close()
            motion.pinLineElapsed = 0
            moveToFront()
        } else { motion.commit() }
        wake()
    }
    func stop() { link?.invalidate(); link = nil; gesture = false }
    func close() { guard motion.mode != .closed else { return }; stop(); motion.close(); wake() }
    func reset() {
        if motion.mode == .deleting && !removalDelivered { remove(); removalDelivered = true }
        stop()
        motion = QueueRowMotion(width:motion.width,cover:motion.cover,rowHeight:motion.rowHeight)
        removalDelivered = false; feedbackSent = false
    }
    func end(cancelled: Bool = false, at time: Double = CACurrentMediaTime()) {
        if gesture {
            if cancelled { motion.close() }
            else if motion.side > 0 && !motion.reverse && motion.raw >= motion.deletionThreshold { commit() }
            else { motion.end(time) }
        }
        gesture = false; wake()
    }
}

/// One monitor per visible queue: a gesture keeps its initial row even when the pointer moves.
@MainActor final class QueueInputCoordinator: ObservableObject {
    fileprivate var rows: [ObjectIdentifier: QueueWheelView] = [:]
    weak var decoration: QueueDecorationView?
    private var monitor: Any?
    private weak var target: QueueSwipeDriver?
    private var accumulated = CGPoint.zero
    private var vertical = false
    private var horizontal = false
    private var ignoreMomentum = false
    private var swallowMouseUp = false
    private var fallback: Task<Void, Never>?
    private var suppressUntil = 0.0
    var swiping: Bool { horizontal || rows.values.contains { $0.driver?.gesture == true } }
    var canClick: Bool { !swiping && CACurrentMediaTime() >= suppressUntil }
    func suppressClicks() { suppressUntil = CACurrentMediaTime() + 0.18 }
    func performFeedback() {
        guard rows.values.contains(where: { $0.window?.isKeyWindow == true && !$0.isHiddenOrHasHiddenAncestor }) else { return }
        NSHapticFeedbackManager.defaultPerformer.perform(.alignment, performanceTime:.now)
    }
    func register(_ row: QueueWheelView) { rows[ObjectIdentifier(row)] = row }
    func unregister(_ row: QueueWheelView) { rows.removeValue(forKey:ObjectIdentifier(row)) }
    func setActive(_ active: Bool) {
        if !active { cancel(); if let monitor { NSEvent.removeMonitor(monitor) }; monitor = nil; return }
        guard monitor == nil else { return }
        monitor = NSEvent.addLocalMonitorForEvents(matching:[.scrollWheel,.leftMouseDown,.leftMouseUp,.rightMouseDown]) { [weak self] event in
            let consumed = MainActor.assumeIsolated { self.map { $0.handle(event) == nil } ?? false }
            return consumed ? nil : event
        }
    }
    func began(_ driver: QueueSwipeDriver) {
        for row in rows.values where row.driver !== driver { row.driver?.close() }
        suppressClicks()
    }
    @discardableResult func closeOpenRows() -> Bool {
        let open = rows.values.contains { $0.driver.map { $0.motion.mode != .closed } == true }
        for row in rows.values { row.driver?.close() }
        return open
    }
    func cancel() {
        fallback?.cancel(); fallback = nil; target?.end(cancelled:true); target = nil
        accumulated = .zero; vertical = false; horizontal = false; ignoreMomentum = false
        for row in rows.values { row.driver?.reset() }
    }
    private func row(at event: NSEvent) -> QueueWheelView? {
        rows.values.first { row in
            guard row.window === event.window, !row.isHiddenOrHasHiddenAncestor,
                  row.visibleRect.intersection(row.contentBounds).contains(row.convert(event.locationInWindow, from: nil)),
                  let root = row.window?.contentView,
                  let hit = root.hitTest(root.convert(root.convert(event.locationInWindow, from: nil), to: root.superview)) else { return false }
            return hit === row || hit.isDescendant(of: row) || row.isDescendant(of: hit)
        }
    }
    func showMenu(for id: UUID) {
        guard canClick, let row = rows.values.first(where: { $0.rowID == id }) else { return }
        Task { @MainActor [weak row] in row?.showMenu() }
    }
    private func handle(_ event: NSEvent) -> NSEvent? {
        let row = row(at:event)
        let controlClick = event.type == .leftMouseDown && event.modifierFlags.contains(.control)
        if event.type == .rightMouseDown || controlClick {
            if canClick, let row, row.showMenu(event: event) {
                return nil
            }
            return event
        }
        if event.type == .leftMouseUp, swallowMouseUp { swallowMouseUp = false; return nil }
        if event.type == .leftMouseDown {
            if event.clickCount == 2, canClick, let row, row.showMenu(event: event) {
                swallowMouseUp = true
                return nil
            }
            for item in rows.values where item !== row { item.driver?.close() }
            if let row, let driver = row.driver, driver.motion.mode == .open {
                let x = row.convert(event.locationInWindow, from: nil).x - row.contentBounds.minX, m = driver.motion
                let action = m.side < 0 ? x > m.width - m.distance : x < m.distance
                if !action { driver.close(); suppressClicks(); swallowMouseUp = true; return nil }
            }
            return event
        }
        if event.type != .scrollWheel { return event }
        return scroll(dx:event.scrollingDeltaX,dy:event.scrollingDeltaY,phase:event.phase,momentum:event.momentumPhase,start:row?.driver) ? nil : event
    }
    @discardableResult func scroll(dx: Double, dy: Double, phase: NSEvent.Phase, momentum: NSEvent.Phase = [], start: QueueSwipeDriver? = nil) -> Bool {
        if phase.contains(.began) {
            target?.end(cancelled:true); target = start
            accumulated = .zero; vertical = false; horizontal = false; ignoreMomentum = false
        }
        // Momentum belongs to scrolling, never to deletion distance or release decisions.
        if !momentum.isEmpty {
            if ignoreMomentum { if momentum.contains(.ended) || momentum.contains(.cancelled) { ignoreMomentum = false }; return true }
            return false
        }
        if target == nil && phase.isEmpty {
            target = start; accumulated = .zero; vertical = false; horizontal = false; ignoreMomentum = false
        }
        guard let driver = target else { return false }
        if phase.contains(.cancelled) { driver.end(cancelled:true); target = nil; horizontal = false; return false }
        if phase.contains(.ended) {
            let consumed = horizontal
            if horizontal { if dx != 0 { driver.update(dx) }; driver.end(); suppressClicks() }
            horizontal = false; target = nil; ignoreMomentum = consumed
            return consumed
        }
        if vertical { return false }
        accumulated.x += dx; accumulated.y += dy
        if !horizontal {
            if abs(accumulated.y) >= 7 && abs(accumulated.y) > abs(accumulated.x) * 1.25 { vertical = true; return false }
            guard abs(accumulated.x) >= 7 && abs(accumulated.x) > abs(accumulated.y) * 1.25 else { return false }
            horizontal = true; driver.begin(); driver.update(Double(accumulated.x))
        } else { driver.update(Double(dx)) }
        fallback?.cancel()
        // Only phase-less wheel events need an idle fallback. Real touches end on phase.ended.
        if phase.isEmpty {
            fallback = Task { @MainActor [weak self, weak driver] in
                do { try await Task.sleep(for:.milliseconds(180)) } catch { return }
                driver?.end(); self?.suppressClicks(); self?.target = nil; self?.horizontal = false
            }
        }
        return true
    }
}

struct QueueWheelSurface: NSViewRepresentable {
    let id: UUID
    let driver: QueueSwipeDriver?
    let input: QueueInputCoordinator
    let menu: () -> NSMenu?
    func makeNSView(context: Context) -> QueueWheelView {
        let view = QueueWheelView()
        view.input = input; input.register(view)
        return view
    }
    func updateNSView(_ view: QueueWheelView, context: Context) {
        view.rowID = id; view.driver = driver; driver?.view = view; view.makeMenu = menu
    }
    static func dismantleNSView(_ view: QueueWheelView, coordinator: ()) { view.input?.unregister(view); view.driver?.stop() }
}
final class QueueWheelView: NSView {
    weak var driver: QueueSwipeDriver?
    weak var input: QueueInputCoordinator?
    var rowID: UUID?
    var makeMenu: () -> NSMenu? = { nil }
    fileprivate var menuOpen = false
    var contentBounds: CGRect {
        CGRect(x: bounds.minX + QueueRowMotion.leadingOverflow, y: bounds.minY,
               width: max(0, bounds.width - QueueRowMotion.leadingOverflow), height: bounds.height)
    }

    @discardableResult func showMenu(event: NSEvent? = nil) -> Bool {
        guard let window, let menu = makeMenu() else { return false }
        let anchor = convert(NSPoint(x: bounds.maxX - 14, y: bounds.midY), to: nil)
        guard let trigger = event ?? NSEvent.mouseEvent(with: .rightMouseDown, location: anchor,
            modifierFlags: [], timestamp: ProcessInfo.processInfo.systemUptime, windowNumber: window.windowNumber,
            context: nil, eventNumber: 0, clickCount: 1, pressure: 1) else { return false }
        menuOpen = true
        input?.decoration?.needsDisplay = true
        window.displayIfNeeded()
        defer { menuOpen = false; input?.decoration?.needsDisplay = true }
        NSMenu.popUpContextMenu(menu, with: trigger, for: self)
        return true
    }
    override func hitTest(_ point: NSPoint) -> NSView? { nil }
}

struct QueueSwipeRow<Content: View>: View {
    var id: UUID
    var protected: Bool
    var scale: CGFloat
    var input: QueueInputCoordinator
    var remove: () -> Void
    var moveToFront: () -> Void
    var menu: () -> NSMenu?
    @ViewBuilder var content: () -> Content
    @Environment(\.accessibilityReduceMotion) private var reduced
    @StateObject private var driver = QueueSwipeDriver()
    var body: some View {
        GeometryReader { geometry in
            let m = driver.motion
            let side = m.side == 0 ? -1 : m.side
            let amount = max(0, m.x * side)
            let reverse = m.reverse && (m.mode == .dragging || m.mode == .settling)
            let protectedOpen = !reverse && (m.mode == .open || m.mode == .deleting || m.mode == .settling && m.anchor != 0 || m.mode == .dragging && m.buttonRevealed)
            let inset = protectedOpen ? min(m.distance, max(0, amount)) : 0
            ZStack(alignment: .topLeading) {
                content().padding(.horizontal, QueueRowMotion.chromeLeadingMargin).disabled(m.mode == .dragging || m.mode == .settling || m.mode == .deleting || m.mode == .removed).frame(height: 72 * scale).offset(x: m.x).opacity(m.opacity)
                    .mask { Rectangle().padding(.leading, side > 0 ? inset : 0).padding(.trailing, side < 0 ? inset : 0) }
                if !protected && m.buttonRevealed && m.buttonX > 0.001 {
                    let frame = m.deleteCapsuleFrame
                    let buttonScale = max(0, m.buttonX)
                    Button { driver.commit() } label: {
                        Image(systemName: side > 0 ? "arrow.up.to.line" : "xmark")
                            .font(.system(size: SonoDesktopTokens.SymbolSize.compact)).foregroundStyle(Color(nsColor: SonoGeneratedColors.artworkControlSurface)).sonoIconFrame(SonoDesktopTokens.IconFrame.s20)
                            .offset(x: side * max(0, (frame.width - m.cover) / 2) * m.iconTravel)
                            .frame(width: frame.width, height: frame.height)
                            .background(Color(nsColor: side > 0 ? SonoGeneratedColors.queuePin : SonoGeneratedColors.queueDelete), in: Capsule())
                    }.scaleEffect(x: min(1, buttonScale), y: buttonScale,
                                  anchor: .center)
                        .opacity(m.opacity * min(1, buttonScale))
                        .offset(x: frame.minX, y: frame.minY)
                        .accessibilityLabel(side > 0 ? "置顶到待播第一位" : "删除此条记录").disabled(reverse || m.mode == .deleting)
                }
            }.contentShape(Rectangle())
                .onAppear { driver.remove = remove; driver.moveToFront = moveToFront; driver.feedback = { [weak coordinator = input] in coordinator?.performFeedback() }; driver.onBegin = { [weak coordinator = input, weak rowDriver = driver] in if let rowDriver { coordinator?.began(rowDriver) } }; driver.reduced = reduced; driver.motion.width = geometry.size.width; driver.motion.cover = 44 * scale; driver.motion.rowHeight = 72 * scale }
                .onChange(of: geometry.size.width) { _, width in driver.reset(); driver.motion.width = width }
        }.frame(height: driver.motion.height * (driver.motion.rowHeight == 72 * scale ? 1 : scale))
            .clipped()
            .overlay { QueueWheelSurface(id: id, driver: protected ? nil : driver, input: input, menu: menu) }
            .onChange(of: scale) { _, value in driver.reset(); driver.motion.cover = 44 * value; driver.motion.rowHeight = 72 * value }
            .onChange(of: protected) { _, value in if value { driver.reset() } }
            .onChange(of: reduced) { _, value in driver.reduced = value; if value { driver.wake() } }
            .onDisappear { driver.stop() }
    }
}

@MainActor
final class QueueDragClock: NSObject, ObservableObject {
    var tick: (Double) -> Void = { _ in }
    private var last = 0.0
    weak var view: NSView?
    private var link: CADisplayLink?
    func start() {
        guard link == nil, let view else { return }
        let next = view.displayLink(target: self, selector: #selector(frame(_:)))
        last = CACurrentMediaTime(); link = next; next.add(to: .main, forMode: .common)
    }
    func stop() { link?.invalidate(); link = nil }
    @objc private func frame(_ display: CADisplayLink) { let dt = max(0,min(0.05,display.targetTimestamp-last)); last = display.targetTimestamp; tick(dt) }
}
struct QueueDragClockSurface: NSViewRepresentable {
    let clock: QueueDragClock
    func makeNSView(context: Context) -> NSView { let view = NSView(); clock.view = view; return view }
    func updateNSView(_ view: NSView, context: Context) { clock.view = view }
    static func dismantleNSView(_ view: NSView, coordinator: ()) { }
}

struct QueueDecorationSurface: NSViewRepresentable {
    @Environment(\.sonoTheme) private var theme
    let input: QueueInputCoordinator
    let divider: NSColor
    var selectionForeground: NSColor? = nil
    var suppressedDividerID: UUID?
    func makeNSView(context: Context) -> QueueDecorationView {
        let view = QueueDecorationView(); view.input = input; input.decoration = view
        return view
    }
    func updateNSView(_ view: QueueDecorationView, context: Context) {
        view.divider = divider
        view.accent = selectionForeground ?? theme.accent
        view.suppressedDividerID = suppressedDividerID
        view.needsDisplay = true
    }
}

final class QueueDecorationView: NSView {
    private struct RowDecoration: Equatable {
        let rect: CGRect
        let menuOpen: Bool
        let lineOpacity: Double
        let pinLine: Bool
    }

    weak var input: QueueInputCoordinator?
    var divider = NSColor.separatorColor
    var accent = SonoTheme.pink.accent
    var suppressedDividerID: UUID?
    private var link: CADisplayLink?
    private var lastGeometry: [ObjectIdentifier: RowDecoration] = [:]
    private var geometry: [ObjectIdentifier: RowDecoration] = [:]
    override var isFlipped: Bool { true }
    override func hitTest(_ point: NSPoint) -> NSView? { nil }
    override func viewDidMoveToWindow() {
        super.viewDidMoveToWindow()
        link?.invalidate(); link = nil
        if window != nil {
            let next = displayLink(target: self, selector: #selector(refresh))
            next.add(to: .main, forMode: .common); link = next
        }
    }
    @objc private func refresh() {
        guard let input, !isHiddenOrHasHiddenAncestor else { return }
        geometry.removeAll(keepingCapacity: true)
        for (id, row) in input.rows where row.window === window && !row.isHiddenOrHasHiddenAncestor {
            let motion = row.driver?.motion
            geometry[id] = RowDecoration(rect: convert(row.bounds, from: row), menuOpen: row.menuOpen,
                                         lineOpacity: motion?.lineOpacity ?? 0, pinLine: motion?.pinLineElapsed != nil)
        }
        if geometry != lastGeometry {
            swap(&geometry, &lastGeometry)
            needsDisplay = true
        }
    }
    override func draw(_ dirtyRect: NSRect) {
        guard let input else { return }
        NSBezierPath(rect: bounds).addClip()
        let rows = input.rows.values.filter { $0.window === window && !$0.isHiddenOrHasHiddenAncestor }.map { row in
            (row, convert(row.bounds, from: row))
        }.sorted { $0.1.minY < $1.1.minY }
        let active = rows.filter { $0.0.menuOpen || ($0.0.driver?.motion.lineOpacity ?? 0) > 0 }
        func line(_ rect: CGRect, _ y: CGFloat, _ color: NSColor) {
            color.setFill()
            NSRect(x: rect.minX + 8, y: y - 0.5, width: max(0, rect.width - 16), height: 1).fill()
        }
        for (row, rect) in rows where rect.intersects(bounds) {
            if let suppressedDividerID, row.rowID == suppressedDividerID { continue }
            let hidden = active.contains { abs($0.1.minY - rect.maxY) < 1 || abs($0.1.maxY - rect.maxY) < 1 }
            if !hidden { line(rect, rect.maxY, divider) }
        }
        for (row, rect) in active where rect.intersects(bounds) {
            if row.menuOpen {
                accent.setStroke()
                // Keep the full 2pt stroke inside the row's outer boundary.
                let width = SonoDesktopTokens.Border.selection
                let radius = SonoDesktopTokens.Radius.small - width / 2
                let path = NSBezierPath(roundedRect: rect.insetBy(dx: width / 2, dy: width / 2), xRadius: radius, yRadius: radius)
                path.lineWidth = width; path.stroke()
            } else if let motion = row.driver?.motion {
                let color = (motion.pinLineElapsed != nil ? SonoGeneratedColors.queuePin : SonoGeneratedColors.deleteLine).withAlphaComponent(motion.lineOpacity)
                line(rect, rect.minY, color); line(rect, rect.maxY, color)
            }
        }
    }
}
