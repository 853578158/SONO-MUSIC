import AVFoundation
import MediaToolbox
import Accelerate
import Synchronization

/// The audio callback owns all DSP buffers. It publishes epoch-tagged numbers;
/// disabling analysis makes even an in-flight old callback invisible immediately.
final class PlaybackAnalysis: @unchecked Sendable {
    private let enabled = Atomic<Bool>(false)
    private let generation = Atomic<UInt32>(0)
    let samples = Atomic<Int>(0)
    private let low = Atomic<UInt64>(0), mid = Atomic<UInt64>(0), high = Atomic<UInt64>(0), total = Atomic<UInt64>(0)
    private var sampleRate = 44100.0, usable = false, cursor = 0, epoch:UInt32 = 0
    private let count = 1024
    private let normalization:Float
    private let input = UnsafeMutablePointer<Float>.allocate(capacity:1024)
    private let imaginary = UnsafeMutablePointer<Float>.allocate(capacity:1024)
    private let realOutput = UnsafeMutablePointer<Float>.allocate(capacity:1024)
    private let imaginaryOutput = UnsafeMutablePointer<Float>.allocate(capacity:1024)
    private let window = UnsafeMutablePointer<Float>.allocate(capacity:1024)
    private let transform:vDSP_DFT_Setup?
    init() {
        input.initialize(repeating:0,count:1024); imaginary.initialize(repeating:0,count:1024)
        realOutput.initialize(repeating:0,count:1024); imaginaryOutput.initialize(repeating:0,count:1024)
        window.initialize(repeating:0,count:1024); vDSP_hann_window(window,1024,Int32(vDSP_HANN_NORM))
        var windowPower:Float = 0
        vDSP_svesq(window,1,&windowPower,1024)
        normalization = sqrt(1024*windowPower)
        transform = vDSP_DFT_zop_CreateSetup(nil,1024,.FORWARD)
    }
    deinit {
        if let transform { vDSP_DFT_DestroySetup(transform) }
        input.deallocate(); imaginary.deallocate(); realOutput.deallocate(); imaginaryOutput.deallocate(); window.deallocate()
    }
    func setEnabled(_ value:Bool) {
        if enabled.exchange(value,ordering:.relaxed) != value { generation.wrappingAdd(1,ordering:.relaxed) }
    }
    var spectrum:SIMD4<Float> {
        guard enabled.load(ordering:.relaxed) else { return .zero }
        let current = generation.load(ordering:.relaxed)
        func decode(_ value:UInt64) -> Float { UInt32(truncatingIfNeeded:value >> 32) == current ? Float(bitPattern:UInt32(truncatingIfNeeded:value)) : 0 }
        return SIMD4(decode(low.load(ordering:.relaxed)),decode(mid.load(ordering:.relaxed)),decode(high.load(ordering:.relaxed)),decode(total.load(ordering:.relaxed)))
    }
    var energy:Float { spectrum.w }
    func prepare(_ format:AudioStreamBasicDescription) {
        usable = format.mFormatID == kAudioFormatLinearPCM && format.mFormatFlags & kAudioFormatFlagIsFloat != 0 && format.mBitsPerChannel == 32 && format.mSampleRate > 0
        sampleRate = format.mSampleRate; cursor = 0
    }
    func consume(_ buffers:UnsafeMutablePointer<AudioBufferList>,frames:Int) {
        guard usable, enabled.load(ordering:.relaxed), let transform else { return }
        let current = generation.load(ordering:.relaxed)
        if epoch != current { cursor = 0; epoch = current }
        let list = UnsafeMutableAudioBufferListPointer(buffers)
        var available = frames, channels = 0
        for buffer in list {
            guard buffer.mData != nil, buffer.mNumberChannels > 0 else { return }
            available = min(available,Int(buffer.mDataByteSize)/MemoryLayout<Float>.stride/Int(buffer.mNumberChannels))
            channels += Int(buffer.mNumberChannels)
        }
        guard channels > 0 else { return }
        for frame in 0..<available {
            var value:Float = 0
            for buffer in list {
                let channelCount = Int(buffer.mNumberChannels), values = buffer.mData!.assumingMemoryBound(to:Float.self)
                for channel in 0..<channelCount { value += values[frame*channelCount+channel] }
            }
            input[cursor] = value/Float(channels)*window[cursor]; cursor += 1
            if cursor == count {
                vDSP_DFT_Execute(transform,input,imaginary,realOutput,imaginaryOutput)
                var power = SIMD4<Float>.zero
                for bin in 1..<count/2 {
                    let frequency = Double(bin)*sampleRate/Double(count)
                    let p = realOutput[bin]*realOutput[bin]+imaginaryOutput[bin]*imaginaryOutput[bin]
                    power.w += p
                    if frequency >= 20 && frequency < 300 { power.x += p }
                    else if frequency < 3500 { power.y += p }
                    else if frequency <= 24000 { power.z += p }
                }
                // Sono input adapter: Hann-windowed band RMS → bounded visual
                // amplitude. Apple's averagePower units are deliberately not reused.
                // Only the positive-frequency half is summed. Parseval's
                // factor of two recovers band RMS; the former 4x gain clipped
                // mastered music to 1 and erased most beat-to-beat variation.
                let adapted = SIMD4<Float>(min(1,sqrt(2*power.x)/normalization),min(1,sqrt(2*power.y)/normalization),min(1,sqrt(2*power.z)/normalization),min(1,sqrt(2*power.w)/normalization))
                let tag = UInt64(current)<<32
                low.store(tag|UInt64(adapted.x.bitPattern),ordering:.relaxed); mid.store(tag|UInt64(adapted.y.bitPattern),ordering:.relaxed)
                high.store(tag|UInt64(adapted.z.bitPattern),ordering:.relaxed); total.store(tag|UInt64(adapted.w.bitPattern),ordering:.relaxed)
                samples.wrappingAdd(count,ordering:.relaxed); cursor = 0
            }
        }
    }
    func makeTap() throws -> MTAudioProcessingTap {
        var callbacks = MTAudioProcessingTapCallbacks(version:kMTAudioProcessingTapCallbacksVersion_0,clientInfo:Unmanaged.passRetained(self).toOpaque(),init:{ _, info, storage in storage.pointee = info },finalize:{ tap in Unmanaged<PlaybackAnalysis>.fromOpaque(MTAudioProcessingTapGetStorage(tap)).release() },prepare:{ tap, _, format in
            Unmanaged<PlaybackAnalysis>.fromOpaque(MTAudioProcessingTapGetStorage(tap)).takeUnretainedValue().prepare(format.pointee)
        },unprepare:nil,process:{ tap, frames, _, buffers, framesOut, flagsOut in
            var range = CMTimeRange.invalid
            let status = MTAudioProcessingTapGetSourceAudio(tap,frames,buffers,flagsOut,&range,framesOut)
            if status == noErr { Unmanaged<PlaybackAnalysis>.fromOpaque(MTAudioProcessingTapGetStorage(tap)).takeUnretainedValue().consume(buffers,frames:Int(framesOut.pointee)) }
        })
        var tap:MTAudioProcessingTap?
        let status = MTAudioProcessingTapCreate(kCFAllocatorDefault,&callbacks,kMTAudioProcessingTapCreationFlag_PreEffects,&tap)
        guard status == noErr, let tap else { Unmanaged<PlaybackAnalysis>.fromOpaque(callbacks.clientInfo!).release(); throw NSError(domain:NSOSStatusErrorDomain,code:Int(status)) }
        return tap
    }
}
