import Foundation
import Combine
import AppKit

enum BrowserLayout: String, CaseIterable { case wall, carousel }
enum BrowseIntent { case root, push, catalog, replace }

struct BrowserLocation {
    var source = "local"
    var isSearchDetail = false
    var searchGlobal = true
    var globalDraft = ""
    var query = ""
    var submittedQuery = ""
    var anchor: String?
    var expanded: String?
    var camera = CGPoint.zero
    var centerOnReturn = false
    var capturedLayout: BrowserLayout = .wall
    var positioned = false
}

@MainActor
final class BrowseTrackData {
    let tracks: [LocalTrack]
    let ids: [String]
    let index: [String: Int]
    let assignment: [Int]
    init(_ tracks: [LocalTrack], assignment: [Int]? = nil) {
        self.assignment = assignment ?? WallAssignment.indices(tracks)
        self.tracks = tracks; ids = tracks.map(\.id)
        index = Dictionary(ids.enumerated().map { ($0.element, $0.offset) }, uniquingKeysWith: { first, _ in first })
    }
}

@MainActor
final class MusicBrowser: ObservableObject {
    @Published var quickListQuery = ""
    @Published var carouselPositionBubbleVisible = false
    @Published var quickListOpen = false
    var quickSelectionRevision = 0
    var onQuickListExit: (() -> Void)?
    var quickListCenter: String?
    func enterQuickList() {
        guard layout == .carousel else { return }
        location = capture(); quickListCenter = location.anchor
        onInteraction?(); quickListOpen = true
    }
    func dismissQuickList() { quickListOpen = false; quickListQuery = ""; quickSelectionRevision += 1 }
    private var dataContext = ""
    var sourceOwner = "local"
    private var trackData: BrowseTrackData?
    private var assignmentOrder: [String] = []
    private var assignments: [String: (count: Int, tracks: [LocalTrack], slots: [Int])] = [:]
    private var cachedGeometry: WallGeometry?
    private var filterInput: [LocalTrack] = []
    private var filterQuery: String?
    private var filterResult: [LocalTrack] = []
    func data(for tracks: [LocalTrack]) -> BrowseTrackData {
        let context = "\(sourceOwner)|\(sourceKey)|\(max(tracks.count, sourceTotal))"
        if let trackData, trackData.tracks == tracks, dataContext == context { return trackData }
        dataContext = context
        let count = max(tracks.count, sourceTotal)
        let cacheKey = sourceOwner + "|" + sourceKey
        let previous = assignments[cacheKey]
        let online = sourceKey != "local" && !roundWall
        // Once an online song has a seat, refreshing its title/album/cover does
        // not move it or resize unrelated cards. New/reordered IDs still rebuild.
        let stable = previous?.count == count && zip(previous?.tracks ?? [], tracks).allSatisfy { $0.id == $1.id && (online || $0.title == $1.title) }
        let rawID = String(sourceKey.split(separator: "/").dropFirst().joined(separator: "/"))
        let collectionID = sourceKey.hasPrefix("artist/") ? "artist:" + rawID : rawID
        let identity = WallAssignment.json([sourceOwner, collectionID])
        var slots: [Int]
        if online, stable, let previous, previous.tracks.count == tracks.count {
            // Reuse the entire permutation, including its initial seat. Mixing
            // a new resting seat with old groups can duplicate a song after a
            // layout change restores an assignment from disk.
            slots = previous.slots
        } else if online {
            slots = WallAssignment.online(tracks, count: count, identity: identity, previous: stable ? previous.map { ($0.tracks, $0.slots) } : nil)
        } else {
            slots = WallAssignment.indices(tracks)
            if stable, let previous {
                for index in 0..<min(slots.count, ((previous.slots.count + WallTemplates.capacity - 1) / WallTemplates.capacity) * WallTemplates.capacity) { slots[index] = index < previous.slots.count ? previous.slots[index] : index }
            }
        }
        if !roundWall {
            assignments[cacheKey] = (count, tracks, slots)
            assignmentOrder.removeAll { $0 == cacheKey }; assignmentOrder.append(cacheKey)
            if assignmentOrder.count > 8 { assignments[assignmentOrder.removeFirst()] = nil }
        }
        if BrowseDiagnostics.shared.enabled, let previous {
            BrowseDiagnostics.shared.mark("geometry.dataChange", fields: [
                "sameIDs": String(previous.tracks.map(\.id) == tracks.map(\.id)),
                "changedTitles": String(zip(previous.tracks, tracks).filter { $0.title != $1.title }.count),
                "changedCovers": String(zip(previous.tracks, tracks).filter { $0.coverURL != $1.coverURL }.count),
                "sameAssignment": String(previous.slots == slots)])
        }
        if trackData?.assignment != slots { cachedGeometry = nil }
        let data = BrowseTrackData(tracks, assignment: slots); trackData = data
        return data
    }
    private var itemData: BrowseItemData?
    private var itemDataContext = ""
    func data(items: [BrowseItem]) -> BrowseItemData {
        let context = "\(sourceOwner)|\(sourceKey)|\(sourceTotal)"
        if let itemData, itemData.tracks == items, itemDataContext == context { return itemData }
        itemDataContext = context
        let songs = items.compactMap(\.song)
        let assignment = songs.count == items.count ? data(for: songs).assignment : Array(items.indices)
        let result = BrowseItemData(items, assignment: assignment)
        itemData = result
        return result
    }
    func geometry(items: [BrowseItem], viewport: CGSize, expanded: Int? = nil) -> WallGeometry {
        let songs = items.compactMap(\.song)
        if songs.count == items.count { return geometry(tracks: songs, viewport: viewport, expanded: expanded) }
        return WallGeometry(count: items.count, viewport: viewport, expanded: expanded, assignment: Array(items.indices), search: true, source: sourceKey)
    }
    func prepare(items: [BrowseItem], viewport: CGSize) {
        let songs = items.compactMap(\.song)
        if songs.count == items.count { prepare(tracks: songs, viewport: viewport); return }
        let previousViewport = sceneViewport
        sceneViewport = viewport
        guard !items.isEmpty, viewport.width > 0, viewport.height > 0 else { return }
        var next = location
        if !items.contains(where: { $0.id == next.anchor }) { next.anchor = items.first?.id; next.expanded = next.anchor }
        if next.centerOnReturn || !next.positioned {
            let expanded = items.firstIndex { $0.id == next.expanded }
            next.camera = geometry(items: items, viewport: viewport, expanded: expanded).centered(on: items.firstIndex { $0.id == next.anchor } ?? 0)
            next.centerOnReturn = false; next.positioned = true
        } else if previousViewport != viewport, previousViewport.width > 0, previousViewport.height > 0 {
            let expanded = items.firstIndex { $0.id == next.expanded }
            let old = geometry(items: items, viewport: previousViewport, expanded: expanded)
            let field = geometry(items: items, viewport: viewport, expanded: expanded)
            next.camera = field.cameraAfterResize(from: old, camera: next.camera)
        }
        if next.anchor != location.anchor || next.expanded != location.expanded || next.camera != location.camera || next.positioned != location.positioned || next.centerOnReturn != location.centerOnReturn { location = next }
    }
    func expand(_ id: String, items: [BrowseItem], viewport: CGSize) {
        guard let index = items.firstIndex(where: { $0.id == id }) else { return }
        onInteraction?()
        location.anchor = id; location.expanded = id; location.positioned = true
        location.camera = geometry(items: items, viewport: viewport, expanded: index).centered(on: index)
    }
    func restoreAssignment(_ slots: [Int]?, tracks: [LocalTrack], count: Int) {
        let key = sourceOwner + "|" + sourceKey
        guard assignments[key] == nil, let slots, slots.count == max(count, tracks.count), Set(slots).count == slots.count,
              slots.enumerated().allSatisfy({ $0.element >= 0 && $0.element < max(count, tracks.count) }) else { return }
        assignments[key] = (count, tracks, slots); trackData = nil
    }
    private var sceneTracks: [LocalTrack] = []
    private var sceneViewport = CGSize.zero
    var preloadViewport: CGSize { sceneViewport.width > 0 ? sceneViewport : CGSize(width: 1440, height: 900) }
    @Published var location = BrowserLocation()
    #if SONO_RELEASE_CANDIDATE
    @Published private var preferredLayout = BrowserLayout(rawValue: PerformanceEnvironment.defaults.string(forKey: "browserLayout") ?? "") ?? .carousel
    #else
    @Published private var preferredLayout = BrowserLayout(rawValue: PerformanceEnvironment.defaults.string(forKey: "browserLayout") ?? "") ?? .wall
    #endif
    private func requiresCarousel(_ source: String) -> Bool {
        source.hasPrefix("search/") || source.hasPrefix("artist/") || source.hasPrefix("album/") || source.hasPrefix("daily-recommendations")
    }
    var carouselOnly: Bool { requiresCarousel(sourceKey) }
    var layout: BrowserLayout { carouselOnly ? .carousel : preferredLayout }
    @Published private(set) var backStack: [BrowserLocation] = []
    @Published private(set) var focusRevision: UInt64 = 0
    var afterFocus: (id: String, action: () -> Void)?
    func finishFocus(_ id: String) {
        guard let pending = afterFocus, pending.id == id else { return }
        afterFocus = nil
        pending.action()
    }
    var onInteraction: (() -> Void)?
    var startupRecoverySource: String?
    var sourceKey: String { location.source }
    @Published private(set) var visit: UInt64 = 0
    var sourceTotal = 0
    var sourceOrderedIDs: [String] = []
    var sourceOrdinals: [String: Int] = [:]
    var roundWall: Bool { searching || sourceKey.hasPrefix("search/") || sourceKey.hasPrefix("album/") }
    var captureView: (() -> BrowserLocation)?
    var onRestoreSource: ((String) -> Void)?
    private var sourceLocations: [String: BrowserLocation] = [:]
    private func capture() -> BrowserLocation {
        if quickListOpen {
            var snapshot = location
            snapshot.anchor = quickListCenter ?? snapshot.anchor; snapshot.expanded = snapshot.anchor
            snapshot.capturedLayout = .carousel; snapshot.positioned = true
            return snapshot
        }
        var snapshot = captureView?() ?? location
        snapshot.capturedLayout = layout
        return snapshot
    }
    private func remember() {
        let snapshot = capture()
        // Filter pages have their own return entry; they must not overwrite the root view.
        if snapshot.submittedQuery.isEmpty { sourceLocations[sourceKey] = snapshot }
    }
    func switchSource(_ key: String, intent: BrowseIntent = .replace, focus: String? = nil, fromSearchSuggestion: Bool = false) {
        afterFocus = nil
        let leaving = capture()
        remember()
        quickListOpen = false
        if intent == .root { backStack = [] }
        else if key != sourceKey && (intent == .push || intent == .catalog) {
            if intent == .catalog, let ancestor = backStack.lastIndex(where: { $0.source == key && $0.submittedQuery.isEmpty }) {
                backStack = Array(backStack.prefix(ancestor))
            } else { backStack.append(leaving) }
        }
        let searchDetail = CapsuleSourceSelection.isSearchDetail(key, fromSearch: intent != .root &&
            (fromSearchSuggestion || leaving.isSearchDetail || leaving.source.hasPrefix("search/")))
        if key == sourceKey {
            if location.isSearchDetail != searchDetail { location.isSearchDetail = searchDetail }
            if let focus { location.anchor = focus; location.expanded = focus; location.centerOnReturn = true }
            return
        }
        var next = sourceLocations[key] ?? BrowserLocation(source: key)
        next.isSearchDetail = searchDetail
        let destinationLayout: BrowserLayout = requiresCarousel(key) ? .carousel : preferredLayout
        next.centerOnReturn = next.positioned && next.capturedLayout != destinationLayout
        if let focus { next.anchor = focus; next.expanded = focus; next.centerOnReturn = true }
        trackData = nil; itemData = nil; cachedGeometry = nil
        location = next; visit &+= 1
        onInteraction?()
    }
    func clearOnlineLocations() {
        assignments = assignments.filter { $0.key == "local|local" }
        sourceLocations = sourceLocations.filter { $0.key == "local" }
        backStack = backStack.filter { $0.source == "local" }
        if sourceKey != "local" { location = sourceLocations["local"] ?? BrowserLocation(); visit &+= 1 }
    }
    var hasSearchTrail: Bool { searching || sourceKey.hasPrefix("search/") || backStack.contains { !$0.submittedQuery.isEmpty || $0.source.hasPrefix("search/") } }
    var searching: Bool { !location.submittedQuery.isEmpty }
    func editDraft(_ value: String, in tracks: [LocalTrack]) {
        location.query = value
    }
    func search(_ query: String, in tracks: [LocalTrack]) {
        let submitted = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !submitted.isEmpty else { clearSearch(in: tracks); return }
        guard submitted != location.submittedQuery else { return }
        onInteraction?()
        if !searching { backStack.append(capture()); remember() }
        quickListOpen = false
        location = BrowserLocation(source: sourceKey, isSearchDetail: location.isSearchDetail, searchGlobal: false, query: query, submittedQuery: submitted)
        visit &+= 1; onRestoreSource?(sourceKey)
        reconcile(tracks); prepare(tracks: filtered(tracks), viewport: sceneViewport)
    }
    func clearSearch(in tracks: [LocalTrack]) {
        if searching { back() }
        location.query = ""; location.submittedQuery = ""
        onInteraction?(); reconcile(tracks); prepare(tracks: filtered(tracks), viewport: sceneViewport)
    }
    func back() {
        quickListOpen = false
        guard var previous = backStack.popLast() else { return }
        remember(); onInteraction?()
        let destinationLayout: BrowserLayout = requiresCarousel(previous.source) ? .carousel : preferredLayout
        previous.centerOnReturn = previous.positioned && previous.capturedLayout != destinationLayout
        location = previous; visit &+= 1
        onRestoreSource?(previous.source)
    }
    func setLayout(_ value: BrowserLayout) {
        guard !carouselOnly, value != layout else { return }
        // Capture the displayed camera/center before changing the layout's coordinate system.
        location = capture()
        quickListOpen = false
        if value == .carousel && location.expanded == nil, !sceneTracks.isEmpty {
            let field = geometry(tracks: sceneTracks, viewport: sceneViewport)
            let point = CGPoint(x: field.metrics.anchor.x - location.camera.x, y: field.metrics.anchor.y - location.camera.y)
            if let nearest = field.nearest(to: point) { location.anchor = sceneTracks[nearest].id }
        }
        location.expanded = location.anchor; location.centerOnReturn = true
        preferredLayout = value
        prepare(tracks: sceneTracks, viewport: sceneViewport)
        PerformanceEnvironment.defaults.set(value.rawValue, forKey: "browserLayout")
    }
    func filtered(_ tracks: [LocalTrack]) -> [LocalTrack] {
        let measurement = BrowseDiagnostics.shared.start(); defer { BrowseDiagnostics.shared.end("data.filter", measurement) }
        let query = location.submittedQuery
        guard !query.isEmpty else { return tracks }
        if filterQuery == query && filterInput == tracks { return filterResult }
        let terms = query.precomposedStringWithCompatibilityMapping.lowercased()
            .split(whereSeparator: { $0.isWhitespace }).map(String.init)
        let result = tracks.filter {
            let text = ($0.title + " " + $0.artist).precomposedStringWithCompatibilityMapping.lowercased()
            return terms.allSatisfy { text.contains($0) }
        }
        filterInput = tracks; filterQuery = query; filterResult = result
        return result
    }
    func geometry(tracks: [LocalTrack], viewport: CGSize, expanded: Int? = nil) -> WallGeometry {
        let data = data(for: tracks)
        if let cachedGeometry, cachedGeometry.count == (roundWall ? tracks.count : max(tracks.count, sourceTotal)), cachedGeometry.viewport == viewport, cachedGeometry.source == sourceKey, cachedGeometry.expanded == expanded, cachedGeometry.search == roundWall { return cachedGeometry }
        let geometry = WallGeometry(count: roundWall ? tracks.count : max(tracks.count, sourceTotal), viewport: viewport, expanded: expanded, assignment: searching ? nil : data.assignment, search: roundWall, source: sourceKey)
        cachedGeometry = geometry
        return geometry
    }
    func reconcile(_ tracks: [LocalTrack]) {
        let visible = filtered(tracks)
        if !visible.contains(where: { $0.id == location.anchor }) && !(layout == .carousel && !searching && location.anchor.map { sourceOrdinals[$0] != nil } == true) { location.anchor = nil; location.centerOnReturn = true }
        if !visible.contains(where: { $0.id == location.expanded }) && !(layout == .carousel && !searching && location.expanded.map { sourceOrdinals[$0] != nil } == true) { location.expanded = nil }
    }
    func prepare(tracks: [LocalTrack], viewport: CGSize) {
        let previousViewport = sceneViewport
        sceneTracks = tracks; sceneViewport = viewport
        guard !tracks.isEmpty, viewport.width > 0, viewport.height > 0 else { return }
        let previousSeatCount = trackData?.assignment.count
        let data = data(for: tracks)
        var next = location
        if let previousSeatCount, previousSeatCount != data.assignment.count { next.centerOnReturn = true }
        if next.anchor.flatMap({ data.index[$0] }) == nil && !(layout == .carousel && !searching && next.anchor.map { sourceOrdinals[$0] != nil } == true) {
            let initial = layout == .wall && !roundWall && !sourceKey.hasPrefix("artist/") ? geometry(tracks: tracks, viewport: viewport).initialIndex : 0
            next.anchor = tracks.indices.contains(initial) ? tracks[initial].id : nil
            if layout == .carousel || roundWall || sourceKey.hasPrefix("artist/") { next.expanded = next.anchor }
        }
        if let expanded = next.expanded, data.index[expanded] == nil && !(layout == .carousel && !searching && sourceOrdinals[expanded] != nil) { next.expanded = next.anchor }
        let resized = previousViewport != viewport && previousViewport.width > 0 && previousViewport.height > 0
        if resized && next.positioned && !next.centerOnReturn {
            let expanded = next.expanded.flatMap { data.index[$0] }
            let old = geometry(tracks: tracks, viewport: previousViewport, expanded: expanded)
            let field = geometry(tracks: tracks, viewport: viewport, expanded: expanded)
            next.camera = field.cameraAfterResize(from: old, camera: next.camera)
        }
        if next.centerOnReturn || !next.positioned {
            let selected = next.anchor.flatMap { data.index[$0] } ?? geometry(tracks: tracks, viewport: viewport).initialIndex
            let expanded = next.expanded.flatMap { data.index[$0] }
            next.camera = geometry(tracks: tracks, viewport: viewport, expanded: expanded).centered(on: selected)
            next.centerOnReturn = false; next.positioned = true
        }
        if next.anchor != location.anchor || next.camera != location.camera || next.positioned != location.positioned || next.centerOnReturn != location.centerOnReturn { location = next }
    }
    func expand(_ id: String, tracks: [LocalTrack], viewport: CGSize, userInitiated: Bool = true) {
        guard let index = tracks.firstIndex(where: { $0.id == id }) else { return }
        if userInitiated { onInteraction?() }
        var next = location
        next.anchor = id; next.expanded = id; next.positioned = true
        next.camera = geometry(tracks: tracks, viewport: viewport, expanded: index).centered(on: index)
        location = next
    }
    @discardableResult
    func follow(_ track: LocalTrack, allTracks: [LocalTrack], locate: Bool) -> Bool {
        if locate && searching { clearSearch(in: allTracks) }
        let visible = filtered(allTracks)
        guard let index = visible.firstIndex(where: { $0.id == track.id }) else { return false }
        location.anchor = track.id; location.expanded = track.id; location.positioned = true
        location.camera = geometry(tracks: visible, viewport: sceneViewport, expanded: index).centered(on: index)
        if locate { focusRevision &+= 1 }
        return true
    }
    func collapse() {
        onInteraction?()
        var next = location
        next.expanded = nil
        next.camera = geometry(tracks: sceneTracks, viewport: sceneViewport).clamp(next.camera)
        location = next
    }
    func pan(to camera: CGPoint, tracks: [LocalTrack], viewport: CGSize) {
        let expanded = location.expanded.flatMap { data(for: tracks).index[$0] }
        pan(to: camera, field: geometry(tracks: tracks, viewport: viewport, expanded: expanded))
    }
    func pan(to camera: CGPoint, field: WallGeometry) {
        let measurement = BrowseDiagnostics.shared.start(); defer { BrowseDiagnostics.shared.end("input.wallPan", measurement) }
        onInteraction?()
        // Dragging the camera does not collapse the selected card or its reflow.
        var next = location
        next.camera = field.clamp(camera, from: next.camera); next.positioned = true
        if next.camera != location.camera || !location.positioned { location = next }
    }
}

// Shared by presentation capture and the camera animation's cubic timing curve.
// Bisection evaluates the curve in time space, independent of the frame rate.
enum BrowseCameraMotion {
    static func progress(_ input: Double) -> Double {
        let p = min(1, max(0, input))
        if p == 0 || p == 1 { return p }
        func cubic(_ t: Double, _ a: Double, _ b: Double) -> Double { 3 * (1 - t) * (1 - t) * t * a + 3 * (1 - t) * t * t * b + t * t * t }
        var low = 0.0, high = 1.0
        for _ in 0..<14 { let t = (low + high) / 2; if cubic(t, 0.22, 0.24) < p { low = t } else { high = t } }
        return cubic((low + high) / 2, 0.8, 1)
    }
}
