import Foundation
import CommonCrypto
import CryptoKit
import Security
import zlib

// Protocol translated from api-enhanced's MIT implementation; see licenses/.
enum NeteaseCrypto {
    static let eapiKey = Data("e82ckenh8dichen8".utf8)
    static let staticKey = Data(hex: "ab1d5a430f6bb04a3f01e81ddd72bd916d5ce591248ac128714806d7f8fb1b84")
    static let signingKey = "mUHCwVNWJbunMqAHf5MImuirT6plvs6VSFW62MGHstFQxhBGdEoIhLItH3djc4+FB/OKty3+lL2rGeoFBpVe5g=="
    static func random(_ count: Int) throws -> Data {
        var data = Data(count: count)
        guard data.withUnsafeMutableBytes({ SecRandomCopyBytes(kSecRandomDefault, count, $0.baseAddress!) }) == errSecSuccess else { throw OnlineError.protocolFailure("随机数生成失败") }
        return data
    }
    static func aes(_ data: Data, key: Data, iv: Data? = nil, decrypt: Bool = false) throws -> Data {
        var output = Data(count: data.count + kCCBlockSizeAES128)
        let capacity = output.count
        var written = 0
        let status = output.withUnsafeMutableBytes { destination in
            data.withUnsafeBytes { source in key.withUnsafeBytes { keyBytes in
                if let iv {
                    return iv.withUnsafeBytes { ivBytes in
                        CCCrypt(CCOperation(decrypt ? kCCDecrypt : kCCEncrypt), CCAlgorithm(kCCAlgorithmAES), CCOptions(kCCOptionPKCS7Padding), keyBytes.baseAddress, key.count, ivBytes.baseAddress, source.baseAddress, data.count, destination.baseAddress, capacity, &written)
                    }
                }
                return CCCrypt(CCOperation(decrypt ? kCCDecrypt : kCCEncrypt), CCAlgorithm(kCCAlgorithmAES), CCOptions(kCCOptionPKCS7Padding | kCCOptionECBMode), keyBytes.baseAddress, key.count, nil, source.baseAddress, data.count, destination.baseAddress, capacity, &written)
            } }
        }
        guard status == kCCSuccess else { throw OnlineError.protocolFailure("AES 加解密失败") }
        return output.prefix(written)
    }
    static func json(_ data: [String: Any]) throws -> Data { try JSONSerialization.data(withJSONObject: data, options: [.sortedKeys, .withoutEscapingSlashes]) }
    static func eapi(path: String, data: [String: Any]) throws -> [String: String] {
        let text = String(decoding: try json(data), as: UTF8.self)
        let digest = Insecure.MD5.hash(data: Data("nobody\(path)use\(text)md5forencrypt".utf8)).map { String(format: "%02x", $0) }.joined()
        return ["params": try aes(Data("\(path)-36cd479b6b5-\(text)-36cd479b6b5-\(digest)".utf8), key: eapiKey).hex.uppercased()]
    }
    static func weapi(_ data: [String: Any]) throws -> [String: String] {
        let alphabet = Array("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".utf8)
        let secret = Data(try random(16).map { alphabet[Int($0) % alphabet.count] })
        let iv = Data("0102030405060708".utf8)
        let first = try aes(json(data), key: Data("0CoJUm6Qyw8W8jud".utf8), iv: iv).base64EncodedString()
        let params = try aes(Data(first.utf8), key: secret, iv: iv).base64EncodedString()
        let spki = Data(base64Encoded: "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDgtQn2JZ34ZC28NWYpAUd98iZ37BUrX/aKzmFbt7clFSs6sXqHauqKWqdtLkF2KexO40H1YTX8z2lSgBBOAxLsvaklV8k4cBFK9snQXE9/DDaFt6Rr7iVZMldczhC0JNgTz+SHXT6CBHuX3e9SdB1Ua44oncaTWz7OBGLbCiK45wIDAQAB")!
        var error: Unmanaged<CFError>?
        guard let key = SecKeyCreateWithData(spki.dropFirst(22) as CFData, [kSecAttrKeyType: kSecAttrKeyTypeRSA, kSecAttrKeyClass: kSecAttrKeyClassPublic] as CFDictionary, &error),
              let encrypted = SecKeyCreateEncryptedData(key, .rsaEncryptionRaw, (Data(count: 112) + secret.reversed()) as CFData, &error) else { throw OnlineError.protocolFailure("RSA 加密失败") }
        return ["params": params, "encSecKey": (encrypted as Data).hex]
    }
    static func signature(_ timestamp: String, nonce: String) -> String {
        Data(HMAC<SHA256>.authenticationCode(for: Data((timestamp + nonce).utf8), using: SymmetricKey(data: Data(signingKey.utf8)))).base64EncodedString()
    }
    static func xeapi(path: String, data: [String: String], publicKey: OnlineJSON, deviceID: String) throws -> [String: String] {
        guard let peer = Data(base64Encoded: publicKey["publicKey"].string), peer.count == 32 else { throw OnlineError.protocolFailure("音源公钥无效") }
        let privateKey = Curve25519.KeyAgreement.PrivateKey()
        let ephemeral = privateKey.publicKey.rawRepresentation
        let shared = try privateKey.sharedSecretFromKeyAgreement(with: .init(rawRepresentation: peer))
        let prk = shared.withUnsafeBytes { Data(HMAC<SHA256>.authenticationCode(for: Data($0), using: SymmetricKey(data: Data(count: 32)))) }
        let derived = Data(HMAC<SHA256>.authenticationCode(for: ephemeral + Data([1]), using: SymmetricKey(data: prk))).prefix(16)
        let dynamic = try random(16)
        let sealed = try AES.GCM.seal(Data("\(dynamic.base64EncodedString())|android|\(publicKey["sk"].string)".utf8), using: SymmetricKey(data: derived))
        let s = ephemeral + Data(sealed.nonce) + sealed.ciphertext + sealed.tag
        let plaintext = try json(["body": Data(form(data).utf8).base64EncodedString(), "queryString": "e_r=true"])
        let inner = try aes(plaintext, key: staticKey)
        let mask = try random(16)
        let xored = Data(inner.enumerated().map { $0.element ^ mask[$0.offset & 15] })
        let base64 = Data(xored.base64EncodedString().utf8)
        let rotation = Int(mask[0] & 15) % base64.count
        let transformed = mask + base64.dropFirst(rotation) + base64.prefix(rotation)
        return ["B": try aes(transformed, key: dynamic).base64EncodedString(), "S": s.base64EncodedString(),
                "R": try aes(Data((publicKey["version"].string + "|").utf8), key: staticKey).base64EncodedString()]
    }
    static func decodeResponse(_ data: Data) throws -> OnlineJSON {
        if let json = try? OnlineJSON(data: data) { return json }
        do {
            let decrypted = try aes(data, key: eapiKey, decrypt: true)
            return try OnlineJSON(data: decrypted.starts(with: [0x1f, 0x8b]) ? gunzip(decrypted) : decrypted)
        } catch { throw OnlineError.protocolFailure("网易云响应格式无效，请稍后重试") }
    }
    static func gunzip(_ data: Data) throws -> Data {
        var stream = z_stream()
        guard inflateInit2_(&stream, 15 + 32, ZLIB_VERSION, Int32(MemoryLayout<z_stream>.size)) == Z_OK else { throw OnlineError.protocolFailure("压缩响应无效") }
        defer { inflateEnd(&stream) }
        return try data.withUnsafeBytes { input in
            stream.next_in = UnsafeMutablePointer(mutating: input.bindMemory(to: Bytef.self).baseAddress!)
            stream.avail_in = uInt(data.count)
            var result = Data()
            var status: Int32 = Z_OK
            repeat {
                var chunk = [UInt8](repeating: 0, count: 32768)
                status = chunk.withUnsafeMutableBufferPointer { buffer in
                    stream.next_out = buffer.baseAddress; stream.avail_out = uInt(buffer.count)
                    return inflate(&stream, Z_NO_FLUSH)
                }
                guard status == Z_OK || status == Z_STREAM_END else { throw OnlineError.protocolFailure("解压响应失败") }
                result.append(contentsOf: chunk.prefix(32768 - Int(stream.avail_out)))
                guard result.count <= 32 * 1024 * 1024 else { throw OnlineError.protocolFailure("响应过大") }
            } while status != Z_STREAM_END
            return result
        }
    }
    static func form(_ values: [String: String]) -> String {
        let allowed = CharacterSet(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789*-._")
        func escape(_ text: String) -> String { text.addingPercentEncoding(withAllowedCharacters: allowed)!.replacingOccurrences(of: "%20", with: "+") }
        return values.sorted { $0.key < $1.key }.map { escape($0.key) + "=" + escape($0.value) }.joined(separator: "&")
    }
}

extension Data {
    init(hex: String) { self.init(stride(from: 0, to: hex.count, by: 2).map { offset in let start = hex.index(hex.startIndex, offsetBy: offset); return UInt8(hex[start..<hex.index(start, offsetBy: 2)], radix: 16)! }) }
    var hex: String { map { String(format: "%02x", $0) }.joined() }
}
