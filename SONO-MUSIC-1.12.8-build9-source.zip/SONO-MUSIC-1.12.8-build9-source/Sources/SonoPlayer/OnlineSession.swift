import AppKit
import Combine
import CoreImage.CIFilterBuiltins
import Foundation

struct OnlineArtist: Identifiable, Codable, Sendable, Equatable { let id: String; let name: String }

struct SearchSuggestion: Identifiable, Equatable, Sendable {
    enum Kind: String, Sendable { case keyword, artist, album, song }
    let id: String
    let kind: Kind
    let name: String
    var detail: String = ""
    var artwork: URL? = nil
    var destination: OnlinePageKind? = nil
}

enum OnlinePlatform: String, Codable, Sendable {
    case netease, qq
}

struct OnlineTrackInfo: Codable, Sendable, Equatable {
    let songID: String
    let albumID: String
    let artistID: String
    var unavailableReason: String? = nil
    var artists: [OnlineArtist]?
    var storedPlatform: OnlinePlatform? = nil
    var numericSongID: String? = nil
    var mediaMID: String? = nil
    var qqRequiresMembershipForFullPlayback: Bool? = nil

    var platform: OnlinePlatform { storedPlatform ?? .netease }
}
extension OnlineSong {
    var track: LocalTrack {
        let unavailableReason = privilege["st"].int < 0 ? "网易云当前限制播放这首歌曲。" : nil
        return LocalTrack(id: "netease/" + id, folderID: UUID(uuidString: "00000000-0000-0000-0000-000000000163")!, url: URL(string: "sono-netease://song/" + id)!, title: title, artist: artist, album: album, duration: duration, coverURL: cover, playable: true, online: OnlineTrackInfo(songID: id, albumID: albumID, artistID: artistID, unavailableReason: unavailableReason, artists: artists))
    }
}
enum OnlinePageKind: Codable, Equatable, Sendable {
    case search(String), classifiedSearch(String, SearchCategory), playlist(String), album(String), artist(String), artistAlbums(String), playback, personalFM, dailyRecommendations, dailyStyleRecommendations
    var key: String { switch self { case .classifiedSearch(let value, let category): "search/" + category.rawValue + "/" + value; case .artistAlbums(let value): "artist/" + value + "/albums"; case .search(let value): "search/" + value; case .playlist(let value): "playlist/" + value; case .album(let value): "album/" + value; case .artist(let value): "artist/" + value; case .playback: "playback"; case .personalFM: "personal-fm"; case .dailyRecommendations: "daily-recommendations"; case .dailyStyleRecommendations: "daily-recommendations/style" } }
}
extension OnlinePageKind {
    var isDailyRecommendation: Bool { switch self { case .dailyRecommendations, .dailyStyleRecommendations: true; default: false } }
    var isArtistAlbums: Bool { if case .artistAlbums = self { return true }; return false }
    var classifiedSearch: Bool { if case .classifiedSearch = self { return true }; return false }
    var searchQuery: String? { switch self { case .search(let query), .classifiedSearch(let query, _): query; default: nil } }
    var searchCategory: SearchCategory? { switch self { case .search: .songs; case .classifiedSearch(_, let category): category; default: nil } }
    var artistID: String? { switch self { case .artist(let id), .artistAlbums(let id): id; default: nil } }
}
struct OnlinePage: Codable, Sendable {
    var kind: OnlinePageKind
    var title: String
    var tracks: [LocalTrack] = []
    var items: [BrowseItem]?
    var browseItems: [BrowseItem] { items ?? tracks.map(BrowseItem.song) }
    var offset = 0
    var total = 0
    var ids: [String] = []
    var more = false
    var isCached = false
    var cachedAt: Date?
    var wallAssignment: [Int]?
    var wallAssignmentVersion: Int?
    var collectionSubtitle: String?
    var collectionArtwork: URL?
    var recommendationStyle: DailyStyleSelection?
    var playlistCover: URL?
    var collectionDisplaySubtitle: String {
        if case .album = kind { return "共：\(total)首" }
        return collectionSubtitle ?? ""
    }
    func canReuseCompletePage(at now: Date = Date()) -> Bool {
        switch kind {
        case .artist, .artistAlbums, .album:
            if collectionSubtitle == nil { return false }
        default: break
        }
        guard let cachedAt, !more else { return false }
        if kind.isDailyRecommendation { return now.timeIntervalSince(cachedAt) < 300 && RecommendationDate.refreshDay(cachedAt) == RecommendationDate.refreshDay(now) }
        return !isCached || now.timeIntervalSince(cachedAt) < 300
    }
}

enum OnlineAuthentication: Equatable {
    case signedOut, restoring, verified, offlineCache
}

@MainActor
final class OnlineSession: ObservableObject {
    @Published private(set) var qqAccounts: [OnlineAccount] = []
    @Published private(set) var qqAccountNotice: String?
    @Published private(set) var activePlatform: OnlinePlatform = .netease
    private var qqFMPage = 1
    private let activeQQAccountKey = "online.activeQQAccount"

    func refreshQQAccounts() {
        do {
            qqAccounts = try QQLoginClient.credentials.loadSaved().accounts
            savedAccounts = try credentials.loadSaved().accounts
        }
        catch { qqAccountNotice = error.localizedDescription }
    }

    func savedAccountAvatar(_ id: String, platform: OnlinePlatform) async throws -> URL? {
        let store = platform == .qq ? QQLoginClient.credentials : credentials
        guard let saved = try store.savedSession(for: id) else { return nil }
        let profile = try await (platform == .qq
            ? QQLoginClient().verify(id: id, cookie: saved.cookie)
            : fetchAccount(saved.cookie))
        return profile.id == id ? profile.avatar : nil
    }

    func verifySavedQQAccount(_ id: String, openPlaylist: Bool = false, fromQRScan: Bool = false) {
        guard !accountLoading else { return }
        cancelLogin()
        connectingAccountKey = OnlinePlatform.qq.rawValue + "/" + id
        accountLoading = true
        let revision = loginRevision
        loginTask = Task { [weak self] in
            guard let self else { return }
            defer { if loginRevision == revision { accountLoading = false } }
            do {
                guard let saved = try QQLoginClient.credentials.savedSession(for: id) else {
                    throw OnlineError.loginRequired
                }
                let profile = try await QQLoginClient().verify(id: id, cookie: saved.cookie)
                try Task.checkCancellation()
                guard loginRevision == revision else { return }
                let catalog = QQOnlineCatalog(cookie: saved.cookie)
                let lists = try await catalog.playlists(owner: id)
                try Task.checkCancellation()
                guard loginRevision == revision else { return }
                let wasOnline = page.map { browser.sourceKey == $0.kind.key } ?? false
                try QQLoginClient.credentials.saveSession(saved.cookie, account: profile)
                resetAccount(preservingLogin: true)
                activePlatform = .qq
                refreshQQAccounts()
                account = profile
                authentication = .verified
                cookie = saved.cookie
                playlists = lists
                PerformanceEnvironment.defaults.set(id, forKey: activeQQAccountKey)
                qqFMPage = 1
                loadFavorites()
                if wasOnline || openPlaylist, let first = playlists.first {
                    open(.playlist(first.id), title: first.name)
                }
                qqAccountNotice = nil
                if fromQRScan { qrState = .succeeded }
            } catch {
                if !Task.isCancelled, loginRevision == revision {
                    if fromQRScan { qrFailed(error, platform: .qq) }
                    else { qqAccountNotice = error.localizedDescription }
                }
            }
        }
    }

    @Published private(set) var savedAccounts: [OnlineAccount] = []
    @Published private(set) var account: OnlineAccount?
    @Published private(set) var playlists: [OnlinePlaylist] = []
    var playlistsByPlayback: [OnlinePlaylist] {
        let recent = account.map { playlistPlaybackHistory(owner: $0.id) } ?? []
        let rank = Dictionary(recent.enumerated().map { ($0.element, $0.offset) }, uniquingKeysWith: min)
        return playlists.enumerated().sorted { lhs, rhs in
            let left = lhs.element
            let right = rhs.element
            if (left.isFavorites == true) != (right.isFavorites == true) { return left.isFavorites == true }
            let leftRank = rank[left.id] ?? Int.max
            let rightRank = rank[right.id] ?? Int.max
            return leftRank == rightRank ? lhs.offset < rhs.offset : leftRank < rightRank
        }.map(\.element)
    }

    func recordPlaylistPlayback(source: OnlinePageKind?) {
        guard let owner = account?.id, case .playlist(let id) = source,
              !playlists.contains(where: { $0.id == id && $0.isFavorites == true }) else { return }
        let history = playlistPlaybackHistory(owner: owner)
        guard history.first != id else { return }
        PerformanceEnvironment.defaults.set([id] + history.filter { $0 != id }, forKey: "playlist-playback." + owner)
        objectWillChange.send()
    }

    private func playlistPlaybackHistory(owner: String) -> [String] {
        PerformanceEnvironment.defaults.stringArray(forKey: "playlist-playback." + owner) ?? []
    }

    @Published private(set) var playlistsMore = false
    @Published private(set) var page: OnlinePage?
    let browser: MusicBrowser
    var backStack: [BrowserLocation] { browser.backStack }
    private var pages: [String: OnlinePage] = [:]
    private var lastSearchPageKey: String?
    private var artistAvatars: [String: URL] = [:]
    private var requestedPage: OnlinePage?
    var pendingSourceKey: String? { loading ? requestedPage?.kind.key : nil }
    var pendingSearchSuggestion: Bool { pendingSourceKey != nil && requestedSuggestionDraft != nil }
    var pendingKind: OnlinePageKind? { (requestedPage ?? page)?.kind }
    private var requestedIntent = BrowseIntent.push
    private var requestedFocus: String?
    private var requestedSuggestionDraft: String?
    @Published private(set) var loading = false
    private(set) var connectingAccountKey: String?
    @Published private(set) var accountLoading = false {
        didSet { if !accountLoading { connectingAccountKey = nil } }
    }
    @Published private(set) var authentication = OnlineAuthentication.signedOut
    var restoringAccount: Bool { authentication == .restoring }
    private var verificationTask: Task<OnlineAccount, Error>?
    @Published private(set) var playlistsLoading = false
    @Published private(set) var qrImage: NSImage?
    enum QRState: Equatable {
        case idle, generating, connecting, waiting, confirming, verifying, succeeded
        case refreshing, failed(String, String)
    }

    @Published private(set) var qrState: QRState = .idle

    private enum QRFailure: Error {
        case expired, canceled, rejected
    }

    private func qrFailed(_ error: Error, platform: OnlinePlatform) {
        let status: String
        let message: String
        let failure: QRFailure?
        if case OnlineError.service(405, _) = error, platform == .netease {
            failure = .rejected
        } else {
            failure = error as? QRFailure
        }
        switch failure {
        case .expired:
            qrState = .failed("二维码已过期", "需要新二维码才能继续登录")
            return
        case .canceled:
            qrState = .failed("已取消登录", "你已在手机上取消登录")
            return
        case .rejected:
            qrState = .failed("登录未完成", "平台未能完成登录，请重新扫码")
            return
        default:
            switch qrState {
            case .generating, .refreshing:
                status = "二维码生成失败"
                message = "暂时无法获取" + platform.title + "二维码"
            case .verifying:
                status = "账号验证失败"
                message = "暂时无法验证" + platform.title + "账号"
            default:
                status = "连接已中断"
                message = "暂时无法连接" + platform.title + "扫码服务"
            }
        }
        let networkCode = (error as? URLError)?.code
        let explanation: String
        switch networkCode {
        case .notConnectedToInternet: explanation = "网络未连接，请检查网络"
        case .timedOut: explanation = "连接超时，请再试一次"
        default: explanation = message
        }
        let details = error as NSError
        NSLog("QR login %@ [%@]: %@ (%ld)", platform.rawValue, status, details.domain, details.code)
        qrState = .failed(status, explanation)
    }

    @Published private(set) var suggestions: [SearchSuggestion] = []
    var searchDraft: String { get { browser.location.globalDraft } set { browser.location.globalDraft = newValue } }
    @Published var notice: String?
    @Published private(set) var favoriteIDs: Set<String>?
    @Published private(set) var favoritesLoading = false
    @Published private(set) var songOperations: Set<String> = []
    private var favoritesTask: Task<Void, Never>?
    var editablePlaylists: [OnlinePlaylist] {
        guard authentication == .verified, let account else { return [] }
        return playlists.filter { $0.ownerID == account.id && $0.subscribed != true && $0.isFavorites != true }
    }
    let client: NeteaseClient
    private let credentials: OnlineCredentialStore
    private let cache: OnlineCache
    private let cacheIO: OnlineCacheIO
    private var cachedPages: [OnlinePage] = []
    private var cachedPagesOwner: String?
    private var startupSelectionPending = true
    private var startupCachedPageKey: String?
    private var cookie = ""
    private let loginPollInterval: Duration
    private var accountRevision = UUID()
    private var loginRevision = UUID()
    private var pageRevision = UUID()
    private var pageTask: Task<Void, Never>?
    private var filterTask: Task<Void, Never>?
    private var filterRevision = UUID()
    @Published private(set) var filtering = false
    @Published private(set) var filterError: String?
    private var loginTask: Task<Void, Never>?
    private var playlistTask: Task<Void, Never>?
    private var warmTask: Task<OnlinePage?, Never>?
    private var warmSourceKey: String?
    private var warmTokens: [UUID] = []
    private var suggestTask: Task<Void, Never>?
    private var suggestionRevision = UUID()
    var onAccountReset: (() -> Void)?
    var onAuthenticationChange: (() -> Void)?
    var onPageChange: (() -> Void)?
    private let searchCoverPreparation: @MainActor (BrowseItem, CGSize, ArtworkPresentation?) async throws -> Void
    init(searchCoverPreparation: @escaping @MainActor (BrowseItem, CGSize, ArtworkPresentation?) async throws -> Void = { item, viewport, presentation in try await SearchArtwork.prepareCenter(item, viewport: viewport, presentation: presentation) }, client: NeteaseClient = NeteaseClient(), credentials: OnlineCredentialStore = OnlineCredentialStore(), cache: OnlineCache = OnlineCache(), loginPollInterval: Duration = .seconds(2), browser: MusicBrowser? = nil) {
        self.searchCoverPreparation = searchCoverPreparation
        self.client = client; self.credentials = credentials; self.cache = cache; self.cacheIO = OnlineCacheIO(cache); self.loginPollInterval = loginPollInterval
        self.browser = browser ?? MusicBrowser()
        self.browser.onRestoreSource = { [weak self] key in self?.restoreSource(key) }
    }
    @Published private(set) var recommendationFeedbackPending = false
    @Published private(set) var recommendationLimitDay: String?
    @Published private(set) var dailyRefreshingOwners: Set<String> = []
    @Published var dailyStylePickerOpen = false
    @Published private(set) var dailyStyleGroups: [DailyStyleGroup] = []
    @Published private(set) var dailyStyleResponse: DailyStyleResponse?
    @Published private(set) var dailyStyleLoading = false
    @Published private(set) var dailyStyleSaving = false
    @Published private(set) var dailyStyleError: String?
    private var dailyStylePickerRevision = UUID()
    private var dailyStyleSavedSelection: DailyStyleSelection?
    private var dailyRefreshTasks: [String: Task<Void, Never>] = [:]
    var recommendationFeedbackLimited: Bool { recommendationLimitDay == RecommendationDate.day() }
    var dailyRefreshing: Bool { dailyRefreshingOwners.contains(account?.id ?? "") }
    private func recommendationPreferenceKey(_ field: String, owner: String) -> String { "daily-recommendations." + owner + "." + field }
    func dailyRefreshUsed(at date: Date = Date()) -> Bool {
        guard let owner = account?.id else { return false }
        return PerformanceEnvironment.defaults.string(forKey: recommendationPreferenceKey("refresh", owner: owner)) == RecommendationDate.refreshDay(date)
    }
    func openRecommendations(style: Bool? = nil) {
        guard authentication == .verified, let owner = account?.id else { notice = "请先登录网易云音乐后使用推荐"; return }
        if activePlatform == .qq { open(.dailyRecommendations, title: "每日推荐", intentOverride: .root); return }
        let useStyle = style ?? PerformanceEnvironment.defaults.bool(forKey: recommendationPreferenceKey("style", owner: owner))
        open(useStyle ? .dailyStyleRecommendations : .dailyRecommendations, title: "每日推荐", intentOverride: .root)
    }
    private func rememberRecommendationMode(_ kind: OnlinePageKind) {
        guard kind.isDailyRecommendation, let owner = account?.id else { return }
        PerformanceEnvironment.defaults.set(kind == .dailyStyleRecommendations, forKey: recommendationPreferenceKey("style", owner: owner))
    }
    func refreshRecommendations() {
        guard activePlatform == .netease else { return }
        guard page?.kind == .dailyRecommendations, authentication == .verified, !loading,
              let owner = account?.id, !dailyRefreshingOwners.contains(owner), !dailyRefreshUsed() else { return }
        let auth = cookie, revision = accountRevision, pageToken = pageRevision
        dailyRefreshingOwners.insert(owner)
        dailyRefreshTasks[owner] = Task { [weak self] in
            guard let self else { return }
            defer { dailyRefreshingOwners.remove(owner); dailyRefreshTasks[owner] = nil }
            do {
                let songs = try await client.dailyRecommendations(afresh: true, cookie: auth)
                PerformanceEnvironment.defaults.set(RecommendationDate.refreshDay(), forKey: recommendationPreferenceKey("refresh", owner: owner))
                guard revision == accountRevision else { return }
                let next = recommendationPage(songs, style: nil)
                pages[next.kind.key] = next
                cachedPages.removeAll { $0.kind == next.kind }
                if pageToken == pageRevision && page?.kind == .dailyRecommendations {
                    publish(next); focusFirstRecommendation(next)
                }
                try await cacheIO.savePage(next, owner: owner)
            } catch { if revision == accountRevision { notice = error.localizedDescription } }
        }
    }
    func closeDailyStylePicker() {
        dailyStylePickerRevision = UUID(); dailyStylePickerOpen = false
        dailyStyleLoading = false; dailyStyleSaving = false
    }
    func prepareDailyStylePicker() async {
        guard authentication == .verified else { notice = "请先登录网易云音乐后使用推荐"; closeDailyStylePicker(); return }
        let token = UUID(), revision = accountRevision, auth = cookie
        dailyStylePickerRevision = token; dailyStyleLoading = true; dailyStyleError = nil
        dailyStyleResponse = nil; dailyStyleSavedSelection = nil
        defer { if token == dailyStylePickerRevision { dailyStyleLoading = false } }
        do {
            async let groups = client.dailyStyleGroups(cookie: auth)
            async let response = client.dailyStyleSongs(cookie: auth)
            let answer = try await (groups, response)
            try Task.checkCancellation()
            guard token == dailyStylePickerRevision, revision == accountRevision, dailyStylePickerOpen else { return }
            dailyStyleGroups = answer.0; dailyStyleResponse = answer.1
        } catch { if token == dailyStylePickerRevision && revision == accountRevision && !Task.isCancelled { dailyStyleError = error.localizedDescription } }
    }
    func confirmDailyStyle(_ selection: DailyStyleSelection) async {
        guard authentication == .verified, let owner = account?.id, !dailyStyleSaving,
              (1...5).contains(selection.tagIDs.count),
              let group = dailyStyleGroups.first(where: { $0.id == selection.categoryID }),
              selection.tagIDs.allSatisfy({ id in group.tags.contains { $0.id == id } }) else { return }
        let token = dailyStylePickerRevision, revision = accountRevision, pageToken = pageRevision, auth = cookie
        dailyStyleSaving = true; dailyStyleError = nil
        var saved = dailyStyleSavedSelection == selection
        defer { if token == dailyStylePickerRevision { dailyStyleSaving = false } }
        do {
            let response: DailyStyleResponse
            if let existing = dailyStyleResponse, existing.selection == selection, !saved { response = existing }
            else {
                if !saved {
                    try await client.saveDailyStyle(selection, cookie: auth)
                    saved = true
                    guard token == dailyStylePickerRevision, revision == accountRevision, dailyStylePickerOpen else { return }
                    dailyStyleSavedSelection = selection
                }
                response = try await client.dailyStyleSongs(cookie: auth)
            }
            try Task.checkCancellation()
            guard token == dailyStylePickerRevision, revision == accountRevision, pageToken == pageRevision, dailyStylePickerOpen else { return }
            let next = recommendationPage(response.songs, style: response.selection ?? selection)
            rememberPage(); pageTask?.cancel(); pageRevision = UUID(); requestedPage = nil; loading = false
            requestedIntent = .root; requestedFocus = next.tracks.first?.id
            publish(next); focusFirstRecommendation(next)
            dailyStylePickerOpen = false; dailyStyleResponse = response
            cachedPages.removeAll { $0.kind == next.kind }
            do { try await cacheIO.savePage(next, owner: owner) }
            catch { if revision == accountRevision { notice = "歌曲已载入，但缓存保存失败：" + error.localizedDescription } }
        } catch {
            if token == dailyStylePickerRevision && revision == accountRevision && !Task.isCancelled {
                dailyStyleError = saved ? "风格已保存，歌曲加载失败，请重试" : error.localizedDescription
                notice = dailyStyleError
            }
        }
    }
    private func recommendationPage(_ songs: [OnlineSong], style: DailyStyleSelection?) -> OnlinePage {
        var next = OnlinePage(kind: style == nil ? .dailyRecommendations : .dailyStyleRecommendations, title: "每日推荐")
        next.tracks = songs.map(\.track); next.ids = songs.map(\.id)
        next.total = songs.count; next.offset = songs.count; next.cachedAt = Date(); next.recommendationStyle = style
        return next
    }
    private func focusFirstRecommendation(_ next: OnlinePage) {
        if let first = next.tracks.first { browser.location.anchor = first.id; browser.location.expanded = first.id; browser.location.centerOnReturn = true }
    }
    func dislikeRecommendation(_ track: LocalTrack, playbackSource: OnlinePageKind? = nil) async -> String? {
        guard authentication == .verified, (page?.kind == .dailyRecommendations || playbackSource == .dailyRecommendations), !recommendationFeedbackPending,
              !recommendationFeedbackLimited, let id = track.online?.songID else { return nil }
        let revision = accountRevision, pageToken = pageRevision, auth = cookie
        recommendationFeedbackPending = true
        defer { if revision == accountRevision { recommendationFeedbackPending = false } }
        do {
            let result = try await client.dislikeRecommendation(id, cookie: auth)
            guard revision == accountRevision else { return nil }
            switch result {
            case .limitReached: recommendationLimitDay = RecommendationDate.day(); return "今日暂无更多推荐，已达到替换上限"
            case .replacement(let song):
                guard pageToken == pageRevision, var current = page, current.kind == .dailyRecommendations,
                      let index = current.tracks.firstIndex(where: { $0.id == track.id }) else {
                    pages["daily-recommendations"]?.cachedAt = nil; pages["daily-recommendations"]?.isCached = true
                    cachedPages.removeAll { $0.kind == .dailyRecommendations }
                    if let owner = account?.id { try await cacheIO.invalidatePage(.dailyRecommendations, owner: owner) }
                    return "反馈已保存"
                }
                let replacement = song.track
                if current.tracks.contains(where: { $0.id == replacement.id && $0.id != track.id }) { current.tracks.remove(at: index) }
                else { current.tracks[index] = replacement }
                current.ids = current.tracks.compactMap { $0.online?.songID }; current.total = current.tracks.count; current.offset = current.total; current.cachedAt = Date()
                if browser.location.anchor == track.id { browser.location.anchor = replacement.id; browser.location.expanded = replacement.id }
                publish(current)
                if let owner = account?.id { try await cacheIO.savePage(current, owner: owner) }
                return "已替换不感兴趣的歌曲"
            }
        } catch { guard revision == accountRevision else { return nil }; return "无法替换推荐：" + error.localizedDescription }
    }
    func requestPersonalFM(_ selection: PersonalFMSelection) async throws -> [LocalTrack] {
        guard authentication == .verified else { throw OnlineError.loginRequired }
        let revision = accountRevision
        if activePlatform == .qq {
            let batch = try await QQOnlineCatalog(cookie: cookie).fm(page: qqFMPage)
            try Task.checkCancellation()
            guard revision == accountRevision else { throw CancellationError() }
            qqFMPage = batch.hasMore && qqFMPage < 100 ? qqFMPage + 1 : 1
            return batch.tracks
        }
        let songs = try await client.personalFM(selection: selection, cookie: cookie)
        try Task.checkCancellation(); guard revision == accountRevision else { throw CancellationError() }
        return songs.map(\.track)
    }
    func trashPersonalFM(_ song: String, playedSeconds: Int) async throws {
        guard activePlatform == .netease else { return }
        guard authentication == .verified else { throw OnlineError.loginRequired }
        let revision = accountRevision
        try await client.trashFM(song, playedSeconds: playedSeconds, cookie: cookie)
        try Task.checkCancellation(); guard revision == accountRevision else { throw CancellationError() }
    }
    func restore() {
        if !accountLoading, PerformanceEnvironment.root == nil,
           let id = PerformanceEnvironment.defaults.string(forKey: activeQQAccountKey) {
            refreshQQAccounts()
            if qqAccounts.contains(where: { $0.id == id }) {
                verifySavedQQAccount(id, openPlaylist: true)
                return
            }
        }
        BrowseDiagnostics.shared.mark("account.restoreStarted")
        cancelLogin(); accountLoading = true; authentication = .restoring; notice = nil
        let revision = accountRevision
        let login = loginRevision
        let savedTask = Task.detached(priority: .userInitiated) { [credentials] in
            let start = BrowseDiagnostics.shared.start()
            defer { BrowseDiagnostics.shared.end("account.credentialRead", start) }
            return try credentials.loadSaved()
        }
        let validation = Task {
            let saved = try await savedTask.value
            try Task.checkCancellation()
            guard NeteaseClient.cookies(saved.cookie)["MUSIC_U"]?.isEmpty == false else { throw OnlineError.loginRequired }
            return try await self.fetchAccount(saved.cookie)
        }
        verificationTask = validation
        loginTask = Task { [weak self] in
            guard let self else { return }
            defer { if loginRevision == login { accountLoading = false; verificationTask = nil; if authentication == .restoring { authentication = .signedOut } } }
            do {
                let saved = try await savedTask.value
                try Task.checkCancellation()
                guard revision == accountRevision, login == loginRevision else { return }
                savedAccounts = saved.accounts
                guard !saved.cookie.isEmpty else { return }
                guard NeteaseClient.cookies(saved.cookie)["MUSIC_U"]?.isEmpty == false else { throw OnlineError.loginRequired }
                // Network validation starts before disk IO, with the account owner
                // taken exclusively from the atomic keychain record.
                if let binding = saved.session {
                    let document = await cacheIO.load(owner: binding.account.id)
                    try Task.checkCancellation()
                    guard revision == accountRevision, login == loginRevision else { return }
                    if !document.playlists.isEmpty, !document.pages.isEmpty {
                        cookie = saved.cookie; account = binding.account
                        cachedPages = document.pages; cachedPagesOwner = binding.account.id; playlists = document.playlists
                        selectStartupPlaylist()
                        startupCachedPageKey = page?.kind.key
                        BrowseDiagnostics.shared.mark("account.cachePublished")
                    }
                }
                let profile = try await validation.value
                try Task.checkCancellation(); guard revision == accountRevision, login == loginRevision else { return }
                try await commitLogin(saved.cookie, profile: profile)
            } catch { if !Task.isCancelled && revision == accountRevision && login == loginRevision {
                if account != nil { authentication = .offlineCache }
                handle(error)
            } }
        }
    }
    private func fetchAccount(_ cookie: String) async throws -> OnlineAccount {
        let measurement = BrowseDiagnostics.shared.start()
        defer { BrowseDiagnostics.shared.end("account.profileRequest", measurement) }
        let json = try await client.request("/api/nuser/account/get", cookie: cookie, weapi: true)
        guard !json["profile"]["userId"].string.isEmpty else { throw OnlineError.loginRequired }
        return OnlineAccount(id: json["profile"]["userId"].string, name: json["profile"]["nickname"].string, avatar: Self.suggestionArtwork(json["profile"]["avatarUrl"].string))
    }
    func importElectronLogin() {
        guard account == nil else { return }
        cancelLogin(); accountLoading = true; notice = nil
        let revision = accountRevision; let login = loginRevision
        loginTask = Task { [weak self] in
            guard let self else { return }
            defer { if loginRevision == login { accountLoading = false } }
            do {
                let imported = try await Task.detached(priority: .userInitiated) { try ElectronLoginImport.read() }.value
                try Task.checkCancellation(); guard revision == accountRevision, login == loginRevision else { return }
                let profile = try await fetchAccount(imported)
                try Task.checkCancellation(); guard revision == accountRevision, login == loginRevision else { return }
                try await commitLogin(imported, profile: profile)
            } catch { if !Task.isCancelled && revision == accountRevision && login == loginRevision { notice = "导入登录失败：" + error.localizedDescription } }
        }
    }
    func switchAccount(to id: String) {
        guard (activePlatform != .netease || id != account?.id), !accountLoading else { return }
        cancelLogin()
        connectingAccountKey = OnlinePlatform.netease.rawValue + "/" + id
        accountLoading = true; notice = nil
        let login = loginRevision
        loginTask = Task { [weak self] in
            guard let self else { return }
            defer { if loginRevision == login { accountLoading = false } }
            do {
                guard let session = try credentials.savedSession(for: id) else { throw OnlineError.loginRequired }
                let verified = try await fetchAccount(session.cookie)
                try Task.checkCancellation()
                guard loginRevision == login, verified.id == id else { throw OnlineError.loginRequired }
                try await commitLogin(session.cookie, profile: verified, selectingAccount: true)
            } catch {
                if !Task.isCancelled && loginRevision == login {
                    notice = "账号切换失败。若登录已过期，请重新扫码。" + error.localizedDescription
                }
            }
        }
    }

    func beginQQLogin(replacingExpiredCode: Bool = false) {
        cancelLogin()
        qqAccountNotice = nil
        accountLoading = true
        notice = nil
        qrState = replacingExpiredCode ? .refreshing : .generating
        let revision = loginRevision
        loginTask = Task { [weak self] in
            guard let self else { return }
            defer {
                if loginRevision == revision {
                    accountLoading = false
                    qrImage = nil
                }
            }
            do {
                let client = QQLoginClient()
                let challenge = try await client.createChallenge()
                try Task.checkCancellation()
                guard loginRevision == revision else { return }
                qrState = .connecting
                let socket = QQLoginSocket()
                try await socket.start(qrID: challenge.id)
                try Task.checkCancellation()
                guard loginRevision == revision else { throw CancellationError() }
                guard let image = NSImage(data: challenge.image), image.isValid else {
                    throw OnlineError.protocolFailure("无效的二维码图片")
                }
                qrImage = image
                qrState = .waiting
                let confirmation = try await withThrowingTaskGroup(of: QQLoginMQTT.Publish.self) { group in
                    group.addTask {
                        try await Task.sleep(for: .seconds(challenge.expiresIn))
                        throw QRFailure.expired
                    }
                    group.addTask { try await socket.keepAlive() }
                    group.addTask {
                        while true {
                            let packet = try await socket.nextPacket()
                            guard packet.type == 3 else { continue }
                            let event = try QQLoginMQTT.publish(packet)
                            guard event.topic == "management.qrcode_login/" + challenge.id else { continue }
                            switch event.event {
                            case "cookies": return event
                            case "canceled": throw QRFailure.canceled
                            case "timeout": throw QRFailure.expired
                            case "loginFailed": throw QRFailure.rejected
                            default: continue
                            }
                        }
                    }
                    defer { group.cancelAll() }
                    guard let result = try await group.next() else { throw CancellationError() }
                    return result
                }
                await socket.close()
                qrImage = nil
                qrState = .verifying
                let profile = try await client.confirm(confirmation, challenge: challenge)
                guard loginRevision == revision else { return }
                refreshQQAccounts()
                accountLoading = false
                verifySavedQQAccount(profile.id, openPlaylist: true, fromQRScan: true)
                qrState = .verifying
            } catch {
                guard !Task.isCancelled, loginRevision == revision else { return }
                if case QRFailure.expired = error, !replacingExpiredCode {
                    beginQQLogin(replacingExpiredCode: true)
                } else {
                    qrFailed(error, platform: .qq)
                }
            }
        }
    }

    func beginLogin(replacingExpiredCode: Bool = false) {
        cancelLogin(); accountLoading = true; notice = nil; qrState = replacingExpiredCode ? .refreshing : .generating
        let revision = accountRevision
        let login = loginRevision
        loginTask = Task { [weak self] in
            guard let self else { return }
            defer { if loginRevision == login { accountLoading = false } }
            do {
                let response = try await client.request("/api/login/qrcode/unikey", ["type": "3"])
                let key = response["unikey"].string
                guard !key.isEmpty else { throw OnlineError.protocolFailure("未取得扫码登录标识") }
                try Task.checkCancellation(); guard revision == accountRevision, login == loginRevision else { return }
                var components = URLComponents(string: "https://music.163.com/login")!
                components.queryItems = [URLQueryItem(name: "codekey", value: key)]
                qrImage = Self.makeQR(components.url!.absoluteString)
                var loginCookie = response["cookie"].string
                qrState = .waiting
                let deadline = Date().addingTimeInterval(180)
                while Date() < deadline {
                    try await Task.sleep(for: loginPollInterval)
                    let status = try await client.request("/api/login/qrcode/client/login", ["key": key, "type": "3"], cookie: loginCookie)
                    try Task.checkCancellation(); guard revision == accountRevision, login == loginRevision else { return }
                    loginCookie = status["cookie"].string
                    switch status["code"].int {
                    case 800: throw QRFailure.expired
                    case 801: break
                    case 802: qrImage = nil; qrState = .confirming
                    case 803:
                        qrImage = nil
                        qrState = .verifying
                        let next = status["cookie"].string
                        guard NeteaseClient.cookies(next)["MUSIC_U"]?.isEmpty == false else { throw OnlineError.protocolFailure("登录响应缺少账号凭据") }
                        let profile = try await fetchAccount(next)
                        try Task.checkCancellation(); guard revision == accountRevision, login == loginRevision else { return }
                        try await commitLogin(next, profile: profile, selectingAccount: true, fromQRScan: true)
                        qrImage = nil
                        qrState = .succeeded
                        return
                    default: throw OnlineError.protocolFailure("无法识别扫码登录状态")
                    }
                }
                throw QRFailure.expired
            } catch {
                guard !Task.isCancelled, revision == accountRevision, login == loginRevision else { return }
                qrImage = nil
                if case QRFailure.expired = error, !replacingExpiredCode {
                    beginLogin(replacingExpiredCode: true)
                } else {
                    qrFailed(error, platform: .netease)
                }
            }
        }
    }
    func cancelLogin() { qrState = .idle; loginRevision = UUID(); loginTask?.cancel(); loginTask = nil; qrImage = nil; accountLoading = false; verificationTask?.cancel(); verificationTask = nil; if authentication == .restoring { authentication = account == nil ? .signedOut : .offlineCache } }
    private func commitLogin(_ value: String, profile: OnlineAccount, selectingAccount: Bool = false, fromQRScan: Bool = false) async throws {
        let sameAccount = activePlatform == .netease && account?.id == profile.id
        let foreground = requestedPage ?? page.flatMap { browser.sourceKey == $0.kind.key ? $0 : nil }
        let publicPage: OnlinePage? = foreground.flatMap { value in
            switch value.kind { case .search, .classifiedSearch, .album, .artist, .artistAlbums: return value; default: return nil }
        }
        if !sameAccount {
            let location = browser.location, draft = searchDraft
            let selectAccountPage = selectingAccount || startupSelectionPending || (startupCachedPageKey != nil && browser.sourceKey == startupCachedPageKey)
            // Withdraw the old owner's cache before any new-owner disk/keychain IO.
            // The validating login owns this reset and must not cancel itself.
            resetAccount(clearPlayback: account != nil, preservingLogin: true)
            credentials.invalidateSnapshot()
            PerformanceEnvironment.defaults.removeObject(forKey: activeQQAccountKey)
            activePlatform = .netease; cookie = value; account = profile; cachedPagesOwner = profile.id
            startupSelectionPending = publicPage == nil && selectAccountPage
            if let publicPage, !fromQRScan {
                pages[publicPage.kind.key] = publicPage
                open(publicPage.kind, title: publicPage.title)
                if location.source == publicPage.kind.key { browser.location = location }
                searchDraft = draft
            }
        }
        let revision = accountRevision
        let cacheStart = BrowseDiagnostics.shared.start()
        let document = await cacheIO.load(owner: profile.id)
        BrowseDiagnostics.shared.end("account.cacheRead", cacheStart)
        try Task.checkCancellation()
        guard accountRevision == revision else { throw CancellationError() }
        var persistenceNotice: String?
        do {
            try credentials.saveSession(value, account: profile)
            savedAccounts.removeAll { $0.id == profile.id }
            savedAccounts.append(profile)
        }
        catch {
            let details = error as NSError
            NSLog("Account persistence: %@ (%ld)", details.domain, details.code)
            persistenceNotice = fromQRScan
                ? "已登录，但未能保存账号。下次打开时可能需要重新登录。"
                : "登录已验证，但本次账号未能保存到钥匙串：" + error.localizedDescription
        }
        BrowseDiagnostics.shared.mark("account.restored")
        cookie = value; account = profile; authentication = .verified
        if !sameAccount {
            cachedPages = document.pages; cachedPagesOwner = profile.id
            playlists = document.playlists
        }
        if fromQRScan {
            startupSelectionPending = true
            if let first = playlists.first { open(.playlist(first.id), title: first.name) }
        } else if !sameAccount {
            selectStartupPlaylist()
        }
        loadPlaylists()
        // Cache publication already owns the page; verification does not reset
        // its generation, geometry, covers or entrance clock.
        if sameAccount, let page, page.isCached, !page.canReuseCompletePage(), !loading { loadPage() }
        if let persistenceNotice { notice = persistenceNotice }
    }
    private func selectStartupPlaylist() {
        guard startupSelectionPending, page == nil, let first = playlists.first else { return }
        browser.startupRecoverySource = "playlist/" + first.id
        open(.playlist(first.id), title: first.name)
    }
    func logout() { logout(id: account?.id, platform: activePlatform) }

    func logout(id: String?, platform: OnlinePlatform) {
        let store = platform == .qq ? QQLoginClient.credentials : credentials
        do { try store.removeSession(id: id) }
        catch { qqAccountNotice = error.localizedDescription; return }
        if platform == .qq { qqAccounts.removeAll { $0.id == id } }
        else { savedAccounts.removeAll { $0.id == id } }
        guard platform == activePlatform, account?.id == id else { return }
        resetAccount()
        if activePlatform == .qq {
            activePlatform = .netease
            PerformanceEnvironment.defaults.removeObject(forKey: activeQQAccountKey)
        }
    }
    private func resetAccount(clearPlayback: Bool = true, preservingLogin: Bool = false) {
        closeDailyStylePicker(); dailyStyleGroups = []; dailyStyleResponse = nil; recommendationFeedbackPending = false; recommendationLimitDay = nil
        favoritesTask?.cancel(); favoritesTask = nil; favoriteIDs = nil; favoritesLoading = false; songOperations = []
        lastSearchPageKey = nil
        accountRevision = UUID(); pageRevision = UUID(); suggestionRevision = UUID()
        quickRequest?.cancel(); quickResolution?.cancel(); quickDetails = [:]
        cancelWarm(); cancelFilter(); if !preservingLogin { cancelLogin() }; pageTask?.cancel(); playlistTask?.cancel(); suggestTask?.cancel()
        startupCachedPageKey = nil; browser.startupRecoverySource = nil
        cookie = ""; account = nil; authentication = preservingLogin ? .restoring : .signedOut; playlists = []; playlistsMore = false; browser.sourceTotal = 0; browser.sourceOrderedIDs = []; browser.sourceOrdinals = [:]; browser.sourceOwner = "local"; page = nil; requestedPage = nil; pages = [:]; cachedPages = []; cachedPagesOwner = nil; artistAvatars = [:]; browser.clearOnlineLocations()
        qrImage = nil; suggestions = []; searchDraft = ""; loading = false; playlistsLoading = false
        if clearPlayback { onAccountReset?() } else { onAuthenticationChange?() }
        onPageChange?()
    }
    private func handle(_ error: Error) {
        if case OnlineError.loginRequired = error {
            do { try credentials.removeSession() } catch { notice = error.localizedDescription; return }
            savedAccounts.removeAll { $0.id == account?.id }
            resetAccount()
        }
        notice = error.localizedDescription
    }
    func loadFavorites(report: ((String) -> Void)? = nil) {
        guard authentication == .verified, let owner = account?.id, !favoritesLoading, favoriteIDs == nil else { return }
        let revision = accountRevision, auth = cookie
        favoritesLoading = true
        favoritesTask = Task { [weak self] in
            guard let self else { return }
            defer { if accountRevision == revision { favoritesLoading = false } }
            do {
                if activePlatform == .qq {
                    let list = try await QQOnlineCatalog(cookie: auth).page(.init(kind: .playlist("201"), title: "我喜欢"))
                    guard !Task.isCancelled, accountRevision == revision else { return }
                    updateQQFavorites(from: list)
                    return
                }
                let ids = try await client.favoriteIDs(owner: owner, cookie: auth)
                guard accountRevision == revision, !Task.isCancelled else { return }
                favoriteIDs = ids
            } catch {
                guard accountRevision == revision, !Task.isCancelled else { return }
                report?("无法读取收藏：" + error.localizedDescription)
                if case OnlineError.loginRequired = error { handle(error) }
            }
        }
    }

    private func updateQQFavorites(from list: OnlinePage) {
        favoriteIDs = Set(list.ids)
        if let index = playlists.firstIndex(where: { $0.isFavorites == true }) {
            playlists[index].cover = list.tracks.first?.coverURL
        }
    }

    private func editQQSong(_ mid: String, directory: Int, add: Bool?) async -> String? {
        guard authentication == .verified else { return nil }
        let id = String(directory)
        let operation = directory == 201 ? "favorites" : "playlist/" + id
        guard songOperations.insert(operation).inserted else { return nil }
        let revision = accountRevision
        let catalog = QQOnlineCatalog(cookie: cookie)
        defer { if accountRevision == revision { songOperations.remove(operation) } }
        do {
            let kind = OnlinePageKind.playlist(id)
            let title = playlists.first(where: { $0.id == id })?.name ?? "我喜欢"
            let before = try await catalog.page(.init(kind: kind, title: title))
            let present = before.ids.contains(mid)
            guard accountRevision == revision, !Task.isCancelled else { return nil }
            let desired = add ?? !present
            var writeError: Error?
            if desired != present {
                do { try await catalog.editSong(mid, directory: directory, add: desired) }
                catch { writeError = error }
            }
            let fresh = try await catalog.page(.init(kind: kind, title: title))
            let confirmed = fresh.ids.contains(mid)
            guard accountRevision == revision, !Task.isCancelled else { return nil }
            guard confirmed == desired else {
                if let writeError { throw writeError }
                return "QQ 音乐未确认歌单变更，请重新打开歌单核对。"
            }
            if directory == 201 { updateQQFavorites(from: fresh) }
            pages[kind.key] = fresh
            if page?.kind == kind, requestedPage == nil {
                pageTask?.cancel()
                pageRevision = UUID()
                loading = false
                publish(fresh)
            }
            return directory == 201 ? (desired ? "已收藏" : "已取消收藏") : (desired ? "已添加到歌单" : "已从歌单移除")
        } catch {
            guard accountRevision == revision, !Task.isCancelled else { return nil }
            return "QQ 音乐歌单更新未确认：" + error.localizedDescription
        }
    }

    func toggleFavorite(_ song: String) async -> String? {
        if activePlatform == .qq { return await editQQSong(song, directory: 201, add: nil) }
        guard authentication == .verified, let owner = account?.id, let favoriteIDs else { return nil }
        let key = "favorites"
        guard songOperations.insert(key).inserted else { return nil }
        let revision = accountRevision, auth = cookie, liked = !favoriteIDs.contains(song)
        if liked { self.favoriteIDs?.insert(song) } else { self.favoriteIDs?.remove(song) }
        defer { if accountRevision == revision { songOperations.remove(key) } }
        do {
            try await client.setFavorite(song, liked: liked, cookie: auth)
        } catch {
            guard accountRevision == revision else { return nil }
            if case OnlineError.loginRequired = error { handle(error); return error.localizedDescription }
            guard let ids = try? await client.favoriteIDs(owner: owner, cookie: auth), ids.contains(song) == liked else {
                guard accountRevision == revision else { return nil }
                self.favoriteIDs = favoriteIDs
                return "收藏未能保存：" + error.localizedDescription
            }
        }
        guard accountRevision == revision else { return nil }
        let message = liked ? "已收藏" : "已取消收藏"
        guard let playlist = playlists.first(where: { $0.isFavorites == true }) else { return message }
        return await refreshEditedPlaylist(playlist, owner: owner, auth: auth, revision: revision, message: message)
    }

    func addSong(_ song: String, to id: String) async -> String? {
        if activePlatform == .qq { guard let directory = Int(id), (1..<200).contains(directory), editablePlaylists.contains(where: { $0.id == id }) else { return nil }; return await editQQSong(song, directory: directory, add: true) }
        guard let owner = account?.id, let playlist = editablePlaylists.first(where: { $0.id == id }) else { return nil }
        let key = "playlist/" + id
        guard songOperations.insert(key).inserted else { return nil }
        let revision = accountRevision, auth = cookie
        defer { if accountRevision == revision { songOperations.remove(key) } }
        do {
            let before = try await playlistPreview(id: id, title: playlist.name, cookie: auth)
            guard accountRevision == revision, authentication == .verified else { return nil }
            if before.ids.contains(song) { return "已在歌单中" }
            do {
                try await client.addSong(song, to: id, cookie: auth)
            } catch {
                guard accountRevision == revision else { return nil }
                if case OnlineError.loginRequired = error { throw error }
                guard let after = try? await playlistPreview(id: id, title: playlist.name, cookie: auth),
                      after.ids.contains(song) else { throw error }
                return await refreshEditedPlaylist(playlist, owner: owner, auth: auth, revision: revision, message: "已添加到歌单", preview: after, addedSong: song)
            }
            return await refreshEditedPlaylist(playlist, owner: owner, auth: auth, revision: revision, message: "已添加到歌单", addedSong: song)
        } catch {
            guard accountRevision == revision else { return nil }
            if case OnlineError.loginRequired = error { handle(error) }
            return "无法添加到歌单：" + error.localizedDescription
        }
    }

    func removeSong(_ song: String, from id: String) async -> String? {
        if activePlatform == .qq { guard let directory = Int(id), (1..<200).contains(directory), editablePlaylists.contains(where: { $0.id == id }) else { return nil }; return await editQQSong(song, directory: directory, add: false) }
        guard let owner = account?.id, let playlist = editablePlaylists.first(where: { $0.id == id }) else { return nil }
        let key = "playlist/" + id
        guard songOperations.insert(key).inserted else { return nil }
        let revision = accountRevision, auth = cookie
        defer { if accountRevision == revision { songOperations.remove(key) } }
        do {
            try await client.editPlaylist(song, playlist: id, removing: true, cookie: auth)
            guard accountRevision == revision else { return nil }
            let fresh = try await playlistPreview(id: id, title: playlist.name, cookie: auth)
            guard !fresh.ids.contains(song) else {
                return "网易云最新歌单仍包含这首歌，请重新打开歌单核对"
            }
            return await refreshEditedPlaylist(playlist, owner: owner, auth: auth, revision: revision,
                                               message: "已从歌单中删除", preview: fresh)
        } catch {
            guard accountRevision == revision else { return nil }
            if case OnlineError.loginRequired = error { handle(error) }
            return "无法从歌单中删除：" + error.localizedDescription
        }
    }

    private func refreshEditedPlaylist(_ playlist: OnlinePlaylist, owner: String, auth: String, revision: UUID,
                                       message: String, preview: OnlinePage? = nil, addedSong: String? = nil) async -> String? {
        guard accountRevision == revision else { return nil }
        let kind = OnlinePageKind.playlist(playlist.id), key = kind.key
        if warmSourceKey == key { cancelWarm() }
        if (requestedPage ?? page)?.kind == kind {
            pageTask?.cancel(); pageRevision = UUID(); loading = false
        }
        let previous = pages.removeValue(forKey: key)
        cachedPages.removeAll { $0.kind == kind }
        quickDetails[key] = nil
        if page?.kind == kind { page?.cachedAt = nil; page?.isCached = true }
        if requestedPage?.kind == kind { requestedPage = OnlinePage(kind: kind, title: playlist.name) }
        do {
            try await cacheIO.invalidatePage(kind, owner: owner)
            guard accountRevision == revision else { return nil }
            var fresh: OnlinePage
            if let preview { fresh = preview }
            else { fresh = try await playlistPreview(id: playlist.id, title: playlist.name, cookie: auth) }
            guard accountRevision == revision else { return nil }
            if let addedSong, !fresh.ids.contains(addedSong) {
                throw OnlineError.protocolFailure("网易云已接受添加，但最新歌单尚未包含这首歌，请重新打开歌单核对")
            }
            // Reuse metadata for surviving songs while taking order and membership from the server.
            let known = Dictionary((fresh.tracks + (previous?.tracks ?? [])).map { ($0.id, $0) }, uniquingKeysWith: { first, _ in first })
            fresh.tracks = fresh.ids.compactMap { known["netease/" + $0] }
            fresh.offset = fresh.ids.prefix { known["netease/" + $0] != nil }.count
            fresh.more = fresh.offset < fresh.total
            if let index = playlists.firstIndex(where: { $0.id == playlist.id }) {
                playlists[index].count = fresh.total
                if let cover = fresh.playlistCover { playlists[index].cover = cover }
            }
            pages[key] = fresh
            if browser.sourceKey == key && (requestedPage == nil || requestedPage?.kind == kind) {
                pageTask?.cancel(); pageRevision = UUID(); loading = false; requestedPage = nil
                cancelFilter()
                publish(fresh)
                if fresh.more { loadPage() }
            } else if requestedPage?.kind == kind {
                pageTask?.cancel(); pageRevision = UUID(); loading = false
                requestedPage = fresh
                loadPage()
            } else if page?.kind == kind {
                page = fresh
            }
            var disk = fresh; disk.isCached = true
            cachedPages = Array((cachedPages.filter { $0.kind != kind } + [disk]).suffix(8))
            try await cacheIO.savePage(disk, owner: owner)
            guard accountRevision == revision else { return nil }
            try await cacheIO.savePlaylists(playlists, owner: owner)
            return accountRevision == revision ? message : nil
        } catch {
            return accountRevision == revision ? message + "，但歌单暂未更新：" + error.localizedDescription : nil
        }
    }

    func cancelStartupSelection() { startupSelectionPending = false }
    func loadPlaylists(more: Bool = false) {
        guard activePlatform == .netease else { return }
        guard authentication == .verified, let account, !playlistsLoading, !more || playlistsMore else { return }
        playlistTask?.cancel(); playlistsLoading = true; notice = nil
        let revision = accountRevision; let auth = cookie; let offset = more ? playlists.count : 0
        playlistTask = Task { [weak self] in
            guard let self else { return }
            var loaded = false
            defer {
                if accountRevision == revision {
                    playlistsLoading = false
                    if loaded && playlistsMore { loadPlaylists(more: true) }
                }
            }
            do {
                let json = try await client.request("/api/user/playlist", ["uid": account.id, "offset": String(offset), "limit": "50", "includeVideo": "true"], cookie: auth, weapi: true)
                try Task.checkCancellation(); guard accountRevision == revision else { return }
                let values = json["playlist"].array.map(OnlinePlaylist.init).filter { !$0.id.isEmpty }
                let next = more ? playlists + values.filter { value in !playlists.contains { $0.id == value.id } } : values
                if more && next.count == playlists.count && json["more"].bool { throw OnlineError.protocolFailure("歌单分页未推进，请重试") }
                playlists = next
                playlistsMore = json["more"].bool && !values.isEmpty
                selectStartupPlaylist()
                loaded = true
                do { try await cacheIO.savePlaylists(playlists, owner: account.id) }
                catch { if accountRevision == revision { notice = "歌单已载入，但缓存保存失败：" + error.localizedDescription } }
            } catch { if !Task.isCancelled && accountRevision == revision { handle(error) } }
        }
    }
    func cancelFilter() { filterRevision = UUID(); filterTask?.cancel(); filterTask = nil; filtering = false; filterError = nil }
    func cancelSearchWork() {
        cancelFilter(); suggestTask?.cancel(); suggestionRevision = UUID(); suggestions = []
        if (requestedPage ?? page)?.kind.key.hasPrefix("search/") == true && loading {
            pageTask?.cancel(); pageRevision = UUID(); requestedPage = nil; loading = false
        }
    }
    @Published private(set) var quickSearchLoading = false
    @Published private(set) var quickSearchError: String?
    private var quickSearchRevision = UUID()
    /// Complete the existing source, including sparse playlist metadata, before
    /// presenting a definitive local-search result. Result data stays in page/workspace.
    func completeQuickListSearch() async {
        let revision = UUID()
        quickSearchRevision = revision
        quickSearchError = nil
        let source = browser.sourceKey, query = browser.quickListQuery
        quickSearchLoading = !query.isEmpty
        defer { if quickSearchRevision == revision { quickSearchLoading = false } }
        guard !query.isEmpty else { return }
        func isCurrent() -> Bool {
            !Task.isCancelled && quickSearchRevision == revision && browser.quickListOpen &&
                browser.sourceKey == source && browser.quickListQuery == query
        }
        while isCurrent() {
            if loading { await pageTask?.value }
            guard isCurrent(), let current = page else { return }
            if !current.more { return }
            let offset = current.offset
            loadPage()
            await pageTask?.value
            guard isCurrent() else { return }
            if page?.more == true && page?.offset == offset {
                quickSearchError = notice ?? "未能读取完整列表，请重试"
                return
            }
        }
    }
    func filterCurrentSource(_ query: String) {
        cancelFilter()
        guard let current = page else { return }
        let key = browser.sourceKey, visit = browser.visit, revision = filterRevision
        filterTask = Task { @MainActor [weak self] in
            guard let self else { return }
            filtering = true
            defer { if revision == filterRevision { filtering = false; filterTask = nil } }
            if case .playlist = current.kind {
                // Explicit search must include edits made in another client.
                loadPage(refreshPlaylist: true)
                await pageTask?.value
            }
            guard !Task.isCancelled, revision == filterRevision, browser.sourceKey == key, browser.visit == visit, let complete = page else { return }
            if case .playlist = complete.kind, complete.more || complete.cachedAt == nil {
                filterError = notice ?? "歌单未能更新完整，请重试"; return
            }
            browser.search(query, in: complete.tracks)
        }
    }
    func suggest(_ value: String) {
        searchDraft = value; suggestTask?.cancel(); suggestionRevision = UUID()
        let text = value.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty, text.count <= 200 else { suggestions = []; return }
        if activePlatform == .qq { suggestions = []; return }
        let retainedEntities = suggestions.filter { $0.kind != .keyword }
        let revision = suggestionRevision; let auth = cookie
        suggestTask = Task { [weak self] in
            guard let self else { return }
            do {
                try await Task.sleep(for: .milliseconds(180))
                async let keywords = client.request("/api/search/suggest/keyword", ["s": text], cookie: auth, weapi: true)
                async let entities = client.request("/api/search/suggest/web", ["s": text, "limit": "8"], cookie: auth, weapi: true)
                // Publish each response independently so a slow or failed endpoint
                // does not hide the other set of suggestions.
                var keywordRows: [SearchSuggestion]?
                do {
                    let result = try await keywords
                    try Task.checkCancellation(); guard revision == suggestionRevision else { return }
                    let rows: [SearchSuggestion] = Array(result["result"]["allMatch"].array.prefix(3)).compactMap {
                        let name = $0["keyword"].string
                        return name.isEmpty ? nil : SearchSuggestion(id: "keyword/" + name, kind: .keyword, name: name)
                    }
                    keywordRows = rows
                    let next = rows + retainedEntities
                    if !next.isEmpty { suggestions = next }
                } catch { if Task.isCancelled { return } }
                do {
                    let result = try await entities
                    try Task.checkCancellation(); guard revision == suggestionRevision else { return }
                    let data = result["result"]
                    var rows: [SearchSuggestion] = []
                    for item in data["artists"].array.prefix(3) {
                        rows.append(SearchSuggestion(id: "artist/" + item["id"].string, kind: .artist, name: item["name"].string, detail: "艺人", artwork: Self.suggestionArtwork(item["picUrl"].string.isEmpty ? item["img1v1Url"].string : item["picUrl"].string), destination: .artist(item["id"].string)))
                    }
                    for item in data["albums"].array.prefix(2) {
                        rows.append(SearchSuggestion(id: "album/" + item["id"].string, kind: .album, name: item["name"].string, detail: "专辑 · " + item["artist"]["name"].string, artwork: Self.suggestionArtwork(item["picUrl"].string), destination: .album(item["id"].string)))
                    }
                    for item in data["songs"].array.prefix(4) {
                        rows.append(SearchSuggestion(id: "song/" + item["id"].string, kind: .song, name: item["name"].string, detail: "歌曲 · " + item["artists"].array.map { $0["name"].string }.joined(separator: " / "), artwork: Self.suggestionArtwork(item["album"]["picUrl"].string)))
                    }
                    suggestions = (keywordRows ?? []) + rows
                    // Suggestion payloads omit album and song artwork; hydrate
                    // only the displayed results and discard stale responses.
                    let songRows = rows.filter { $0.kind == .song && $0.artwork == nil }
                    if !songRows.isEmpty {
                        do {
                            let songs = try await fetchSongs(songRows.map { String($0.id.dropFirst(5)) }, cookie: auth)
                            try Task.checkCancellation(); guard revision == suggestionRevision else { return }
                            for song in songs {
                                if let index = suggestions.firstIndex(where: { $0.id == "song/" + song["id"].string }) {
                                    suggestions[index].artwork = OnlineSong(song).cover
                                }
                            }
                        } catch { if Task.isCancelled { return } }
                    }
                    for row in rows where row.kind == .album && row.artwork == nil {
                        do {
                            let album = try await client.request("/api/v1/album/" + String(row.id.dropFirst(6)), cookie: auth, weapi: true)
                            try Task.checkCancellation(); guard revision == suggestionRevision else { return }
                            if let index = suggestions.firstIndex(where: { $0.id == row.id }) {
                                suggestions[index].artwork = Self.suggestionArtwork(album["album"]["picUrl"].string)
                            }
                        } catch { if Task.isCancelled { return } }
                    }
                } catch {
                    guard !Task.isCancelled, revision == suggestionRevision else { return }
                    if let keywordRows { suggestions = keywordRows }
                }
            } catch { /* Debounce cancellation. */ }
        }
    }
    private static func suggestionArtwork(_ value: String) -> URL? {
        guard !value.isEmpty else { return nil }
        return URL(string: value.replacingOccurrences(of: "http://", with: "https://"))
    }
    func selectSuggestion(_ value: SearchSuggestion) {
        if let destination = value.destination {
            suggestTask?.cancel(); suggestionRevision = UUID(); suggestions = []; searchDraft = value.name
            open(destination, title: value.name, suggestionDraft: value.name)
        } else { search(value.name, category: .combined) }
    }
    func search(_ value: String, category: SearchCategory? = nil) {
        let text = value.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty, text.count <= 200 else { return }
        suggestTask?.cancel(); suggestionRevision = UUID(); suggestions = []; searchDraft = text
        let keepList = browser.quickListOpen
        browser.quickListQuery = ""
        open(category.map { .classifiedSearch(text, $0) } ?? .search(text), title: "搜索：" + text)
        if keepList {
            requestedQuickList = requestedPage != nil
            browser.quickListOpen = true
        }
    }
    private var requestedQuickList = false
    func selectSearchCategory(_ category: SearchCategory) {
        let keepList = browser.quickListOpen
        defer {
            if keepList {
                requestedQuickList = requestedPage != nil
                browser.quickListOpen = true

            }
        }

        if requestedPage != nil, let page, page.kind.searchCategory == category {
            open(page.kind, title: page.title, intentOverride: .replace)
        }
        guard let current = page, let query = current.kind.searchQuery, current.kind.searchCategory != category else { return }
        open(.classifiedSearch(query, category), title: current.title, intentOverride: .replace)
    }
    func selectArtistAlbums(_ albums: Bool) {
        guard let current = page, let id = current.kind.artistID else { return }
        let kind: OnlinePageKind = albums ? .artistAlbums(id) : .artist(id)
        guard current.kind != kind else { return }
        let keepList = browser.quickListOpen
        open(kind, title: current.title, intentOverride: .replace)
        if keepList {
            requestedQuickList = requestedPage != nil
            browser.quickListOpen = true
            if requestedPage == nil { browser.quickListCenter = quickListEntries().first?.id }
        }
    }
    func openEntity(_ entity: BrowseEntity) {
        open(entity.destination, title: entity.title, intentOverride: .push)
    }
    func retryCurrentPage() { loadPage() }
    private func searchHandoffItem(_ next: OnlinePage) -> BrowseItem? {
        guard next.kind.searchQuery != nil, next.kind.key != browser.sourceKey || page?.cachedAt == nil else { return nil }
        let items = next.browseItems
        let id = browser.sourceKey == next.kind.key ? browser.location.anchor : nil
        return id.flatMap { target in items.first { $0.id == target } } ?? items.first
    }
    private func prepareSearchHandoff(_ next: OnlinePage) async throws {
        guard let item = searchHandoffItem(next) else { return }
        try await searchCoverPreparation(item, browser.preloadViewport, NSApplication.shared.mainWindow?.colorSpace.flatMap(ArtworkPresentation.init))
        try Task.checkCancellation()
    }
    @discardableResult
    func restoreLastSearch() -> Bool {
        guard let key = lastSearchPageKey else { return false }
        cancelFilter(); cancelStartupSelection()
        guard let saved = pages[key] else { return false }
        open(saved.kind, title: saved.title, intentOverride: .root)
        return true
    }
    private func rememberPage() { if let page { pages[page.kind.key] = page } }
    private func restoreSource(_ key: String) {
        rememberPage()
        pageTask?.cancel(); pageRevision = UUID(); loading = false; requestedPage = nil
        page = pages[key]; notice = nil
        if let page, page.kind.searchQuery != nil { lastSearchPageKey = page.kind.key }
        browser.sourceOwner = page == nil ? "local" : (account?.id ?? "guest")
        browser.sourceTotal = page?.total ?? 0
        browser.sourceOrderedIDs = page?.items?.map(\.id) ?? page?.ids.map { activePlatform.rawValue + "/" + $0 } ?? []
        browser.sourceOrdinals = Dictionary(browser.sourceOrderedIDs.enumerated().map { ($0.element, $0.offset) }, uniquingKeysWith: { first, _ in first })
        onPageChange?()
    }
    private func canReusePage(_ value: OnlinePage) -> Bool {
        if value.kind.classifiedSearch || value.kind.isArtistAlbums {
            if !value.isCached && value.cachedAt != nil { return true }
        }
        guard value.canReuseCompletePage() else { return false }
        guard case .playlist(let id) = value.kind,
              let playlist = playlists.first(where: { $0.id == id }) else { return true }
        guard playlist.count == value.total else { return false }
        if let cover = value.playlistCover, cover != playlist.cover { return false }
        if let updated = playlist.tracksUpdatedAt, let fetched = value.cachedAt,
           updated > fetched.timeIntervalSince1970 { return false }
        return true
    }
    func open(_ kind: OnlinePageKind, title: String, focus: String? = nil, suggestionDraft: String? = nil, intentOverride: BrowseIntent? = nil) {
        guard kind != .personalFM else { return }
        closeDailyStylePicker()
        requestedQuickList = false
        BrowseDiagnostics.shared.mark("page.requested")
        cancelFilter()
        cancelStartupSelection()
        let intent: BrowseIntent
        if let intentOverride { intent = intentOverride } else { switch kind { case .playlist, .dailyRecommendations, .dailyStyleRecommendations: intent = .root; case .album, .artist, .artistAlbums: intent = .catalog; default: intent = .push } }
        if kind == page?.kind, requestedPage == nil, kind.searchQuery == nil || browser.sourceKey == kind.key {
            let sourceChanged = browser.sourceKey != kind.key
            if sourceChanged || intent != .root {
                browser.switchSource(kind.key, intent: intent, focus: focus, fromSearchSuggestion: suggestionDraft != nil)
                if let suggestionDraft { searchDraft = suggestionDraft; browser.location.searchGlobal = true }
                if sourceChanged { onPageChange?() }
            }
            if let page, !canReusePage(page), !loading {
                if case .playlist = kind { loadPage(refreshPlaylist: true) }
                else { loadPage() }
            }
            return
        }
        rememberPage()
        pageTask?.cancel(); pageRevision = UUID(); loading = false
        requestedIntent = intent; requestedFocus = focus
        requestedSuggestionDraft = suggestionDraft
        if let existing = pages[kind.key] { requestedPage = existing }
        else if var cached = cachedPages.first(where: { $0.kind == kind }) {
            cached.isCached = true; requestedPage = cached
        } else { requestedPage = OnlinePage(kind: kind, title: title) }
        if let cached = requestedPage, canReusePage(cached) {
            if let item = searchHandoffItem(cached), let url = item.coverURL,
               !BrowseArtworkStore.shared.hasAvailablePreview(url, presentation: NSApplication.shared.mainWindow?.colorSpace.flatMap(ArtworkPresentation.init)) {
                loading = true; notice = nil
                let revision = pageRevision
                pageTask = Task { [weak self] in
                    guard let self else { return }
                    defer { if revision == pageRevision { loading = false } }
                    do {
                        try await prepareSearchHandoff(cached)
                        guard revision == pageRevision else { return }
                        publish(cached); requestedPage = nil
                    } catch { if !Task.isCancelled && revision == pageRevision { handle(error) } }
                }
                return
            }
            publish(cached); requestedPage = nil; return
        }
        if let cached = requestedPage, !cached.browseItems.isEmpty, kind.searchQuery == nil { publish(cached) }
        else if page == nil && (kind.classifiedSearch || kind.artistID != nil) {
            var empty = requestedPage!
            if case .artistAlbums = kind {
                empty.items = []; empty.collectionSubtitle = page?.collectionSubtitle; empty.collectionArtwork = page?.collectionArtwork
            }
            publish(empty)
        }
        if case .playlist = kind { loadPage(refreshPlaylist: true) }
        else { loadPage() }
    }
    func openPlaybackSnapshot(_ tracks: [LocalTrack], title: String, kind: OnlinePageKind? = nil, focus: String? = nil) {
        guard kind != .personalFM else { return }
        cancelFilter(); cancelStartupSelection(); rememberPage()
        pageTask?.cancel(); pageRevision = UUID(); loading = false
        requestedPage = nil; notice = nil
        let intent: BrowseIntent = browser.hasSearchTrail ? .root : .push

        if let kind, kind.searchQuery != nil, let focus, let saved = pages[kind.key],
           saved.tracks.contains(where: { $0.id == focus }) {
            browser.switchSource(kind.key, intent: intent, focus: focus)
            publish(saved)
            return
        }
        if let kind, case .playlist = kind, let focus {
            if var playlist = pages[kind.key] ?? cachedPages.first(where: { $0.kind == kind }) {
                // The playlist owns the slot order. The playback copy can supply
                // metadata for a song whose playlist details have not arrived.
                if !playlist.tracks.contains(where: { $0.id == focus }),
                   playlist.ids.contains(String(focus.dropFirst("netease/".count))),
                   let track = tracks.first(where: { $0.id == focus }) {
                    let known = Dictionary((playlist.tracks + [track]).map { ($0.id, $0) }, uniquingKeysWith: { first, _ in first })
                    playlist.tracks = playlist.ids.compactMap { known["netease/" + $0] }
                }
                if playlist.tracks.contains(where: { $0.id == focus }) {
                    browser.switchSource(kind.key, intent: intent, focus: focus)
                    publish(playlist)
                    if playlist.more && !playlist.isCached {
                        requestedPage = playlist
                        loadPage()
                    }
                    return
                }
            }
        }

        if kind?.isDailyRecommendation == true {
            browser.switchSource("playback", intent: intent, focus: focus)
            publish(OnlinePage(kind: .playback, title: title, tracks: tracks, total: tracks.count)); return
        }
        let destination: OnlinePageKind
        if let kind, case .playlist = kind, focus != nil { destination = .playback }
        else { destination = kind ?? .playback }
        browser.switchSource(destination.key, intent: intent, focus: focus)
        publish(OnlinePage(kind: destination, title: title, tracks: tracks, total: tracks.count))
    }

    func showLocal(intent: BrowseIntent = .root) {
        cancelStartupSelection(); rememberPage()
        pageTask?.cancel(); pageRevision = UUID(); requestedPage = nil; loading = false; notice = nil
        browser.sourceTotal = 0; browser.sourceOrderedIDs = []; browser.sourceOrdinals = [:]; browser.sourceOwner = "local"
        browser.switchSource("local", intent: intent)
        onPageChange?()
    }
    func back() { browser.back() }
    private func publish(_ value: OnlinePage) {
        let keepRecommendationList = browser.quickListOpen && page?.kind.isDailyRecommendation == true && value.kind.isDailyRecommendation
        var next = value
        browser.sourceOwner = account?.id ?? "guest"
        browser.sourceTotal = next.total
        let orderedIDs = next.items?.map(\.id) ?? next.ids.map { activePlatform.rawValue + "/" + $0 }
        if browser.sourceOrderedIDs != orderedIDs {
            browser.sourceOrderedIDs = orderedIDs
            browser.sourceOrdinals = Dictionary(orderedIDs.enumerated().map { ($0.element,$0.offset) }, uniquingKeysWith: { first, _ in first })
        }
        if browser.sourceKey != next.kind.key {
            browser.switchSource(next.kind.key, intent: requestedIntent, focus: requestedFocus, fromSearchSuggestion: requestedSuggestionDraft != nil)
            if let query = next.kind.searchQuery { browser.location.globalDraft = query; browser.location.searchGlobal = true }
            else if let draft = requestedSuggestionDraft { searchDraft = draft; browser.location.searchGlobal = true }
        }
        if !browser.roundWall {
            if next.wallAssignment != nil && next.wallAssignmentVersion != WallAssignment.version { browser.location.centerOnReturn = true }
            browser.restoreAssignment(next.wallAssignmentVersion == WallAssignment.version ? next.wallAssignment : nil, tracks: next.tracks, count: max(next.total, next.tracks.count))
            next.wallAssignment = browser.data(for: next.tracks).assignment; next.wallAssignmentVersion = WallAssignment.version
        }
        BrowseDiagnostics.shared.mark("page.published", fields: ["tracks": String(next.tracks.count), "cached": String(next.isCached)])
        BrowseDiagnostics.shared.count("metadata.publishedTracks", by: next.tracks.count)
        if next.kind.searchQuery != nil { lastSearchPageKey = next.kind.key }
        page = next; pages[next.kind.key] = next
        rememberRecommendationMode(next.kind)
        if requestedQuickList || keepRecommendationList {
            requestedQuickList = false
            browser.quickListOpen = true
            browser.quickListCenter = browser.location.anchor ?? quickListEntries().first?.id
        }
        onPageChange?()
    }
    func firstCover(playlistID: String) -> URL? { pages["playlist/" + playlistID]?.tracks.first?.coverURL }
    func loadMoreIfNeeded(visibleIndex: Int) {
        guard let page, page.more, !loading else { return }
        let threshold: Int
        switch page.kind { case .search, .classifiedSearch, .artistAlbums: threshold = 5; case .artist, .album: threshold = 20; default: return }
        if visibleIndex >= page.browseItems.count - threshold { loadPage() }
    }
    func loadPage(refreshPlaylist: Bool = false) {
        guard let visible = requestedPage ?? page, !loading || refreshPlaylist else { return }
        if case .playlist = visible.kind, authentication == .restoring || authentication == .offlineCache { return }
        if refreshPlaylist {
            cancelWarm()
            if page?.kind == visible.kind { page?.cachedAt = nil; page?.isCached = true }
        }
        let original = visible.isCached || refreshPlaylist || visible.kind.isDailyRecommendation ? OnlinePage(kind: visible.kind, title: visible.title) : visible
        pageTask?.cancel(); pageRevision = UUID(); let revision = pageRevision; let authRevision = accountRevision
        let auth = cookie; loading = true; notice = nil
        pageTask = Task { [weak self] in
            guard let self else { return }
            defer { if pageRevision == revision { loading = false } }
            do {
                if activePlatform == .qq {
                    let next = try await QQOnlineCatalog(cookie: auth).page(original)
                    try Task.checkCancellation()
                    guard revision == pageRevision, authRevision == accountRevision else { return }
                    publish(next)
                    requestedPage = nil
                    return
                }
                let owner = account?.id ?? "guest"
                if cachedPagesOwner != owner {
                    let document = await cacheIO.load(owner: owner)
                    try Task.checkCancellation()
                    guard revision == pageRevision, authRevision == accountRevision else { return }
                    cachedPages = document.pages; cachedPagesOwner = owner
                    if var preview = cachedPages.first(where: { $0.kind == original.kind }) {
                        preview.isCached = true; publish(preview)
                    }
                }
                var next = original
                let json: OnlineJSON
                switch original.kind {
                case .search, .classifiedSearch:
                    next = try await client.searchPage(original, cookie: auth)
                case .artistAlbums(let id):
                    let result = try await client.request("/api/artist/albums/" + id, ["offset": String(original.offset), "limit": "60", "total": "true"], cookie: auth, weapi: true)
                    let artist = result["artist"]
                    if !artist["name"].string.isEmpty { next.title = artist["name"].string }
                    if next.collectionArtwork == nil { next.collectionArtwork = Self.suggestionArtwork(artist["picUrl"].string) }
                    if next.collectionSubtitle == nil { next.collectionSubtitle = artist["alias"].array.map(\.string).joined(separator: "/") }
                    let values = result["hotAlbums"].array
                    var items = next.items ?? []
                    let known = Set(items.map(\.id))
                    items += values.map { BrowseItem.entity(BrowseEntity($0, kind: .album)) }.filter { !known.contains($0.id) }
                    items.sort { ($0.entity?.published ?? 0) > ($1.entity?.published ?? 0) }
                    next.items = items; next.offset += values.count
                    next.total = max(items.count, artist["albumSize"].int)
                    next.more = !values.isEmpty && result["more"].bool
                case .playlist(let id):
                    if warmSourceKey == original.kind.key, let warmTask, let preview = await warmTask.value { next = preview }
                    try Task.checkCancellation()
                    if next.ids.isEmpty && next.cachedAt == nil { next = try await playlistPreview(id: id, title: next.title, cookie: auth) }
                    var songs = Dictionary(next.tracks.map { ($0.online?.songID ?? $0.id, $0) }, uniquingKeysWith: { first, _ in first })
                    // Fresh playlist IDs are authoritative. Reuse matching metadata
                    // while it is revalidated, rather than shrinking an already
                    // displayed disk preview to 36/150 songs and cancelling covers.
                    let cachedPreview = visible.isCached ? visible : cachedPages.first { $0.kind == next.kind }
                    let freshIDs = Set(next.ids)
                    var staleIDs: Set<String> = []
                    for track in cachedPreview?.tracks ?? [] {
                        let id = track.online?.songID ?? track.id
                        if freshIDs.contains(id), songs[id] == nil {
                            songs[id] = track; staleIDs.insert(id)
                        }
                    }
                    @MainActor func publishPrefix() throws {
                        try Task.checkCancellation()
                        guard revision == pageRevision, authRevision == accountRevision else { throw CancellationError() }
                        let prefix = next.ids.prefix { songs[$0] != nil }
                        var available = self.quickDetails[next.kind.key] ?? [:]
                        for (id, track) in songs { available["netease/" + id] = track }
                        self.quickDetails[next.kind.key] = available
                        next.tracks = next.ids.compactMap { available["netease/" + $0] }
                        next.offset = prefix.count; next.more = next.offset < next.total; next.isCached = !staleIDs.isEmpty
                        if !next.tracks.isEmpty && !(page?.kind == next.kind && page?.tracks == next.tracks && page?.total == next.total && page?.more == next.more && page?.isCached == next.isCached) { publish(next) }
                    }
                    try publishPrefix()
                    for limit in [36, 150] {
                        let missing = next.ids.prefix(limit).filter { songs[$0] == nil || staleIDs.contains($0) }
                        if !missing.isEmpty {
                            for song in try await fetchSongs(missing, cookie: auth) {
                                songs[song["id"].string] = OnlineSong(song).track
                                staleIDs.remove(song["id"].string)
                            }
                            guard missing.allSatisfy({ songs[$0] != nil && !staleIDs.contains($0) }) else { throw OnlineError.protocolFailure("部分歌曲详情暂不可用，请重试") }
                            try publishPrefix()
                        }
                    }
                    let missing = next.ids.filter { songs[$0] == nil || staleIDs.contains($0) }
                    let batches = stride(from: 0, to: missing.count, by: 500).map { Array(missing[$0..<min($0 + 500, missing.count)]) }
                    try await withThrowingTaskGroup(of: [LocalTrack].self) { group in
                        var cursor = 0
                        func enqueue() {
                            guard cursor < batches.count else { return }
                            let batch = batches[cursor]; cursor += 1
                            group.addTask { [client] in
                                let result = try await client.request("/api/v3/song/detail", ["c": "[" + batch.map { "{\"id\":\($0)}" }.joined(separator: ",") + "]"], cookie: auth, weapi: true)
                                let values = result["songs"].array
                                guard Set(values.map { $0["id"].string }).isSuperset(of: batch) else { throw OnlineError.protocolFailure("部分歌曲详情暂不可用，请重试") }
                                return values.map { OnlineSong($0).track }
                            }
                        }
                        for _ in 0..<min(2, batches.count) { enqueue() }
                        while let values = try await group.next() {
                            for song in values {
                                let id = song.online?.songID ?? song.id
                                songs[id] = song; staleIDs.remove(id)
                            }
                            try publishPrefix(); enqueue()
                        }
                    }
                    try publishPrefix()
                case .album(let id):
                    json = try await client.request("/api/v1/album/" + id, cookie: auth, weapi: true)
                    next.collectionSubtitle = json["album"]["artists"].array.map { $0["name"].string }.filter { !$0.isEmpty }.joined(separator: " / ")
                    if next.collectionSubtitle?.isEmpty != false { next.collectionSubtitle = json["album"]["artist"]["name"].string }
                    next.collectionArtwork = Self.suggestionArtwork(json["album"]["picUrl"].string)
                    append(json["songs"].array, to: &next); next.total = next.tracks.count; next.more = false
                case .artist(let id):
                    json = try await client.request("/api/v1/artist/songs", ["id": id, "private_cloud": "true", "work_type": "1", "order": "hot", "offset": String(next.offset), "limit": "100"], cookie: auth)
                    let values = json["songs"].array
                    if next.offset == 0 {
                        let popular = try await client.request("/api/v1/artist/" + id, cookie: auth, weapi: true)
                        let artist = popular["artist"]
                        var aliases: [String] = []
                        for name in (artist["transNames"].array + artist["alias"].array).map(\.string) where !name.isEmpty && !aliases.contains(name) { aliases.append(name) }
                        next.collectionSubtitle = aliases.joined(separator: "/")
                        next.collectionArtwork = await artistAvatar(id) ?? Self.suggestionArtwork(artist["picUrl"].string)
                        append(popular["hotSongs"].array, to: &next)
                    }
                    append(values, to: &next); next.offset += values.count; next.total = max(next.tracks.count, json["total"].int)
                    let more = json["more"].isNull ? values.count == 100 : json["more"].bool
                    next.more = !values.isEmpty && more && (json["total"].int <= 0 || next.offset < json["total"].int)
                case .dailyRecommendations, .dailyStyleRecommendations:
                    guard authentication == .verified else { throw OnlineError.loginRequired }
                    let songs: [OnlineSong]
                    if original.kind == .dailyStyleRecommendations {
                        let response = try await client.dailyStyleSongs(cookie: auth)
                        songs = response.songs; next.recommendationStyle = response.selection
                    } else { songs = try await client.dailyRecommendations(cookie: auth) }
                    next.tracks = songs.map(\.track); next.ids = songs.map(\.id); next.total = songs.count; next.offset = songs.count; next.more = false
                case .playback, .personalFM: break
                }
                try Task.checkCancellation(); guard revision == pageRevision, authRevision == accountRevision else { return }
                try await prepareSearchHandoff(next)
                try Task.checkCancellation(); guard revision == pageRevision, authRevision == accountRevision else { return }
                next.cachedAt = Date(); publish(next); requestedPage = nil
                if next.kind.searchQuery != nil { return }
                if case .playback = next.kind { return }
                var preview = page ?? next
                preview.isCached = true
                cachedPages.removeAll { $0.kind == preview.kind }
                cachedPages = Array((cachedPages + [preview]).suffix(8))
                do { try await cacheIO.savePage(preview, owner: owner) }
                catch { if revision == pageRevision, authRevision == accountRevision { notice = "歌曲已载入，但缓存保存失败：" + error.localizedDescription } }
            } catch { if !Task.isCancelled && revision == pageRevision && authRevision == accountRevision { handle(error) } }
        }
    }
    private func playlistPreview(id: String, title: String, cookie: String) async throws -> OnlinePage {
        let detail = try await client.request("/api/v6/playlist/detail", ["id": id, "n": "100000", "s": "0"], cookie: cookie)
        try Task.checkCancellation()
        guard case .array(let rows) = detail["playlist"]["trackIds"] else {
            throw OnlineError.protocolFailure("网易云未返回有效的歌单曲目")
        }
        let ids = rows.map { $0["id"].string }
        let songs = Dictionary(songsWithPrivileges(detail["playlist"]["tracks"].array, privileges: detail["privileges"].array).map { ($0["id"].string, OnlineSong($0).track) }, uniquingKeysWith: { first, _ in first })
        let prefix = ids.prefix { songs[$0] != nil }
        let name = detail["playlist"]["name"].string
        let cover = URL(string: detail["playlist"]["coverImgUrl"].string.replacingOccurrences(of: "http://", with: "https://"))
        return OnlinePage(kind: .playlist(id), title: name.isEmpty ? title : name, tracks: prefix.compactMap { songs[$0] }, offset: prefix.count, total: ids.count, ids: ids, more: prefix.count < ids.count, cachedAt: Date(), playlistCover: cover)
    }
    private func cancelWarm() {
        warmTask?.cancel(); warmTask = nil; warmSourceKey = nil
        for token in warmTokens { BrowseArtworkStore.shared.cancel(token) }; warmTokens = []
    }
    func warmPlaylist(_ playlist: OnlinePlaylist) {
        guard activePlatform == .netease else { return }
        let key = "playlist/" + playlist.id
        guard authentication != .restoring && authentication != .offlineCache else { return }
        guard browser.sourceKey != key, warmSourceKey != key, pages[key].map(canReusePage) != true else { return }
        cancelWarm(); warmSourceKey = key
        let revision = accountRevision, auth = cookie, owner = account?.id ?? "guest", viewport = browser.preloadViewport
        warmTask = Task { @MainActor [weak self] in
            guard let self else { return nil }
            do {
                let preview: OnlinePage
                if let cached = pages[key], canReusePage(cached) { preview = cached }
                else { preview = try await playlistPreview(id: playlist.id, title: playlist.name, cookie: auth) }
                try Task.checkCancellation(); guard accountRevision == revision else { return nil }
                pages[key] = preview; objectWillChange.send()
                guard preview.total > 0 else { return preview }
                let assignment = WallAssignment.online(preview.tracks, count: preview.total, identity: WallAssignment.json([owner, playlist.id]), previous: nil)
                let field = WallGeometry(count: preview.total, viewport: viewport, assignment: assignment)
                let camera = field.centered(on: 0), anchor = field.metrics.anchor
                let indices = field.visibleIndices(camera: camera).filter { preview.tracks.indices.contains($0) }.sorted { a,b in
                    if a == b { return false }; if a == 0 { return true }; if b == 0 { return false }
                    let x = field.rect(a), y = field.rect(b)
                    return hypot(x.midX + camera.x - anchor.x, x.midY + camera.y - anchor.y) < hypot(y.midX + camera.x - anchor.x, y.midY + camera.y - anchor.y)
                }
                for index in indices.prefix(6) {
                    if let url = preview.tracks[index].coverURL, let token = BrowseArtworkStore.shared.request(url, pixels: Int(ceil(field.rect(index).width * (NSScreen.main?.backingScaleFactor ?? 2))), center: false, visible: false, completion: { _ in }) { warmTokens.append(token) }
                }
                return preview
            } catch { return nil }
        }
    }
    private func fetchSongs(_ ids: [String], cookie: String) async throws -> [OnlineJSON] {
        let result = try await client.request("/api/v3/song/detail", ["c": "[" + ids.map { "{\"id\":\($0)}" }.joined(separator: ",") + "]"], cookie: cookie, weapi: true)
        return songsWithPrivileges(result["songs"].array, privileges: result["privileges"].array)
    }
    private func songsWithPrivileges(_ songs: [OnlineJSON], privileges: [OnlineJSON]) -> [OnlineJSON] {
        let byID = Dictionary(privileges.map { ($0["id"].string, $0) }, uniquingKeysWith: { first, _ in first })
        return songs.map { song in
            guard case .object(var fields) = song, let privilege = byID[song["id"].string] else { return song }
            fields["privilege"] = privilege
            return .object(fields)
        }
    }
    private var quickDetails: [String: [String: LocalTrack]] = [:]
    private var quickRequest: Task<Void, Never>?
    private var quickResolution: Task<[LocalTrack], Error>?
    private var quickResolutionID: UUID?
    func quickListEntries() -> [QuickListEntry] {
        guard let page else { return [] }
        if let items = page.items { return items.map { QuickListEntry(id: $0.id, track: $0.song, item: $0) } }
        let known = Dictionary(page.tracks.map { ($0.id, $0) }, uniquingKeysWith: { first, _ in first })
        guard !page.ids.isEmpty else { return page.tracks.map { QuickListEntry(id: $0.id, track: $0) } }
        return page.ids.map { id in
            let key = activePlatform.rawValue + "/" + id
            return QuickListEntry(id: key, track: known[key] ?? quickDetails[page.kind.key]?[key])
        }
    }
    private var pendingQuickIDs: [String]?
    private var quickDemandSource: String?
    func requestQuickDetails(_ ids: [String], priority: Bool = false) {
        let source = page?.kind.key
        if priority || source != quickDemandSource { quickRequest?.cancel(); quickRequest = nil }
        quickDemandSource = source; pendingQuickIDs = ids
        guard quickRequest == nil else { return }
        quickRequest = Task { @MainActor [weak self] in
            guard let self else { return }
            while !Task.isCancelled, let next = self.pendingQuickIDs {
                self.pendingQuickIDs = nil
                let started = ProcessInfo.processInfo.systemUptime
                do { _ = try await self.resolveQuickDetails(next) }
                catch { if !Task.isCancelled { self.notice = "读取歌曲信息失败：" + error.localizedDescription } }
                guard !Task.isCancelled else { return }
                let remaining = 0.1 - (ProcessInfo.processInfo.systemUptime - started)
                if remaining > 0 { do { try await Task.sleep(for: .seconds(remaining)) } catch { return } }
            }
            self.quickRequest = nil
        }
    }
    func resolveQuickDetails(_ ids: [String]) async throws -> [LocalTrack] {
        while let pending = quickResolution {
            let pendingID = quickResolutionID
            _ = try? await pending.value
            if quickResolutionID == pendingID { quickResolution = nil; quickResolutionID = nil }
            try Task.checkCancellation()
        }
        try Task.checkCancellation()
        let generation = UUID()
        let task = Task { @MainActor in try await self.fetchQuickDetails(ids) }
        quickResolution = task; quickResolutionID = generation
        defer { if quickResolutionID == generation { quickResolution = nil; quickResolutionID = nil } }
        return try await withTaskCancellationHandler { try await task.value } onCancel: { task.cancel() }
    }
    private func fetchQuickDetails(_ ids: [String]) async throws -> [LocalTrack] {
        guard let source = page else { return [] }
        if activePlatform == .qq {
            let tracks = Dictionary(source.tracks.map { ($0.id, $0) }, uniquingKeysWith: { first, _ in first })
            return ids.compactMap { tracks[$0] }
        }
        let sourceKey = source.kind.key, revision = accountRevision
        let known = Dictionary(source.tracks.map { ($0.id, $0) }, uniquingKeysWith: { first, _ in first })
        let missing = ids.filter { known[$0] == nil && quickDetails[sourceKey]?[$0] == nil }
        if !missing.isEmpty {
            let values = try await fetchSongs(Array(missing.prefix(32)).map { String($0.dropFirst("netease/".count)) }, cookie: cookie)
            try Task.checkCancellation()
            guard page?.kind.key == sourceKey, accountRevision == revision else { throw CancellationError() }
            for value in values { let track = OnlineSong(value).track; quickDetails[sourceKey, default: [:]][track.id] = track }
            objectWillChange.send()
        }
        return ids.compactMap { known[$0] ?? quickDetails[sourceKey]?[$0] }
    }
    func revealQuickTrack(_ track: LocalTrack) {
        guard var current = page, !current.tracks.contains(where: { $0.id == track.id }) else { return }
        let known = Dictionary((current.tracks + [track]).map { ($0.id, $0) }, uniquingKeysWith: { first, _ in first })
        current.tracks = current.ids.compactMap { known["netease/" + $0] }
        page = current; pages[current.kind.key] = current
    }
    func resolveReferencedSong(_ id: String) async throws -> LocalTrack {
        if let track = page?.tracks.first(where: { $0.id == id }) { return track }
        let values = try await fetchSongs([String(id.dropFirst("netease/".count))], cookie: cookie)
        try Task.checkCancellation()
        guard let value = values.first else { throw OnlineError.protocolFailure("歌曲信息暂不可用") }
        let track = OnlineSong(value).track
        guard track.id == id else { throw OnlineError.protocolFailure("歌曲详情与请求不一致") }
        return track
    }
    private func append(_ values: [OnlineJSON], to page: inout OnlinePage) {
        let known = Set(page.tracks.map(\.id))
        var added = Set<String>()
        page.tracks += values.map(OnlineSong.init).filter { !$0.id.isEmpty && !known.contains("netease/" + $0.id) && added.insert($0.id).inserted }.map(\.track)
    }
    func artistAvatar(_ id: String) async -> URL? {
        if let cached = artistAvatars[id] { return cached }
        let revision = accountRevision, auth = cookie
        do {
            let json = try await client.request("/api/artist/head/info/get", ["id": id], cookie: auth)
            try Task.checkCancellation(); guard revision == accountRevision else { return nil }
            guard let url = URL(string: json["data"]["artist"]["avatar"].string.replacingOccurrences(of: "http://", with: "https://")), url.scheme == "https" else { return nil }
            if artistAvatars.count >= 24, let key = artistAvatars.keys.first { artistAvatars[key] = nil }
            artistAvatars[id] = url; return url
        } catch { return nil } // Portraits are optional; keep the named fallback.
    }
    var lyricsPreparationRevision: UUID { accountRevision }
    func resolve(_ info: OnlineTrackInfo) async throws -> URL {
        try await resolveSource(info).url
    }
    func resolveSource(_ info:OnlineTrackInfo, reportingFailure:Bool = true) async throws -> OnlineAudioSource {
        if info.platform == .qq {
            guard activePlatform == .qq else { throw OnlineError.loginRequired }
            let revision = accountRevision
            let url = try await QQOnlineCatalog(cookie: cookie).playURL(mid: info.songID, mediaMID: info.mediaMID)
            try Task.checkCancellation()
            guard revision == accountRevision else { throw CancellationError() }
            return OnlineAudioSource(url: url, expires: Date().addingTimeInterval(300))
        }
        let revision = accountRevision
        do {
            if authentication == .restoring, let verificationTask {
                let restoration = loginTask
                let verified = try await verificationTask.value
                await restoration?.value
                try Task.checkCancellation()
                guard account == nil || account?.id == verified.id else { throw CancellationError() }
                guard revision == accountRevision else { throw CancellationError() }
            } else if authentication == .offlineCache { throw OnlineError.loginRequired }
            let auth = cookie
            let url = try await client.audioSource(info.songID, cookie: auth)
            try Task.checkCancellation(); guard revision == accountRevision else { throw CancellationError() }
            return url
        } catch {
            if reportingFailure && !Task.isCancelled && revision == accountRevision, case OnlineError.loginRequired = error { handle(error) }
            throw error
        }
    }
    #if DEBUG
    func validationResetAccount() { resetAccount() }
    func validationAccount(_ account: OnlineAccount, playlists: [OnlinePlaylist], verifiedCookie: String? = nil) { if let verifiedCookie { cookie = verifiedCookie; authentication = .verified }; self.account = account; self.playlists = playlists; cachedPages = cache.load(owner: account.id).pages; cachedPagesOwner = account.id; startupSelectionPending = false }
    #endif
    func lyrics(_ id: String) async throws -> OnlineJSON {
        try await client.request("/api/song/lyric/v1", ["id":id,"lv":"-1","kv":"-1","tv":"-1","rv":"-1","yv":"-1","ytv":"-1","yrv":"-1"], cookie:cookie)
    }
    func chorus(_ id: String) async throws -> [ChorusRange] {
        try await client.chorus(id, cookie: cookie)
    }
    func shutdown() { closeDailyStylePicker(); for task in dailyRefreshTasks.values { task.cancel() }; favoritesTask?.cancel(); quickRequest?.cancel(); quickResolution?.cancel(); cancelWarm(); cancelFilter(); cancelLogin(); pageTask?.cancel(); playlistTask?.cancel(); suggestTask?.cancel() }
    static func makeQR(_ text: String) -> NSImage? {
        let filter = CIFilter.qrCodeGenerator(); filter.message = Data(text.utf8); filter.correctionLevel = "M"
        guard let output = filter.outputImage?.transformed(by: CGAffineTransform(scaleX: 8, y: 8)), let image = CIContext().createCGImage(output, from: output.extent) else { return nil }
        return NSImage(cgImage: image, size: NSSize(width: 190, height: 190))
    }
}
