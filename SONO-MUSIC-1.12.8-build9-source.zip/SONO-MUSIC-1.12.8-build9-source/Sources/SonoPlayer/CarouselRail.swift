import AppKit

/// Scroll reveals navigation; hovering keeps it visible until the pointer leaves.
@MainActor
final class CarouselRail: NSControl {
    var position: Double = 0
    var count = 0 { didSet { if (oldValue > 1) != (count > 1) { bubbleVisibilityChanged() } } }
    var thumbPressed = false
    private var pressX: CGFloat = 0
    var moved: () -> Void = {}
    var cancelled: () -> Void = {}
    var began: () -> Void = {}
    var changed: (Double) -> Void = { _ in }
    var ended: () -> Void = {}
    var midpoint: (() -> Void)?
    var searchCount: (position: Double, left: Int, right: Int)?
    private var midpointArmed = false
    private var midpointHitRect: CGRect { CGRect(x: bounds.midX - 12, y: trackCenterY - 12, width: 24, height: 24) }
    private(set) var dragging = false { didSet { if oldValue != dragging { updateTrackStyle(); bubbleVisibilityChanged() } } }
    private var trackFillProgress: CGFloat = 0
    private var trackStyleTask: Task<Void, Never>?
    var bubbleVisibilityChanged: () -> Void = {}
    var bubbleVisible: Bool { !isHidden && indicatorVisible && count > 1 && (dragging || keyboardFocused) }
    var visibilityChanged: (Bool) -> Void = { _ in }
    private(set) var indicatorVisible = false {
        didSet {
            if oldValue != indicatorVisible {
                visibilityChanged(indicatorVisible)
                bubbleVisibilityChanged()
                window?.invalidateCursorRects(for: self)
            }
        }
    }
    private let trackCenterY: CGFloat = 44
    private var activationRect: CGRect { CGRect(x: 0, y: trackCenterY - 16, width: bounds.width, height: 32) }
    private var grab: CGFloat = 0
    private var armed = false
    private var hideTask: Task<Void, Never>?
    private var keyboardFocused = false { didSet { if oldValue != keyboardFocused { bubbleVisibilityChanged() } } }
    override var isHidden: Bool { didSet { if oldValue != isHidden { bubbleVisibilityChanged() } } }
    private var hovered = false
    override var isFlipped: Bool { true }
    override var acceptsFirstResponder: Bool { true }
    var knob: CGRect {
        let width = min(bounds.width, max(36, bounds.width / CGFloat(max(1, count))))
        let fraction = count > 1 ? CGFloat(position / Double(count - 1)) : 0
        let height: CGFloat = dragging && thumbPressed ? 8 : 4
        return CGRect(x: fraction * (bounds.width - width), y: trackCenterY + 2 - height, width: width, height: height)
    }
    override init(frame: NSRect) {
        super.init(frame: frame)
        wantsLayer = true; layer?.opacity = 0
        identifier = NSUserInterfaceItemIdentifier("carousel-scrollbar")
        setAccessibilityElement(true); setAccessibilityRole(.slider)
        setAccessibilityLabel("轮播浏览位置")
    }
    private func updateTrackStyle() {
        trackStyleTask?.cancel()
        let target: CGFloat = dragging ? 1 : 0
        guard !NSWorkspace.shared.accessibilityDisplayShouldReduceMotion else {
            trackFillProgress = target; needsDisplay = true; return
        }
        let initial = trackFillProgress
        let start = CACurrentMediaTime()
        trackStyleTask = Task { @MainActor [weak self] in
            while let self {
                let progress = min(1, (CACurrentMediaTime() - start) / 0.18)
                let eased = progress * progress * (3 - 2 * progress)
                self.trackFillProgress = initial + (target - initial) * eased
                self.needsDisplay = true
                if progress >= 1 { self.trackStyleTask = nil; return }
                do { try await Task.sleep(for: .milliseconds(16)) } catch { return }
            }
        }
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    func scrollActivity() {
        guard !isHidden else { return }
        layer?.removeAnimation(forKey: "rail-fade")
        CATransaction.begin(); CATransaction.setDisableActions(true); layer?.opacity = 1; CATransaction.commit()
        indicatorVisible = true; needsDisplay = true
        if let window {
            let point = convert(window.mouseLocationOutsideOfEventStream, from: nil)
            hovered = activationRect.contains(point)
            _ = updateCursor(at: point)
        }
        scheduleHide()
    }
    private func scheduleHide() {
        hideTask?.cancel()
        hideTask = nil
        guard indicatorVisible, !dragging, !midpointArmed, !hovered else { return }
        hideTask = Task { @MainActor [weak self] in
            do { try await Task.sleep(for: .seconds(2.5)) } catch { return }
            guard let self else { return }
            let fade = CABasicAnimation(keyPath: "opacity")
            fade.fromValue = Float(1); fade.toValue = Float(0); fade.duration = 0.2
            fade.timingFunction = CAMediaTimingFunction(name: .easeOut)
            // This task owns the fade lifetime, including views whose render
            // context is temporarily detached during a scene transition.
            fade.isRemovedOnCompletion = false
            CATransaction.begin(); CATransaction.setDisableActions(true)
            self.layer?.opacity = 0; self.layer?.add(fade, forKey: "rail-fade")
            CATransaction.commit()
            do { try await Task.sleep(for: .milliseconds(200)) } catch { return }
            self.layer?.removeAnimation(forKey: "rail-fade")
            self.indicatorVisible = false; self.needsDisplay = true; self.hideTask = nil
        }
    }
    func reset() {
        hideTask?.cancel(); hideTask = nil
        layer?.removeAnimation(forKey: "rail-fade")
        CATransaction.begin(); CATransaction.setDisableActions(true); layer?.opacity = 0; CATransaction.commit()
        let wasDragging = dragging
        dragging = false; armed = false; midpointArmed = false; keyboardFocused = false; hovered = false; indicatorVisible = false
        if wasDragging { ended() }
        needsDisplay = true
    }
    func finishInteraction() {
        midpointArmed = false
        guard dragging else { return }
        dragging = false; armed = false; ended(); scheduleHide()
    }
    override func viewDidChangeEffectiveAppearance() { super.viewDidChangeEffectiveAppearance(); needsDisplay = true }
    override func draw(_ dirtyRect: NSRect) {
        guard indicatorVisible, count > 1 else { return }
        for (rect, alpha) in [
            (CGRect(x: 0, y: trackCenterY + 1, width: bounds.width, height: 1), (hovered ? 1.0 : 0.5) * (1 - trackFillProgress)),
            (CGRect(x: 0, y: trackCenterY - 6, width: bounds.width, height: 8), 0.3 * trackFillProgress)
        ] where alpha > 0 {
            NSGradient(colorsAndLocations: (NSColor.white.withAlphaComponent(0), 0),
                       (SonoGeneratedColors.railTrack.withAlphaComponent(SonoGeneratedColors.railTrack.alphaComponent * alpha), 0.5),
                       (NSColor.white.withAlphaComponent(0), 1))?.draw(in: rect, angle: 0)
        }
        let midpointRect = CGRect(x: bounds.midX - 0.5, y: trackCenterY - 4, width: 1, height: 6)
        if midpoint != nil && !knob.intersects(midpointRect) {
            SonoGeneratedColors.railTrack.setFill()
            midpointRect.fill()
        }
        SonoGeneratedColors.railThumb.setFill()
        NSBezierPath(roundedRect: knob, xRadius: knob.height/2, yRadius: knob.height/2).fill()
        if bubbleVisible {
            let left = (searchCount?.position ?? 0) < 0
            let label: String
            if let searchCount {
                let current = Int(abs(searchCount.position).rounded())
                label = left ? "\(searchCount.left) / \(current)" : "\(current) / \(searchCount.right)"
            } else { label = "\(Int(position.rounded()) + 1) / \(count)" }
            let colors = SonoProgressBubbleColors(appearance: effectiveAppearance)
            let attributes: [NSAttributedString.Key: Any] = [.font: NSFont.monospacedDigitSystemFont(ofSize: SonoDesktopTokens.FontSize.caption, weight: SonoDesktopTokens.NativeFontWeight.medium), .foregroundColor: colors.text]
            let text = NSAttributedString(string: label, attributes: attributes)
            let width = ceil(text.size().width) + 16
            let rect = CGRect(x: max(0, min(bounds.width - width, knob.midX - width / 2)), y: knob.minY - SonoDesktopTokens.Spacing.s8 - 28, width: width, height: 28)
            colors.fill.setFill()
            NSBezierPath(roundedRect: rect, xRadius: 8, yRadius: 8).fill()
            text.draw(at: CGPoint(x: rect.minX + 8, y: rect.minY + 6))
        }
    }
    override func hitTest(_ point: NSPoint) -> NSView? {
        guard !isHidden, indicatorVisible, let parent = superview else { return nil }
        let local = convert(point, from: parent)
        return activationRect.contains(local) ? self : nil
    }
    override func updateTrackingAreas() {
        super.updateTrackingAreas()
        trackingAreas.forEach(removeTrackingArea)
        addTrackingArea(NSTrackingArea(rect: activationRect, options: [.activeInKeyWindow, .cursorUpdate, .mouseMoved, .mouseEnteredAndExited], owner: self))
    }
    @discardableResult
    func updateCursor(at point: CGPoint) -> Bool {
        guard !isHidden, indicatorVisible, activationRect.contains(point) else { return false }
        (dragging ? NSCursor.closedHand : .pointingHand).set()
        return true
    }
    override func mouseMoved(with event: NSEvent) {
        updateCursor(at: convert(event.locationInWindow, from: nil))
    }
    override func mouseEntered(with event: NSEvent) {
        hovered = true
        guard indicatorVisible else { return }
        scrollActivity()
        (dragging ? NSCursor.closedHand : .pointingHand).set()
    }
    override func mouseExited(with event: NSEvent) {
        hovered = false; needsDisplay = true
        scheduleHide()
        if !dragging { NSCursor.arrow.set() }
    }
    override func resetCursorRects() { if indicatorVisible { addCursorRect(activationRect, cursor: dragging ? .closedHand : .pointingHand) } }
    override func cursorUpdate(with event: NSEvent) { (indicatorVisible ? (dragging ? NSCursor.closedHand : .pointingHand) : .arrow).set() }
    override func mouseDown(with event: NSEvent) {
        armed = indicatorVisible
        guard armed else { return }
        window?.makeFirstResponder(self)
        keyboardFocused = false
        let point = convert(event.locationInWindow, from: nil)
        thumbPressed = CGRect(x: knob.minX, y: activationRect.minY, width: knob.width, height: activationRect.height).contains(point)
        pressX = point.x
        grab = thumbPressed ? point.x - knob.minX : knob.width / 2
        midpointArmed = midpoint != nil && midpointHitRect.contains(point)
        if midpointArmed { scrollActivity(); return }
        dragging = true; began(); mouseDragged(with: event)
    }
    override func mouseDragged(with event: NSEvent) {
        guard armed else { return }
        let point = convert(event.locationInWindow, from: nil)
        if midpointArmed {
            guard abs(point.x - pressX) > 4 else { return }
            midpointArmed = false; dragging = true; began()
        }
        guard dragging else { return }
        if abs(point.x - pressX) > 4 { moved() }
        let fraction = max(0, min(1, (point.x - grab) / max(1, bounds.width - knob.width)))
        changed(Double(fraction) * Double(max(0, count - 1)))
        scrollActivity(); NSCursor.closedHand.set()
    }
    override func mouseUp(with event: NSEvent) {
        if midpointArmed {
            midpointArmed = false; armed = false
            if midpointHitRect.contains(convert(event.locationInWindow, from: nil)) { midpoint?() }
            scrollActivity()
        }
        if dragging { mouseDragged(with: event); finishInteraction() }
        armed = false
        window?.invalidateCursorRects(for: self)
        NSCursor.pointingHand.set()
    }
    override func becomeFirstResponder() -> Bool { keyboardFocused = true; needsDisplay = true; return true }
    override func resignFirstResponder() -> Bool { keyboardFocused = false; finishInteraction(); needsDisplay = true; return true }
    override func keyDown(with event: NSEvent) {
        if event.keyCode == 53 && dragging { dragging = false; armed = false; cancelled(); scheduleHide(); return }
        let destination: Double
        switch event.keyCode {
        case 123: destination = position.rounded() - 1
        case 124: destination = position.rounded() + 1
        case 115: destination = 0
        case 119: destination = Double(max(0, count - 1))
        default: super.keyDown(with: event); return
        }
        keyboardFocused = true
        scrollActivity()
        move(to: destination)
    }
    private func move(to destination: Double) {
        thumbPressed = false
        began(); changed(max(0, min(Double(max(0, count - 1)), destination))); ended(); needsDisplay = true
    }
    override func accessibilityValue() -> Any? { position.rounded() + 1 }
    override func accessibilityMinValue() -> Any? { 1 }
    override func accessibilityMaxValue() -> Any? { count }
    override func accessibilityValueDescription() -> String? { "第\(Int(position.rounded()) + 1)首，共\(count)首" }
    override func setAccessibilityValue(_ value: Any?) {
        guard let number = value as? NSNumber else { return }
        move(to: number.doubleValue - 1)
    }
    override func accessibilityPerformIncrement() -> Bool { move(to: position.rounded() + 1); return true }
    override func accessibilityPerformDecrement() -> Bool { move(to: position.rounded() - 1); return true }
    override func accessibilityCustomActions() -> [NSAccessibilityCustomAction]? {
        guard midpoint != nil else { return super.accessibilityCustomActions() }
        return [NSAccessibilityCustomAction(name: "返回中点", target: self, selector: #selector(returnToMidpoint))]
    }
    @objc private func returnToMidpoint() -> Bool {
        guard let midpoint else { return false }
        midpoint(); scrollActivity(); return true
    }
}
