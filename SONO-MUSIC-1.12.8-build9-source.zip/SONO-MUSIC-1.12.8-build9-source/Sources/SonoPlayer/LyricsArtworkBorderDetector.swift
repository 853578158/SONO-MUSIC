import CoreGraphics

enum LyricsArtworkBorderDetector {
    private enum Edge: CaseIterable {
        case left, right, top, bottom

        var vertical: Bool { self == .left || self == .right }

        func pixel(in rect: CGRect, across: Int, depth: Int) -> (Int, Int) {
            let x = Int(rect.minX), y = Int(rect.minY)
            switch self {
            case .left: return (x + depth, y + across)
            case .right: return (Int(rect.maxX) - 1 - depth, y + across)
            case .top: return (x + across, y + depth)
            case .bottom: return (x + across, Int(rect.maxY) - 1 - depth)
            }
        }
    }

    private struct Pixel {
        let r: Int, g: Int, b: Int, a: Int

        var opaque: Bool { a >= 250 }

        var neutralExtreme: Bool {
            let low = min(r, g, b), high = max(r, g, b)
            return a >= 250 && high - low <= 12 && (low >= 230 || high <= 30)
        }

        func distance(to other: Self) -> Int {
            max(abs(r-other.r), abs(g-other.g), abs(b-other.b), abs(a-other.a))
        }
    }

    private struct Raster {
        let width: Int, height: Int
        let canvas: CGContext
        let bytes: UnsafePointer<UInt8>

        init?(_ image: CGImage, maxSide: Int) {
            let scale = min(1, Double(maxSide) / Double(max(image.width, image.height)))
            width = max(1, Int((Double(image.width) * scale).rounded()))
            height = max(1, Int((Double(image.height) * scale).rounded()))
            guard let space = CGColorSpace(name: CGColorSpace.sRGB),
                  let canvas = CGContext(data:nil, width:width, height:height, bitsPerComponent:8,
                                         bytesPerRow:width*4, space:space,
                                         bitmapInfo:CGBitmapInfo.byteOrder32Big.rawValue |
                                             CGImageAlphaInfo.premultipliedLast.rawValue),
                  let data = canvas.data else { return nil }
            canvas.interpolationQuality = .none
            canvas.draw(image, in:CGRect(x:0,y:0,width:width,height:height))
            self.canvas = canvas
            bytes = UnsafePointer(data.assumingMemoryBound(to: UInt8.self))
        }

        func pixel(_ position: (Int, Int)) -> Pixel {
            let i = (position.1 * width + position.0) * 4
            return Pixel(r:Int(bytes[i]), g:Int(bytes[i+1]), b:Int(bytes[i+2]), a:Int(bytes[i+3]))
        }

        func scaled(_ rect: CGRect, from original: CGRect) -> CGRect {
            let sx = Double(width) / original.width, sy = Double(height) / original.height
            let x = (rect.minX * sx).rounded(), y = (rect.minY * sy).rounded()
            return CGRect(x:x,y:y,width:(rect.maxX*sx).rounded()-x,height:(rect.maxY*sy).rounded()-y)
        }
    }

    private struct Band {
        let depth: Int
        let color: Pixel
        let seam: Int
    }

    static func contentRect(in image: CGImage) -> CGRect {
        let original = CGRect(x:0,y:0,width:image.width,height:image.height)
        guard min(image.width, image.height) >= 32,
              let preview = Raster(image, maxSide:384) else { return original }
        var full: Raster?
        var content = original
        for _ in 0..<3 {
            guard !Task.isCancelled else { return original }
            let small = preview.scaled(content, from:original)
            var bands: [Edge: Band] = [:]
            for edge in Edge.allCases {
                let limit = remainingLimit(edge, content:content, original:original)
                let alreadyTrimmed = limit < remainingLimit(edge, content:original, original:original)
                let scale = edge.vertical ? Double(preview.width)/original.width : Double(preview.height)/original.height
                guard limit >= 2,
                      let guess = candidate(edge, in:small, raster:preview,
                                            limit:Int((Double(limit)*scale).rounded()) + 1, tolerance:1, seam:alreadyTrimmed ? Int(ceil(2 * scale)) : 0) else { continue }
                if full == nil { full = Raster(image, maxSide:max(image.width,image.height)) }
                let expected = Double(guess.depth) / scale
                let slack = max(2, Int(ceil(2 / scale)))
                guard let full, let band = candidate(edge, in:content, raster:full,
                                                     limit:min(limit, Int(ceil(expected)) + slack), tolerance:2, seam:alreadyTrimmed ? 2 : 0),
                      band.depth >= 2, abs(Double(band.depth) - expected) <= Double(slack) else { continue }
                bands[edge] = band
            }
            guard let full, !bands.isEmpty else { break }

            // Orthogonal padding may occupy the corners of another band.
            // Revalidate if a proposed perpendicular cut fails.
            while !bands.isEmpty {
                let rejected = bands.compactMap { edge, band in
                    isBlank(edge, band:band, outer:content, bands:bands, raster:full) ? nil : edge
                }
                if rejected.isEmpty { break }
                for edge in rejected { bands[edge] = nil }
            }
            guard !bands.isEmpty else { break }
            content = inset(content, by:bands.mapValues(\.depth))
        }
        guard !Task.isCancelled else { return original }
        let originalPreview = preview.scaled(original, from:original)
        if Edge.allCases.contains(where: { overlayDepth($0, in:originalPreview, raster:preview) != nil }) {
            if full == nil { full = Raster(image, maxSide:max(image.width,image.height)) }
            if let full {
                var overlays: [Edge: Band] = [:]
                for edge in Edge.allCases {
                    let existing = remainingLimit(edge, content:original, original:original)
                        - remainingLimit(edge, content:content, original:original)
                    if let depth = overlayDepth(edge, in:original, raster:full), depth > existing {
                        overlays[edge] = Band(depth:depth-existing,color:full.pixel(edge.pixel(in:content,across:0,depth:0)),seam:0)
                    }
                }
                content = inset(content, by:overlays.mapValues(\.depth))
            }
        }
        var removedWidePadding = false
        for _ in 0..<3 {
            guard !Task.isCancelled else { return original }
            let small = preview.scaled(content, from:original)
            let candidates = Edge.allCases.filter {
                overlayDepth($0, in:small, raster:preview) != nil
                    || paddingDepth($0, in:small, raster:preview, allowNarrowWhite:removedWidePadding) != nil
            }
            guard !candidates.isEmpty else { break }
            if full == nil { full = Raster(image, maxSide:max(image.width,image.height)) }
            guard let full else { break }
            var bands: [Edge: Band] = [:]
            for edge in Edge.allCases {
                let depth = overlayDepth(edge, in:content, raster:full)
                    ?? (candidates.contains(edge) ? paddingDepth(edge, in:content, raster:full, allowNarrowWhite:removedWidePadding) : nil)
                if let depth, depth <= remainingLimit(edge, content:content, original:original) {
                    bands[edge] = Band(depth:depth,color:full.pixel(edge.pixel(in:content,across:0,depth:0)),seam:0)
                }
            }
            guard !bands.isEmpty else { break }
            removedWidePadding = true
            content = inset(content, by:bands.mapValues(\.depth))
        }
        // A narrow, low-contrast frame may survive stripping its outer layer.
        // Require continuity at both corners before using weaker seam evidence.
        guard !Task.isCancelled else { return original }
        let small = preview.scaled(content, from:original)
        let framedEdges = Edge.allCases.filter { narrowFrameDepth($0, in:small, raster:preview) != nil }
        var narrowDepths: [Edge: Int] = [:]
        if !framedEdges.isEmpty {
            if full == nil { full = Raster(image, maxSide:max(image.width,image.height)) }
            if let full {
                for edge in framedEdges {
                    if let depth = narrowFrameDepth(edge, in:content, raster:full),
                       depth <= remainingLimit(edge, content:content, original:original) {
                        narrowDepths[edge] = depth
                    }
                }
                content = inset(content, by:narrowDepths)
            }
        }
        guard let full else { return content }
        // Resampling can leave a short blend with the padding on the retained side
        // of a verified cut. Inspect it once, after all padding layers are resolved.
        var transitions: [Edge: Int] = [:]
        for edge in Edge.allCases {
            let remaining = remainingLimit(edge, content:content, original:original)
            let removed = remainingLimit(edge, content:original, original:original) - remaining
            guard removed >= 2, remaining > 0 else { continue }
            if narrowDepths[edge] != nil {
                // The first retained pixels of a low-contrast frame can still
                // contain its color even when the ordinary seam vote is weak.
                let allowance = min(4, Int(min(original.width, original.height)) / 300)
                guard allowance > 0 else { continue }
                let span = Int(edge.vertical ? content.height : content.width)
                let sampleCount = 48
                let votes = (0..<sampleCount).filter { sample in
                    let across = (2 * sample + 1) * span / (2 * sampleCount)
                    let pad = full.pixel(edge.pixel(in:content, across:across, depth:-2))
                    let first = full.pixel(edge.pixel(in:content, across:across, depth:0))
                    let inside = full.pixel(edge.pixel(in:content, across:across, depth:allowance))
                    return first.distance(to:pad) <= 8 && inside.distance(to:pad) > 8
                }.count
                if votes >= 4 { transitions[edge] = min(remaining, allowance) }
            } else {
                transitions[edge] = min(remaining, transitionDepth(edge, in:content, raster:full))
            }
        }
        return inset(content, by:transitions)
    }

    private static func narrowFrameDepth(_ edge: Edge, in rect: CGRect, raster: Raster) -> Int? {
        let span = Int(edge.vertical ? rect.height : rect.width)
        let limit = Int(min(rect.width, rect.height)) / 20
        guard span >= 32, limit >= 3 else { return nil }
        func pixel(_ across: Int, _ depth: Int) -> Pixel {
            raster.pixel(edge.pixel(in:rect, across:across, depth:depth))
        }
        let color = pixel(span / 2, 0)
        guard color.opaque,
              [1, span - 2].allSatisfy({ pixel($0, 0).distance(to:color) <= 8 }) else { return nil }
        let sampleCount = 48
        let depths = (0..<sampleCount).map { sample in
            let across = (2 * sample + 1) * span / (2 * sampleCount)
            return (0..<limit).first { depth in
                pixel(across, depth).distance(to:color) > 8 &&
                pixel(across, depth + 1).distance(to:color) > 8
            } ?? limit
        }
        let tolerance = max(1, limit / 20)
        for start in Set(depths).sorted() where start >= 2 && start < limit {
            let votes = depths.indices.filter { (start...min(limit - 1, start + tolerance)).contains(depths[$0]) }
            guard votes.count >= 16, votes.filter({ $0 < 16 }).count >= 2,
                  votes.filter({ $0 >= 32 }).count >= 2 else { continue }
            // Inspect the full band. Never erase a coherent mark inside it.
            for depth in 0..<start {
                var run = 0
                for across in 1..<(span - 1) {
                    let distance = pixel(across, depth).distance(to:color)
                    run = distance > 16 ? run + 1 : 0
                    if distance > 24 || run >= 2 { return nil }
                }
            }
            return start
        }
        return nil
    }

    private static func transitionDepth(_ edge: Edge, in rect: CGRect, raster: Raster) -> Int {
        let span = Int(edge.vertical ? rect.height : rect.width)
        guard (edge.vertical ? rect.width : rect.height) >= 6 else { return 0 }
        let samples = 48
        var votes = Array(repeating: 0, count: 4)
        for sample in 0..<samples {
            let across = (2 * sample + 1) * span / (2 * samples)
            func pixel(_ depth: Int) -> Pixel {
                raster.pixel(edge.pixel(in:rect, across:across, depth:depth))
            }
            let pad = pixel(-2), first = pixel(0), inside = pixel(4), neighbor = pixel(5)
            let contrast = pad.distance(to:inside)
            guard pad.opaque, first.opaque, inside.opaque, neighbor.opaque, contrast >= 32,
                  first.distance(to:pad) * 4 <= contrast * 3,
                  first.r >= min(pad.r,inside.r)-12, first.r <= max(pad.r,inside.r)+12,
                  first.g >= min(pad.g,inside.g)-12, first.g <= max(pad.g,inside.g)+12,
                  first.b >= min(pad.b,inside.b)-12, first.b <= max(pad.b,inside.b)+12 else { continue }
            let noise = max(10, 2 * inside.distance(to:neighbor))
            var error = first.distance(to:inside)
            for depth in votes.indices {
                let next = pixel(depth+1)
                let nextError = next.distance(to:inside)
                guard next.opaque, error > noise, nextError + 4 <= error else { break }
                votes[depth] += 1
                error = nextError
            }
        }
        return votes.prefix { $0 * 5 >= samples * 3 }.count
    }

    // A translucent frame preserves texture but introduces a consistent step
    // toward a neutral color. Demand support in each third of the edge.
    private static func overlayDepth(_ edge: Edge, in rect: CGRect, raster: Raster) -> Int? {
        let span = Int(edge.vertical ? rect.height : rect.width)
        let limit = Int(min(rect.width, rect.height)) / 20
        guard limit >= 2, span >= 32 else { return nil }
        for depth in 2...limit {
            var bright = [0, 0, 0], dark = [0, 0, 0]
            var textured = 0
            for sample in 0..<36 {
                let across = limit + (sample * 2 + 1) * (span-2*limit) / 72
                let outside = raster.pixel(edge.pixel(in:rect,across:across,depth:depth-2))
                let inside = raster.pixel(edge.pixel(in:rect,across:across,depth:depth+1))
                let outer = raster.pixel(edge.pixel(in:rect,across:across,depth:0))
                guard outside.opaque, inside.opaque, outer.opaque else { continue }
                let changes = [outside.r-inside.r, outside.g-inside.g, outside.b-inside.b]
                if changes.min()! >= 10 { bright[sample/12] += 1 }
                if changes.max()! <= -10 { dark[sample/12] += 1 }
                if outside.distance(to:outer) <= 12 { textured += 1 }
            }
            guard textured >= 24, bright.allSatisfy({ $0 >= 10 }) || dark.allSatisfy({ $0 >= 10 }) else { continue }
            // Uniform bands are handled by the stricter blank-strip check.
            let values = (0..<12).map {
                raster.pixel(edge.pixel(in:rect,across:(2*$0+1)*span/24,depth:0))
            }
            guard let reference = values.first,
                  values.filter({ $0.distance(to:reference) > 12 }).count >= 3 else { continue }
            return min(depth+1,limit)
        }
        return nil
    }

    private static func paddingDepth(_ edge: Edge, in rect: CGRect, raster: Raster, allowNarrowWhite: Bool) -> Int? {
        let span = Int(edge.vertical ? rect.height : rect.width)
        let extent = Int(edge.vertical ? rect.width : rect.height)
        let limit = extent/4
        guard limit > 2, span >= 32 else { return nil }
        let positions = (0..<48).map { span/12 + (2*$0+1)*span*5/576 }
        let colors = positions.map { raster.pixel(edge.pixel(in:rect,across:$0,depth:0)) }
        func median(_ component: KeyPath<Pixel, Int>) -> Int {
            colors.map { $0[keyPath:component] }.sorted()[colors.count/2]
        }
        let reference = Pixel(r:median(\.r),g:median(\.g),b:median(\.b),a:median(\.a))
        let nearWhite = min(reference.r,reference.g,reference.b) >= 245
        let minimum = allowNarrowWhite && nearWhite ? 2 : max(2, Int(min(rect.width,rect.height))/20)
        guard reference.opaque, colors.filter({ $0.distance(to:reference) <= 12 }).count >= 40 else { return nil }

        let depths = positions.map { across in
            (0..<limit).first { depth in
                let pixel = raster.pixel(edge.pixel(in:rect,across:across,depth:depth))
                let next = raster.pixel(edge.pixel(in:rect,across:across,depth:depth+1))
                return pixel.distance(to:reference) > 12 && next.distance(to:reference) > 12
            } ?? limit
        }
        let tolerance = max(2,extent/100)
        for start in Set(depths).sorted() where start >= minimum && start < limit {
            let support = depths.indices.filter { depths[$0] >= start && depths[$0] <= min(limit-1,start+tolerance) }
            guard support.count >= 22, support.filter({ $0 < 16 }).count >= 5,
                  support.filter({ $0 >= 32 }).count >= 5 else { continue }
            let safeDepth = max(0, start - max(2, extent / 300))
            for across in 1..<(span-1) {
                for depth in 0..<safeDepth where raster.pixel(edge.pixel(in:rect,across:across,depth:depth)).distance(to:reference) > 24 {
                    return nil
                }
            }
            let sorted = support.map { depths[$0] }.sorted()
            return sorted[sorted.count * 3 / 4]
        }
        return nil
    }

    #if SONO_VALIDATION
    static func validationNarrowWhiteLeftPadding(in image: CGImage) -> Int? {
        guard let raster = Raster(image, maxSide: max(image.width, image.height)) else { return nil }
        let rect = CGRect(x: 0, y: 0, width: image.width, height: image.height)
        return paddingDepth(.left, in: rect, raster: raster, allowNarrowWhite: true)
    }
    #endif

    private static func remainingLimit(_ edge: Edge, content: CGRect, original: CGRect) -> Int {
        switch edge {
        case .left: return Int(original.width / 4 - content.minX)
        case .right: return Int(content.maxX - original.width * 0.75)
        case .top: return Int(original.height / 4 - content.minY)
        case .bottom: return Int(content.maxY - original.height * 0.75)
        }
    }

    private static func inset(_ rect: CGRect, by depths: [Edge: Int]) -> CGRect {
        let left = depths[.left] ?? 0, right = depths[.right] ?? 0
        let top = depths[.top] ?? 0, bottom = depths[.bottom] ?? 0
        return CGRect(x:rect.minX+Double(left),y:rect.minY+Double(top),
                      width:rect.width-Double(left+right),height:rect.height-Double(top+bottom))
    }

    private static func candidate(_ edge: Edge, in rect: CGRect, raster: Raster,
                                  limit: Int, tolerance: Int, seam: Int) -> Band? {
        let span = Int(edge.vertical ? rect.height : rect.width)
        let extent = Int(edge.vertical ? rect.width : rect.height)
        let limit = min(limit, extent - 3)
        guard span >= 16, limit > seam else { return nil }
        // Locate the seam across the middle half. The full strip is checked below.
        let color = raster.pixel(edge.pixel(in:rect, across:span/2, depth:seam))
        guard color.opaque else { return nil }
        var depths: [Int] = []
        for sample in 0..<64 {
            let across = span/4 + sample*(span/2)/64
            for depth in seam...limit {
                let p = raster.pixel(edge.pixel(in:rect, across:across, depth:depth))
                guard p.distance(to:color) > 12 else { continue }
                let inside = raster.pixel(edge.pixel(in:rect, across:across, depth:depth+2))
                if depth > seam, inside.a >= 250, inside.distance(to:color) >= 22 {
                    depths.append(depth)
                }
                break
            }
        }
        guard depths.count >= 48 else { return nil }
        depths.sort()
        let middle = depths[depths.count/2]
        let aligned = depths.filter { abs($0-middle) <= tolerance }
        guard aligned.count >= 48, let depth = aligned.first else { return nil }
        return Band(depth:depth, color:color, seam:seam)
    }

    private static func isBlank(_ edge: Edge, band: Band, outer: CGRect, bands: [Edge: Band],
                                raster: Raster) -> Bool {
        let span = Int(edge.vertical ? outer.height : outer.width)
        let leadingEdge: Edge = edge.vertical ? .top : .left
        let trailingEdge: Edge = edge.vertical ? .bottom : .right
        let leading = bands[leadingEdge], trailing = bands[trailingEdge]
        let perpendicularCenter = Int(edge.vertical ? outer.width : outer.height) / 2
        func reference(_ edge: Edge, _ band: Band, depth: Int, center: Int) -> Pixel {
            guard depth < band.seam else { return band.color }
            let pixel = raster.pixel(edge.pixel(in:outer, across:center, depth:depth))
            return pixel.a >= 250 && max(pixel.r,pixel.g,pixel.b)-min(pixel.r,pixel.g,pixel.b) <= 12
                ? pixel : band.color
        }
        var deviations = 0
        var toleratesTransition = band.depth * 20 <= Int(min(outer.width, outer.height))
        for depth in 0..<band.depth {
            // A previously confirmed cut can expose a narrow gray transition
            // between two layers. It still has to be uniform along the edge.
            let color = reference(edge, band, depth:depth, center:span/2)
            var run = 0
            var transitionRun = 0
            let isInnerTransition = depth >= max(1, band.depth - 2)
            for across in 0..<span {
                let pixel = raster.pixel(edge.pixel(in:outer, across:across, depth:depth))
                var distance = pixel.distance(to:color)
                if let leading, across < leading.depth {
                    distance = min(distance, pixel.distance(to:reference(leadingEdge, leading, depth:across, center:perpendicularCenter)))
                }
                if let trailing, across >= span - trailing.depth {
                    distance = min(distance, pixel.distance(to:reference(trailingEdge, trailing, depth:span-1-across, center:perpendicularCenter)))
                }
                if distance > 12 {
                    deviations += 1
                    if toleratesTransition {
                        transitionRun += 1
                        toleratesTransition = isInnerTransition && distance <= 24 && pixel.opaque && transitionRun < 4
                    }
                } else {
                    transitionRun = 0
                }
                // Isolated encoding noise is acceptable. A coherent mark is not.
                run = distance > 24 ? run + 1 : 0
                if run >= (band.color.neutralExtreme ? 3 : 1) { return false }
            }
        }
        if deviations == 0 { return true }
        guard deviations * 200 <= span * band.depth else { return false }
        if band.color.neutralExtreme { return true }
        guard toleratesTransition else { return false }

        // The middle samples locate a candidate. Check its continuation near both
        // ends before accepting noise at the transition, even on a lone edge.
        let start = leading?.depth ?? 0
        let length = span - start - (trailing?.depth ?? 0)
        guard length >= 16 else { return false }
        for section in 0..<3 {
            var aligned = 0
            for sample in 0..<8 {
                let across = start + (section * 16 + sample * 2 + 1) * length / 48
                for offset in -2...2 where band.depth + offset > band.seam {
                    let depth = band.depth + offset
                    let extent = Int(edge.vertical ? outer.width : outer.height)
                    guard depth + 2 < extent else { continue }
                    let boundary = raster.pixel(edge.pixel(in:outer, across:across, depth:depth))
                    let inside = raster.pixel(edge.pixel(in:outer, across:across, depth:depth+2))
                    if boundary.distance(to:band.color) > 12 && inside.opaque && inside.distance(to:band.color) >= 22 {
                        aligned += 1
                        break
                    }
                }
            }
            if aligned < 5 { return false }
        }
        return true
    }
}
