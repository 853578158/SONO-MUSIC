import Foundation
import Metal
import simd

/// Sono-authored highlight compression. This is not Apple's BackdropLUT resource.
enum LyricsBackdropLUT {
    static func bytes() -> [UInt8] {
        var bytes = [UInt8](repeating:255,count:32*32*32*4)
        for z in 0..<32 { for y in 0..<32 { for x in 0..<32 {
            let rgb = SIMD3<Float>(Float(x),Float(y),Float(z))/31
            // Compress the brightest channel smoothly, scaling RGB together to
            // preserve hue and neutral grays. The previous S curve boosted
            // light artwork and left saturated channel endpoints at full white.
            let peak = max(rgb.x,rgb.y,rgb.z)
            let output = rgb/(1+0.6*peak)
            let index = ((z*32+y)*32+x)*4
            for channel in 0..<3 { bytes[index+channel] = UInt8((output[channel]*255).rounded()) }
        } } }
        return bytes
    }
    static func texture(device:MTLDevice) -> MTLTexture? {
        let descriptor = MTLTextureDescriptor(); descriptor.textureType = .type3D; descriptor.pixelFormat = .rgba8Unorm
        descriptor.width = 32; descriptor.height = 32; descriptor.depth = 32; descriptor.usage = .shaderRead; descriptor.storageMode = .shared
        guard let texture = device.makeTexture(descriptor:descriptor) else { return nil }
        let bytes = bytes()
        bytes.withUnsafeBytes { buffer in texture.replace(region:MTLRegionMake3D(0,0,0,32,32,32),mipmapLevel:0,slice:0,withBytes:buffer.baseAddress!,bytesPerRow:128,bytesPerImage:4096) }
        return texture
    }
}
enum LyricsBackdropMesh {
    /// Sono subdivision: smooth tensor B-spline patches, four samples per
    /// source cell. Boundary extrapolation preserves the regular grid. A bounded
    /// displacement Jacobian prevents folds throughout the from/to blend.
    /// This is independent of CAMeshTransform.subdividedMesh:2.
    static func subdivide(_ points:[SIMD2<Float>],segments:Int) -> [SIMD2<Float>] {
        let edge = segments+1, outputEdge = segments*4+1
        precondition(points.count == edge*edge && segments > 0)
        func at(_ x:Int,_ y:Int) -> SIMD2<Float> {
            if x < 0 { return 2*at(0,y)-at(1,y) }
            if x > segments { return 2*at(segments,y)-at(segments-1,y) }
            if y < 0 { return 2*at(x,0)-at(x,1) }
            if y > segments { return 2*at(x,segments)-at(x,segments-1) }
            return points[y*edge+x]
        }
        func cubic(_ a:SIMD2<Float>,_ b:SIMD2<Float>,_ c:SIMD2<Float>,_ d:SIMD2<Float>,_ t:Float) -> SIMD2<Float> {
            let t2 = t*t, t3 = t2*t
            return (a*pow(1-t,3)+b*(3*t3-6*t2+4)+c*(-3*t3+3*t2+3*t+1)+d*t3)/6
        }
        var result:[SIMD2<Float>] = [], regular:[SIMD2<Float>] = []
        result.reserveCapacity(outputEdge*outputEdge); regular.reserveCapacity(outputEdge*outputEdge)
        for y in 0..<outputEdge { for x in 0..<outputEdge {
            let px = Float(x)/4, py = Float(y)/4, ix = min(segments-1,Int(px)), iy = min(segments-1,Int(py))
            let tx = px-Float(ix), ty = py-Float(iy)
            let a = cubic(at(ix-1,iy-1),at(ix,iy-1),at(ix+1,iy-1),at(ix+2,iy-1),tx)
            let b = cubic(at(ix-1,iy),at(ix,iy),at(ix+1,iy),at(ix+2,iy),tx)
            let c = cubic(at(ix-1,iy+1),at(ix,iy+1),at(ix+1,iy+1),at(ix+2,iy+1),tx)
            let d = cubic(at(ix-1,iy+2),at(ix,iy+2),at(ix+1,iy+2),at(ix+2,iy+2),tx)
            var point = cubic(a,b,c,d,ty)
            // Keep the outer contour at or beyond the viewport. Overshooting
            // interpolants otherwise leave unrendered slivers at screen edges.
            if x == 0 { point.x = min(0,point.x) }; if x == outputEdge-1 { point.x = max(1,point.x) }
            if y == 0 { point.y = min(0,point.y) }; if y == outputEdge-1 { point.y = max(1,point.y) }
            result.append(point); regular.append(SIMD2(Float(x),Float(y))/Float(outputEdge-1))
        } }
        let displacement = zip(result,regular).map { $0-$1 }
        var maximum:Float = 0
        let step = Float(outputEdge-1)
        for y in 0..<outputEdge-1 { for x in 0..<outputEdge-1 {
            let i = y*outputEdge+x
            let dx1 = (displacement[i+1]-displacement[i])*step, dy1 = (displacement[i+outputEdge]-displacement[i])*step
            let dx2 = (displacement[i+outputEdge+1]-displacement[i+outputEdge])*step, dy2 = (displacement[i+outputEdge+1]-displacement[i+1])*step
            maximum = max(maximum,sqrt(simd_length_squared(dx1)+simd_length_squared(dy1)),sqrt(simd_length_squared(dx2)+simd_length_squared(dy2)))
        } }
        // ||J(displacement)|| < 1 makes I+J non-singular. Convex interpolation
        // of two bounded fields keeps this property at every warp phase.
        let amount = min(1,0.85/max(0.85,maximum))
        return zip(regular,displacement).map { $0+$1*amount }
    }
}
struct LyricsSpectrumResponse {
    private var history = [SIMD4<Float>](repeating:.zero,count:4)
    private var power = SIMD4<Float>.zero
    private var average:Float = 0
    mutating func reset() { for i in 0..<4 { history[i] = .zero }; power = .zero; average = 0 }
    mutating func append(_ sample:SIMD4<Float>) { history[0] = history[1]; history[1] = history[2]; history[2] = history[3]; history[3] = sample }
    mutating func advance(deltaTime:Float = 1/60,settings:LyricsMusicMotionSettings = .init(enabled:true)) -> SIMD4<Float> {
        let input = history[0]*0.1+history[1]*0.2+history[2]*0.3+history[3]*0.4
        average += (input.w-average)*(1-exp(-deltaTime/3))
        let gate = min(1,max(0,(input.w-0.001)/0.007))
        let gain = gate > 0 ? min(3,max(1,0.18/max(0.06,average))) : 1
        let target = (input*gain*gate*gate*(3-2*gate)*settings.style.weights*2.4)
            .clamped(lowerBound:.zero,upperBound:SIMD4<Float>(repeating:1))
        let attack = settings.style.attack, release = settings.style.release
        for channel in 0..<4 {
            let time = target[channel] > power[channel] ? attack[channel] : release[channel]
            power[channel] += (target[channel]-power[channel])*(1-exp(-deltaTime/time))
        }
        let strength = settings.strength
        let deformation = strength*(0.65 + 0.7*strength)
        return settings.active ? power*SIMD4(deformation,deformation,deformation,strength) : .zero
    }
}
