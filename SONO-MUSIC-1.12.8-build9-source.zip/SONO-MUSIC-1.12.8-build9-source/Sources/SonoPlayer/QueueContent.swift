import AppKit
import SwiftUI

// Row geometry is needed only by that row's reorder gesture. Keeping it local
// avoids rebuilding the entire queue on every frame of a deletion collapse.
private struct QueueReorderGesture: ViewModifier {
    let changed: (DragGesture.Value, CGRect) -> Void
    let ended: () -> Void
    @ViewState private var frame = CGRect.zero
    func body(content: Content) -> some View {
        content.onGeometryChange(for: CGRect.self) { $0.frame(in: .named("queueViewport")) } action: { frame = $0 }
            .simultaneousGesture(DragGesture(minimumDistance: 6, coordinateSpace: .named("queueViewport"))
                .onChanged { changed($0, frame) }.onEnded { _ in ended() })
    }
}
private struct QueueScrollMetrics: Equatable { var offset = 0.0; var content = 0.0; var viewport = 0.0 }
@MainActor private final class QueueViewport: ObservableObject {
    @Published var metrics = QueueScrollMetrics()
}
private struct QueueScrollbarGeometry<Content: View>: View {
    @ObservedObject var viewport: QueueViewport
    let content: (QueueScrollMetrics) -> Content
    var body: some View { content(viewport.metrics) }
}

@MainActor final class QueuePresentationState: ObservableObject {
    @Published var history = false
}

struct QueueContent: View {
    @Environment(\.lyricsInk) private var ink
    @Environment(\.colorScheme) private var colorScheme
    @ObservedObject var session: PlayerSession
    @ObservedObject var state: QueuePresentationState
    @Environment(\.sonoTheme) private var theme
    let scale: CGFloat
    var embedded = false
    var visible = true
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @StateObject private var input = QueueInputCoordinator()
    @ViewState private var draggingEntry: UUID?
    @ViewState private var queueScroll = ScrollPosition(y: 0)
    // Only the scrollbar observes geometry updates; deletion must not invalidate
    // all queue entries just because the scroll content gets shorter.
    @State private var viewport = QueueViewport()
    private var queueMetrics: QueueScrollMetrics { viewport.metrics }
    @ViewState private var queueScrollPhase = ScrollPhase.idle
    @ViewState private var scrollbarVisible = false
    @GestureState private var draggingScrollbar = false
    @ViewState private var scrollbarDragStart: CGFloat?
    @ViewState private var dragOrder: [UUID] = []
    @ViewState private var dragOriginal: [UUID] = []
    @ViewState private var dragFrame = CGRect.zero
    @ViewState private var dragTranslation = CGSize.zero
    @ViewState private var dragScrollStart = 0.0
    @ViewState private var queueBrowsing = false
    @StateObject private var dragClock = QueueDragClock()
    @ViewState private var landingEntry: UUID?
    @ViewState private var landingY: CGFloat = 0
    @ViewState private var dragRowHeight: CGFloat = 72
    @ViewState private var landingTask: Task<Void, Never>?
    private var queueHistory: Bool { get { state.history } nonmutating set { state.history = newValue } }
    private var scrolling: Bool { queueScrollPhase != .idle || draggingEntry != nil || draggingScrollbar }
    private var displayedEntries: [QueueEntry] {
        guard draggingEntry != nil else { return session.upcoming }
        let entries = Dictionary(uniqueKeysWithValues:session.upcoming.map { ($0.id,$0) })
        return dragOrder.compactMap { entries[$0] }
    }
    var body: some View {
        Group {
            if embedded { panel }
            else {
                panel.frame(maxWidth: .infinity, maxHeight: .infinity)
                    .clipped()
                    .glass(radius: 0)
            }
        }.foregroundStyle(Color(nsColor: queueTitleColor))
            .onAppear {
                dragClock.tick = { dt in autoScrollQueue(dt: dt) }
                input.setActive(visible)
                session.onQueueEscape = {
                    if draggingEntry != nil { finishQueueDrag(commit: false); return true }
                    return input.closeOpenRows()
                }
            }
            .onChange(of: visible) { _, value in input.setActive(value); if !value { cancelInteractions() } }
            .onChange(of: state.history) { _, _ in cancelInteractions() }
            .onChange(of: session.upcoming.map(\.id)) { _, _ in if draggingEntry != nil { finishQueueDrag(commit: false) } }
            .onChange(of: session.activeEntry) { _, _ in
                cancelInteractions()
                if !queueBrowsing { queueScroll.scrollTo(edge: .top) }
            }
            .onChange(of: scale) { _, _ in cancelInteractions() }
            .onReceive(NotificationCenter.default.publisher(for: NSWindow.didResignKeyNotification)) { note in
                if note.object as? NSWindow === session.window { cancelInteractions() }
            }
            .onDisappear { cancelInteractions(); input.setActive(false) }
    }
    private func cancelInteractions() {
        finishQueueDrag(commit: false); input.cancel()
        landingTask?.cancel(); landingTask = nil; landingEntry = nil
    }

    private var queueUsesLightForeground: Bool {
        embedded ? ink.light : colorScheme == .light
    }

    private var queueTitleColor: NSColor {
        queueUsesLightForeground ? SonoGeneratedColors.queueTitleLight : SonoGeneratedColors.queueTitleDark
    }

    private var queueSecondaryColor: NSColor {
        queueUsesLightForeground ? SonoGeneratedColors.queueTextSecondaryLight : SonoGeneratedColors.queueTextSecondaryDark
    }

    private var selectedTabColor: NSColor {
        queueUsesLightForeground ? SonoGeneratedColors.queueSelectedTabLight : SonoGeneratedColors.queueSelectedTabDark
    }

    private var lyricsPlaybackForeground: NSColor? {
        guard embedded else { return nil }
        let appearance = NSAppearance(named: ink.light ? .darkAqua : .aqua)
        var color: NSColor?
        appearance?.performAsCurrentDrawingAppearance {
            color = SonoGeneratedColors.monochromeOnAccent.usingColorSpace(.sRGB)
        }
        return color ?? (ink.light ? .black : .white)
    }

    private var queueActionColor: NSColor {
        embedded ? (ink.light ? SonoGeneratedColors.lyricsQueueActionLight : SonoGeneratedColors.lyricsQueueActionDark) : (colorScheme == .light ? SonoGeneratedColors.queueAction : SonoGeneratedColors.queueActionDark)
    }

    private var controlHoverForeground: NSColor {
        let light = embedded ? ink.light : colorScheme == .light
        return light ? SonoGeneratedColors.interfaceHoverForeground : SonoGeneratedColors.interfaceHoverForegroundDark
    }

    static let rowContentInset = SonoDesktopTokens.Spacing.s16 + QueueRowMotion.chromeLeadingMargin

    private var panel: some View {
        let horizontalInset = SonoDesktopTokens.Spacing.s16
        let actionCenterInset = QueueRowMotion.chromeLeadingMargin + SonoDesktopTokens.Component.control / 2
        let tabBottomInset: CGFloat = embedded ? 11 : 0
        return VStack(spacing: SonoDesktopTokens.Spacing.s12) {
            HStack(spacing: 0) {
                HStack(spacing: SonoDesktopTokens.Spacing.s20 * scale) {
                    ForEach([false, true], id: \.self) { historical in
                        Button { finishQueueDrag(commit: false); queueHistory = historical; queueScroll.scrollTo(edge: .top) } label: {
                            Text(historical ? "历史记录" : "播放队列").font(SonoTypography.font(size: SonoDesktopTokens.FontSize.sectionTitle * scale, weight: SonoDesktopTokens.FontWeight.semibold)).lineLimit(1).fixedSize(horizontal: true, vertical: false)
                                .padding(.bottom, tabBottomInset)
                                .frame(height: embedded ? nil : SonoChromeMetrics.buttonSize)
                        }
                        .buttonStyle(SonoQueueButtonStyle(normal: queueHistory == historical ? selectedTabColor : (embedded ? (ink.light ? SonoGeneratedColors.lyricsQueueTabLight : SonoGeneratedColors.lyricsQueueTabDark) : (colorScheme == .light ? SonoGeneratedColors.queueTabLight : SonoGeneratedColors.queueTabDark)), light: queueUsesLightForeground, hover: controlHoverForeground, active: queueHistory != historical))
                        .alignmentGuide(VerticalAlignment.center) { dimensions in
                            dimensions[VerticalAlignment.center] - tabBottomInset / 2
                        }
                    }
                }
                Spacer(minLength: 0)
                Button { session.queueOpen = false } label: {
                    Image(systemName: "xmark")
                        .font(.system(size: SonoDesktopTokens.SymbolSize.control))
                        .sonoIconFrame(SonoDesktopTokens.IconFrame.s24)

                        .frame(width: SonoDesktopTokens.Component.control, height: SonoDesktopTokens.Component.control)
                        .contentShape(Circle())
                }
                .buttonStyle(SonoQueueButtonStyle(normal: embedded ? (ink.light ? SonoGeneratedColors.lyricsQueueCloseLight : SonoGeneratedColors.lyricsQueueCloseDark) : (colorScheme == .light ? SonoGeneratedColors.queueCloseLight : SonoGeneratedColors.queueCloseDark), light: queueUsesLightForeground, hover: controlHoverForeground))
                .accessibilityLabel("关闭播放队列")
                .padding(.trailing, actionCenterInset - SonoDesktopTokens.Component.control / 2)
            }
            .padding(.leading, QueueRowMotion.chromeLeadingMargin)
            HStack(spacing: SonoDesktopTokens.Spacing.s8) {
                Text(queueHistory ? "最近播放 · \(session.listeningRecords.count) 条" : "来自：\(session.queueTitle)").font(SonoTypography.font(size: SonoDesktopTokens.FontSize.caption)).foregroundStyle(Color(nsColor: queueSecondaryColor)).lineLimit(1)
                Spacer(minLength: 0)
                if !queueHistory && session.canUndoClear { Button("撤销") { session.undoClear() }.buttonStyle(SonoQueueButtonStyle(normal: queueActionColor, light: queueUsesLightForeground, hover: controlHoverForeground)).disabled(!session.queueEditingAllowed) }
                HStack(spacing: SonoDesktopTokens.Spacing.s8) {
                    if !queueHistory {
                        Button {
                            withAnimation(reduceMotion ? nil : .timingCurve(0.65, 0, 0.35, 1, duration: 0.28).delay(0.16)) {
                                queueScroll.scrollTo(edge: .top)
                            }
                        } label: {
                            Image(systemName: "arrow.up.to.line").font(.system(size: SonoDesktopTokens.SymbolSize.small)).sonoIconFrame(SonoDesktopTokens.IconFrame.s16).frame(width: SonoDesktopTokens.Component.inlineAction, height: SonoDesktopTokens.Component.inlineAction).contentShape(Rectangle())
                        }
                        .buttonStyle(SonoQueueButtonStyle(normal: queueActionColor, light: queueUsesLightForeground, hover: controlHoverForeground))
                        .help("定位当前")
                        .accessibilityLabel("定位当前")
                        .disabled(session.displayedTrack == nil)
                    }
                    if !queueHistory {
                        Button { session.clearQueue() } label: {
                            Image(systemName: "trash").font(.system(size: SonoDesktopTokens.SymbolSize.small)).sonoIconFrame(SonoDesktopTokens.IconFrame.s16).frame(width: SonoDesktopTokens.Component.inlineAction, height: SonoDesktopTokens.Component.inlineAction).contentShape(Rectangle())
                        }
                        .buttonStyle(SonoQueueButtonStyle(normal: queueActionColor, light: queueUsesLightForeground, hover: SonoGeneratedColors.queueDelete))
                        .help("清空待播")
                        .accessibilityLabel("清空待播")
                        .disabled(!session.queueEditingAllowed || session.upcoming.count <= 1)
                    }
                }
                .padding(.trailing, actionCenterInset - SonoDesktopTokens.Component.inlineAction / 2)
            }
            .padding(.leading, QueueRowMotion.chromeLeadingMargin)
            .font(SonoTypography.font(size: SonoDesktopTokens.FontSize.caption))
            .frame(height: 20)
            .padding(.top, SonoDesktopTokens.Spacing.s4)
            ScrollView {
                LazyVStack(spacing: SonoDesktopTokens.Spacing.s0) {
                    if queueHistory {
                        ForEach(session.listeningRecords) { record in queueRow(track: record.track, id: record.id, current: false, historical: true, scale: scale) }
                        if session.listeningRecords.isEmpty { Text("暂无播放历史").font(SonoTypography.font(size: SonoDesktopTokens.FontSize.caption)).foregroundStyle(Color(nsColor: queueSecondaryColor)).padding(.top, SonoDesktopTokens.Spacing.s16) }
                    } else {
                        ForEach(displayedEntries) { entry in
                            queueRow(track: entry.track, id: entry.id, current: entry.id == session.activeEntry, historical: false, scale: scale)
                                .offset(y: landingEntry == entry.id ? landingY : 0)
                                .opacity(draggingEntry == entry.id ? 0 : 1)
                                .modifier(QueueReorderGesture(changed: { value, frame in
                                    NSCursor.openHand.set()
                                    guard session.queueEditingAllowed, entry.id != session.activeEntry, !input.swiping, landingEntry == nil else { return }
                                    guard draggingEntry == entry.id || abs(value.translation.height) > abs(value.translation.width) * 1.25 else { return }
                                    updateQueueDrag(entry.id, translation: value.translation, frame: frame, scale: scale)
                                }, ended: { NSCursor.pointingHand.set(); if draggingEntry == entry.id { finishQueueDrag(commit: true) } }))
                        }
                        Color.clear.frame(height: 140)
                        if session.upcoming.isEmpty { Text("选择歌曲播放后，当前歌曲与待播列表会显示在这里").font(SonoTypography.font(size: SonoDesktopTokens.FontSize.caption)).foregroundStyle(Color(nsColor: queueSecondaryColor)) }
                    }
                }.padding(.leading, QueueRowMotion.leadingOverflow)
            }.coordinateSpace(name: "queueViewport").scrollPosition($queueScroll).scrollIndicators(.never)
                .onScrollGeometryChange(for: QueueScrollMetrics.self) { geo in QueueScrollMetrics(offset: geo.contentOffset.y, content: geo.contentSize.height, viewport: geo.containerSize.height) } action: { _, next in viewport.metrics = next }
                .onScrollPhaseChange { _, phase in
                    queueScrollPhase = phase
                    if phase == .interacting || phase == .tracking { queueBrowsing = true }
                }
                .overlay {
                    QueueDecorationSurface(input: input, divider: embedded ? (ink.light ? SonoGeneratedColors.lyricsDividerLight : SonoGeneratedColors.lyricsDividerDark) : (colorScheme == .light ? SonoGeneratedColors.dividerLight : SonoGeneratedColors.dividerDark), selectionForeground: lyricsPlaybackForeground, suppressedDividerID: draggingEntry ?? landingEntry)
                        .allowsHitTesting(false)
                }
                .overlay(alignment: .trailing) {
                    queueScrollbar.offset(x: horizontalInset - PanelScrollConfiguration.overlayThumbTrailingInset)
                }
                .overlay(alignment: .topLeading) {
                    if let id = draggingEntry, let entry = session.upcoming.first(where: { $0.id == id }) {
                        queueSongLabel(entry.track, scale: scale, artistColor: Color(nsColor: theme.foreground()), titleColor: Color(nsColor: theme.foreground()))
                            .padding(.trailing, QueueRowMotion.rowInset)
                            .frame(width: dragFrame.width, height: dragFrame.height)
                            .background {
                                RoundedRectangle(cornerRadius: QueueRowMotion.chromeCornerRadius)
                                    .fill(Color(nsColor: theme.color(pink: SonoGeneratedColors.queueDrag)))
                                    .padding(.leading, -QueueRowMotion.chromeLeadingMargin)
                            }
                            .shadow(color: Color(nsColor: SonoGeneratedColors.queueDragShadow), radius: 15, y: 12)
                            .offset(x: dragFrame.minX, y: dragFrame.minY + dragTranslation.height).allowsHitTesting(false)
                    }
                }
                .background { QueueDragClockSurface(clock: dragClock).frame(width: 0, height: 0) }
                .padding(.leading, -QueueRowMotion.leadingOverflow)
        }.padding(.horizontal, horizontalInset)
            .padding(.top, embedded ? 0 : SonoChromeMetrics.topInset)
            .padding(.bottom, SonoDesktopTokens.Spacing.s16 * scale)
    }
    private var queueScrollbar: some View {
        QueueScrollbarGeometry(viewport: viewport) { metrics in
        GeometryReader { proxy in
            if metrics.content > metrics.viewport && metrics.viewport > 0 {
                let height = min(proxy.size.height, max(SonoScrollbarStyle.minimumThumbHeight, proxy.size.height * metrics.viewport / metrics.content))
                let travel = proxy.size.height - height
                let range = metrics.content - metrics.viewport
                let offset = min(travel, max(0, metrics.offset / range * travel))
                Capsule().fill(Color(nsColor: embedded ? (ink.light ? SonoGeneratedColors.lyricsQueueScrollbarLight : SonoGeneratedColors.lyricsQueueScrollbarDark) : (colorScheme == .light ? SonoGeneratedColors.scrollbarLight : SonoGeneratedColors.scrollbarDark)))
                    .frame(width: SonoScrollbarStyle.thumbWidth, height: height)
                    .frame(width: proxy.size.width, alignment: .trailing)
                    .contentShape(Rectangle())
                    .gesture(DragGesture(minimumDistance: 0, coordinateSpace: .named("queueViewport"))
                        .updating($draggingScrollbar) { _, active, _ in active = true }
                        .onChanged { value in
                            guard travel > 0 else { return }
                            let start = scrollbarDragStart ?? offset
                            scrollbarDragStart = start
                            queueBrowsing = true
                            queueScroll.scrollTo(y: min(range, max(0, (start + value.translation.height) / travel * range)))
                        })
                    .offset(y: offset)
            }
        }
        }.frame(width: 16)
            .opacity(scrollbarVisible ? 1 : 0)
            .animation(reduceMotion ? nil : .easeOut(duration: 0.18), value: scrollbarVisible)
            .allowsHitTesting(scrollbarVisible)
            .onChange(of: draggingScrollbar) { _, active in
                if !active { scrollbarDragStart = nil }
            }
            .task(id: scrolling) {
                if scrolling { scrollbarVisible = true; return }
                guard scrollbarVisible else { return }
                do { try await Task.sleep(for: .seconds(5)) }
                catch { return }
                scrollbarVisible = false
            }
    }
    private func updateQueueDrag(_ id: UUID, translation: CGSize, frame: CGRect, scale: CGFloat) {
        guard session.queueEditingAllowed else { return }
        if draggingEntry == nil {
            input.cancel(); input.suppressClicks(); dragRowHeight = 72 * scale
            draggingEntry = id; dragOriginal = session.upcoming.map(\.id); dragOrder = dragOriginal
            dragFrame = frame; dragScrollStart = queueMetrics.offset; queueBrowsing = true; dragClock.start()
        }
        guard draggingEntry == id, let original = dragOriginal.firstIndex(of: id) else { return }
        dragTranslation = translation
        let shift = translation.height + queueMetrics.offset - dragScrollStart
        let minimum = dragOriginal.first == session.activeEntry ? 1 : 0
        let target = max(minimum, min(dragOriginal.count - 1, original + Int(floor(shift / (72 * scale) + 0.5))))
        var order = dragOriginal.filter { $0 != id }; order.insert(id, at: target)
        if order != dragOrder {
            input.performFeedback()
            withAnimation(reduceMotion ? nil : .interactiveSpring(response:0.25,dampingFraction:0.86)) { dragOrder = order }
        }
    }
    private func autoScrollQueue(dt: Double) {
        guard let id = draggingEntry, queueMetrics.viewport > 0 else { return }
        let y = dragFrame.midY + dragTranslation.height
        let speed = y < 48 ? -min(12, (48 - y) / 4) : y > queueMetrics.viewport - 48 ? min(12, (y - queueMetrics.viewport + 48) / 4) : 0
        if speed != 0 {
            queueScroll.scrollTo(y: min(max(0, queueMetrics.content - queueMetrics.viewport), max(0, queueMetrics.offset + speed * dt * 60)))
            updateQueueDrag(id, translation: dragTranslation, frame: dragFrame, scale: dragRowHeight / 72)
        }
    }
    private func finishQueueDrag(commit: Bool) {
        dragClock.stop()
        guard let id = draggingEntry else { return }
        let index = dragOrder.firstIndex(of: id)
        let before = index.flatMap { $0 + 1 < dragOrder.count ? dragOrder[$0 + 1] : nil }
        let original = dragOriginal.firstIndex(of: id) ?? 0
        let destination = commit ? (index ?? original) : original
        // Keep the released row at its exact visible position while the model reorders.
        landingEntry = id
        landingY = dragTranslation.height + queueMetrics.offset - dragScrollStart - CGFloat(destination - original) * dragRowHeight
        draggingEntry = nil; dragOrder = []; dragOriginal = []; dragTranslation = .zero
        if commit { session.moveEntry(id, before: before) }
        input.suppressClicks()
        landingTask?.cancel()
        if reduceMotion { landingY = 0; landingEntry = nil; return }
        landingTask = Task { @MainActor in
            await Task.yield()
            guard !Task.isCancelled else { return }
            withAnimation(reduceMotion ? nil : .timingCurve(0.2, 0.8, 0.2, 1, duration: 0.22)) { landingY = 0 }
            do { try await Task.sleep(for: .milliseconds(220)) } catch { return }
            landingEntry = nil
        }
    }

    @Environment(\.songActions) private var songActions

    private func queueRow(track: LocalTrack, id: UUID, current: Bool, historical: Bool, scale: CGFloat) -> some View {
        let remove: @MainActor () -> Void = {
            session.removeEntry(id)
        }
        return QueueSwipeRow(id: id, protected: historical || current || !session.queueEditingAllowed, scale: scale, input: input, remove: remove, moveToFront: {
            guard let first = session.upcoming.first(where: { $0.id != session.activeEntry }) else { return }
            withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.22)) { session.moveEntry(id, before: first.id) }
        }, menu: {
            guard draggingEntry == nil else { return nil }
            return queueSongMenu(track, id: id, current: current, historical: historical, remove: remove)
        }) {
        HStack(spacing: SonoDesktopTokens.Spacing.s16) {
            if historical {
                queueSongLabel(track, scale: scale, artistColor: Color(nsColor: queueSecondaryColor), replayEnabled: session.queueEditingAllowed, replay: {
                        guard input.canClick, draggingEntry == nil else { return }
                        session.replayListeningRecord(id)
                    })
            } else {
                Button {
                    guard input.canClick, draggingEntry == nil else { return }
                    if let entry = session.queue.first(where: { $0.id == id }) { session.playQueue(entry) }
                } label: {
                    queueSongLabel(track, scale: scale, artistColor: Color(nsColor: queueSecondaryColor))
                }
            }
            if current {
                CapsulePlaybackIndicator(playing: session.audio.isPlaying, foreground: lyricsPlaybackForeground)
                    .sonoIconFrame(SonoDesktopTokens.IconFrame.s20).frame(width: 24, height: 24).frame(width: SonoDesktopTokens.Component.control)
            }
            else {
                Button { input.showMenu(for: id) } label: {
                    Image(systemName: "ellipsis").font(.system(size: SonoDesktopTokens.SymbolSize.compact))
                        .sonoIconFrame(SonoDesktopTokens.IconFrame.s20).frame(width: 24, height: 24).frame(width: SonoDesktopTokens.Component.control)
                        .contentShape(Rectangle())
                }.buttonStyle(SonoQueueButtonStyle(normal: queueActionColor, light: queueUsesLightForeground, hover: controlHoverForeground))
                    .fixedSize().disabled(draggingEntry != nil)
                    .accessibilityLabel("更多操作：" + track.title)
            }
        }.frame(height: 72 * scale)
            .contentShape(Rectangle())
        }
    }

    private func queueSongLabel(_ track: LocalTrack, scale: CGFloat, artistColor: Color, titleColor: Color? = nil, replayEnabled: Bool = true, replay: (() -> Void)? = nil) -> some View {
        HStack(spacing: SonoDesktopTokens.Spacing.s16) {
            QueueSongCover(track: track, scale: scale, ink: ink, replay: replay, replayEnabled: replayEnabled)
            VStack(alignment: .leading, spacing: SonoDesktopTokens.Spacing.s4) {
                Text(track.title).font(SonoTypography.font(size: SonoDesktopTokens.FontSize.body * scale, weight: SonoDesktopTokens.FontWeight.semibold)).foregroundStyle(titleColor ?? Color(nsColor: queueTitleColor)).lineLimit(1)
                Text(track.artist).font(SonoTypography.font(size: SonoDesktopTokens.FontSize.caption * scale)).foregroundStyle(artistColor).lineLimit(1)
            }
            Spacer(minLength: 0)
        }
    }

    private func queueSongMenu(_ track: LocalTrack, id: UUID, current: Bool, historical: Bool, remove: @escaping @MainActor () -> Void) -> NSMenu? {
        let actions = songActions.items(track)
        let menu = NSMenu()
        menu.autoenablesItems = false
        if historical {
            menu.addItem(SongMenuItem(SongAction(title: "播放", enabled: session.queueEditingAllowed, perform: { session.replayListeningRecord(id) })))
            menu.addItem(SongMenuItem(SongAction(title: "下一首播放", enabled: session.queueEditingAllowed, perform: { session.queueListeningRecordNext(id) })))
            if !actions.isEmpty { menu.addItem(.separator()) }
        }
        if !historical, let entry = session.queue.first(where: { $0.id == id }) {
            let playable = (track.playable || track.online != nil)
            menu.addItem(SongMenuItem(SongAction(title: "播放", enabled: playable) { session.playQueue(entry) }))
            menu.addItem(SongMenuItem(SongAction(title: "下一首播放", enabled: playable && session.queueEditingAllowed) {
                session.queueTrackNext(track)
            }))
            if !actions.isEmpty { menu.addItem(.separator()) }
        }
        for action in actions { menu.addItem(SongMenuItem(action)) }
        if !historical && !current {
            if !actions.isEmpty { menu.addItem(.separator()) }
            menu.addItem(SongMenuItem(SongAction(title: "移出播放队列", enabled: session.queueEditingAllowed, perform: remove)))
        }
        return menu
    }
}

private struct QueueSongCover: View {
    let track: LocalTrack
    let scale: CGFloat
    let ink: LyricsInk
    let replay: (() -> Void)?
    let replayEnabled: Bool
    @State private var hovered = false

    private var artwork: some View {
        Group {
            if track.coverURL != nil { Cover(track: track) }
            else { RoundedRectangle(cornerRadius: 4).fill(Color(nsColor: SonoGeneratedColors.quickPlaceholder)).overlay { SonoIcon(name: "icon-music", size: SonoDesktopTokens.SvgSize.s24 * scale, tint: Color(nsColor: SonoGeneratedColors.interfacePlaceholderIcon)).sonoIconFrame(SonoDesktopTokens.IconFrame.s24 * scale) } }
        }.frame(width: SonoDesktopTokens.Cover.listCover * scale, height: SonoDesktopTokens.Cover.listCover * scale)
    }
    var body: some View {
        Group {
            if let replay {
                Button(action: replay) {
                    artwork.overlay {
                        if hovered {
                            Color(nsColor: SonoGeneratedColors.historyScrim)
                            Image(systemName: "play.fill").font(.system(size: SonoDesktopTokens.SymbolSize.listPlay * scale)).foregroundStyle(Color(nsColor: SonoGeneratedColors.artworkControlSurface)).sonoIconFrame(SonoDesktopTokens.IconFrame.s24 * scale)
                        }
                    }.contentShape(Rectangle())
                }.buttonStyle(.plain).disabled(!replayEnabled)
                    .onHover { hovered = $0; ($0 ? NSCursor.pointingHand : NSCursor.arrow).set() }
                    .accessibilityLabel("重新播放：" + track.title)
            } else { artwork }
        }.clipShape(RoundedRectangle(cornerRadius: 4))
    }
}
