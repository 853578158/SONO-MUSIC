import SwiftUI

struct SearchSuggestionRow: View {
    @Environment(\.sonoTheme) private var theme
    let value: SearchSuggestion
    let query: String
    let selected: Bool

    private func highlighted(_ text: String) -> Text {
        var result = AttributedString(text)
        result.foregroundColor = Color(nsColor: SonoGeneratedColors.suggestionText)
        let term = query.trimmingCharacters(in: .whitespacesAndNewlines)
        var matches: [Range<String.Index>] = []
        if !term.isEmpty {
            var start = text.startIndex
            while start < text.endIndex, let range = text.range(of: term, options: [.caseInsensitive, .diacriticInsensitive], range: start..<text.endIndex) {
                matches.append(range); start = range.upperBound
            }
            // Match a composing pinyin draft to the original Chinese characters.
            if matches.isEmpty, term.allSatisfy({ $0.isASCII && $0.isLetter }) {
                var roman = ""
                var spans: [(Range<Int>, Range<String.Index>)] = []
                for index in text.indices {
                    let end = text.index(after: index)
                    let syllable = String(text[index..<end]).applyingTransform(.toLatin, reverse: false)?.folding(options: [.diacriticInsensitive, .caseInsensitive], locale: Locale(identifier: "en_US_POSIX")).replacingOccurrences(of: " ", with: "") ?? ""
                    let offset = roman.count
                    roman += syllable
                    spans.append((offset..<roman.count, index..<end))
                }
                if let range = roman.range(of: term.lowercased()) {
                    let offsets = roman.distance(from: roman.startIndex, to: range.lowerBound)..<roman.distance(from: roman.startIndex, to: range.upperBound)
                    matches = spans.filter { $0.0.overlaps(offsets) }.map { $0.1 }
                }
            }
        }
        for range in matches {
            if let match = Range(range, in: result) {
                result[match].foregroundColor = Color(nsColor: theme.color(pink: SonoGeneratedColors.suggestionMatch))
                result[match].font = .system(size: SonoDesktopTokens.FontSize.label, weight: SonoDesktopTokens.FontWeight.semibold)
            }
        }
        return Text(result)
    }
    var body: some View {
        HStack(spacing: SonoDesktopTokens.Spacing.s8) {
            if value.kind == .keyword {
                SonoIcon(name: "icon-search", size: SonoDesktopTokens.SvgSize.s16, tint: Color(nsColor: SonoGeneratedColors.suggestionIcon)).sonoIconFrame(SonoDesktopTokens.IconFrame.s16)
            } else {
                AsyncImage(url: value.artwork) { image in image.resizable().scaledToFill() } placeholder: {
                    Color(nsColor: SonoGeneratedColors.quickPlaceholder).overlay {
                        Image(systemName: value.kind == .artist ? "person.fill" : "music.note").font(.system(size: SonoDesktopTokens.SymbolSize.listPlay)).foregroundStyle(Color(nsColor: SonoGeneratedColors.suggestionIcon)).sonoIconFrame(SonoDesktopTokens.IconFrame.s24)
                    }
                }.frame(width: SonoDesktopTokens.Cover.listCover, height: SonoDesktopTokens.Cover.listCover)
                    .clipShape(RoundedRectangle(cornerRadius: value.kind == .artist ? 22 : 6))
            }
            VStack(alignment: .leading, spacing: SonoDesktopTokens.Spacing.s4) {
                highlighted(value.name).lineLimit(1)
                if !value.detail.isEmpty { highlighted(value.detail).font(.system(size: SonoDesktopTokens.FontSize.caption)).lineLimit(1) }
            }
            Spacer(minLength: 0)
        }.padding(.horizontal, SonoDesktopTokens.Spacing.s8).frame(height: value.kind == .keyword ? 36 : 62)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(selected ? Color(nsColor: SonoGeneratedColors.suggestionSelection) : Color.clear, in: RoundedRectangle(cornerRadius: 10))
            .contentShape(Rectangle())
            .accessibilityElement(children: .ignore).accessibilityLabel(value.name + (value.detail.isEmpty ? "" : "，" + value.detail))
    }
}
