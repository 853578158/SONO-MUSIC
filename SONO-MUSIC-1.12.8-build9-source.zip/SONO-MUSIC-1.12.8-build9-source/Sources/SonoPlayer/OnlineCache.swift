import CryptoKit
import Foundation

struct OnlineCache: Sendable {
    struct Document: Codable, Sendable {
        var version = 1
        var savedAt = Date()
        var playlists: [OnlinePlaylist] = []
        var pages: [OnlinePage] = []
    }
    let root: URL
    init(root: URL? = nil) {
        self.root = root ?? PerformanceEnvironment.cacheDirectory(default: FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0].appendingPathComponent((Bundle.main.bundleIdentifier ?? "app.sono.native.preview") + "/Online", isDirectory: true), subdirectory: "Online")
    }
    private func url(_ owner: String) -> URL {
        root.appendingPathComponent("v1-" + SHA256.hash(data: Data(owner.utf8)).map { String(format: "%02x", $0) }.joined() + ".json")
    }
    func load(owner: String) -> Document {
        guard let data = try? Data(contentsOf: url(owner)), var document = try? JSONDecoder().decode(Document.self, from: RecommendationPersistenceMigration.data(data, cache: true)), document.version == 1,
              Date().timeIntervalSince(document.savedAt) < 7 * 86400 else { return Document() }
        document.pages.removeAll { $0.kind == .personalFM }
        return document
    }
    func save(_ document: Document, owner: String) throws {
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        var value = document; value.savedAt = Date()
        try JSONEncoder().encode(value).write(to: url(owner), options: .atomic)
    }
}

// Serial disk ownership prevents playlist/page writes from racing, and keeps
// JSON encoding and file IO away from AppKit's display callback.
actor OnlineCacheIO {
    private let cache: OnlineCache
    init(_ cache: OnlineCache) { self.cache = cache }
    func load(owner: String) -> OnlineCache.Document { cache.load(owner: owner) }
    func savePlaylists(_ playlists: [OnlinePlaylist], owner: String) throws {
        var document = cache.load(owner: owner); document.playlists = playlists
        try cache.save(document, owner: owner)
    }
    func invalidatePage(_ kind: OnlinePageKind, owner: String) throws {
        var document = cache.load(owner: owner)
        guard document.pages.contains(where: { $0.kind == kind }) else { return }
        document.pages.removeAll { $0.kind == kind }
        try cache.save(document, owner: owner)
    }
    func savePage(_ page: OnlinePage, owner: String) throws {
        var document = cache.load(owner: owner)
        document.pages.removeAll { $0.kind == page.kind }
        document.pages = Array((document.pages + [page]).suffix(8))
        try cache.save(document, owner: owner)
    }
}
