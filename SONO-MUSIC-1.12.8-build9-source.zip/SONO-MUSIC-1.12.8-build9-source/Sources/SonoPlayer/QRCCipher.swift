// SPDX-FileCopyrightText: Copyright (C) 2024-2025 沉默の金 <cmzj@cmzj.org>
// SPDX-License-Identifier: GPL-3.0-only
// Sono, 2026-11-23: Swift port of LDDC's cloud QRC cipher, using packed round keys.
// https://github.com/chenmozhijin/LDDC/tree/84631e8cd011fcc3f71ca0ae017e2c9758958ffc/LDDC/core/decryptor
import Foundation

enum QRCCipher {
    private static let initialBits = [
        30, 22, 14, 6, 62, 54, 46, 38, 28, 20, 12, 4, 60, 52, 44, 36,
        26, 18, 10, 2, 58, 50, 42, 34, 24, 16, 8, 0, 56, 48, 40, 32,
        31, 23, 15, 7, 63, 55, 47, 39, 29, 21, 13, 5, 61, 53, 45, 37,
        27, 19, 11, 3, 59, 51, 43, 35, 25, 17, 9, 1, 57, 49, 41, 33,
    ]
    private static let finalBits = [
        27, 59, 19, 51, 11, 43, 3, 35, 26, 58, 18, 50, 10, 42, 2, 34,
        25, 57, 17, 49, 9, 41, 1, 33, 24, 56, 16, 48, 8, 40, 0, 32,
        31, 63, 23, 55, 15, 47, 7, 39, 30, 62, 22, 54, 14, 46, 6, 38,
        29, 61, 21, 53, 13, 45, 5, 37, 28, 60, 20, 52, 12, 44, 4, 36,
    ]
    private static let expansionBits = [
        0, 31, 30, 29, 28, 27, 28, 27, 26, 25, 24, 23, 24, 23, 22, 21,
        20, 19, 20, 19, 18, 17, 16, 15, 16, 15, 14, 13, 12, 11, 12, 11,
        10, 9, 8, 7, 8, 7, 6, 5, 4, 3, 4, 3, 2, 1, 0, 31,
    ]
    private static let roundBits = [
        16, 25, 12, 11, 3, 20, 4, 15, 31, 17, 9, 6, 27, 14, 1, 22,
        30, 24, 8, 18, 0, 5, 29, 23, 13, 19, 2, 26, 10, 21, 28, 7,
    ]
    private static let keyShifts = [
        1, 1, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 1,
    ]
    private static let keyLeft = [
        56, 48, 40, 32, 24, 16, 8, 0, 57, 49, 41, 33, 25, 17, 9, 1,
        58, 50, 42, 34, 26, 18, 10, 2, 59, 51, 43, 35,
    ]
    private static let keyRight = [
        62, 54, 46, 38, 30, 22, 14, 6, 61, 53, 45, 37, 29, 21, 13, 5,
        60, 52, 44, 36, 28, 20, 12, 4, 27, 19, 11, 3,
    ]
    private static let keyCompression = [
        13, 16, 10, 23, 0, 4, 2, 27, 14, 5, 20, 9, 22, 18, 11, 3,
        25, 7, 15, 6, 26, 19, 12, 1, 40, 51, 30, 36, 46, 54, 29, 39,
        50, 44, 32, 47, 43, 48, 38, 55, 33, 52, 45, 41, 49, 35, 28, 31,
    ]
    private static let sboxes: [[UInt32]] = [
        [14, 4, 13, 1, 2, 15, 11, 8, 3, 10, 6, 12, 5, 9, 0, 7, 0, 15, 7, 4, 14, 2, 13, 1, 10, 6, 12, 11, 9, 5, 3, 8, 4, 1, 14, 8, 13, 6, 2, 11, 15, 12, 9, 7, 3, 10, 5, 0, 15, 12, 8, 2, 4, 9, 1, 7, 5, 11, 3, 14, 10, 0, 6, 13],
        [15, 1, 8, 14, 6, 11, 3, 4, 9, 7, 2, 13, 12, 0, 5, 10, 3, 13, 4, 7, 15, 2, 8, 15, 12, 0, 1, 10, 6, 9, 11, 5, 0, 14, 7, 11, 10, 4, 13, 1, 5, 8, 12, 6, 9, 3, 2, 15, 13, 8, 10, 1, 3, 15, 4, 2, 11, 6, 7, 12, 0, 5, 14, 9],
        [10, 0, 9, 14, 6, 3, 15, 5, 1, 13, 12, 7, 11, 4, 2, 8, 13, 7, 0, 9, 3, 4, 6, 10, 2, 8, 5, 14, 12, 11, 15, 1, 13, 6, 4, 9, 8, 15, 3, 0, 11, 1, 2, 12, 5, 10, 14, 7, 1, 10, 13, 0, 6, 9, 8, 7, 4, 15, 14, 3, 11, 5, 2, 12],
        [7, 13, 14, 3, 0, 6, 9, 10, 1, 2, 8, 5, 11, 12, 4, 15, 13, 8, 11, 5, 6, 15, 0, 3, 4, 7, 2, 12, 1, 10, 14, 9, 10, 6, 9, 0, 12, 11, 7, 13, 15, 1, 3, 14, 5, 2, 8, 4, 3, 15, 0, 6, 10, 10, 13, 8, 9, 4, 5, 11, 12, 7, 2, 14],
        [2, 12, 4, 1, 7, 10, 11, 6, 8, 5, 3, 15, 13, 0, 14, 9, 14, 11, 2, 12, 4, 7, 13, 1, 5, 0, 15, 10, 3, 9, 8, 6, 4, 2, 1, 11, 10, 13, 7, 8, 15, 9, 12, 5, 6, 3, 0, 14, 11, 8, 12, 7, 1, 14, 2, 13, 6, 15, 0, 9, 10, 4, 5, 3],
        [12, 1, 10, 15, 9, 2, 6, 8, 0, 13, 3, 4, 14, 7, 5, 11, 10, 15, 4, 2, 7, 12, 9, 5, 6, 1, 13, 14, 0, 11, 3, 8, 9, 14, 15, 5, 2, 8, 12, 3, 7, 0, 4, 10, 1, 13, 11, 6, 4, 3, 2, 12, 9, 5, 15, 10, 11, 14, 1, 7, 6, 0, 8, 13],
        [4, 11, 2, 14, 15, 0, 8, 13, 3, 12, 9, 7, 5, 10, 6, 1, 13, 0, 11, 7, 4, 9, 1, 10, 14, 3, 5, 12, 2, 15, 8, 6, 1, 4, 11, 13, 12, 3, 7, 14, 10, 15, 6, 8, 0, 5, 9, 2, 6, 11, 13, 8, 1, 4, 10, 7, 9, 5, 0, 15, 14, 2, 3, 12],
        [13, 2, 8, 4, 6, 15, 11, 1, 10, 9, 3, 14, 5, 0, 12, 7, 1, 15, 13, 8, 10, 3, 7, 4, 12, 5, 6, 11, 0, 14, 9, 2, 7, 11, 4, 1, 9, 12, 14, 2, 0, 6, 10, 13, 15, 3, 5, 8, 2, 1, 14, 7, 4, 10, 8, 13, 15, 12, 9, 0, 3, 5, 6, 11],
    ]

    private static func permute(_ value: UInt64, by bits: [Int]) -> UInt64 {
        bits.reduce(0) { ($0 << 1) | ((value >> $1) & 1) }
    }

    private static func schedule(_ key: ArraySlice<UInt8>) -> [UInt64] {
        let bytes = Array(key)
        func bit(_ index: Int) -> UInt32 {
            let byte = (index / 32) * 4 + 3 - (index % 32) / 8
            return UInt32((bytes[byte] >> (7 - index % 8)) & 1)
        }
        var left = keyLeft.reduce(UInt32(0)) { ($0 << 1) | bit($1) }
        var right = keyRight.reduce(UInt32(0)) { ($0 << 1) | bit($1) }
        return keyShifts.map { shift in
            left = ((left << shift) | (left >> (28 - shift))) & 0x0fff_ffff
            right = ((right << shift) | (right >> (28 - shift))) & 0x0fff_ffff
            return keyCompression.enumerated().reduce(UInt64(0)) { packed, entry in
                let (index, bit) = entry
                let word = index < 24 ? left : right
                let shift = 27 - (index < 24 ? bit : bit - 27)
                return (packed << 1) | UInt64((word >> shift) & 1)
            }
        }
    }

    private static let keys: [[UInt64]] = {
        let key = Array("!@#)(*$%123ZXC!@!@#)(NHL".utf8)
        return [Array(schedule(key[16..<24]).reversed()),
                schedule(key[8..<16]),
                Array(schedule(key[0..<8]).reversed())]
    }()

    private static let roundTables: [[UInt32]] = sboxes.enumerated().map { index, box in
        (0..<64).map { value in
            let entry = (value & 32) | ((value & 31) >> 1) | ((value & 1) << 4)
            return UInt32(permute(UInt64(box[entry]) << ((7 - index) * 4), by: roundBits))
        }
    }

    private static func crypt(_ input: UInt64, keys: [UInt64]) -> UInt64 {
        let permuted = permute(input, by: initialBits)
        var left = UInt32(truncatingIfNeeded: permuted >> 32)
        var right = UInt32(truncatingIfNeeded: permuted)
        for key in keys {
            let mixed = permute(UInt64(right), by: expansionBits) ^ key
            var transformed: UInt32 = 0
            for (index, table) in roundTables.enumerated() {
                transformed |= table[Int((mixed >> ((7 - index) * 6)) & 63)]
            }
            (left, right) = (right, left ^ transformed)
        }
        return permute((UInt64(right) << 32) | UInt64(left), by: finalBits)
    }

    static func decrypt(_ data: Data) throws -> Data {
        guard !data.isEmpty, data.count.isMultiple(of: 8) else {
            throw CocoaError(.fileReadCorruptFile)
        }
        var result = Data(capacity: data.count)
        data.withUnsafeBytes { input in
            for offset in stride(from: 0, to: input.count, by: 8) {
                var block = UInt64(bigEndian: input.loadUnaligned(fromByteOffset: offset, as: UInt64.self))
                for key in keys { block = crypt(block, keys: key) }
                var bytes = block.bigEndian
                withUnsafeBytes(of: &bytes) { result.append(contentsOf: $0) }
            }
        }
        return result
    }
}

// Port of LDDC's krc_decrypt. Sono retains header detection and text fallback
// at the provider boundary, shared by online lyrics and local imports.
enum KRCCipher {
    private static let key: [UInt8] = [64, 71, 97, 119, 94, 50, 116, 71, 81, 54, 49, 45, 206, 210, 110, 105]

    static func compressedPayload(_ data: Data) -> Data {
        Data(data.dropFirst(4).enumerated().map { offset, byte in
            byte ^ key[offset % key.count]
        })
    }
}
