import AppKit
import SwiftUI

/// Attach inside scroll content to configure the panel's native overlay scroller.
struct PanelScrollConfiguration: NSViewRepresentable {
    // The regular native overlay thumb leaves 3 pt at the trailing edge of the search panel.
    static let overlayThumbTrailingInset: CGFloat = 3

    // Reserve the full system scroller width, including its expanded hover state.
    static var contentClearance: CGFloat {
        NSScroller.scrollerWidth(for: .regular, scrollerStyle: .overlay) + 4
    }
    var usesCustomIndicator = false

    func makeNSView(context: Context) -> ConfigurationView { ConfigurationView() }
    func updateNSView(_ view: ConfigurationView, context: Context) {
        view.usesCustomIndicator = usesCustomIndicator
        view.configure()
    }

    final class ConfigurationView: NSView {
        var usesCustomIndicator = false
        override func hitTest(_ point: NSPoint) -> NSView? { nil }
        override func viewDidMoveToWindow() {
            super.viewDidMoveToWindow()
            configure()
        }
        override func layout() {
            super.layout()
            configure()
        }
        func configure() {
            guard let scrollView = enclosingScrollView else { return }
            if usesCustomIndicator {
                if scrollView.hasVerticalScroller {
                    scrollView.hasVerticalScroller = false
                    scrollView.tile()
                }
                return
            }
            // Keep the native overlay behavior while letting AppKit choose the knob color.
            if scrollView.scrollerStyle != .overlay { scrollView.scrollerStyle = .overlay }
            if !scrollView.autohidesScrollers { scrollView.autohidesScrollers = true }
            scrollView.scrollerKnobStyle = .default
            guard let scroller = scrollView.verticalScroller else { return }
            if scroller.controlSize != .regular {
                scroller.controlSize = .regular
                scrollView.tile()
            }
        }
    }
}

extension View {
    func panelOverlayScrollbar() -> some View {
        modifier(PanelOverlayScrollbar())
    }
}

private struct PanelOverlayScrollbar: ViewModifier {
    private struct Metrics: Equatable {
        var offset: CGFloat = 0
        var viewport: CGFloat = 0
        var content: CGFloat = 0
    }

    @Environment(\.colorScheme) private var colorScheme
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var metrics = Metrics()
    @State private var position = ScrollPosition()
    @State private var scrolling = false
    @State private var hovering = false
    @State private var dragStart: CGFloat?

    func body(content: Content) -> some View {
        content
            .scrollIndicators(.never)
            .scrollPosition($position)
            .onScrollGeometryChange(for: Metrics.self) { geometry in
                Metrics(offset: geometry.contentOffset.y + geometry.contentInsets.top,
                        viewport: geometry.containerSize.height, content: geometry.contentSize.height)
            } action: { _, next in
                metrics = next
            }
            .onScrollPhaseChange { _, phase in scrolling = phase != .idle }
            .overlay(alignment: .trailing) {
                GeometryReader { proxy in
                    let range = metrics.content - metrics.viewport
                    if range > 0, metrics.viewport > 0 {
                        let height = min(proxy.size.height, max(SonoScrollbarStyle.minimumThumbHeight,
                                                                 proxy.size.height * metrics.viewport / metrics.content))
                        let travel = proxy.size.height - height
                        let offset = min(travel, max(0, travel * metrics.offset / range))
                        Capsule()
                            .fill(Color(nsColor: colorScheme == .light ? SonoGeneratedColors.scrollbarLight : SonoGeneratedColors.scrollbarDark))
                            .frame(width: SonoScrollbarStyle.thumbWidth, height: height)
                            .offset(y: offset)
                            .gesture(DragGesture(minimumDistance: 0, coordinateSpace: .global)
                                .onChanged { value in
                                    guard travel > 0 else { return }
                                    let start = dragStart ?? offset
                                    dragStart = start
                                    position.scrollTo(y: min(range, max(0, (start + value.translation.height) * range / travel)))
                                }
                                .onEnded { _ in dragStart = nil })
                    }
                }
                .frame(width: SonoScrollbarStyle.thumbWidth)
                .padding(.trailing, PanelScrollConfiguration.overlayThumbTrailingInset)
                .opacity(scrolling || hovering || dragStart != nil ? 1 : 0)
                .animation(reduceMotion ? nil : .easeOut(duration: 0.18), value: scrolling || hovering)
                .allowsHitTesting(scrolling || hovering || dragStart != nil)
                .accessibilityHidden(true)
            }
            .onHover { hovering = $0 }
    }
}
