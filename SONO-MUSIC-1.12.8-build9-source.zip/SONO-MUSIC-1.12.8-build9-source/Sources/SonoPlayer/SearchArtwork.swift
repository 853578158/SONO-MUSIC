import AppKit
import QuartzCore

@MainActor
enum SearchArtwork {
    static func prepareCenter(_ item: BrowseItem, viewport: CGSize, presentation: ArtworkPresentation?) async throws {
        guard let url = item.coverURL else { return }
        let store = BrowseArtworkStore.shared
        if store.availablePreview(url, presentation: presentation) != nil { return }
        let side = BrowseMetrics(viewport: viewport).side
        let pixels = ArtworkPixelSize.demand(width: side, height: side, scale: NSApplication.shared.mainWindow?.backingScaleFactor ?? 2, remote: !url.isFileURL)
        let (events, continuation) = AsyncStream<Void>.makeStream(bufferingPolicy: .bufferingNewest(1))
        let started = BrowseDiagnostics.shared.start()
        defer { BrowseDiagnostics.shared.end("search.centerArtworkWait", started) }
        let token = store.request(url, pixels: pixels, center: true, progressive: true, presentation: presentation,
            preview: { _ in continuation.yield(()); continuation.finish() },
            completion: { _ in continuation.yield(()); continuation.finish() })
        continuation.onTermination = { _ in Task { @MainActor in store.cancel(token) } }
        for await _ in events { break }
        try Task.checkCancellation()
    }
    // Legacy persisted timeout flags are not evidence that a cover is absent.
    static func prepare(_ tracks: [LocalTrack]) -> [LocalTrack] {
        tracks.map { track in
            var value = track
            value.searchCoverFallback = track.coverURL == nil
            return value
        }
    }
}
