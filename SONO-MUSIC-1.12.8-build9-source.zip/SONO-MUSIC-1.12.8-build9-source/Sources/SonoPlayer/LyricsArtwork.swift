import AppKit
import SwiftUI
import CoreImage
import simd
import CryptoKit

private extension SIMD4 where Scalar == Float {
    var lab: SIMD3<Float> { SIMD3(x, y, z) }
}

/// One small analysis shared by the baked cover and the moving backdrop.
struct LyricsArtworkProfile: Sendable {
    var edge = SIMD3<Float>(repeating:0.3)
    var tint = SIMD3<Float>(repeating:0.3)
    var bright:Float = 0
    var saturation:Float = 1.5
    var tintAmount:Float = 0
    var median:Float = 0
    var light:Float = 0
    var base = SIMD3<Float>(repeating:0.82)
}
struct LyricsTextureArtwork: Sendable {
    let image: CGImage

}

struct LyricsArtworkAnalysis: @unchecked Sendable {
    let thumbnail:CGImage
    let profile:LyricsArtworkProfile
    var palette: CGImage?
    var textureArtwork: LyricsTextureArtwork?
    var flow: SIMD4<Float> = .zero
    var background: CGImage { palette ?? thumbnail }
    var cost: Int {
        [thumbnail, palette, textureArtwork?.image].compactMap { $0 }.reduce(0) { $0+$1.bytesPerRow*$1.height }
    }
}

struct LyricsCoverEdges: OptionSet, Hashable, Sendable {
    let rawValue: Int
    static let top = Self(rawValue: 1)
    static let bottom = Self(rawValue: 2)
    static let left = Self(rawValue: 4)
    static let right = Self(rawValue: 8)
    static let standard: Self = [.top, .bottom, .right]
    static let portrait: Self = [.bottom, .left, .right]
    static let all: Self = [.standard, .left]
    static let directions: [Self] = [.top, .bottom, .left, .right]

    var title: String {
        switch self {
        case .top: "上"
        case .bottom: "下"
        case .left: "左"
        default: "右"
        }
    }
}

struct LyricsCoverFeather {
    let landscape: LyricsCoverEdges
    let portrait: LyricsCoverEdges
    let layoutProgress: CGFloat
    let reveal: CGFloat

    var landscapeWeight: CGFloat { (1 - layoutProgress) * (1 - reveal) }
    var portraitWeight: CGFloat { layoutProgress * (1 - reveal) }

    // Grow a feather inward from the moving boundary. Blending mask opacity
    // alone leaves a straight seam wherever the other mask has a hard edge.
    var movingEdgeWidth: CGFloat {
        guard landscape == .standard, portrait == .portrait else { return 0 }
        let distanceFromRest = max(0, min(layoutProgress, 1 - layoutProgress))
        return 0.16 * CGFloat(LyricsArtworkProcessor.smooth(0, 0.16, Double(distanceFromRest))) * (1 - reveal)
    }

    var strengths: SIMD4<Float> {
        func strength(_ edge: LyricsCoverEdges) -> Float {
            Float((landscape.contains(edge) ? landscapeWeight : 0) + (portrait.contains(edge) ? portraitWeight : 0))
        }
        return SIMD4(strength(.top), strength(.bottom), strength(.left), strength(.right))
    }
}

enum LyricsArtworkProcessor {
    // Fixed classification reference: independent of user-selected display colors.
    static func lightContrastScore(_ background: SIMD3<Float>) -> Float {
        let primary = LyricsColor.luminance(SIMD3<Float>(28,33,40)/255*0.90 + background*0.10)
        let secondary = LyricsColor.luminance(SIMD3<Float>(37,43,52)/255)
        let luminance = LyricsColor.luminance(background)
        return log((luminance+0.05)/(max(primary, secondary)+0.05)/4.5)
    }
    static let context = CIContext(options:[.cacheIntermediates:false])
    static func smooth(_ low:Double,_ high:Double,_ value:Double) -> Double {
        let t = min(1,max(0,(value-low)/(high-low)))
        return t*t*(3-2*t)
    }
    static func mask(side:Int,blur:Bool = false,bright:Double = 0, featherLeft:Bool = false, edges: LyricsCoverEdges? = nil, overlay: Bool = false) -> CGImage {
        let edges = edges ?? (featherLeft ? .all : .standard)
        var pixels = [UInt8](repeating:0,count:side*side*4)
        for y in 0..<side { for x in 0..<side {
            let u = Double(x)/Double(side-1), v = Double(y)/Double(side-1)
            let q = pow(2*v-1,2)
            let start = 0.78-0.04*q, end = 1-0.015*q
            let right = edges.contains(.right) ? 1-smooth(start,end,u) : 1
            let left = edges.contains(.left) ? 1-smooth(start,end,1-u) : 1
            let horizontal = min(right, left)
            let top = edges.contains(.top) ? smooth(0,0.28+0.04*bright,v) : 1
            let bottom = edges.contains(.bottom) ? 1-smooth(0.72-0.04*bright,1,v) : 1
            let vertical = top * bottom
            let value = blur || overlay ? 1-horizontal*sqrt(vertical) : horizontal*vertical
            let byte = UInt8((255*value).rounded()), i = (y*side+x)*4
            pixels[i] = byte; pixels[i+1] = byte; pixels[i+2] = byte
            pixels[i+3] = blur ? 255 : byte
        } }
        let data = Data(pixels) as CFData
        return CGImage(width:side,height:side,bitsPerComponent:8,bitsPerPixel:32,bytesPerRow:side*4,space:CGColorSpace(name:CGColorSpace.sRGB)!,bitmapInfo:CGBitmapInfo(rawValue:CGImageAlphaInfo.premultipliedLast.rawValue),provider:CGDataProvider(data:data)!,decode:nil,shouldInterpolate:true,intent:.defaultIntent)!
    }

    static func analyze(_ image:CGImage, sourceCover:CGImage? = nil) throws -> LyricsArtworkAnalysis {
        let side = 128
        guard let c = CGContext(data:nil,width:side,height:side,bitsPerComponent:8,bytesPerRow:side*4,space:CGColorSpace(name:CGColorSpace.sRGB)!,bitmapInfo:CGImageAlphaInfo.premultipliedLast.rawValue) else { throw CocoaError(.coderInvalidValue) }
        c.interpolationQuality = .high
        c.draw(image,in:CGRect(x:0,y:0,width:side,height:side))
        guard let thumbnail = c.makeImage(), let data = c.data else { throw CocoaError(.coderInvalidValue) }
        let bytes = data.assumingMemoryBound(to:UInt8.self)
        var edge = SIMD3<Float>.zero, tint = SIMD3<Float>.zero
        var flowHash: UInt64 = 14695981039346656037
        var edges:Float = 0, colored:Float = 0, brightness:Float = 0, saturation:Float = 0
        for y in 0..<side { for x in 0..<side {
            let i = (y*side+x)*4
            for channel in 0..<4 { flowHash = (flowHash ^ UInt64(bytes[i+channel])) &* 1099511628211 }
            let a = Float(bytes[i+3])/255
            let rgb = SIMD3<Float>(Float(bytes[i]),Float(bytes[i+1]),Float(bytes[i+2]))/max(1,255*a)
            let peak = max(rgb.x,rgb.y,rgb.z), low = min(rgb.x,rgb.y,rgb.z)
            let sat = (peak-low)/max(0.001,peak)
            saturation += sat
            if x > 80 || y < 30 || y > 97 {
                edge += rgb; brightness += rgb.x*0.2126+rgb.y*0.7152+rgb.z*0.0722; edges += 1
            }
            if sat > 0.18 && peak > 0.12 && a > 0.5 {
                tint += rgb*sat; colored += sat
            }
        } }
        // Stable image-derived variation; independent of playback and palette settings.
        var state = flowHash
        func unit() -> Float {
            state &+= 0x9e3779b97f4a7c15
            var value = state
            value = (value ^ (value >> 30)) &* 0xbf58476d1ce4e5b9
            value = (value ^ (value >> 27)) &* 0x94d049bb133111eb
            value ^= value >> 31
            return Float(value >> 40)/16777216
        }
        let flow = SIMD4((unit()-0.5)*6, (unit()-0.5)*6, (unit()-0.5)*2*Float.pi, (unit()-0.5)*0.2)
        edge /= edges
        let mean = brightness/edges
        var profile = LyricsArtworkProfile()
        profile.edge = edge
        profile.bright = Float(smooth(0.35,0.85,Double(mean)))
        profile.saturation = 1.5-0.5*Float(smooth(0.18,0.65,Double(saturation/Float(side*side))))*Float(smooth(0.18,0.45,Double(mean)))
        profile.tint = colored > 0 ? tint/colored : edge
        profile.tintAmount = profile.bright*0.18*Float(smooth(0.015,0.10,Double(colored/Float(side*side))))
        var validIndices: [Int] = []
        var samples = [SIMD4<Float>](repeating: .zero, count: side*side)
        var bins = [SIMD3<Float>](repeating:.zero,count:12), counts = [Int](repeating:0,count:12)
        for y in 0..<side { for x in 0..<side {
            let i = (y*side+x)*4, alpha = Float(bytes[i+3])/255
            guard alpha > 0.05 else { continue }
            let rgb = SIMD3<Float>(Float(bytes[i]),Float(bytes[i+1]),Float(bytes[i+2]))/(255*alpha)
            let lab = LyricsColor.lab(rgb)
            validIndices.append(y*side+x)
            samples[y*side+x] = SIMD4(lab, alpha)
            if lab.y*lab.y+lab.z*lab.z > 0.0009 {
                let angle = atan2(lab.z,lab.y)+Float.pi
                let bin = min(11,Int(angle/(2*Float.pi)*12))
                bins[bin] += rgb; counts[bin] += 1
            }
        } }
        guard !validIndices.isEmpty else { return LyricsArtworkAnalysis(thumbnail: thumbnail, profile: profile, flow: flow) }
        let colors = backgroundColors(samples, indices: validIndices, side: side)
        profile.median = colors.median
        let weight = min(colors.area, 0.5)
        let score = (1-weight)*Self.lightContrastScore(LyricsColor.gamutRGB(colors.whole))
            + weight*Self.lightContrastScore(LyricsColor.gamutRGB(colors.dominant))
        let texture = makeTextureArtwork(sourceCover ?? image).map { LyricsTextureArtwork(image:$0) }
        guard score >= 0 else {
            return LyricsArtworkAnalysis(thumbnail: thumbnail, profile: profile, textureArtwork: texture, flow: flow)
        }

        profile.light = 1
        let pigmentedPixels = counts.reduce(0,+)
        // Weight pigment area by perceptual chroma so a broad muted skin tone
        // does not automatically defeat a smaller, distinctive cover color.
        let pigmentScores = counts.indices.map { i -> Float in
            guard counts[i] > 0 else { return 0 }
            let lab = LyricsColor.lab(bins[i]/Float(counts[i]))
            return Float(counts[i]) * (lab.y*lab.y+lab.z*lab.z)
        }
        let strongestBin = counts.indices.max { pigmentScores[$0] < pigmentScores[$1] }!
        let pigment = pigmentedPixels >= max(1,validIndices.count/40)
            ? LyricsColor.lab(bins[strongestBin]/Float(counts[strongestBin])) : nil
        let pigmentCoverage = Double(counts[strongestBin])/Double(validIndices.count)
        let source = colors.dominant
        let sourceChroma = hypot(source.y, source.z)
        let brightNeutral = Float(smooth(0.86, 0.94, Double(source.x))
            * (1 - smooth(0.025, 0.065, Double(sourceChroma))))
        profile.base = LyricsColor.lightBackground(source, brightNeutral: brightNeutral)
        let palette = lightPalette(base: LyricsColor.lab(profile.base), pigment: pigment,
                                     pigmentCoverage: pigmentCoverage, brightNeutral: brightNeutral)
        return LyricsArtworkAnalysis(thumbnail: thumbnail, profile: profile, palette: palette, textureArtwork: texture, flow: flow)
    }

    private static func backgroundColors(
        _ samples: [SIMD4<Float>], indices: [Int], side: Int
    ) -> (median: Float, whole: SIMD3<Float>, dominant: SIMD3<Float>, area: Float) {
        var total = SIMD4<Float>.zero
        for i in indices { total += SIMD4(samples[i].lab*samples[i].w, samples[i].w) }

        // Farthest-point seeding with ties resolved by the original scan order.
        var centers = [total.lab/total.w]
        var distances = [Float](repeating: .infinity, count: samples.count)
        while centers.count < 5 {
            var farthest = indices[0]
            for i in indices {
                distances[i] = min(distances[i], simd_distance_squared(samples[i].lab, centers.last!))
                if distances[i] > distances[farthest] { farthest = i }
            }
            if distances[farthest] == 0 { break }
            centers.append(samples[farthest].lab)
        }

        var labels = [Int](repeating: -1, count: samples.count)
        for _ in 0..<8 {
            var sums = [SIMD4<Float>](repeating: .zero, count: centers.count)
            var changed = false
            for i in indices {
                let sample = samples[i]
                var nearest = 0
                var distance = simd_distance_squared(sample.lab, centers[0])
                for k in 1..<centers.count {
                    let candidate = simd_distance_squared(sample.lab, centers[k])
                    if candidate < distance { nearest = k; distance = candidate }
                }
                changed = changed || labels[i] != nearest
                labels[i] = nearest
                sums[nearest] += SIMD4(sample.lab*sample.w, sample.w)
            }
            if !changed { break }
            for k in centers.indices where sums[k].w > 0 { centers[k] = sums[k].lab/sums[k].w }
        }

        var areas = [Float](repeating: 0, count: centers.count)
        var edges = areas
        var tiles = Array(repeating: [Float](repeating: 0, count: 16), count: centers.count)
        for i in indices {
            let k = labels[i], x = i%side, y = i/side, alpha = samples[i].w
            areas[k] += alpha
            tiles[k][(y/32)*4+x/32] += alpha
            if x >= 90 || y < 28 || y >= 100 { edges[k] += alpha }
        }
        let edgeArea = edges.reduce(0,+)
        var winner = 0, bestScore: Float = -.infinity
        for k in centers.indices where areas[k] > 0 {
            let entropy = tiles[k].reduce(Float.zero) { sum, tile in
                let p = tile/areas[k]
                return p > 0 ? sum-p*log2(p) : sum
            }/4
            let edgeShare = edgeArea > 0 ? edges[k]/edgeArea : 0
            let areaShare = areas[k]/total.w
            let score: Float = 0.70*areaShare + 0.20*entropy + 0.10*edgeShare
            if score > bestScore || (score == bestScore && areas[k] > areas[winner]) {
                winner = k; bestScore = score
            }
        }

        let sorted = indices.sorted { samples[$0].x < samples[$1].x }
        func representative(_ members: [Int], area: Float) -> (Float, SIMD3<Float>) {
            var cumulative: Float = 0
            var median = samples[members.last!].x
            for i in members {
                cumulative += samples[i].w
                if cumulative >= area/2 { median = samples[i].x; break }
            }
            var sum = SIMD4<Float>.zero
            for i in members {
                let sample = samples[i]
                let offset = (sample.x-median)/0.06
                let weight = sample.w*exp(-0.5*offset*offset)
                sum += SIMD4(sample.lab*weight, weight)
            }
            return (median, sum.lab/sum.w)
        }
        let (median, whole) = representative(sorted, area: total.w)
        let (_, dominant) = representative(sorted.filter { labels[$0] == winner }, area: areas[winner])
        return (median, whole, dominant, areas[winner]/total.w)
    }

    private static func lightPalette(
        base: SIMD3<Float>, pigment: SIMD3<Float>?, pigmentCoverage: Double, brightNeutral: Float
    ) -> CGImage {
        let chroma = hypot(base.y,base.z)
        let hue = atan2(base.z,base.y)
        let strength = min(0.19,chroma)
        let subjectWeight = pigment == nil ? 0 : Float(1 - smooth(0.025,0.065,Double(chroma)))
        let subjectChroma = pigment.map { min(0.13,hypot($0.y,$0.z)) } ?? 0
        let accentStrength = subjectChroma * Float(smooth(0.01,0.12,pigmentCoverage))
        let levels: [Float] = [-0.16,-0.065,0.025,0.050,-0.10,-0.045]
        let saturation: [Float] = [1.18,1.05,0.97,0.88,1.10,0.90]
        let offsets: [Float] = [-0.14,0.08,-0.04,0.16,0,-0.10]
        var pixels = [UInt8](repeating:255,count:6*4)
        for i in levels.indices {
            let angle = hue+offsets[i]
            let c = strength*saturation[i]
            var h = SIMD2(cos(angle),sin(angle))*c
            // Four tonal stops preserve the base; two local stops carry pigment.
            if i >= 4, let pigment, subjectWeight > 0 {
                let accentHue = atan2(pigment.z,pigment.y)
                let subject = SIMD2(cos(accentHue),sin(accentHue))*accentStrength
                h += (subject-h)*subjectWeight
            }
            let minimum = LyricsColor.lightness(atLuminance: 0.315, hue:h)
            let maximum = LyricsColor.lightness(atLuminance: LyricsColor.lightCeiling(brightNeutral), hue:h)
            let level: Float
            if levels[i] < 0 {
                level = base.x - min(-levels[i], (base.x-minimum)*0.85)
            } else {
                level = base.x + min(levels[i], (maximum-base.x)*0.85)
            }
            let color = LyricsColor.gamutRGB(SIMD3(min(maximum,max(minimum,level)),h.x,h.y))
            for channel in 0..<3 { pixels[i*4+channel] = UInt8(min(255,max(0,(color[channel]*255).rounded()))) }
        }
        return CGImage(width:6,height:1,bitsPerComponent:8,bitsPerPixel:32,bytesPerRow:24,
            space:CGColorSpace(name:CGColorSpace.sRGB)!,bitmapInfo:CGBitmapInfo(rawValue:CGImageAlphaInfo.premultipliedLast.rawValue),
            provider:CGDataProvider(data:Data(pixels) as CFData)!,decode:nil,shouldInterpolate:true,intent:.defaultIntent)!
    }

    static func coverSquare(in rect: CGRect) -> CGRect {
        let side = min(rect.width, rect.height)
        // CGImage crop coordinates start at the top-left. Preserve more of the upper portrait.
        return CGRect(x:rect.minX+floor((rect.width-side)/2),y:rect.minY+floor((rect.height-side)*0.10),
                      width:side,height:side)
    }

    private static func makeTextureArtwork(_ image: CGImage) -> CGImage? {
        let scale = min(1,40/Double(max(image.width,image.height)))
        let width = max(1,Int((Double(image.width)*scale).rounded()))
        let height = max(1,Int((Double(image.height)*scale).rounded()))
        guard let context = CGContext(data:nil,width:width,height:height,
                bitsPerComponent:8,bytesPerRow:0,space:CGColorSpace(name:CGColorSpace.sRGB)!,
                bitmapInfo:CGBitmapInfo(rawValue:CGImageAlphaInfo.premultipliedLast.rawValue).rawValue) else { return nil }
        context.interpolationQuality = .high
        context.setBlendMode(.copy)
        context.draw(image,in:CGRect(x:0,y:0,width:width,height:height))
        return context.makeImage()
    }

    static func prepare(_ image:CGImage,analysis:LyricsArtworkAnalysis? = nil, featherLeft:Bool = false) throws -> ArtworkBitmap {
        let analysis = try analysis ?? analyze(image)
        let profile = analysis.profile
        let bounds = CGRect(x:0,y:0,width:image.width,height:image.height)
        guard let square = image.cropping(to:coverSquare(in:bounds)) else { throw CocoaError(.coderInvalidValue) }
        let side = square.width
        let rect = CGRect(x:0,y:0,width:side,height:side)
        let original = CIImage(cgImage:square)
        let edgeMask = CIImage(cgImage:mask(side:side,blur:true,bright:Double(profile.bright),featherLeft:featherLeft))
        // Only the transition region receives a small exposure/chroma reduction.
        let adjusted:CIImage
        if profile.light > 0 {
            let b = profile.base
            let solid = CIImage(color:CIColor(red:CGFloat(b.x),green:CGFloat(b.y),blue:CGFloat(b.z))).cropped(to:rect)
            adjusted = solid
        } else { adjusted = original.applyingFilter("CIColorControls",parameters:[kCIInputBrightnessKey:-0.07*Double(profile.bright),kCIInputSaturationKey:1-0.16*Double(profile.bright)]) }
        let input = adjusted.applyingFilter("CIBlendWithMask",parameters:[kCIInputBackgroundImageKey:original,kCIInputMaskImageKey:edgeMask]).clampedToExtent()
        let filter = CIFilter(name:"CIMaskedVariableBlur")!
        filter.setValue(input,forKey:kCIInputImageKey)
        filter.setValue(edgeMask,forKey:"inputMask")
        filter.setValue(Double(side)*0.012,forKey:kCIInputRadiusKey)
        guard let output = filter.outputImage, let bitmap = context.createCGImage(output,from:rect),
              let canvas = CGContext(data:nil,width:side,height:side,bitsPerComponent:8,bytesPerRow:0,space:CGColorSpace(name:CGColorSpace.sRGB)!,bitmapInfo:CGImageAlphaInfo.premultipliedLast.rawValue) else { throw CocoaError(.coderInvalidValue) }
        canvas.draw(bitmap,in:rect)
        canvas.setBlendMode(.destinationIn)
        canvas.draw(mask(side:side,bright:Double(profile.bright),featherLeft:featherLeft),in:rect)
        guard let result = canvas.makeImage() else { throw CocoaError(.coderInvalidValue) }
        return ArtworkBitmap(result)
    }
}

actor LyricsArtworkWorker {
    static let shared = LyricsArtworkWorker()
    struct Crop { let rect:CGRect; var access:UInt64 }
    private var crops:[String:Crop] = [:]
    private var clock:UInt64 = 0
    func trim() { crops = [:]; BrowseDiagnostics.shared.set("lyrics.cropCacheEntriesLast", "0") }
    func prepare(_ bitmap:ArtworkBitmap) throws -> LyricsArtworkPrepared {
        let preparationStart = BrowseDiagnostics.shared.start()
        defer { BrowseDiagnostics.shared.end("lyrics.coverPreparationCPU", preparationStart) }
        try Task.checkCancellation()
        let identityStart = BrowseDiagnostics.shared.start()
        let original = bitmap.image
        // Version the actual pixel input, including profile and dimensions. No rectangle crosses renditions.
        let data = original.dataProvider?.data
        let digest = data.map { SHA256.hash(data:$0 as Data).map { String(format:"%02x",$0) }.joined() } ?? UUID().uuidString
        let profile = original.colorSpace?.copyICCData().map { SHA256.hash(data:$0 as Data).description } ?? ""
        let key = "v9-\(original.width)x\(original.height)-\(profile)-\(digest)"
        BrowseDiagnostics.shared.end("lyrics.coverIdentityCPU", identityStart)
        clock &+= 1
        let bounds = CGRect(x:0,y:0,width:original.width,height:original.height)
        let rect: CGRect
        if var cached = crops[key] {
            BrowseDiagnostics.shared.count("lyrics.cropCacheHits")
            cached.access = clock; crops[key] = cached; rect = cached.rect
        }
        else {
            BrowseDiagnostics.shared.count("lyrics.cropCacheMisses")
            let cropStart = BrowseDiagnostics.shared.start()
            rect = LyricsArtworkBorderDetector.contentRect(in:original)
            BrowseDiagnostics.shared.end("lyrics.coverBorderDetectCPU", cropStart)
            try Task.checkCancellation()
            if crops.count >= 256, let oldest = crops.min(by:{$0.value.access < $1.value.access}) { crops[oldest.key] = nil }
            crops[key] = Crop(rect:rect,access:clock)
        }
        try Task.checkCancellation()
        let image = rect == bounds ? original : original.cropping(to:rect) ?? original
        let analysisStart = BrowseDiagnostics.shared.start()
        let analysis = try LyricsArtworkProcessor.analyze(image,sourceCover:original)
        BrowseDiagnostics.shared.end("lyrics.coverAnalyzeCPU", analysisStart)
        try Task.checkCancellation()
        let bakeStart = BrowseDiagnostics.shared.start()
        let result = ArtworkBitmap(image)
        BrowseDiagnostics.shared.end("lyrics.coverBakeCPU", bakeStart)
        BrowseDiagnostics.shared.peak("lyrics.cropCacheEntriesPeak", crops.count)
        BrowseDiagnostics.shared.set("lyrics.cropCacheEntriesLast", String(crops.count))
        try Task.checkCancellation()
        let value = LyricsArtworkPrepared(analysis:analysis,result:result)
        return value
    }
}
struct LyricsArtworkPrepared: @unchecked Sendable { let analysis:LyricsArtworkAnalysis; let result:ArtworkBitmap }

/// Request ownership is independent of the lyrics page. Background requests use the
/// artwork store's existing bounded, visible-first admission lane.
@MainActor final class LyricsArtworkPreparation {
    static let shared = LyricsArtworkPreparation()
    private struct Work { let id = UUID(); var subscribers:[UUID:(LyricsArtworkPrepared?) -> Void]; var request:UUID?; var task:Task<Void,Never>?; var foreground = false; var idle:UUID?; var start:(() -> Void)? }
    private var work:[String:Work] = [:], keys:[UUID:String] = [:]
    private var ready:[String:LyricsArtworkPrepared] = [:], order:[String] = []
    private var pressure:DispatchSourceMemoryPressure?
    init() {
        let source = DispatchSource.makeMemoryPressureSource(eventMask:[.warning,.critical],queue:.main)
        source.setEventHandler { [weak self] in
            Task { @MainActor in
                self?.ready = [:]; self?.order = []
                self?.diagnosticResources()
                await LyricsArtworkWorker.shared.trim()
            }
        }
        pressure = source; source.resume()
    }
    isolated deinit { pressure?.cancel() }

    private var warmTargets:[URL] = [], warmToken:UUID?, warmingURL:URL?
    func setWarmTargets(_ tracks:[LocalTrack]) {
        var seen = Set<String>()
        let targets = tracks.compactMap(\.coverURL).filter { seen.insert(identity($0)).inserted }.prefix(2)
        if let warmingURL, !targets.contains(warmingURL) { cancel(warmToken); warmToken = nil; self.warmingURL = nil }
        warmTargets = Array(targets)
        if BrowseDiagnostics.shared.enabled {
            for url in targets { if let value = ready[identity(url)] { LyricsPerformanceDiagnostics.shared.prepared(url, analysis:value.analysis) } }
        }
        advanceWarm()
    }
    private func advanceWarm() {
        guard warmingURL == nil else { return }
        while let url = warmTargets.first {
            warmTargets.removeFirst()
            if ready[identity(url)] != nil { continue }
            warmingURL = url
            let token = request(url,foreground:false) { [weak self] _ in
                guard let self, self.warmingURL == url else { return }
                self.warmingURL = nil; self.warmToken = nil; self.advanceWarm()
            }
            if warmingURL == url { warmToken = token }
            return
        }
    }
    private func identity(_ url:URL?) -> String {
        guard let url else { return "default" }
        let version = url.isFileURL ? ((try? FileManager.default.attributesOfItem(atPath:url.path)).map { "\(($0[.modificationDate] as? Date)?.timeIntervalSince1970 ?? 0)-\(($0[.size] as? NSNumber)?.intValue ?? 0)" } ?? "") : ""
        return ArtworkResource.identity(url)+version
    }
    @discardableResult func request(_ url:URL?, foreground:Bool = true, completion:@escaping (LyricsArtworkPrepared?) -> Void) -> UUID? {
        let key = identity(url)
        if let value = ready[key] {
            BrowseDiagnostics.shared.count("lyrics.coverPreparedCacheHits")
            LyricsPerformanceDiagnostics.shared.prepared(url, analysis:value.analysis)
            order.removeAll { $0 == key }; order.append(key); completion(value); return nil
        }
        BrowseDiagnostics.shared.count("lyrics.coverPreparedCacheMisses")
        let token = UUID(); keys[token] = key
        if work[key] != nil {
            BrowseDiagnostics.shared.count("lyrics.coverRequestsCoalesced")
            work[key]?.subscribers[token] = completion
            if foreground { work[key]?.foreground = true; BrowseArtworkStore.shared.setPriority(work[key]?.request,center:true,visible:true,prefetch:false); work[key]?.start?() }
            return token
        }
        work[key] = Work(subscribers:[token:completion],foreground:foreground)
        let workID = work[key]!.id
        let requestStart = BrowseDiagnostics.shared.start()
        let diagnosticFields = BrowseDiagnostics.shared.enabled ? ["artwork": BrowseDiagnostics.shared.resourceID(key), "artworkGeneration": workID.uuidString, "foreground": String(foreground)] : [:]
        BrowseDiagnostics.shared.mark("lyrics.coverRequest", fields:diagnosticFields)
        diagnosticResources()
        let receive:(ArtworkBitmap?) -> Void = { [weak self] bitmap in
            guard let self, self.work[key]?.id == workID else { return }
            BrowseDiagnostics.shared.end("lyrics.coverOriginalRequestWall", requestStart)
            BrowseDiagnostics.shared.mark("lyrics.coverOriginalReady", fields:diagnosticFields.merging(["hasOriginal":String(bitmap != nil)]) { _, new in new })
            let input = bitmap ?? SonoAssets.image("local-default")?.cgImage(forProposedRect:nil,context:nil,hints:nil).map { ArtworkBitmap($0) }
            let start:() -> Void = { [weak self] in
                guard let self, self.work[key]?.id == workID, self.work[key]?.task == nil else { return }
                BrowseArtworkStore.shared.cancelForegroundIdle(self.work[key]?.idle)
                self.work[key]?.idle = nil; self.work[key]?.start = nil
                let queued = BrowseDiagnostics.shared.start()
                BrowseDiagnostics.shared.mark("lyrics.coverWorkerEnqueued", fields:diagnosticFields)
                self.work[key]?.task = Task { [weak self] in
                do {
                    guard let input else { throw CocoaError(.fileNoSuchFile) }
                    let value = try await LyricsArtworkWorker.shared.prepare(input)
                    BrowseDiagnostics.shared.end("lyrics.coverWorkerWall", queued)
                    BrowseDiagnostics.shared.mark("lyrics.coverWorkerReady", fields:diagnosticFields)
                    try Task.checkCancellation()
                    if bitmap != nil || url == nil { LyricsPerformanceDiagnostics.shared.prepared(url, analysis:value.analysis) }
                    self?.finish(key,id:workID,value:value,cache:bitmap != nil || url == nil)
                } catch { if !Task.isCancelled { self?.finish(key,id:workID,value:nil) } }
                }
                self.diagnosticResources()
            }
            self.work[key]?.start = start
            if self.work[key]?.foreground == true { start() }
            else { let idle = BrowseArtworkStore.shared.whenForegroundIdle(start); self.work[key]?.idle = idle }
        }
        if let url { let request = BrowseArtworkStore.shared.requestOriginal(url,pixels:url.isFileURL ? 1440:1200,foreground:foreground,completion:receive); work[key]?.request = request }
        else { receive(nil) }
        return token
    }
    private func finish(_ key:String,id:UUID,value:LyricsArtworkPrepared?,cache:Bool = false) {
        guard work[key]?.id == id, let item = work.removeValue(forKey:key) else { return }
        if let value, cache {
            order.removeAll { $0 == key }; order.append(key); ready[key] = value
            while order.count > 3 || ready.values.reduce(0,{$0+$1.result.cost+$1.analysis.cost}) > 24*1024*1024 {
                let first = order.removeFirst(); ready[first] = nil
            }
        }
        for (token,callback) in item.subscribers { keys[token] = nil; callback(value) }
        diagnosticResources()
    }
    func cancel(_ token:UUID?) {
        guard let token, let key = keys.removeValue(forKey:token) else { return }
        work[key]?.subscribers[token] = nil
        if work[key]?.subscribers.isEmpty == true {
            BrowseDiagnostics.shared.count("lyrics.coverWorkCancelled")
            BrowseArtworkStore.shared.cancelForegroundIdle(work[key]?.idle)
            BrowseArtworkStore.shared.cancel(work[key]?.request); work[key]?.task?.cancel(); work[key] = nil
        }
        diagnosticResources()
    }
    private func diagnosticResources() {
        guard BrowseDiagnostics.shared.enabled else { return }
        let tasks = work.values.filter { $0.task != nil }.count
        let bytes = ready.values.reduce(0) { $0 + $1.result.cost + $1.analysis.cost }
        BrowseDiagnostics.shared.peak("lyrics.coverWorkPeak", work.count)
        BrowseDiagnostics.shared.peak("lyrics.coverTasksPeak", tasks)
        BrowseDiagnostics.shared.peak("lyrics.coverSubscribersPeak", keys.count)
        BrowseDiagnostics.shared.peak("lyrics.coverPreparedCacheEntriesPeak", ready.count)
        BrowseDiagnostics.shared.peak("lyrics.coverPreparedCacheBytesPeak", bytes)
        BrowseDiagnostics.shared.set("lyrics.coverWorkLast", String(work.count))
        BrowseDiagnostics.shared.set("lyrics.coverTasksLast", String(tasks))
        BrowseDiagnostics.shared.set("lyrics.coverPreparedCacheEntriesLast", String(ready.count))
        BrowseDiagnostics.shared.set("lyrics.coverPreparedCacheBytesLast", String(bytes))
    }
}

@MainActor final class LyricsArtworkModel: ObservableObject {
    @Published private(set) var prepared: LyricsArtworkPrepared?
    var result: ArtworkBitmap? { prepared?.result }
    var analysis: LyricsArtworkAnalysis? { prepared?.analysis }
    private var request: UUID?
    private var generation = UUID()
    private var currentURL: URL?
    private var loaded = false

    func load(_ url: URL?) {
        let preparation = LyricsArtworkPreparation.shared
        if !loaded || currentURL != url {
            loaded = true
            currentURL = url
            generation = UUID()
            preparation.cancel(request)
            let generation = generation
            request = preparation.request(url) { [weak self] value in
                guard let self, self.generation == generation else { return }
                self.prepared = value
            }
        }
    }

    func stop() {
        generation = UUID()
        LyricsArtworkPreparation.shared.cancel(request)
        request = nil
        loaded = false
        prepared = nil
    }
}

struct LyricsArtworkView: View {
    @ObservedObject var model: LyricsArtworkModel
    let size: CGSize
    let feather: LyricsCoverFeather
    let cornerRadius: CGFloat
    @State private var masks: [LyricsCoverEdges: [CGImage]] = [:]

    private struct MaskStyle: Equatable {
        let edges: Set<LyricsCoverEdges>
        let bright: Float
    }

    private func blendedMask(overlay: Bool) -> some View {
        let index = overlay ? 1 : 0
        let landscape = feather.landscapeWeight
        let portrait = feather.portraitWeight
        let hardWeight = feather.reveal
            + (masks[feather.landscape] == nil ? landscape : 0)
            + (masks[feather.portrait] == nil ? portrait : 0)
        return ZStack {
            if !overlay, hardWeight > 0 {
                Color.white.opacity(hardWeight)
            }
            if landscape > 0, let mask = masks[feather.landscape]?[index] {
                Image(decorative: mask, scale: 1).resizable().opacity(landscape).blendMode(.plusLighter)
            }
            if portrait > 0, let mask = masks[feather.portrait]?[index] {
                Image(decorative: mask, scale: 1).resizable().opacity(portrait).blendMode(.plusLighter)
            }
        }
        .frame(width: size.width, height: size.height)
        .compositingGroup()
    }

    private func movingEdgeMask(to end: UnitPoint, width: CGFloat) -> some View {
        LinearGradient(stops: [
            .init(color: .clear, location: 0),
            .init(color: .white.opacity(0.16), location: width * 0.25),
            .init(color: .white.opacity(0.5), location: width * 0.5),
            .init(color: .white.opacity(0.84), location: width * 0.75),
            .init(color: .white, location: width)
        ], startPoint: .topLeading, endPoint: end)
    }

    var body: some View {
        let profile = model.analysis?.profile
        let style = MaskStyle(edges: Set([feather.landscape, feather.portrait]).subtracting([[]]), bright: profile?.bright ?? 0)
        let source = model.result?.image
        let aspect = source.map { CGFloat($0.width) / CGFloat($0.height) } ?? 1
        let width = max(size.width, size.height * aspect)
        let height = width / aspect
        let image = source.map { Image(decorative: $0, scale: 1) }
            ?? Image(nsImage: SonoAssets.image("local-default")!)
        let cover = image.resizable().scaledToFill()
            .frame(width: width, height: height)
            .offset(x: (size.width - width) / 2, y: (size.height - height) * 0.1)
        ZStack(alignment: .topLeading) {
            cover
            if (feather.landscapeWeight > 0 && !feather.landscape.isEmpty)
                || (feather.portraitWeight > 0 && !feather.portrait.isEmpty) {
                let base = profile?.base ?? SIMD3<Float>(repeating: 0.82)
                Group {
                    if profile?.light == 1 {
                        Color(red: Double(base.x), green: Double(base.y), blue: Double(base.z))
                    } else {
                        cover.blur(radius: min(size.width, size.height) * 0.012)
                            .brightness(-0.07 * Double(style.bright))
                            .saturation(1 - 0.16 * Double(style.bright))
                    }
                }
                .frame(width: size.width, height: size.height, alignment: .topLeading)
                .mask { blendedMask(overlay: true) }
            }
        }
        .frame(width: size.width, height: size.height, alignment: .topLeading)
        .mask {
            let width = feather.movingEdgeWidth
            blendedMask(overlay: false)
                .mask {
                    if width > 0 {
                        movingEdgeMask(to: .bottomLeading, width: width)
                            .mask { movingEdgeMask(to: .topTrailing, width: width) }
                    } else {
                        Rectangle()
                    }
                }
        }
        .clipShape(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
        .onChange(of: style, initial: true) { _, style in
            masks = Dictionary(uniqueKeysWithValues: style.edges.map { edges in
                (edges, [
                    LyricsArtworkProcessor.mask(side: 128, bright: Double(style.bright), edges: edges),
                    LyricsArtworkProcessor.mask(side: 128, bright: Double(style.bright), edges: edges, overlay: true)
                ])
            })
        }
        .accessibilityHidden(true)
    }
}
