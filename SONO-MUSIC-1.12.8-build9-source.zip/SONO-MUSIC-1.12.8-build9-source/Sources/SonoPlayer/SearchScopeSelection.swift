import SwiftUI
import AppKit

struct SearchScopeInteraction: View {
    @Environment(\.sonoTheme) private var theme
    let selectedGlobal: Bool
    var allowsGlobalSearch = true
    let select: (Bool) -> Void
    @State private var hoveredGlobal: Bool?

    var body: some View {
        HStack(spacing: SonoDesktopTokens.Spacing.s4) {
            if allowsGlobalSearch {
                scopeButton("全局搜索", icon: "magnifyingglass", global: true)
            }
            scopeButton("歌单搜索", icon: "text.page.badge.magnifyingglass", global: false)
        }
        .accessibilityElement(children: .contain)
        .accessibilityLabel("搜索范围")
    }

    private func scopeButton(_ title: String, icon: String, global: Bool) -> some View {
        let selected = selectedGlobal == global
        let hovered = hoveredGlobal == global
        return Button {
            select(global)
        } label: {
            Image(systemName: icon)
                .font(.system(size: SonoDesktopTokens.SymbolSize.navigation, weight: SonoDesktopTokens.FontWeight.regular))
                .symbolRenderingMode(.monochrome)
                .foregroundStyle(Color(nsColor: selected ? theme.foreground(onAccent: SonoGeneratedColors.scopeIcon) : SonoGeneratedColors.scopeIconMuted))
                .sonoIconFrame(SonoDesktopTokens.IconFrame.s28).frame(width: 32, height: 32)
                .background(selected ? Color(nsColor: theme.color(pink: SonoGeneratedColors.scopeSelection)) : hovered ? Color(nsColor: SonoGeneratedColors.scopeHover) : Color.clear, in: Circle())
                .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .onHover { inside in
            (inside ? NSCursor.pointingHand : .arrow).set()
            if inside { hoveredGlobal = global }
            else if hoveredGlobal == global { hoveredGlobal = nil }
        }
        .accessibilityLabel(title)
        .accessibilityAddTraits(selected ? [.isSelected] : [])
    }
}
