import AppKit
import SwiftUI
import CoreText
import QuartzCore
import CoreImage

struct NativeLyricsView: NSViewRepresentable {
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    let document:LyricDocument; let revision:UInt64; let status:String
    @ObservedObject var audio:PlaybackController
    let reduced:Bool; let contrast:Bool
    var ink = LyricsInk()
    var presented = true
    var centering: CGFloat = 0
    var centerCurrentLine = false
    var layoutMoving = false
    func makeNSView(context:Context) -> LyricsCanvas { LyricsCanvas() }
    func updateNSView(_ view:LyricsCanvas,context:Context) {
        view.setInk(ink)
        view.updateResumeAppearance(reduceTransparency: reduceTransparency)
        view.setPresented(presented)
        view.configure(document,revision:revision,status:status,audio:audio,reduced:reduced,contrast:contrast,centering:centering,centerCurrentLine:centerCurrentLine,layoutMoving:layoutMoving)
    }
    static func dismantleNSView(_ view:LyricsCanvas,coordinator:()) { view.stop() }
}

@MainActor final class LyricsCanvas:NSView {
    private struct Row { let lyric:LyricLine; var frame:CGRect; let text:[LyricTextRow]; let auxiliary:[LyricTextRow]; let inkBounds:CGRect; let right:Bool }
    @MainActor private final class ClusterLayers {
        let geometry:LyricCluster; let layer = CALayer(); let base = CALayer(); let lit = CALayer()
        var baseColor: NSColor?
        var highlightColor: NSColor?
        var masks:[CAGradientLayer] = []; var progress:[Double] = []; var lifted = false; var emphasized = false
        init(_ geometry:LyricCluster,scale:CGFloat,ink:LyricsInk) {
            self.geometry = geometry
            layer.frame = geometry.frame
            let image = LyricsTypesetter.image(geometry,scale:scale,color:ink.primary)
            for item in [base,lit] { item.frame = layer.bounds; item.contents = image; item.contentsScale = scale; layer.addSublayer(item) }
            base.opacity = 0.3
            if !geometry.coverage.isEmpty {
                let mask = CALayer(); mask.frame = layer.bounds
                let visualLeft = geometry.coverage.map(\.start).min() ?? 0
                let visualRight = geometry.coverage.map(\.end).max() ?? 0
                for piece in geometry.coverage {
                    let gradient = CAGradientLayer()
                    // Only outer cells include glyph overhangs; shared ligatures
                    // retain their complete image while coverage follows CT carets.
                    let left = piece.start <= visualLeft ? 0 : piece.start
                    let right = piece.end >= visualRight ? layer.bounds.width : piece.end
                    gradient.frame = CGRect(x:left,y:0,width:max(1,right-left),height:layer.bounds.height)
                    gradient.startPoint = CGPoint(x:0,y:0.5); gradient.endPoint = CGPoint(x:1,y:0.5)
                    gradient.colors = geometry.rtl ? LyricsCanvas.rtlColors : LyricsCanvas.ltrColors
                    mask.addSublayer(gradient); masks.append(gradient); progress.append(-1)
                }
                lit.mask = mask
            }
        }
    }
    @MainActor private final class RowLayers {
        let layer = CALayer(); var clusters:[ClusterLayers] = []; var active:Bool?; var blur:CGFloat = -1
        var motion = LyricsRowMotion(); var hovered = false
        var mainCount = 0
        var lines: [(layer: CALayer, width: CGFloat)] = []
        var emphasisGroups:[Double:[ClusterLayers]] = [:]
    }
    private static let white = NSColor.white.cgColor, clear = NSColor.clear.cgColor
    private static let solidColors = [white,white], rtlColors = [clear,white], ltrColors = [white,clear]
    private var ink = LyricsInk()
    func setInk(_ next:LyricsInk) {
        guard next != ink else { return }
        ink = next
        updateResumeAppearance()
        for row in visibleRows.values { for cluster in row.clusters {
            let image = LyricsTypesetter.image(cluster.geometry,scale:layoutScale,color:ink.primary)
            cluster.base.contents = image; cluster.lit.contents = image
            cluster.baseColor = nil; cluster.highlightColor = nil
        } }
        for dot in dotLayers { dot.backgroundColor = ink.primary.cgColor }
        forceSample = true; needsDisplay = true
    }
    private var document = LyricDocument(), revision:UInt64?, status = ""
    private weak var audio:PlaybackController?
    private var rows:[Row] = [], visibleRows:[Int:RowLayers] = [:]
    private var timeOrder:[Int] = [], orderedStarts:[Double] = [], prefixEnds:[Double] = []
    private func lowerBound(_ count:Int,_ predicate:(Int)->Bool) -> Int {
        var low = 0, high = count
        while low < high { let middle = (low+high)/2; if predicate(middle) { high = middle } else { low = middle+1 } }
        return low
    }
    private let viewportLayer = CALayer(), content = CALayer(), edgeMask = CAGradientLayer(), dots = CALayer()
    private let resume = NSButton(title:"恢复跟随",target:nil,action:nil)
    private var dotLayers:[CALayer] = []
    private var link:CADisplayLink?, observations:[NSObjectProtocol] = []
    private var offset:CGFloat = 0, target:CGFloat = 0, velocity:CGFloat = 0, contentHeight:CGFloat = 0
    private var layoutSize = CGSize.zero, layoutScale:CGFloat = 0
    private var wrapWidth: CGFloat = 0
    private var lastTick:CFTimeInterval = 0, manualUntil:CFTimeInterval = 0
    private var sampledPosition:UInt64?, anchor:Int?, selected:Int?, forceSample = true
    private var reduced = false, contrast = false, wasVisible = false
    private var presented = true
    private var gaps:[LyricsTimeline.Gap] = []
    private var gapNext:Int?, gapHeight:CGFloat = 0, gapVelocity:CGFloat = 0
    private var rowsMoving = false
    private var hoverTracking:NSTrackingArea?, hoverPoint:CGPoint?, hoveredIndex:Int?
    override var isFlipped:Bool { true }
    override var acceptsFirstResponder:Bool { true }
    override init(frame:NSRect) {
        super.init(frame:frame); wantsLayer = true
        layer?.addSublayer(viewportLayer); viewportLayer.addSublayer(content); viewportLayer.mask = edgeMask; viewportLayer.masksToBounds = true
        edgeMask.colors = [NSColor.clear.cgColor,NSColor.white.cgColor,NSColor.white.cgColor,NSColor.clear.cgColor]
        edgeMask.startPoint = CGPoint(x:0.5,y:0); edgeMask.endPoint = CGPoint(x:0.5,y:1)
        content.addSublayer(dots)
        for i in 0..<3 {
            let dot = CALayer(); dot.frame = CGRect(x:i*20,y:14,width:12,height:12); dot.cornerRadius = 6
            dot.backgroundColor = NSColor.white.cgColor; dots.addSublayer(dot); dotLayers.append(dot)
        }
        resume.target = self; resume.action = #selector(resumeFollowing)
        resume.isBordered = false; resume.wantsLayer = true
        resume.layer?.cornerRadius = 6
        updateResumeAppearance()
        resume.isHidden = true; addSubview(resume)
        setAccessibilityRole(.group); setAccessibilityLabel("歌词")
    }
    required init?(coder:NSCoder) { fatalError("init(coder:) has not been implemented") }
    func updateResumeAppearance(reduceTransparency: Bool? = nil) {
        let opaque = reduceTransparency ?? NSWorkspace.shared.accessibilityDisplayShouldReduceTransparency
        resume.attributedTitle = NSAttributedString(string: resume.title, attributes: [.foregroundColor: opaque ? NSColor.labelColor : ink.primary])
        resume.layer?.backgroundColor = (opaque ? NSColor.windowBackgroundColor : (SonoGeneratedColors.color(for: ink.light ? "lyrics-colors:NativeLyricsView:o14:返回当前歌词按钮" : "lyrics-colors:NativeLyricsView:resume-dark:返回当前歌词按钮暗底填充") ?? ink.primary.withAlphaComponent(0.14))).sonoCGColor(in: effectiveAppearance)
    }
    private var centering: CGFloat = 0
    private var centerCurrentLine = false
    private var layoutMoving = false
    private var lockedLine: Int?
    private var settlingLayout = false
    private var diagnosticDocumentTrackID: String?

    func configure(_ doc:LyricDocument,revision:UInt64,status:String,audio:PlaybackController,reduced:Bool,contrast:Bool,centering:CGFloat = 0,centerCurrentLine:Bool = false,layoutMoving:Bool = false) {
        self.audio = audio
        let changedDocument = self.revision != revision
        if !changedDocument && layoutMoving && !self.layoutMoving {
            lockedLine = activeLines(at: audio.preciseTime()).first { !rows[$0].lyric.background }
            target = offset
            velocity = 0
            gapVelocity = 0
            for row in visibleRows.values { row.motion.snap(to: row.motion.position) }
        }
        let finishedMoving = !changedDocument && self.layoutMoving && !layoutMoving
        if finishedMoving { settlingLayout = true }
        self.layoutMoving = layoutMoving
        if self.centerCurrentLine != centerCurrentLine {
            self.centerCurrentLine = centerCurrentLine; forceSample = true; needsDisplay = true
        }
        if self.centering != centering {
            self.centering = centering
            needsDisplay = true
        }
        if changedDocument {
            diagnosticDocumentTrackID = audio.current?.id
            self.revision = revision; document = doc; gaps = LyricsTimeline.gaps(in:doc)
            gapNext = nil; gapHeight = 0; gapVelocity = 0
            layoutSize = .zero; wrapWidth = 0; manualUntil = 0; offset = 0; target = 0; velocity = 0; anchor = nil; selected = nil; forceSample = true
            lockedLine = nil; settlingLayout = false
        }
        if self.reduced != reduced || self.contrast != contrast { forceSample = true }
        self.reduced = reduced; self.contrast = contrast
        if self.status != status { self.status = status; needsDisplay = true }
        if presented { rebuild() }; updateClock(); if presented { sample(dt:0) }
    }
    func setPresented(_ value:Bool) {
        guard presented != value else { return }
        presented = value; isHidden = !value
        if value { forceSample = true; lastTick = 0; rebuild() }
        updateClock()
    }
    override func viewDidMoveToWindow() {
        super.viewDidMoveToWindow()
        for token in observations { NotificationCenter.default.removeObserver(token) }; observations = []
        if let window {
            for name in [NSWindow.didChangeOcclusionStateNotification,NSWindow.didMiniaturizeNotification,NSWindow.didDeminiaturizeNotification] {
                observations.append(NotificationCenter.default.addObserver(forName:name,object:window,queue:.main) { [weak self] _ in MainActor.assumeIsolated { self?.updateClock() } })
            }
        }
        updateClock()
    }
    override func viewDidChangeBackingProperties() { super.viewDidChangeBackingProperties(); rebuild() }
    override func viewDidHide() { super.viewDidHide(); updateClock() }
    override func viewDidUnhide() { super.viewDidUnhide(); updateClock() }
    override func layout() {
        super.layout()
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        rebuild()
        sample(dt: 0)
        CATransaction.commit()
    }

    override func viewWillStartLiveResize() {
        super.viewWillStartLiveResize()
        forceSample = true
        sample(dt: 0)
    }

    override func viewDidEndLiveResize() {
        super.viewDidEndLiveResize()
        forceSample = true
        sample(dt: 0)
    }
    private var canRenderLyrics: Bool {
        presented && !isHiddenOrHasHiddenAncestor && window?.isMiniaturized != true && window?.occlusionState.contains(.visible) == true
    }
    private func updateClock() {
        guard canRenderLyrics else { link?.invalidate(); link = nil; wasVisible = false; return }
        if !wasVisible { forceSample = true; lastTick = 0; wasVisible = true; sample(dt:0) }
        if link == nil {
            let next = displayLink(target:self,selector:#selector(tick(_:)))
            next.preferredFrameRateRange = CAFrameRateRange(minimum:60,maximum:60,preferred:60)
            link = next; next.add(to:.main,forMode:.common)
        }
        link?.isPaused = false
    }
    func stop() { link?.invalidate(); link = nil; for token in observations { NotificationCenter.default.removeObserver(token) }; observations = [] }
    @objc private func tick(_ link:CADisplayLink) {
        let now = CACurrentMediaTime(), dt = lastTick == 0 ? 0 : min(0.033,now-lastTick)
        if lastTick != 0 { BrowseDiagnostics.shared.record("lyrics.callbackInterval",(now-lastTick)*1000) }
        lastTick = now
        let measurement = BrowseDiagnostics.shared.start()
        sample(dt:dt)
        BrowseDiagnostics.shared.end("lyrics.canvasCPU",measurement)
        if (document.lines.isEmpty || audio?.isPlaying != true) && abs(target-offset)<0.05 && abs(velocity)<0.05 && manualUntil == 0 && !rowsMoving { link.isPaused = true }
    }
    private func layoutViewport() {
        // Leave room for the Gaussian blur and animated glyphs while keeping
        // content coordinates aligned with the view's text and hit testing.
        let leftOverhang: CGFloat = 16
        var drawingBounds = bounds
        drawingBounds.origin.x -= leftOverhang
        drawingBounds.size.width += leftOverhang
        viewportLayer.frame = drawingBounds
        viewportLayer.bounds = drawingBounds
        edgeMask.frame = drawingBounds
    }

    private func rebuild() {
        let scale = window?.backingScaleFactor ?? 2
        let width = layoutMoving && wrapWidth > 0 ? wrapWidth : max(1, bounds.width)
        guard presented, bounds.width > 0, layoutSize != bounds.size || layoutScale != scale || wrapWidth != width else { return }
        CATransaction.begin(); CATransaction.setDisableActions(true)
        defer { CATransaction.commit() }
        if wrapWidth == width, layoutScale == scale, layoutSize.height > 0 {
            let delta = document.lines.isEmpty ? 0 : (bounds.height-layoutSize.height)/2
            if delta != 0 {
                for id in rows.indices { rows[id].frame.origin.y += delta }
            }
            contentHeight += 2*delta; layoutSize = bounds.size
            content.setAffineTransform(.identity)
            content.frame = CGRect(x:0,y:0,width:bounds.width,height:contentHeight)
            resume.frame = CGRect(x:bounds.width-110,y:bounds.height-38,width:100,height:28)
            layoutViewport()
            forceSample = forceSample || !layoutMoving
            return
        }
        let focus = settlingLayout ? lockedLine ?? anchor : nil
        let previousY = focus.flatMap { id in
            rows.indices.contains(id) ? focusY(rows[id], centering: centering) + rowShift(id) - layoutSize.height / 2 : nil
        }
        wrapWidth = width
        layoutSize = bounds.size; layoutScale = scale; accessibleIndices = []; setAccessibilityChildren([])
        for row in visibleRows.values { row.layer.removeFromSuperlayer() }; visibleRows = [:]; rows = []
        let isStatic = document.lines.isEmpty
        let lines = isStatic ? document.plain.components(separatedBy:.newlines).filter { !$0.isEmpty }.enumerated().map { LyricLine(id:$0.offset,start:0,end:0,words:[LyricWord(text:$0.element,start:0,end:0)]) } : document.lines
        let size = LyricsTimeline.fontSize
        var y:CGFloat = isStatic ? 30 : bounds.height/2
        // Voice alignment is independent of each run's writing direction.
        let primaryRTL = lines.first.map { first in
            LyricsTypesetter.shape(first.text,words:[],size:size,width:width,right:false).flatMap(\.clusters).first?.rtl == true
        } ?? false
        for lyric in lines {
            let right = primaryRTL != (lyric.voice == "v2")
            let font = lyric.background ? SonoDesktopTokens.FontSize.sectionTitle : size
            let text = LyricsTypesetter.shape(lyric.text,words:lyric.words,size:font,width:width,right:false,regular:isStatic)
            var aux:[LyricTextRow] = [], localY = text.reduce(0) { $0 + $1.height } + LyricsTimeline.primaryToAuxiliaryGap
            let auxiliarySize = lyric.background ? SonoDesktopTokens.FontSize.caption : SonoDesktopTokens.FontSize.body
            for value in [lyric.translation, lyric.romanization] where !value.isEmpty {
                let shaped = LyricsTypesetter.shape(value,words:[],size:auxiliarySize,width:width,right:false)
                aux += shaped.map { line in
                    LyricTextRow(line:line.line,baseline:CGPoint(x:line.baseline.x,y:line.baseline.y+localY),height:line.height,clusters:line.clusters.map { cluster in
                        LyricCluster(range:cluster.range,frame:cluster.frame.offsetBy(dx:0,dy:localY),baseline:cluster.baseline,glyphs:cluster.glyphs,rtl:cluster.rtl,coverage:[])
                    })
                }
                localY += shaped.reduce(0) { $0 + $1.height } + LyricsTimeline.auxiliaryGap
            }
            let height = localY+(isStatic ? max(20,size*0.6) : LyricsTimeline.lineSpacing)
            let inkBounds = (text+aux).reduce(CGRect.null) { bounds,line in
                let ink = CTLineGetImageBounds(line.line,nil)
                return bounds.union(CGRect(x:line.baseline.x+ink.minX,y:line.baseline.y-ink.maxY,width:ink.width,height:ink.height))
            }
            rows.append(Row(lyric:lyric,frame:CGRect(x:0,y:y,width:width,height:height),text:text,auxiliary:aux,inkBounds:inkBounds.isNull ? .zero : inkBounds,right:right)); y += height
        }
        timeOrder = rows.indices.sorted { rows[$0].lyric.start < rows[$1].lyric.start }
        orderedStarts = timeOrder.map { rows[$0].lyric.start }
        var end = -Double.infinity
        prefixEnds = timeOrder.map { end = max(end,rows[$0].lyric.end); return end }
        contentHeight = y+(isStatic ? 30 : bounds.height/2)
        if let focus, let previousY, rows.indices.contains(focus) {
            offset = clamp(focusY(rows[focus], centering: centering) + gapShift(focus) - bounds.height / 2 - previousY)
        }
        content.setAffineTransform(.identity)
        content.frame = CGRect(x:0,y:0,width:bounds.width,height:contentHeight)
        resume.frame = CGRect(x:bounds.width-110,y:bounds.height-38,width:100,height:28)
        layoutViewport(); forceSample = true
    }
    private func activeLines(at time: Double) -> [Int] {
        let start = lowerBound(prefixEnds.count) { prefixEnds[$0] > time }
        let end = lowerBound(orderedStarts.count) { orderedStarts[$0] > time }
        return start < end ? timeOrder[start..<end].filter { time < rows[$0].lyric.end }.sorted() : []
    }

    private func focusY(_ row: Row, centering: CGFloat) -> CGFloat {
        let inkCenter = row.inkBounds.isEmpty ? row.frame.midY : row.frame.minY + row.inkBounds.midY
        return LyricsPageLayout.blend(row.frame.midY, inkCenter, centering)
    }

    private func sample(dt:Double,animateScroll:Bool = false) {
        guard canRenderLyrics, let audio else { return }
        let now = CACurrentMediaTime(), time = audio.preciseTime(), isStatic = document.lines.isEmpty
        let discontinuity = forceSample || sampledPosition != audio.positionRevision
        // A lyric click resets vocal timing immediately, but keeps each row's
        // current position and velocity for the ordinary staggered transition.
        if diagnosticDocumentTrackID != audio.current?.id { lockedLine = nil; settlingLayout = false }
        let snapScroll = !layoutMoving && !settlingLayout && (inLiveResize || forceSample || (discontinuity && !animateScroll))
        sampledPosition = audio.positionRevision; forceSample = false
        if !layoutMoving && manualUntil != 0 && manualUntil <= now { manualUntil = 0; anchor = nil }
        let gap = gaps.first { $0.start <= time && time < $0.end && $0.end-$0.start >= 5.8 }
        let next = gap.flatMap { gap in
            if gap.start == 0 { return rows.indices.first }
            return rows.firstIndex { $0.lyric.start >= gap.end }
        }
        if !layoutMoving, let next { gapNext = next }
        let expandedHeight:CGFloat = next == nil ? 0 : max(84,LyricsTimeline.fontSize*2.4)
        if layoutMoving { /* Keep the interlude spacing with the frozen rows. */ }
        else if reduced || snapScroll { gapHeight = expandedHeight; gapVelocity = 0 }
        else if dt > 0 {
            gapVelocity += ((expandedHeight-gapHeight)*120-gapVelocity*21)*dt
            gapHeight += gapVelocity*dt
        }
        if !layoutMoving && next == nil && abs(gapHeight)<0.05 && abs(gapVelocity)<0.05 { gapHeight = 0; gapNext = nil }
        let active = layoutMoving && diagnosticDocumentTrackID == audio.current?.id
            ? lockedLine.map { [$0] } ?? activeLines(at: time)
            : activeLines(at: time)
        if !layoutMoving && !isStatic && manualUntil == 0 {
            if anchor == nil || !active.contains(anchor!) || rows[anchor!].lyric.background {
                anchor = active.first(where:{ !rows[$0].lyric.background }) ?? active.first ?? rows.indices.last(where:{ !rows[$0].lyric.background && rows[$0].lyric.start <= time })
            }
            if let next {
                target = clamp(interludeCenter(next:next,height:expandedHeight)-bounds.height/2)
            } else if let anchor {
                target = clamp(focusY(rows[anchor], centering: centering) - bounds.height / 2)
            } else {
                target = 0
            }
        }
        if !layoutMoving {
            if reduced || snapScroll { offset = target; velocity = 0 }
            else if dt > 0 { velocity += ((target-offset)*100-velocity*18)*dt; offset = clamp(offset+velocity*dt) }
        }
        CATransaction.begin(); CATransaction.setDisableActions(true)
        content.setAffineTransform(CGAffineTransform(translationX:0,y:-offset))
        let viewport = CGRect(x:0,y:offset-150,width:bounds.width,height:bounds.height+300)
        let visibleStart = lowerBound(rows.count) { rows[$0].frame.maxY+gapShift($0) >= viewport.minY }
        let visibleEnd = lowerBound(rows.count) { rows[$0].frame.minY+gapShift($0) > viewport.maxY }
        // The padded range already covers every row's bounded stagger.
        let visible = visibleStart..<max(visibleStart,visibleEnd)
        rowsMoving = abs(expandedHeight-gapHeight)>0.05 || abs(gapVelocity)>0.05
        for id in Array(visibleRows.keys) where !visible.contains(id) { visibleRows.removeValue(forKey:id)?.layer.removeFromSuperlayer() }
        let hovered = hoverPoint.flatMap { row(at:$0) }
        if hovered != hoveredIndex { hoveredIndex = hovered; (hovered == nil ? NSCursor.arrow : NSCursor.pointingHand).set() }
        var inactiveIndex = 0
        for id in visible {
            let row = rows[id], rendering = visibleRows[id] ?? makeLayers(row)
            visibleRows[id] = rendering
            let selected = !isStatic && active.contains(id)
            let hovered = hoveredIndex == id, hoverChanged = rendering.hovered != hovered
            rendering.hovered = hovered
            // The outgoing line starts first; the focus and following lines
            // each follow one Specs lineDelay later. Focus-relative ordering is
            // our reconstruction; the recorded native transition array is partial.
            if !layoutMoving {
                if isStatic || reduced || snapScroll || manualUntil > now {
                    rendering.motion.snap(to:offset)
                } else {
                    let step = max(0,min(id-(next ?? anchor ?? id)+1,7))
                    rendering.motion.move(to:target,delay:Double(step)*LyricsTimeline.lineDelay,at:now)
                    rendering.motion.advance(dt:dt,at:now)
                }
            }
            // Always position the row from its layout frame. Writing a frame to
            // a translated layer during a dock resize baked the gap into its origin.
            rendering.layer.frame = row.frame.offsetBy(dx: 0, dy: offset + rowShift(id))
            for line in rendering.lines {
                let slack = max(0, bounds.width - line.width)
                let alignment = row.right ? 1 - centering / 2 : centering / 2
                line.layer.setAffineTransform(CGAffineTransform(translationX: slack * alignment, y: 0))
            }
            rowsMoving = rowsMoving || rendering.motion.isMoving
            let blur:CGFloat = selected || hovered || isStatic || contrast || manualUntil > now ? 0 : min(CGFloat(inactiveIndex+3),4)
            if !selected { inactiveIndex += 1 }
            if snapScroll { rendering.layer.removeAnimation(forKey: "blur") }
            if rendering.blur != blur {
                if let filter = CIFilter(name:"CIGaussianBlur") {
                    filter.name = "lyricsBlur"; filter.setValue(blur,forKey:kCIInputRadiusKey)
                    rendering.layer.filters = [filter]
                    if !snapScroll && !reduced && rendering.blur >= 0 {
                        let animation = CABasicAnimation(keyPath:"filters.lyricsBlur.inputRadius")
                        animation.fromValue = rendering.blur; animation.toValue = blur; animation.duration = 0.12
                        animation.timingFunction = CAMediaTimingFunction(controlPoints:0.33,0,0.2,0.1)
                        rendering.layer.add(animation,forKey:"blur")
                    }
                }
                rendering.blur = blur
            }
            // Once an inactive row has settled its target, Core Animation owns
            // the remaining spring. Do not dirty every off-focus glyph each frame.
            if rendering.active == false && !selected && !discontinuity && !hoverChanged { continue }
            let mainCount = rendering.mainCount
            let emphasisGroups = rendering.emphasisGroups
            // On a word-timed row, hover reveals the text by removing its blur.
            // Only the timed mask may give the main text the sung color.
            let hoverColor = hovered && !row.lyric.words.contains(where: { $0.timed })
            for (index,cluster) in rendering.clusters.enumerated() {
                if discontinuity {
                    cluster.layer.removeAllAnimations(); cluster.lit.removeAllAnimations()
                    cluster.layer.transform = CATransform3DIdentity
                    cluster.lit.transform = CATransform3DIdentity
                    cluster.emphasized = false; cluster.lifted = false
                }
                let auxiliary = index >= mainCount
                // Both foreground scenes use the same state hierarchy and independent references.
                let candidate: NSColor = ink.light
                    ? (isStatic ? SonoGeneratedColors.lyricLightStatic
                       : hoverColor ? (auxiliary ? SonoGeneratedColors.lyricLightAuxHover : SonoGeneratedColors.lyricLightHover)
                       : auxiliary ? (selected ? SonoGeneratedColors.lyricLightAuxSelected : SonoGeneratedColors.lyricLightAuxIdle)
                       : (selected ? SonoGeneratedColors.lyricLightIdle : SonoGeneratedColors.lyricLightUnselected))
                    : isStatic ? SonoGeneratedColors.lyricDarkStatic
                    : hoverColor ? (auxiliary ? SonoGeneratedColors.lyricAuxHover : SonoGeneratedColors.lyricDarkHover)
                    : auxiliary ? (selected ? SonoGeneratedColors.lyricAuxSelected : SonoGeneratedColors.lyricAuxIdle)
                    : (selected ? SonoGeneratedColors.lyricDarkSelected : SonoGeneratedColors.lyricDarkIdle)
                let baseColor = candidate.usingColorSpace(.sRGB)!
                let highlight = (ink.light ? SonoGeneratedColors.lyricLightHighlight : SonoGeneratedColors.lyricHighlight).usingColorSpace(.sRGB)!
                if cluster.baseColor != baseColor {
                    cluster.baseColor = baseColor
                    cluster.base.contents = LyricsTypesetter.image(cluster.geometry, scale: layoutScale, color: baseColor.withAlphaComponent(1))
                }
                if cluster.highlightColor != highlight {
                    cluster.highlightColor = highlight
                    cluster.lit.contents = LyricsTypesetter.image(cluster.geometry, scale: layoutScale, color: highlight.withAlphaComponent(1))
                }
                let baseOpacity = Float(contrast ? max(0.7, baseColor.alphaComponent) : baseColor.alphaComponent)
                let litOpacity: Float = !auxiliary && selected ? Float(highlight.alphaComponent) : 0
                if cluster.base.opacity != baseOpacity { cluster.base.opacity = baseOpacity }
                if cluster.lit.opacity != litOpacity { cluster.lit.opacity = litOpacity }
                for (pieceIndex,piece) in cluster.geometry.coverage.enumerated() {
                    let p = piece.progress(at:time,active:selected)
                    guard discontinuity || cluster.progress[pieceIndex] != p else { continue }
                    cluster.progress[pieceIndex] = p
                    let mask = cluster.masks[pieceIndex]
                    mask.opacity = p <= 0 ? 0 : 1
                    if p >= 1 { mask.colors = Self.solidColors }
                    else {
                        mask.colors = cluster.geometry.rtl ? LyricsCanvas.rtlColors : LyricsCanvas.ltrColors
                        let edge = (cluster.geometry.rtl ? piece.end-(piece.end-piece.start)*p : piece.start+(piece.end-piece.start)*p)-mask.frame.minX
                        let a = max(0,min(1,(edge-15)/mask.bounds.width)), b = max(a,min(1,(edge+15)/mask.bounds.width))
                        mask.locations = [NSNumber(value:Double(a)),NSNumber(value:Double(b))]
                    }
                }
                let shouldLift = !auxiliary && selected && cluster.geometry.coverage.contains { $0.word.timed && time >= $0.word.start }
                if (audio.isPlaying || discontinuity || !selected) && cluster.lifted != shouldLift {
                    let old:CGFloat = cluster.lifted ? -3 : 0, next:CGFloat = shouldLift && !reduced ? -3 : 0
                    cluster.layer.transform = CATransform3DMakeTranslation(0,next,0)
                    if !discontinuity && !reduced { spring(cluster.layer,key:"transform.translation.y",from:old,to:next,stiffness:14,damping:7) }
                    cluster.lifted = shouldLift
                }
                if !reduced, !auxiliary, let word = cluster.geometry.coverage.first(where:{ LyricsTimeline.emphasized($0.word) })?.word,
                   let group = emphasisGroups[word.start], let ordinal = group.firstIndex(where:{ $0 === cluster }) {
                    let duration = word.end-word.start, n = Double(group.count), h = min(0.4*duration/n,0.4)
                    let up = Double(ordinal+1)*h, down = up+2*duration/n
                    let elapsed = time-word.start
                    let emphasized = selected && elapsed >= up && elapsed < down
                    if (audio.isPlaying || !selected || discontinuity) && emphasized != cluster.emphasized {
                        let next:CGFloat = emphasized && !discontinuity ? 1.08 : 1
                        let response = min(duration,3), k = pow(2*Double.pi/response,2)
                        if !discontinuity { spring(cluster.lit,key:"transform.scale",from:cluster.emphasized ? 1.08 : 1,to:next,stiffness:k,damping:2*sqrt(k)) }
                        cluster.lit.transform = CATransform3DMakeScale(next,next,1)
                        cluster.emphasized = emphasized && !discontinuity
                    }
                } else if cluster.emphasized {
                    cluster.lit.transform = CATransform3DIdentity; cluster.emphasized = false
                }
            }
            rendering.active = selected
        }
        let normalEdge = LyricsTimeline.edgeLength(height:bounds.height,manual:manualUntil > now)
        let centeredEdge = max(6, (bounds.height - LyricsTimeline.compactViewportHeight) / 2 + 6)
        let edge = LyricsPageLayout.blend(normalEdge, min(normalEdge, bounds.height / 4, centeredEdge), centering)
        edgeMask.locations = [0,NSNumber(value:Double(edge/max(1,bounds.height))),NSNumber(value:Double(1-edge/max(1,bounds.height))),1]
        resume.isHidden = manualUntil == 0 || isStatic
        updateDots(gap:gap,next:next,time:time,playing:audio.isPlaying,reset:discontinuity)
        CATransaction.commit()
        if settlingLayout && !layoutMoving && abs(target-offset) < 0.05 && abs(velocity) < 0.05 && !rowsMoving {
            settlingLayout = false
            lockedLine = nil
        }
        if BrowseDiagnostics.shared.enabled {
            BrowseDiagnostics.shared.peak("lyrics.visibleRowLayersPeak", visibleRows.count)
            BrowseDiagnostics.shared.peak("lyrics.visibleGlyphLayersPeak", visibleRows.values.reduce(0) { $0 + $1.clusters.count })
            if diagnosticDocumentTrackID == audio.current?.id, window?.occlusionState.contains(.visible) == true, !isHiddenOrHasHiddenAncestor, bounds.width > 0, bounds.height > 0,
               visible.contains(where: { id in
                   guard let rendering = visibleRows[id], rendering.clusters.contains(where: { $0.base.contents != nil }) else { return false }
                   return rows[id].frame.offsetBy(dx:0,dy:rowShift(id)).intersects(bounds)
               }) {
                LyricsPerformanceDiagnostics.shared.milestone("lyricsGlyphLayersSubmitted", token:LyricsPerformanceDiagnostics.shared.token(for:audio.current?.id), fields:["documentRevision":revision.map(String.init) ?? "unset", "boundary":"visible nonempty glyph layers submitted in CATransaction; not compositor presentation"])
            }
        }
        updateAccessibility(Array(visible))
    }
    private func makeLayers(_ row:Row) -> RowLayers {
        let result = RowLayers(); result.motion.snap(to:offset); result.layer.frame = row.frame; content.addSublayer(result.layer)
        for line in row.text+row.auxiliary {
            let layer = CALayer()
            result.lines.append((layer, CGFloat(CTLineGetTypographicBounds(line.line, nil, nil, nil))))
            result.layer.addSublayer(layer)
            for cluster in line.clusters {
                let item = ClusterLayers(cluster,scale:layoutScale,ink:ink); result.clusters.append(item); layer.addSublayer(item.layer)
            }
        }
        result.mainCount = row.text.reduce(0) { $0+$1.clusters.count }
        result.emphasisGroups = Dictionary(grouping:result.clusters.prefix(result.mainCount).filter { $0.geometry.coverage.contains { LyricsTimeline.emphasized($0.word) } },by:{ $0.geometry.coverage.first(where:{ LyricsTimeline.emphasized($0.word) })!.word.start })
        return result
    }
    private func spring(_ layer:CALayer,key:String,from:CGFloat,to:CGFloat,stiffness:Double,damping:Double) {
        let animation = CASpringAnimation(keyPath:key); animation.mass = 1; animation.stiffness = stiffness; animation.damping = damping
        animation.fromValue = layer.presentation()?.value(forKeyPath:key) ?? from; animation.toValue = to; animation.duration = animation.settlingDuration
        layer.add(animation,forKey:key)
    }
    private func gapShift(_ index:Int) -> CGFloat { gapNext.map { index >= $0 ? gapHeight : 0 } ?? 0 }
    private func rowScroll(_ index:Int) -> CGFloat { visibleRows[index]?.motion.displayPosition(relativeTo:offset) ?? offset }
    private func rowShift(_ index:Int) -> CGFloat { gapShift(index)-rowScroll(index) }
    private func interludeEdges(next: Int, height: CGFloat) -> (top: CGFloat, bottom: CGFloat) {
        let bottom = rows[next].frame.minY + height
        guard next > 0 else { return (bottom - height, bottom) }
        let previous = rows[next - 1]
        let textEnd = max(previous.frame.height - LyricsTimeline.lineSpacing, previous.inkBounds.maxY)
        return (previous.frame.minY + textEnd, bottom)
    }

    private func interludeCenter(next: Int, height: CGFloat) -> CGFloat {
        let edges = interludeEdges(next: next, height: height)
        return (edges.top + edges.bottom) / 2
    }
    private func updateDots(gap:LyricsTimeline.Gap?,next:Int?,time:Double,playing:Bool,reset:Bool) {
        guard let gap, let next else {
            dots.isHidden = true
            for dot in dotLayers { dot.removeAllAnimations(); dot.setValue(nil,forKey:"phase"); dot.setValue(nil,forKey:"exiting"); dot.transform = CATransform3DIdentity }
            return
        }
        let edges = interludeEdges(next: next, height: gapHeight)
        let nextScroll = rowScroll(next)
        let previousScroll = next > 0 ? rowScroll(next - 1) : nextScroll
        let top = edges.top - previousScroll
        let bottom = edges.bottom - nextScroll
        // Wait until the stagger leaves room for the breathing dots.
        dots.isHidden = bottom - top < 40
        let center = (top + bottom) / 2 + offset
        dots.frame = CGRect(x:(bounds.width - 52) / 2 * centering,y:center-20,width:52,height:40)
        let q = gap.end-gap.start-1.8, cycles = floor(q/4)
        guard cycles >= 1 else { dots.isHidden = true; return }
        let breath = 0.5*q/cycles, phase = Int((time-gap.start)/breath)+1
        for (index,dot) in dotLayers.enumerated() {
            if reset { dot.removeAllAnimations(); dot.setValue(nil,forKey:"phase"); dot.setValue(nil,forKey:"exiting") }
            let fade = (gap.end-gap.start-2.8)/3
            let alpha = min(1,max(0,(time-gap.start-Double(index)*fade)/0.3))
            var scale:CGFloat = phase % 2 == 1 ? 1.2 : 0.9
            var opacity = Float(0.25+0.75*alpha)
            let exiting = time > gap.end-1.8
            if exiting { let t = time-(gap.end-1.8); scale = t < 1 ? 1.2 : max(0.2,1.2-CGFloat((t-1)/0.5)); opacity *= Float(max(0,1-(t-1)/0.3)) }
            if reduced { scale = 1 }
            if playing || reset {
                if dot.value(forKey:"phase") as? Int != phase && !exiting && !reduced {
                    let animation = CABasicAnimation(keyPath:"transform.scale"); animation.fromValue = dot.presentation()?.value(forKeyPath:"transform.scale") ?? 1
                    animation.toValue = scale; animation.duration = max(0,breath-0.4); animation.beginTime = CACurrentMediaTime()+0.2
                    // Keep the previous presentation during the delay. Without
                    // backwards fill the model target flashes before each breath.
                    animation.fillMode = .backwards
                    animation.timingFunction = CAMediaTimingFunction(name:.easeOut); dot.add(animation,forKey:"breath")
                }
                if exiting && dot.value(forKey:"exiting") as? Bool != true && !reduced && !reset {
                    let animation = CABasicAnimation(keyPath:"transform.scale")
                    animation.fromValue = dot.presentation()?.value(forKeyPath:"transform.scale") ?? dot.value(forKeyPath:"transform.scale")
                    animation.toValue = 1.2; animation.duration = max(0,1-(time-(gap.end-1.8)))
                    animation.timingFunction = CAMediaTimingFunction(controlPoints:0.25,0.1,0.25,1)
                    dot.removeAnimation(forKey:"breath"); dot.add(animation,forKey:"exit")
                    dot.setValue(true,forKey:"exiting")
                }
                dot.setValue(phase,forKey:"phase"); dot.setValue(scale,forKeyPath:"transform.scale"); dot.opacity = opacity
            }
        }
    }
    override func draw(_ dirtyRect:NSRect) {
        guard rows.isEmpty else { return }
        let paragraph = NSMutableParagraphStyle()
        paragraph.alignment = centering >= 0.5 ? .center : .natural
        let verticalInset = centerCurrentLine ? min(100,max(0,(bounds.height-32)/2)) : 100
        status.draw(in:bounds.insetBy(dx:0,dy:verticalInset),withAttributes:[
            .font:NSFont.systemFont(ofSize:SonoDesktopTokens.FontSize.pageTitle),
            .foregroundColor:ink.secondary,
            .paragraphStyle:paragraph
        ])
    }
    private func clamp(_ value:CGFloat) -> CGFloat { max(0,min(max(0,contentHeight+gapHeight-bounds.height),value)) }
    override func scrollWheel(with event:NSEvent) {
        guard !layoutMoving else { return }
        manualUntil = document.lines.isEmpty ? 0 : CACurrentMediaTime()+3
        target = clamp(offset-event.scrollingDeltaY); offset = target; velocity = 0; sample(dt:0); updateClock()
    }
    @objc private func resumeFollowing() { manualUntil = 0; anchor = nil; updateClock(); sample(dt:0) }
    private func activate(_ index:Int) {
        guard !layoutMoving, !document.lines.isEmpty, rows.indices.contains(index), rows[index].lyric.end > rows[index].lyric.start else { return }
        selected = index; manualUntil = 0; anchor = index; audio?.seek(rows[index].lyric.start,play:true); sample(dt:0,animateScroll:true); updateClock()
    }
    override func updateTrackingAreas() {
        super.updateTrackingAreas()
        if let hoverTracking { removeTrackingArea(hoverTracking) }
        let tracking = NSTrackingArea(rect:.zero,options:[.inVisibleRect,.mouseEnteredAndExited,.mouseMoved,.cursorUpdate,.activeInKeyWindow],owner:self)
        addTrackingArea(tracking); hoverTracking = tracking
    }
    override func mouseEntered(with event:NSEvent) { mouseMoved(with:event) }
    override func mouseMoved(with event:NSEvent) { hoverPoint = convert(event.locationInWindow,from:nil); sample(dt:0) }
    override func mouseExited(with event:NSEvent) { hoverPoint = nil; sample(dt:0); NSCursor.arrow.set() }
    override func cursorUpdate(with event:NSEvent) { (hoveredIndex == nil ? NSCursor.arrow : NSCursor.pointingHand).set() }
    private func row(at point:CGPoint) -> Int? {
        guard !document.lines.isEmpty, bounds.contains(point), resume.isHidden || !resume.frame.contains(point) else { return nil }
        return rows.indices.first { id in
            rows[id].lyric.end > rows[id].lyric.start && rowRect(id).contains(point)
        }
    }
    override func mouseDown(with event:NSEvent) {
        window?.makeFirstResponder(self)
        let point = convert(event.locationInWindow,from:nil)
        if let index = row(at:point) { activate(index) }
    }
    override func keyDown(with event:NSEvent) {
        switch event.keyCode {
        case 125,126:
            guard !rows.isEmpty else { return }
            selected = min(rows.count-1,max(0,(selected ?? anchor ?? 0)+(event.keyCode == 125 ? 1 : -1)))
            manualUntil = CACurrentMediaTime()+3; target = clamp(rows[selected!].frame.midY-bounds.height/2); updateClock()
        case 36,49: if let index = selected ?? anchor { activate(index) }
        case 115: resumeFollowing()
        default: super.keyDown(with:event)
        }
    }
    private var accessibleIndices:[Int] = []
    private var accessibleManual = false
    private func updateAccessibility(_ indices:[Int]) {
        let browsing = !resume.isHidden
        guard indices != accessibleIndices || accessibleManual != browsing else { return }
        accessibleIndices = indices; accessibleManual = browsing
        var children:[Any] = []
        for index in indices {
            let action:(@MainActor @Sendable () -> Void)?
            if document.lines.isEmpty { action = nil } else { action = { [weak self] in self?.activate(index) } }
            let frame:@MainActor @Sendable () -> CGRect = { [weak self] in
                guard let self, let window = self.window, self.rows.indices.contains(index) else { return .zero }
                return window.convertToScreen(self.convert(self.rowRect(index),to:nil))
            }
            let element = LyricsAccessibilityElement(press:action,frame:frame)
            element.setAccessibilityParent(self); element.setAccessibilityEnabled(true); element.setAccessibilityRole(document.lines.isEmpty ? .staticText : .button)
            let line = rows[index].lyric
            element.setAccessibilityLabel(([line.text,line.translation,line.romanization].filter { !$0.isEmpty }).joined(separator:"，"))
            children.append(element)
        }
        if browsing { children.append(resume) }
        setAccessibilityChildren(children)
    }

    private func rowRect(_ index: Int) -> CGRect {
        var frame = rows[index].frame.offsetBy(dx: 0, dy: rowShift(index))
        frame.size.width = max(1, bounds.width)
        return frame
    }
}
@MainActor private final class LyricsAccessibilityElement:NSAccessibilityElement {
    private nonisolated let press:(@MainActor @Sendable () -> Void)?
    private nonisolated let frame:@MainActor @Sendable () -> CGRect
    init(press:(@MainActor @Sendable () -> Void)?,frame:@escaping @MainActor @Sendable () -> CGRect) { self.press = press; self.frame = frame; super.init() }
    override nonisolated func accessibilityFrame() -> NSRect {
        let provider = frame
        if Thread.isMainThread { return MainActor.assumeIsolated { provider() } }
        return DispatchQueue.main.sync { MainActor.assumeIsolated { provider() } }
    }
    override nonisolated func accessibilityPerformPress() -> Bool {
        guard let press else { return false }; Task { @MainActor in press() }; return true
    }
}
