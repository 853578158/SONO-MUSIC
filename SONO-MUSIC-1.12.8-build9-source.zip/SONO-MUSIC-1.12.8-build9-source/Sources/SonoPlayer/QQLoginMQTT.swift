import Foundation

/// MQTT 5 packet framing for the QQ Music QR status connection.
enum QQLoginMQTT {
    static let keepAliveSeconds: UInt16 = 45
    static let pingRequest = Data([0xc0, 0])

    struct Packet {
        let header: UInt8
        let body: Data

        var type: UInt8 { header >> 4 }
    }

    enum PacketError: Error {
        case invalidLength
        case invalidString
    }

    static func connect(clientID: String, qrID: String) throws -> Data {
        let properties = try userProperties([
            ("tmeAppID", "qqmusic"),
            ("business", "management"),
            ("hashTag", qrID),
            ("clientTag", "management.user"),
            ("userID", qrID)
        ], prefix: Data([0x15]) + string("pass"))

        let body = try string("MQTT") + Data([5, 2, UInt8(keepAliveSeconds >> 8), UInt8(truncatingIfNeeded: keepAliveSeconds)]) + properties + string(clientID)
        return try frame(header: 0x10, body: body)
    }

    static func subscribe(qrID: String) throws -> Data {
        let properties = try userProperties([
            ("authorization", "tmelogin"),
            ("pubsub", "unicast")
        ])
        let topic = try string("management.qrcode_login/" + qrID)
        return try frame(header: 0x82, body: Data([0, 1]) + properties + topic + Data([0]))
    }

    /// Reads one complete packet, leaving an incomplete packet in the buffer.
    static func nextPacket(in buffer: inout Data) throws -> Packet? {
        guard let header = buffer.first else { return nil }
        var length = 0
        var multiplier = 1
        for (offset, byte) in buffer.dropFirst().prefix(4).enumerated() {
            length += Int(byte & 0x7f) * multiplier
            if byte & 0x80 == 0 {
                let prefixLength = offset + 2
                guard buffer.count >= prefixLength + length else { return nil }
                let body = Data(buffer.dropFirst(prefixLength).prefix(length))
                buffer.removeFirst(prefixLength + length)
                return Packet(header: header, body: body)
            }
            multiplier *= 128
        }
        if buffer.count >= 5 { throw PacketError.invalidLength }
        return nil
    }

    static func serverReference(_ packet: Packet) throws -> String? {
        guard packet.type == 2, let reason = packet.body.dropFirst().first,
              reason == 0x9c || reason == 0x9d else { return nil }
        var body = Reader(bytes: packet.body.dropFirst(2))
        let length = try body.variableLength()
        var properties = Reader(bytes: try body.take(length))
        var reference: String?
        while !properties.bytes.isEmpty {
            switch try properties.byte() {
            case 0x1c:
                guard reference == nil else { throw PacketError.invalidLength }
                reference = try properties.string()
            case 0x12, 0x15, 0x16, 0x1a, 0x1f: _ = try properties.lengthPrefixed()
            case 0x13, 0x21, 0x22: _ = try properties.take(2)
            case 0x11, 0x27: _ = try properties.take(4)
            case 0x24, 0x25, 0x28, 0x29, 0x2a: _ = try properties.byte()
            case 0x26:
                _ = try properties.string()
                _ = try properties.string()
            default: throw PacketError.invalidLength
            }
        }
        return reference
    }

    struct Publish: Sendable {
        let topic: String
        let event: String?
        let payload: Data
    }

    static func publish(_ packet: Packet) throws -> Publish {
        guard packet.type == 3 else { throw PacketError.invalidLength }
        var body = Reader(bytes: packet.body[...])
        let topic = try body.string()
        let qos = (packet.header >> 1) & 3
        guard qos != 3 else { throw PacketError.invalidLength }
        if qos > 0 { _ = try body.take(2) }
        let length = try body.variableLength()
        var properties = Reader(bytes: try body.take(length))
        var event: String?
        while !properties.bytes.isEmpty {
            switch try properties.byte() {
            case 0x26:
                let name = try properties.string()
                let value = try properties.string()
                if name == "type" { event = value }
            case 0x01: _ = try properties.take(1)
            case 0x02: _ = try properties.take(4)
            case 0x23: _ = try properties.take(2)
            case 0x03, 0x08, 0x09: _ = try properties.lengthPrefixed()
            case 0x0b: _ = try properties.variableLength()
            default: throw PacketError.invalidLength
            }
        }
        return Publish(topic: topic, event: event, payload: Data(body.bytes))
    }

    private struct Reader {
        var bytes: Data.SubSequence

        mutating func take(_ count: Int) throws -> Data.SubSequence {
            guard count <= bytes.count else { throw PacketError.invalidLength }
            let value = bytes.prefix(count)
            bytes = bytes.dropFirst(count)
            return value
        }

        mutating func byte() throws -> UInt8 {
            guard let value = bytes.first else { throw PacketError.invalidLength }
            bytes = bytes.dropFirst()
            return value
        }

        mutating func lengthPrefixed() throws -> Data.SubSequence {
            let high = Int(try byte())
            let low = Int(try byte())
            return try take(high * 256 + low)
        }

        mutating func string() throws -> String {
            guard let value = String(data: try lengthPrefixed(), encoding: .utf8) else {
                throw PacketError.invalidString
            }
            return value
        }

        mutating func variableLength() throws -> Int {
            var length = 0
            for shift in stride(from: 0, through: 21, by: 7) {
                let value = try byte()
                length |= Int(value & 0x7f) << shift
                if value & 0x80 == 0 { return length }
            }
            throw PacketError.invalidLength
        }
    }

    private static func frame(header: UInt8, body: Data) throws -> Data {
        Data([header]) + (try variableLength(body.count)) + body
    }

    private static func userProperties(_ fields: [(String, String)], prefix: Data = Data()) throws -> Data {
        var properties = prefix
        for (key, value) in fields {
            properties.append(0x26)
            properties.append(try string(key))
            properties.append(try string(value))
        }
        return try variableLength(properties.count) + properties
    }

    private static func string(_ value: String) throws -> Data {
        let bytes = Data(value.utf8)
        guard bytes.count <= Int(UInt16.max) else { throw PacketError.invalidString }
        let length = UInt16(bytes.count).bigEndian
        return withUnsafeBytes(of: length) { Data($0) } + bytes
    }

    private static func variableLength(_ length: Int) throws -> Data {
        guard (0...268_435_455).contains(length) else { throw PacketError.invalidLength }
        var remaining = length
        var bytes = Data()
        repeat {
            let digit = UInt8(remaining % 128)
            remaining /= 128
            bytes.append(remaining == 0 ? digit : digit | 0x80)
        } while remaining > 0
        return bytes
    }
}
