import AppKit
import SwiftUI

private struct SonoTooltip: ViewModifier {
    let text: String
    @ViewState private var hovered = false

    func body(content: Content) -> some View {
        content
            .background(TooltipHoverRegion(hovered: $hovered))
            .overlay {
                GeometryReader { geometry in
                    if hovered {
                        Text(text)
                            .font(SonoTypography.font(size: SonoDesktopTokens.FontSize.caption))
                            .foregroundStyle(Color(nsColor: SonoGeneratedColors.primaryText))
                            .padding(.horizontal, SonoDesktopTokens.Spacing.s12).padding(.vertical, SonoDesktopTokens.Spacing.s8)
                            .glass(radius: 12)
                            .fixedSize()
                            .frame(width: geometry.size.width)
                            .offset(y: geometry.size.height + 8)
                            .accessibilityHidden(true)
                    }
                }.allowsHitTesting(false)
            }
            .zIndex(hovered ? 1 : 0)
            .onDisappear { hovered = false }
    }
}

extension View {
    func sonoTooltip(_ text: String) -> some View {
        modifier(SonoTooltip(text: text))
    }
}

private struct TooltipHoverRegion: NSViewRepresentable {
    @Binding var hovered: Bool

    func makeNSView(context: Context) -> Region { Region() }
    func updateNSView(_ view: Region, context: Context) {
        view.changed = { hovered = $0 }
    }

    final class Region: NSView {
        var changed: (Bool) -> Void = { _ in }
        private var tracking: NSTrackingArea?

        override func hitTest(_ point: NSPoint) -> NSView? { nil }
        override func updateTrackingAreas() {
            super.updateTrackingAreas()
            if let tracking { removeTrackingArea(tracking) }
            let area = NSTrackingArea(rect: .zero, options: [.activeAlways, .inVisibleRect, .mouseEnteredAndExited], owner: self)
            addTrackingArea(area); tracking = area
        }
        override func mouseEntered(with event: NSEvent) { changed(true) }
        override func mouseExited(with event: NSEvent) { changed(false) }
    }
}
