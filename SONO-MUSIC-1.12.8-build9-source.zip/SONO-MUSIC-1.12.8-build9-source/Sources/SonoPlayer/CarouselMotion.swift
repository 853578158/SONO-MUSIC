import Foundation
import QuartzCore

/// CSS-point input at the boundary; rendering and AppKit event delivery are separate owners.
/// Times are monotonic seconds. A virtual clock can drive exactly the production state machine.
@MainActor
final class CarouselMotion {
    enum Phase: String, Codable { case idle, tracking, awaitingMomentum = "awaiting-momentum", momentum, wheel, dragging, snapping }
    enum ScrollPhase: String, Codable { case none, mayBegin = "may-begin", begin, update, end, cancel }
    struct Input: Codable {
        var gesture: Int, sequence: Int
        var timestamp: Double
        var trackpad: Bool
        var finger: ScrollPhase, momentum: ScrollPhase
        var dx: Double, dy: Double
    }
    struct Snapshot: Codable {
        let position: Double
        let phase: Phase
        let target: Double?
        let gesture: Int
        let snaps: Int
    }
    private(set) var position: Double
    private(set) var phase = Phase.idle
    private(set) var target: Double?
    private var gesture = 0, closedGesture = 0, sequence = 0, snaps = 0
    private var timestamp = -Double.infinity
    private var pending = 0.0, dragPixels = 0.0, from = 0.0, started = 0.0
    private var horizontal: Bool?
    private var finishing = false, scheduled = false
    private var deadline: Double?
    private var count: Int
    private var minimumPosition: Double = 0
    private var side: Double
    private var duration = 0.35
    private(set) var intentVelocity = 0.0
    private var intentTime: Double?
    var paint: ((Snapshot, Bool) -> Void)?
    var wake: (() -> Void)?
    var snapshot: Snapshot { Snapshot(position: position, phase: phase, target: target, gesture: gesture, snaps: snaps) }
    var needsTick: Bool { scheduled || deadline != nil }
    init(position: Double, count: Int, side: Double) { self.position = position; self.count = count; self.side = side }
    func configure(count: Int, side: Double, reduced: Bool, minimumPosition: Double = 0) {
        if self.side > 0 { pending *= side / self.side }
        self.count = count; self.side = side; self.minimumPosition = minimumPosition; duration = reduced ? 0 : 0.35
        position = bound(position)
        if let target { self.target = rounded(target) }
    }
    private func bound(_ value: Double) -> Double { max(minimumPosition, min(minimumPosition + Double(max(0, count - 1)), value)) }
    private func rounded(_ value: Double) -> Double { bound(floor(value + 0.5)) }
    private func schedule() { scheduled = true; wake?() }
    private func cancel() { deadline = nil; scheduled = false; pending = 0; target = nil; finishing = false; horizontal = nil }
    private func add(_ pixels: Double, now: Double) {
        guard side > 0 else { return }
        // Clamp each event before coalescing, preserving a reversal at either endpoint.
        if let intentTime, now > intentTime { intentVelocity = max(-120, min(120, pixels / (side * 0.42) / max(0.016, now - intentTime))) }
        else { intentVelocity = pixels.sign == .minus ? -6 : 6 }
        intentTime = now
        let next = bound(position + pending / (side * 0.42) + pixels / (side * 0.42))
        pending = (next - position) * side * 0.42
        schedule()
    }
    private func delta(_ dx: Double, _ dy: Double) -> Double {
        if horizontal == nil && (dx != 0 || dy != 0) { horizontal = abs(dx) > abs(dy) }
        return horizontal == true ? dx : dy
    }
    private func later(_ now: Double, _ seconds: Double) { deadline = now + seconds; wake?() }
    private func settle() {
        guard !finishing, phase != .idle, phase != .snapping else { return }
        closedGesture = max(closedGesture, gesture); deadline = nil; finishing = true; schedule()
    }
    @discardableResult
    func native(_ input: Input, hit: Bool, now: Double) -> Bool {
        guard input.dx.isFinite, input.dy.isFinite, input.sequence > sequence, input.timestamp >= timestamp else { return false }
        sequence = input.sequence; timestamp = input.timestamp
        if !input.trackpad { return hit && wheel(dx: input.dx, dy: input.dy, now: now) }
        guard input.finger != .none || input.momentum != .none else { return false }
        if input.finger == .begin && input.momentum == .none {
            guard hit, phase != .dragging, input.gesture > max(gesture, closedGesture) else { return false }
            cancel(); gesture = input.gesture; phase = .tracking; snaps = 0
        }
        guard input.gesture == gesture, input.gesture > closedGesture, phase != .dragging, phase != .snapping, phase != .idle else { return false }
        if input.momentum == .begin || input.momentum == .update { deadline = nil; phase = .momentum }
        let pixels = delta(input.dx, input.dy)
        if pixels != 0 { add(pixels, now: now) }
        if input.momentum == .end || input.momentum == .cancel || input.finger == .cancel { settle() }
        else if input.finger == .end && input.momentum == .none {
            phase = .awaitingMomentum; schedule(); later(now, 0.1)
        } else if input.momentum == .none && phase == .tracking { schedule() }
        return true
    }
    @discardableResult
    func wheel(dx: Double, dy: Double, now: Double) -> Bool {
        guard dx.isFinite, dy.isFinite, dx != 0 || dy != 0, phase != .dragging else { return false }
        if phase != .wheel { close(); phase = .wheel; snaps = 0 }
        add(delta(dx, dy), now: now)
        later(now, 0.14)
        return true
    }
    func beginDrag() { close(); phase = .dragging; dragPixels = 0; snaps = 0 }
    func drag(_ pixels: Double) { guard phase == .dragging else { return }; add(-(pixels - dragPixels), now: CACurrentMediaTime()); dragPixels = pixels }
    /// Absolute scrubbing uses the same position and frame coalescing as gestures.
    func scrub(to value: Double) {
        guard phase == .dragging, value.isFinite else { return }
        pending = (bound(value) - position) * side * 0.42
        schedule()
    }
    func finishScrub() {
        guard phase == .dragging else { return }
        position = rounded(position + pending / (side * 0.42)); close(); paint?(snapshot, true)
    }
    func endDrag() { if phase == .dragging { settle() } }
    func navigate(_ value: Double, now: Double, animated: Bool = true) {
        close()
        if value != position { intentVelocity = (value - position) / max(0.35, duration) }
        let destination = rounded(value)
        phase = .snapping; target = destination; from = position; started = now - (animated ? 0 : duration); schedule()
    }
    func close() { closedGesture = max(closedGesture, gesture); cancel(); phase = .idle }
    func blur() { if phase != .idle { closedGesture = max(closedGesture, gesture); deadline = nil; settle() } }
    func expire(at now: Double) { if let deadline, now + 1e-10 >= deadline { self.deadline = nil; settle() } }
    /// One display tick flushes the final accumulated delta before starting a snap.
    func tick(at now: Double) {
        expire(at: now)
        guard scheduled else { return }
        scheduled = false
        if phase == .snapping, let target {
            let t = duration > 0 ? min(1, max(0, (now - started) / duration)) : 1
            position = from + (target - from) * (1 - pow(1 - t, 3))
            if t == 1 { phase = .idle; self.target = nil; paint?(snapshot, true) }
            else { paint?(snapshot, false); schedule() }
        } else {
            position = side > 0 ? bound(position + pending / (side * 0.42)) : bound(position); pending = 0
            if finishing {
                finishing = false; closedGesture = max(closedGesture, gesture)
                target = rounded(position); from = position; phase = .snapping; started = now; snaps += 1; schedule()
            }
            paint?(snapshot, false)
        }
    }
}
