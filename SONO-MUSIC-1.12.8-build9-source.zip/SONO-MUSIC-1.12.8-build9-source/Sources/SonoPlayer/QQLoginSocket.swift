import Foundation
import OSLog

/// Receives the binary MQTT stream carried by QQ Music's WebSocket.
actor QQLoginSocket {
    private static let logger = Logger(subsystem: "app.sono.native", category: "QQLoginSocket")
    private let session: URLSession
    private var socket: URLSessionWebSocketTask
    private var buffer = Data()
    private var earlyEvents: [QQLoginMQTT.Packet] = []

    init() {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = 20
        let session = URLSession(configuration: configuration)
        self.session = session
        socket = session.webSocketTask(
            with: URL(string: "wss://mu.y.qq.com/ws/handshake")!,
            protocols: ["mqtt"]
        )
        socket.maximumMessageSize = 65_536
    }

    deinit {
        session.invalidateAndCancel()
    }

    func start(qrID: String) async throws {
        try await withTaskCancellationHandler {
            var stage = "CONNECT"
            do {
                try Task.checkCancellation()
                let connect = try QQLoginMQTT.connect(clientID: UUID().uuidString, qrID: qrID)
                var endpoint = URL(string: "wss://mu.y.qq.com/ws/handshake")!
                var visited = Set<URL>()
                while true {
                    try Task.checkCancellation()
                    visited.insert(endpoint)
                    stage = "CONNECT"
                    socket.resume()
                    try await socket.send(.data(connect))
                    stage = "CONNACK"
                    let response = try await readPacket()
                    if response.type == 2, response.body.count >= 3,
                       response.body.dropFirst().first == 0 { break }
                    let reason = response.body.dropFirst().first ?? 255
                    Self.logger.notice("QQ CONNACK: type=\(response.type) reason=\(reason)")
                    guard visited.count < 3,
                          let reference = try QQLoginMQTT.serverReference(response) else {
                        throw URLError(.badServerResponse)
                    }
                    guard let next = Self.redirectEndpoint(reference),
                          !visited.contains(next) else { throw URLError(.badServerResponse) }
                    Self.logger.notice("Following QQ MQTT redirect through the QQ Music gateway")
                    socket.cancel(with: .goingAway, reason: nil)
                    buffer.removeAll()
                    endpoint = next
                    socket = session.webSocketTask(with: next, protocols: ["mqtt"])
                    socket.maximumMessageSize = 65_536
                }
                stage = "SUBSCRIBE"
                try await socket.send(.data(QQLoginMQTT.subscribe(qrID: qrID)))
                stage = "SUBACK"
                while true {
                    let packet = try await readPacket()
                    if packet.type == 9 {
                        guard packet.body.count >= 4, packet.body.prefix(2).elementsEqual([0, 1]),
                              packet.body.last == 0 else {
                            Self.logger.error("Unexpected SUBACK: length=\(packet.body.count) reason=\(packet.body.last ?? 255)")
                            throw URLError(.badServerResponse)
                        }
                        break
                    }
                    guard packet.type == 3, earlyEvents.count < 16 else {
                        Self.logger.error("Unexpected packet before SUBACK: type=\(packet.type) length=\(packet.body.count)")
                        throw URLError(.badServerResponse)
                    }
                    earlyEvents.append(packet)
                }
            } catch {
                if !Task.isCancelled {
                    let failure = error as NSError
                    Self.logger.error("QQ login \(stage, privacy: .public): \(failure.domain, privacy: .public) (\(failure.code)), close=\(self.socket.closeCode.rawValue)")
                }
                socket.cancel(with: .goingAway, reason: nil)
                throw error
            }
        } onCancel: {
            Task { await self.close() }
        }
    }

    static func redirectEndpoint(_ reference: String) -> URL? {
        // QQ Music accepts the broker address as a route on its TLS gateway.
        let address = reference.split(separator: ":", omittingEmptySubsequences: false)
        guard address.count == 2, let port = UInt16(address[1]), port > 0,
              String(port) == address[1] else { return nil }
        let octets = address[0].split(separator: ".", omittingEmptySubsequences: false)
        guard octets.count == 4, octets.allSatisfy({ part in
            UInt8(part).map { String($0) == part } ?? false
        }) else { return nil }
        return URL(string: "wss://mu.y.qq.com/ws/handshake/" + reference)
    }

    /// Use a single reader for the subscription acknowledgment and subsequent events.
    func nextPacket() async throws -> QQLoginMQTT.Packet {
        try await withTaskCancellationHandler {
            try Task.checkCancellation()
            if !earlyEvents.isEmpty { return earlyEvents.removeFirst() }
            return try await readPacket()
        } onCancel: { [socket] in
            socket.cancel(with: .goingAway, reason: nil)
        }
    }

    func keepAlive() async throws -> Never {
        while true {
            try await Task.sleep(for: .seconds(Int(QQLoginMQTT.keepAliveSeconds) / 2))
            try await socket.send(.data(QQLoginMQTT.pingRequest))
        }
    }

    func close() {
        socket.cancel(with: .normalClosure, reason: nil)
    }

    private func readPacket() async throws -> QQLoginMQTT.Packet {
        while true {
            try Task.checkCancellation()
            if let packet = try QQLoginMQTT.nextPacket(in: &buffer) { return packet }
            guard case .data(let data) = try await socket.receive(),
                  buffer.count + data.count <= 65_536 else {
                throw URLError(.cannotDecodeRawData)
            }
            buffer.append(data)
        }
    }
}
