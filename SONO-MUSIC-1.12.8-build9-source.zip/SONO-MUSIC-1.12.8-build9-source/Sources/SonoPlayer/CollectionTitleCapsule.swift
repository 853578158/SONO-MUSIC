import SwiftUI
import AppKit

/// The reference banner expands for roughly a second, with a small late overshoot.
private struct TitleCapsulePose {
    var width: CGFloat = 1
    var height: CGFloat = 1
    var y: CGFloat = 0
    var blur: CGFloat = 0
    var opacity: Double = 1

    static let hidden = Self(width: 0.35, height: 0.9, y: -36, blur: 5, opacity: 0)
    static let entrance: [(Double, Self)] = [
        (0, .hidden),
        (0.10, Self(width: 0.53, height: 1.02, y: -12, blur: 1)),
        (0.20, Self(width: 0.74, height: 1.06, y: -1)),
        (0.30, Self(width: 0.91, height: 1.06, y: 3)),
        (0.43, Self(width: 1.004, height: 1.01, y: 2)),
        (0.57, Self(width: 1.022, y: 0.2)),
        (0.73, Self(width: 1.013)),
        (1.03, Self())
    ]

    static func mix(_ a: Self, _ b: Self, _ t: Double) -> Self {
        let t = CGFloat(t)
        return Self(width: a.width + (b.width-a.width)*t,
                    height: a.height + (b.height-a.height)*t,
                    y: a.y + (b.y-a.y)*t, blur: a.blur + (b.blur-a.blur)*t,
                    opacity: a.opacity + (b.opacity-a.opacity)*Double(t))
    }

    static func entering(_ elapsed: Double) -> Self {
        for index in 1..<entrance.count where elapsed < entrance[index].0 {
            let (start, a) = entrance[index-1], (end, b) = entrance[index]
            let (beforeTime, before) = entrance[max(0, index-2)]
            let (afterTime, after) = entrance[min(entrance.count-1, index+1)]
            let t = max(0, (elapsed-start)/(end-start)), span = end-start
            func curve(_ p: CGFloat, _ q: CGFloat, _ previous: CGFloat, _ next: CGFloat) -> CGFloat {
                let m0 = (q-previous) / CGFloat(end-beforeTime) * CGFloat(span)
                let m1 = index == entrance.count-1 ? 0 : (next-p) / CGFloat(afterTime-start) * CGFloat(span)
                let u = CGFloat(t), u2 = u*u, u3 = u2*u
                return (2*u3-3*u2+1)*p + (u3-2*u2+u)*m0 + (-2*u3+3*u2)*q + (u3-u2)*m1
            }
            return Self(width: curve(a.width,b.width,before.width,after.width),
                        height: curve(a.height,b.height,before.height,after.height),
                        y: curve(a.y,b.y,before.y,after.y),
                        blur: max(0,curve(a.blur,b.blur,before.blur,after.blur)),
                        opacity: min(1,max(0,Double(curve(CGFloat(a.opacity),CGFloat(b.opacity),CGFloat(before.opacity),CGFloat(after.opacity))))))
        }
        return Self()
    }
}

private struct CollectionTitleContent: Equatable, Hashable {
    let key: String
    let title: String
    let subtitle: String
    let artwork: URL?
    let artistID: String?
}

private struct CollectionTitleHitShape: Shape {
    let size: CGSize
    func path(in rect: CGRect) -> Path {
        Path(roundedRect:CGRect(x:rect.midX-size.width/2,y:36,width:size.width,height:size.height),cornerRadius:18)
    }
}

private struct CollectionTitleHover: NSViewRepresentable {
    let size: CGSize
    let changed: (Bool) -> Void

    func makeNSView(context: Context) -> Surface { Surface() }
    func updateNSView(_ view: Surface, context: Context) {
        view.size = size
        view.changed = changed
    }
    static func dismantleNSView(_ view: Surface, coordinator: ()) { view.stopMonitoring() }

    final class Surface: NSView {
        var size: CGSize = .zero
        var changed: (Bool) -> Void = { _ in }
        private var monitor: Any?
        override var isFlipped: Bool { true }
        override func hitTest(_ point: NSPoint) -> NSView? { nil }

        override func viewDidMoveToWindow() {
            super.viewDidMoveToWindow()
            stopMonitoring()
            guard let window else { return }
            window.acceptsMouseMovedEvents = true
            monitor = NSEvent.addLocalMonitorForEvents(matching: [.mouseMoved, .mouseEntered, .mouseExited, .leftMouseDown, .leftMouseDragged]) { [weak self] event in
                MainActor.assumeIsolated {
                    guard let self else { return }
                    let point = self.convert(event.locationInWindow, from: nil)
                    let shape = CollectionTitleHitShape(size: self.size).path(in: self.bounds)
                    self.changed(event.window === self.window && shape.contains(point))
                }
                return event
            }
        }

        func stopMonitoring() {
            if let monitor { NSEvent.removeMonitor(monitor) }
            monitor = nil
        }
    }
}

struct CollectionTitleCapsule: View {
    let pageKey: String
    let title: String
    let subtitle: String
    let artwork: URL?
    let artistID: String?
    let maximumWidth: CGFloat
    var maximumHeight: CGFloat = 72
    let online: OnlineSession
    let visible: Bool
    var presentationChanged: (Bool) -> Void = { _ in }
    @Environment(\.accessibilityReduceMotion) private var reduced
    private enum Phase: String { case entering, holding, shrinking, compact, expanding, expanded, exiting }
    @State private var displayed: CollectionTitleContent?
    @State private var phase = Phase.compact
    @State private var started = Date()
    private let holdDuration: Double = 5
    @State private var remaining: Double = 5
    @State private var holdStarted = Date()
    @State private var hovered = false
    @State private var morphStart: CGFloat = 0
    @State private var exitStart = TitleCapsulePose()
    @State private var exitCompact: CGFloat = 0
    @State private var portrait: NSImage?
    private let fill = Color(nsColor: SonoGeneratedColors.collectionCapsule)
    private var content: CollectionTitleContent { .init(key: pageKey, title: title, subtitle: subtitle, artwork: artwork, artistID: artistID) }
    private var morphing: Bool { phase == .shrinking || phase == .expanding }
    private var moving: Bool { phase == .entering || morphing || phase == .exiting }
    private var acceptsHover: Bool { visible && phase != .entering && phase != .exiting }

    private func compact(at date: Date) -> CGFloat {
        switch phase {
        case .compact: return 1
        case .shrinking, .expanding:
            let t = min(1, max(0, date.timeIntervalSince(started)/(reduced ? 0.14 : 0.45)))
            let target: CGFloat = phase == .shrinking ? 1 : 0
            return morphStart + (target - morphStart) * CGFloat(t*t*(3-2*t))
        case .exiting: return exitCompact
        default: return 0
        }
    }
    private func pose(at date: Date) -> TitleCapsulePose {
        let elapsed = max(0,date.timeIntervalSince(started))
        if phase == .entering {
            return reduced ? TitleCapsulePose(opacity:min(1,elapsed/0.14)) : .entering(elapsed)
        }
        if phase == .exiting {
            let t = min(1,elapsed/(reduced ? 0.14 : 0.15))
            return reduced ? TitleCapsulePose(opacity:1-t) : .mix(exitStart,.hidden,t*t)
        }
        return TitleCapsulePose()
    }
    private func setHover(_ inside: Bool) {
        guard hovered != inside else { return }
        if phase == .holding {
            if inside { remaining = max(0, remaining-Date().timeIntervalSince(holdStarted)) }
            else { holdStarted = Date() }
        }
        hovered = inside
        if inside && (phase == .compact || phase == .shrinking) {
            morph(to: .expanding)
        } else if !inside && (phase == .expanded || phase == .expanding) {
            morph(to: .shrinking)
        }
    }

    private func morph(to next: Phase) {
        let now = Date()
        morphStart = compact(at: now)
        started = now
        phase = next
    }

    private func layoutWidth(_ content: CollectionTitleContent, compact: Bool) -> CGFloat {
        let titleWidth = SonoTypography.width(content.title, size: compact ? SonoDesktopTokens.FontSize.itemTitle : SonoDesktopTokens.FontSize.sectionTitle, weight: SonoDesktopTokens.FontWeight.medium)
        if compact {
            return min(maximumWidth / 2, (portrait == nil ? 14 : 54) + ceil(titleWidth))
        }
        let subtitleWidth = SonoTypography.width(content.subtitle, size: SonoDesktopTokens.FontSize.body)
        return min(maximumWidth, (portrait == nil ? 60 : 120) + ceil(max(titleWidth, subtitleWidth)))
    }

    private var hitSize: CGSize {
        guard let displayed else { return .zero }
        let small = phase == .compact
        let height: CGFloat = small ? 36 : 72
        let fit = min(1, maximumHeight / height)
        return CGSize(width: layoutWidth(displayed, compact: small) * fit, height: height * fit)
    }

    private func labels(_ content: CollectionTitleContent, wide: CGFloat, narrow: CGFloat,
                        shellWidth: CGFloat, height: CGFloat, compact c: CGFloat) -> some View {
        let wideLeft: CGFloat = portrait == nil ? 12 : 72
        let narrowLeft: CGFloat = portrait == nil ? 2 : 42
        let left = wideLeft + (narrowLeft - wideLeft) * c
        let wideText = max(0, wide - wideLeft - 48)
        let narrowText = max(0, narrow - narrowLeft - 12) / 0.8
        let room = max(0, shellWidth - left - 12)
        let fontScale = 1 - 0.2 * c
        let opening = phase == .entering || phase == .exiting
        let useWide = opening ? c < 0.5 : c < 1 && room + 0.5 >= wideText * fontScale
        // Use one of the two resting line widths. The ellipsis changes once, while the glyphs scale continuously.
        let lineWidth = useWide ? wideText : narrowText
        let availableScale = room / max(1, lineWidth)
        let entranceScale = opening ? min(1, max(0, (shellWidth / (c < 0.5 ? wide : narrow) - 0.56) / 0.4)) : 1
        let titleScale = min(fontScale, availableScale) * entranceScale
        let interactive = phase == .holding || phase == .expanded
        let titleCenter = height / 2 - (content.subtitle.isEmpty ? 0 : 11 * (1 - c))
        let subtitleScale = min(1 - c, room / max(1, wideText)) * entranceScale

        return ZStack(alignment: .topLeading) {
            ConsoleReadingText(text: content.title, size: SonoDesktopTokens.FontSize.sectionTitle, weight: SonoDesktopTokens.FontWeight.medium,
                               color: SonoGeneratedColors.capsuleText, scrollsOnHover: interactive)
                .frame(width: lineWidth, height: 28, alignment: .leading)
                .scaleEffect(titleScale, anchor: .topLeading)
                .offset(x: left, y: titleCenter - 14 * titleScale)
            if subtitleScale > 0 && !content.subtitle.isEmpty {
                ConsoleReadingText(text: content.subtitle, size: SonoDesktopTokens.FontSize.body, weight: SonoDesktopTokens.FontWeight.regular,
                                   color: SonoGeneratedColors.capsuleText, scrollsOnHover: interactive)
                    .frame(width: wideText, height: 20, alignment: .leading)
                    .scaleEffect(subtitleScale, anchor: .topLeading)
                    .offset(x: left, y: titleCenter + 4 * (1 - c) + 10 * subtitleScale)
                    .accessibilityHidden(!interactive)
            }
        }
        .fixedSize()
        .allowsHitTesting(interactive)
    }

    var body: some View {
        GeometryReader { geometry in
            TimelineView(.animation(paused: !moving)) { timeline in
                if let displayed {
                    let pose = pose(at:timeline.date), c = compact(at:timeline.date)
                    let wide = layoutWidth(displayed, compact: false)
                    let narrow = layoutWidth(displayed, compact: true)
                    let width = wide + (narrow - wide) * c
                    let height: CGFloat = 72 - 36 * c
                    let fit = min(1, maximumHeight / height)
                    let shellWidth = min(maximumWidth, width * pose.width) / pose.height
                    let avatarSize: CGFloat = SonoDesktopTokens.Cover.portrait + (SonoDesktopTokens.Cover.compactTitle - SonoDesktopTokens.Cover.portrait) * c
                    let leading: CGFloat = 12 - 10 * c
                    RoundedRectangle(cornerRadius: 18)
                        .fill(fill)
                        .frame(width: shellWidth, height: height)
                        .overlay(alignment: .topLeading) {
                            labels(displayed, wide: wide, narrow: narrow,
                                   shellWidth: shellWidth, height: height, compact: c)
                        }
                        .overlay(alignment: .leading) {
                            if let portrait {
                                Image(nsImage: portrait).resizable().scaledToFill()
                                    .frame(width: avatarSize, height: avatarSize)
                                    .clipShape(RoundedRectangle(cornerRadius: 12 + 4 * c))
                                    .padding(.leading, leading)
                                    .allowsHitTesting(false)
                            }
                        }
                        .clipShape(RoundedRectangle(cornerRadius: 18))
                    .scaleEffect(pose.height * fit, anchor: .top)
                    .blur(radius:pose.blur).opacity(pose.opacity)
                    .contentShape(RoundedRectangle(cornerRadius:18))
                    .allowsHitTesting(acceptsHover).accessibilityHidden(!visible)
                    .position(x:geometry.size.width/2,y:4+height/2+pose.y)
                }
            }
        }
        .clipped().padding(.top,SonoDesktopTokens.Spacing.s32)
        .contentShape(CollectionTitleHitShape(size:hitSize))
        .allowsHitTesting(acceptsHover)
        .background {
            if acceptsHover && displayed != nil {
                CollectionTitleHover(size: hitSize, changed: setHover)
            }
        }
        .onChange(of: displayed != nil && phase != .exiting, initial: true) { _, presented in
            presentationChanged(presented)
        }
        .onDisappear { presentationChanged(false) }
        .task(id: visible ? content : nil) {
            if visible {
                let next = content
                if let current = displayed, current.key == next.key, phase != .exiting {
                    displayed = next
                    // A tab changes the work list, not the artist's portrait.
                    if let artistID = current.artistID, artistID == next.artistID, portrait != nil { return }
                    guard current.artwork != next.artwork || current.artistID != next.artistID else { return }
                    if let image = await loadPortrait(for: next), !Task.isCancelled {
                        portrait = image
                    }
                    return
                }
                displayed = nil; phase = .compact
                let image = await loadPortrait(for: next)
                guard !Task.isCancelled else { return }
                portrait = image
                displayed = next
                hovered = false
                phase = .entering; started = Date()
            } else {
                guard displayed != nil else { return }
                exitStart = pose(at:Date()); exitCompact = compact(at:Date())
                phase = .exiting; started = Date()
                do { try await Task.sleep(for:.seconds(reduced ? 0.14 : 0.15)) } catch { return }
                displayed = nil; phase = .compact
            }
        }
        .task(id: phase == .entering ? started : nil) {
            guard phase == .entering else { return }
            do { try await Task.sleep(for: .seconds(reduced ? 0.14 : 1.03)) }
            catch { return }
            phase = .holding; remaining = holdDuration; holdStarted = Date()
        }
        .task(id:"\(displayed?.key ?? "")/\(phase.rawValue)/\(hovered)") {
            guard phase == .holding, !hovered else { return }
            do {
                try await Task.sleep(for:.seconds(remaining))
                morph(to: .shrinking)
            } catch { return }
        }
        .task(id:phase) {
            guard morphing else { return }
            let end: Phase = phase == .shrinking ? .compact : .expanded
            do { try await Task.sleep(for:.seconds(reduced ? 0.14 : 0.45)) }
            catch { return }
            phase = end
        }
    }

    private func loadPortrait(for content: CollectionTitleContent) async -> NSImage? {
        let url: URL?
        if let id = content.artistID { url = await online.artistAvatar(id) ?? content.artwork }
        else if let artwork = content.artwork { url = artwork }
        else { url = nil }
        guard !Task.isCancelled,
              var components = url.flatMap({ URLComponents(url:$0,resolvingAgainstBaseURL:false) }) else { return nil }
        components.queryItems = (components.queryItems ?? []).filter { $0.name != "param" } + [URLQueryItem(name:"param",value:"128y128")]
        guard let requestURL = components.url else { return nil }
        do {
            let request = URLRequest(url:requestURL,timeoutInterval:5)
            let (data,response) = try await URLSession.shared.data(for:request)
            guard (response as? HTTPURLResponse)?.statusCode == 200 else { return nil }
            return NSImage(data:data)
        } catch {
            // On failure, the banner can still present the result as text.
            return nil
        }
    }
}
