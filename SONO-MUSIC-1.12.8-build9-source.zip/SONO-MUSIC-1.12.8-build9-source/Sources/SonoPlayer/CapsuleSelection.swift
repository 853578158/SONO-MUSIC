enum CapsuleSourceSelection {
    static func isSearchDetail(_ key: String, fromSearch: Bool) -> Bool {
        fromSearch && (key.hasPrefix("artist/") || key.hasPrefix("album/"))
    }

    static func resolve(requested: String?, displayed: String, fromSearch: Bool = false) -> String? {
        let key = requested ?? displayed
        if key.hasPrefix("search/") || isSearchDetail(key, fromSearch: fromSearch || displayed.hasPrefix("search/")) {
            return "search"
        }
        return key == "local" || key.hasPrefix("playlist/") ? key : nil
    }
}
