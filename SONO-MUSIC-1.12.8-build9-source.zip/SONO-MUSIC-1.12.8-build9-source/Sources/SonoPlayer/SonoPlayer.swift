import AppKit
import SwiftUI

private struct SonoWindowContentVisibleKey: EnvironmentKey {
    static let defaultValue = true
}

extension EnvironmentValues {
    var sonoWindowContentVisible: Bool {
        get { self[SonoWindowContentVisibleKey.self] }
        set { self[SonoWindowContentVisibleKey.self] = newValue }
    }
}

struct Cover: View {
    let track: LocalTrack?
    var pixels: Int = 160
    private func artworkURL(_ url: URL) -> URL {
        guard var components = URLComponents(url: url, resolvingAgainstBaseURL: false) else { return url }
        var query = components.queryItems ?? []
        query.removeAll { $0.name == "param" }
        query.append(URLQueryItem(name: "param", value: "\(pixels)y\(pixels)"))
        components.queryItems = query
        return components.url ?? url
    }
    var body: some View {
        Group {
            if let url = track?.coverURL, !url.isFileURL {
                AsyncImage(url: artworkURL(url)) { image in image.resizable().scaledToFill() } placeholder: { Image(nsImage: SonoAssets.image("local-default")!).resizable().scaledToFill() }
            } else if let image = ArtworkCache.shared.image(track?.coverURL) ?? SonoAssets.image("local-default") {
                Image(nsImage: image).resizable().scaledToFill()
            }
        }.clipped().accessibilityHidden(true)
    }
}

private struct ConsoleArtworkRotation: ViewModifier {
    let playing: Bool
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.sonoWindowContentVisible) private var windowContentVisible
    @State private var elapsed: TimeInterval = 0
    @State private var started: Date?
    private var rotating: Bool { playing && !reduceMotion && windowContentVisible }

    func body(content: Content) -> some View {
        TimelineView(.animation(minimumInterval: 1.0 / 30, paused: !rotating)) { timeline in
            let seconds = elapsed + (started.map { timeline.date.timeIntervalSince($0) } ?? 0)
            content.rotationEffect(.degrees(seconds.truncatingRemainder(dividingBy: 30) * 12))
        }
        .onChange(of: rotating, initial: true) { _, active in
            let now = Date()
            if let started { elapsed += now.timeIntervalSince(started) }
            started = active ? now : nil
        }
        .onDisappear {
            if let started { elapsed += Date().timeIntervalSince(started) }
            started = nil
        }
        .onAppear { if rotating && started == nil { started = Date() } }
    }
}

private struct ConsoleButtonStyle: ButtonStyle {
    @Environment(\.isEnabled) private var enabled
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .onHover { inside in (inside && enabled ? NSCursor.pointingHand : NSCursor.arrow).set() }
    }
}

private struct ConsoleControlStyle: ButtonStyle {
    var color: NSColor? = nil
    var ordinary = true
    var preservesHue = false
    var loading = false
    var selected = false

    func makeBody(configuration: Configuration) -> some View {
        ConsoleControlBody(style: self, configuration: configuration)
    }
}

private struct ConsoleControlBody: View {
    let style: ConsoleControlStyle
    let configuration: ButtonStyleConfiguration
    @Environment(\.isEnabled) private var enabled
    @Environment(\.colorScheme) private var colorScheme
    @State private var hovered = false

    private func foreground(pressed: Bool) -> NSColor {
        let light = colorScheme == .light
        if !enabled && !style.loading && !style.preservesHue { return light ? SonoGeneratedColors.consoleDisabledIcon : SonoGeneratedColors.consoleDisabledIconDark }
        if style.preservesHue, let color = style.color { return color }
        if pressed || style.selected { return light ? SonoGeneratedColors.consolePressedIconLight : SonoGeneratedColors.consolePressedIconDark }
        if hovered && enabled { return light ? SonoGeneratedColors.consoleHoverIcon : SonoGeneratedColors.consoleHoverIconDark }
        return light ? SonoGeneratedColors.inactiveIcon : SonoGeneratedColors.consoleDefaultIconDark
    }

    var body: some View {
        Group {
            if style.ordinary {
                configuration.label.foregroundStyle(Color(nsColor: foreground(pressed: configuration.isPressed)))
            } else if let color = style.color {
                configuration.label.foregroundStyle(Color(nsColor: color))
            } else {
                configuration.label
            }
        }
        .onHover { inside in
            hovered = inside
            (inside && enabled ? NSCursor.pointingHand : .arrow).set()
        }
        .onDisappear { hovered = false }
    }
}

private struct PlaybackProgress: View {
    @Environment(\.lyricsInk) private var ink
    @Environment(\.colorScheme) private var colorScheme
    @ObservedObject var audio: PlaybackController
    @ObservedObject var chorus: ChorusState
    let scale: CGFloat
    var targeting = false
    var trackColor: NSColor = SonoGeneratedColors.progressTrack
    var trackHeight: CGFloat? = nil
    var squareOuterEnds = false
    var capsule = false
    var bubbleHorizontalAllowance: CGFloat = 0
    var expandedChanged: (Bool) -> Void = { _ in }
    var draggingChanged: (Bool) -> Void = { _ in }
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @ViewState private var pointer: CGPoint?
    @ViewState private var dragging = false
    @GestureState private var dragMoved = false
    @State private var hoverReady = false
    private var duration: Double { targeting ? 0 : audio.duration }
    private var elapsed: Double { targeting ? 0 : audio.elapsed }
    private var enabled: Bool { audio.current != nil && !targeting && duration > 0 }
    var body: some View {
        GeometryReader { geometry in
            let expanded = capsule && enabled && (hoverReady || dragging)
            let dragInset: CGFloat = capsule ? 32 * scale : 0
            let dragWidth = max(1, geometry.size.width - dragInset * 2)
            let inset: CGFloat = expanded ? dragInset : 0
            let width = max(1, geometry.size.width - inset * 2)
            let progress = duration > 0 ? min(1, max(0, elapsed / duration)) : 0
            let thumbX: CGFloat = inset + width * CGFloat(progress)
            let railY = capsule ? (expanded ? geometry.size.height * 0.7 : geometry.size.height - scale) : geometry.size.height / 2
            let hitHeight = capsule && !expanded ? 8 * scale : geometry.size.height
            let hitTop = geometry.size.height - hitHeight
            let height = capsule ? (expanded ? 4 : 2) * scale : (trackHeight ?? 3 * scale) * (squareOuterEnds && (pointer != nil || dragging) ? 2 : 1)
            let diameter = max(10, 12 * scale)
            let showsThumb = enabled && (capsule ? expanded : pointer != nil || dragging)
            let overThumb = pointer.map { hypot($0.x - thumbX, $0.y - railY) <= diameter / 2 + 2 } ?? false
            let hoverCursor: NSCursor = enabled && pointer != nil ? (overThumb ? .openHand : .pointingHand) : .arrow
            ZStack(alignment: .topLeading) {
                ZStack(alignment: .leading) {
                    RoundedRectangle(cornerRadius: squareOuterEnds ? 0 : height / 2)
                        .fill(Color(nsColor: trackColor)).frame(height: height)
                    UnevenRoundedRectangle(topLeadingRadius: squareOuterEnds ? 0 : height / 2,
                                           bottomLeadingRadius: squareOuterEnds ? 0 : height / 2,
                                           bottomTrailingRadius: squareOuterEnds && progress == 1 ? 0 : height / 2,
                                           topTrailingRadius: squareOuterEnds && progress == 1 ? 0 : height / 2)
                        .fill(Color(nsColor: ink.primary)).frame(width: width * CGFloat(progress), height: height)
                }
                .frame(width: width, height: height)
                .overlay(alignment: .topLeading) {
                    if enabled {
                        let light = ink.contentAdaptive ? ink.light : colorScheme == .light
                        let nodeColor = light ? SonoGeneratedColors.progressChorusLight : SonoGeneratedColors.progressChorusDark
                        ZStack(alignment: .topLeading) {
                            ForEach(Array(chorus.ranges.enumerated()), id: \.offset) { _, range in
                                if let fraction = range.startFraction(duration: duration) {
                                    Circle().fill(Color(nsColor: nodeColor))
                                        .frame(width: height, height: height)
                                        .position(x: min(max(height / 2, width * fraction), width - height / 2), y: height / 2)
                                }
                            }
                        }
                        .frame(width: width, height: height)
                        .opacity(capsule && !expanded ? 0 : 1)
                    }
                }
                .overlay(alignment: .leading) {
                    // Keep the console thumb attached to the rail during both directions of motion.
                    if capsule || showsThumb {
                        let thumbDiameter = showsThumb ? diameter : 0
                        Circle().fill(Color(nsColor: ink.primary.withAlphaComponent(1)))
                            .frame(width: thumbDiameter, height: thumbDiameter)
                            .offset(x: width * CGFloat(progress) - thumbDiameter / 2)
                    }
                }
                .position(x: geometry.size.width / 2, y: railY)
                .allowsHitTesting(false)
                Color.clear
                    .frame(width: geometry.size.width, height: hitHeight)
                    .contentShape(Rectangle())
                    .onContinuousHover { phase in
                        switch phase {
                        case .active(let location):
                            pointer = CGPoint(x: location.x, y: location.y + hitTop)
                            if !dragging { (enabled ? (overThumb ? NSCursor.openHand : .pointingHand) : .arrow).set() }
                        case .ended:
                            pointer = nil
                            hoverReady = false
                            if !dragging { NSCursor.arrow.set() }
                        }
                    }
                    .gesture(DragGesture(minimumDistance: 0)
                        .updating($dragMoved) { value, moved, _ in
                            moved = moved || abs(value.translation.width) >= 3 * scale
                        }
                        .onChanged { value in
                            guard enabled else { return }
                            if !dragging { hoverReady = capsule; dragging = true; draggingChanged(true) }
                            let location = CGPoint(x: value.location.x, y: value.location.y + hitTop)
                            pointer = location
                            NSCursor.closedHand.set()
                            seek(at: location, inset: dragInset, width: dragWidth, railY: railY,
                                 snapsToChorus: hypot(value.translation.width, value.translation.height) < 3 * scale)
                        }
                        .onEnded { value in
                            if enabled {
                                seek(at: CGPoint(x: value.location.x, y: value.location.y + hitTop), inset: dragInset, width: dragWidth, railY: railY,
                                     snapsToChorus: hypot(value.translation.width, value.translation.height) < 3 * scale)
                            }
                            dragging = false
                            draggingChanged(false)
                            (enabled && pointer != nil ? NSCursor.openHand : NSCursor.arrow).set()
                        })
                    .focusable(enabled).focusEffectDisabled()
                    .accessibilityRepresentation {
                        Slider(value: Binding(get: { elapsed }, set: { audio.seek($0) }), in: 0...max(1, duration)) { Text("播放进度") }
                            .accessibilityValue(time(elapsed) + "/" + time(duration, padded: true)).disabled(!enabled)
                    }
                    .onKeyPress(.leftArrow) { adjust(by: -1); return .handled }
                    .onKeyPress(.rightArrow) { adjust(by: 1); return .handled }
                    .position(x: geometry.size.width / 2, y: hitTop + hitHeight / 2)
            }
            .frame(width: geometry.size.width, height: geometry.size.height, alignment: .topLeading)
            .clipShape(RoundedRectangle(cornerRadius: capsule ? geometry.size.height / 2 : 0))
            .task(id: capsule && enabled && pointer != nil) {
                guard !dragging else { return }
                hoverReady = false
                guard capsule && enabled && pointer != nil else { return }
                do { try await Task.sleep(for: .milliseconds(200)) }
                catch { return } // Leaving the bottom target cancels the intentional hover dwell.
                guard !Task.isCancelled else { return }
                hoverReady = true
            }
            .onChange(of: expanded) { _, value in expandedChanged(value) }
            .onChange(of: hoverCursor) { _, cursor in
                if pointer != nil && !dragging { cursor.set() }
            }
            .overlay(alignment: .topLeading) {
                if showsThumb && dragging && dragMoved {
                    let width = geometry.size.width
                    let allowance = bubbleHorizontalAllowance
                    let gap = capsule ? SonoDesktopTokens.Spacing.s4 : SonoDesktopTokens.Spacing.s8
                    let bottom = railY - diameter / 2 - gap
                    let colors = SonoProgressBubbleColors(dark: capsule ? colorScheme == .dark : !ink.light)
                    Text(time(elapsed) + "/" + time(duration, padded: true))
                        .font(SonoTypography.font(size: SonoDesktopTokens.FontSize.caption * scale, weight: SonoDesktopTokens.FontWeight.medium)).monospacedDigit()
                        .foregroundStyle(Color(nsColor: colors.text))
                        .padding(.horizontal, SonoDesktopTokens.Spacing.s8)
                        .padding(.vertical, SonoDesktopTokens.Spacing.s8 * scale)
                        .background(Color(nsColor: colors.fill), in: RoundedRectangle(cornerRadius: 7))
                        .fixedSize()
                        .visualEffect { content, bubble in
                            let left = min(max(-allowance, thumbX - bubble.size.width / 2), width + allowance - bubble.size.width)
                            return content.offset(x: left, y: bottom - bubble.size.height)
                        }
                        .allowsHitTesting(false).accessibilityHidden(true)
                }
            }
            .animation(reduceMotion || dragging ? nil : .easeInOut(duration: 0.18), value: expanded)
        }
            .onChange(of: audio.current?.id) { _, _ in
                if dragging { draggingChanged(false) }
                dragging = false; pointer = nil; hoverReady = false
            }
            .onDisappear { if dragging { draggingChanged(false) }; expandedChanged(false) }
    }
    private func seek(at location: CGPoint, inset: CGFloat, width: CGFloat, railY: CGFloat, snapsToChorus: Bool) {
        let seconds = min(1, max(0, (location.x - inset) / width)) * duration
        if snapsToChorus, abs(location.y - railY) <= 8 * scale,
           let start = ChorusRange.jumpTarget(in: chorus.ranges, seconds: seconds,
                                             tolerance: Double(8 * scale / width) * duration, duration: duration) {
            audio.seek(start)
        } else {
            audio.seek((seconds * 10).rounded() / 10)
        }
    }
    private func adjust(by seconds: Double) {
        guard enabled else { return }
        audio.seek(min(duration, max(0, elapsed + seconds)))
    }
    private func time(_ seconds: Double, padded: Bool = false) -> String {
        guard seconds.isFinite, seconds >= 0 else { return "00:00" }
        return String(format: padded ? "%02d:%02d" : "%d:%02d", Int(seconds) / 60, Int(seconds) % 60)
    }
}

private struct ConsoleVolumeSlider: View {
    @Binding var volume: Double
    let scale: CGFloat
    var tint: Color = Color(nsColor: SonoGeneratedColors.primaryText)
    var trackColor: NSColor = SonoGeneratedColors.volumeTrack
    let onDraggingChanged: (Bool) -> Void
    @GestureState private var dragging = false

    var body: some View {
        GeometryReader { geometry in
            let width = geometry.size.width
            Capsule()
                .fill(Color(nsColor: trackColor))
                .frame(width: width, height: 8 * scale)
                .overlay(alignment: .leading) {
                    Rectangle().fill(tint).frame(width: width * volume)
                }
                .clipShape(Capsule())
                .frame(height: geometry.size.height)
                .contentShape(Rectangle())
                .gesture(DragGesture(minimumDistance: 0)
                    .updating($dragging) { _, dragging, _ in dragging = true }
                    .onChanged { drag in
                        let fraction = drag.location.x / width
                        volume = min(1, max(0, (fraction * 100).rounded() / 100))
                    })
        }
        .onChange(of: dragging) { _, dragging in onDraggingChanged(dragging) }
        .onDisappear { onDraggingChanged(false) }
        .focusable()
        .focusEffectDisabled()
        .accessibilityRepresentation {
            Slider(value: $volume, in: 0...1, step: 0.01) { Text("音量") }
                .accessibilityValue("\(Int((volume * 100).rounded()))%")
        }
        .onKeyPress(.leftArrow) { volume = max(0, volume - 0.01); return .handled }
        .onKeyPress(.rightArrow) { volume = min(1, volume + 0.01); return .handled }
    }
}

private struct SonoToast: Identifiable {
    enum Source { case search, player, audio, online, song, loading, membership }
    let id = UUID()
    let source: Source
    let message: String
    let expires: ContinuousClock.Instant?
}

struct SonoScene: View {
    @Environment(\.colorScheme) private var colorScheme
    private let capsuleThickness = SonoChromeMetrics.buttonSize
    @ObservedObject var session: PlayerSession
    @ObservedObject var browser: MusicBrowser
    @ObservedObject var online: OnlineSession
    private var globalSearch: Bool { get { !browser.quickListOpen && browser.location.searchGlobal } nonmutating set { browser.location.searchGlobal = newValue } }
    @State private var playlistSong: LocalTrack?
    @State private var favoriteRemoval: LocalTrack?
    @State private var songRemoval: (song: String, playlist: String, title: String, name: String, owner: String)?
    @State private var confirmsSongRemoval = false
    @ViewState private var accountOpen = false
    @State private var accountRowOrder: [String] = []
    @ViewState private var addAccountOpen = false
    @ViewState private var searchExpanded = false
    @ViewState private var pendingCollectionSearch: String?
    @ViewState private var searchCaretRequest = 0
    @ViewState private var toasts: [SonoToast] = []
    @ViewState private var titleCapsuleVisible = false
    @ViewState private var suggestionIndex = -1
    @ViewState private var suggestionScrollIndex: Int?
    @ViewState private var capsuleTip: (id: String, title: String, y: CGFloat)?
    @ViewState private var artistChoice: LocalTrack?
    @ViewState private var artistChoiceClosing = false
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @AppStorage("glassDensity", store: PerformanceEnvironment.defaults) private var glassDensity = SonoGlassDensity.regular
    @AppStorage("theme", store: PerformanceEnvironment.defaults) private var theme = SonoTheme.initialValue
    @AppStorage("appearance", store: PerformanceEnvironment.defaults) private var appearance = SonoAppearance.initialValue
    @ViewState private var homeVolumeExpanded = false
    @ViewState private var homeVolumeHovered = false
    @ViewState private var homeVolumeDragging = false
    @ViewState private var progressDragging = false
    @ViewState private var homeProgressExpanded = false
    @ViewState private var previousVolume = 0.65
    @StateObject private var queueState = QueuePresentationState()
    @ViewState private var selectedFolders: Set<UUID> = []
    @ViewState private var searchFocused = false
    @State private var sourceWidth: CGFloat = 278
    @State private var collapsedPlaylistSections: Set<SourcePlaylistSection> = []
    @State private var collapsedLocalFolders: Set<UUID> = []
    @State private var lyricsBackgroundCanStart = false
    @State private var lyricsMounted = false
    @State private var lyricsAtTop = false
    @State private var lyricsSettled = false
    @State private var lyricsTransition = UUID()

    private func presentLyrics(_ open: Bool) {
        let transition = UUID()
        lyricsTransition = transition
        if open {
            collapseSearch()
            if !lyricsMounted { lyricsBackgroundCanStart = false }
            lyricsMounted = true
        }
        if reduceMotion {
            lyricsAtTop = open
            lyricsSettled = open
            lyricsMounted = open
            lyricsBackgroundCanStart = open
            return
        }

        lyricsSettled = false
        let animation: Animation = open
            ? .timingCurve(0.16, 1, 0.3, 1, duration: 0.42)
            : .timingCurve(0.4, 0, 0.6, 1, duration: 0.20)
        // Mount the page in its offscreen position before starting the first move.
        Task { @MainActor in
            await Task.yield()
            guard lyricsTransition == transition else { return }
            withAnimation(animation, completionCriteria: .removed) {
                lyricsAtTop = open
            } completion: {
                guard lyricsTransition == transition else { return }
                lyricsSettled = open
                if !open {
                    lyricsMounted = false
                    lyricsBackgroundCanStart = false
                }
            }
        }
    }

    var body: some View {
        GeometryReader { geometry in
            let tracks = browser.filtered(session.browseTracks)
            let itemCount = session.onlineShowing && !browser.searching ? online.page?.items?.count ?? tracks.count : tracks.count
            let count = browser.roundWall ? itemCount : max(itemCount, browser.sourceTotal)
            let metrics = BrowseMetrics(viewport: geometry.size, count: count, source: browser.sourceKey)
            let categoryY = browser.layout == .carousel && !browser.quickListOpen && count > 0
                ? metrics.carouselCategoryCenterY : metrics.categoryCenterY
            let hideCarouselCategories = browser.layout == .carousel && !browser.quickListOpen && browser.carouselPositionBubbleVisible
            let scale = metrics.scale
            let consoleWidth = 552 * scale
            let consoleHeight = 64 * scale
            let topControlsY = SonoChromeMetrics.topCenterY
            let drawerWidth = 351 * scale
            let hasBrowseContent = (session.onlineShowing && online.page?.items?.isEmpty == false) || (!session.browseTracks.isEmpty && !tracks.isEmpty) || (browser.layout == .carousel && !browser.searching && !browser.sourceOrderedIDs.isEmpty)
            ZStack(alignment: .topLeading) {
                ZStack(alignment: .topLeading) {
                Group {
                Color(nsColor: SonoGeneratedColors.pageBackground).accessibilityHidden(true)
                if hasBrowseContent || (session.onlineShowing && browser.carouselOnly) {
                    LibraryStage(session: session, browser: browser, presented: !lyricsSettled, catalog: openCatalog, openEntity: openBrowseEntity).allowsHitTesting(!session.lyricsOpen).accessibilityHidden(session.lyricsOpen)
                }
                if !hasBrowseContent && !online.loading && !online.restoringAccount { welcome }
                }.disabled(searchSuggestionsOpen).allowsHitTesting(!searchSuggestionsOpen)
                if !lyricsSettled {
                    let inset = SonoChromeMetrics.horizontalInset
                    let spacing: CGFloat = 12
                    let searchLeading = inset + capsuleThickness + spacing
                    let trailingControlsWidth = 3 * capsuleThickness + 2 * spacing
                    let searchWidth = min(SonoChromeMetrics.sourceDrawerMaximumWidth - searchLeading, geometry.size.width - searchLeading - inset - trailingControlsWidth - spacing)
                    searchChrome(width: searchWidth, spacing: spacing)
                        .padding(.leading, inset)
                        .padding(.top, SonoChromeMetrics.topInset)
                        .zIndex(searchSuggestionsOpen ? 2 : 0)
                }
                CollectionTitleCapsule(pageKey: online.page?.kind.artistID.map { "artist/" + $0 } ?? browser.sourceKey, title: session.browseTitle,
                    subtitle: online.page?.collectionDisplaySubtitle ?? "",
                    artwork: online.page?.collectionArtwork,
                    artistID: online.page?.kind.artistID,
                    maximumWidth: consoleWidth,
                    maximumHeight: online.page?.kind.artistID != nil
                        ? min(72, max(36, categoryY - 18 * scale - SonoDesktopTokens.Spacing.s8 - SonoChromeMetrics.topInset)) : 72,
                    online: online,
                    visible: !lyricsSettled && !searchExpanded && collectionPage && online.page?.kind.key == browser.sourceKey,
                    presentationChanged: { titleCapsuleVisible = $0 })
                    .zIndex(1)
                if !lyricsSettled && (!searchSuggestionsOpen || browser.quickListOpen) {
                    resultCategories(scale: scale)
                        .opacity(hideCarouselCategories ? 0 : 1)
                        .allowsHitTesting(!hideCarouselCategories).accessibilityHidden(hideCarouselCategories)
                        .position(x: geometry.size.width / 2, y: categoryY)
                }
                if !lyricsSettled && online.activePlatform == .netease && online.page?.kind.isDailyRecommendation == true && browser.sourceKey == online.page?.kind.key {
                    Color.black.opacity(0.001).contentShape(Rectangle())
                        .frame(height: 44 * scale)
                        .pointerStyle(.default)
                        .position(x: geometry.size.width / 2, y: categoryY)
                    if online.dailyStylePickerOpen {
                        Color.black.opacity(0.001).contentShape(Rectangle())
                            .onTapGesture { online.closeDailyStylePicker() }
                            .zIndex(2)
                    }
                    DailyRecommendationToolbar(online: online, scale: scale, viewport: geometry.size)
                        .opacity(hideCarouselCategories ? 0 : 1)
                        .allowsHitTesting(!hideCarouselCategories).accessibilityHidden(hideCarouselCategories)
                        .position(x: geometry.size.width / 2, y: categoryY)
                        .zIndex(3)
                    if !browser.quickListOpen && online.page?.tracks.isEmpty == true {
                        DailyRecommendationEmptyState(online: online)
                            .position(x: geometry.size.width / 2, y: geometry.size.height / 2)
                    }
                }
                toastStack
                    .frame(maxWidth: min(540, geometry.size.width - 32))
                    .frame(maxWidth: .infinity)
                    .padding(.top, topControlsY + capsuleThickness / 2 + SonoDesktopTokens.Spacing.s16)
                Group {
                if !lyricsSettled {
                if !browser.quickListOpen {
                HStack(spacing: SonoDesktopTokens.Spacing.s12) {
                    HStack(spacing: SonoDesktopTokens.Spacing.s0) {
                        Button { browser.setLayout(browser.layout == .wall ? .carousel : .wall) } label: {
                            Group {
                                if browser.layout == .wall {
                                    SonoIcon(name: "icon-carousel", size: SonoDesktopTokens.SvgSize.s24, inheritsForeground: true)
                                        .sonoIconFrame(SonoDesktopTokens.IconFrame.s24)
                                } else {
                                    Image(systemName: "square.grid.2x2").font(.system(size: SonoDesktopTokens.SymbolSize.control)).sonoIconFrame(SonoDesktopTokens.IconFrame.s24)
                                }
                            }.frame(width: SonoChromeMetrics.buttonSize, height: SonoChromeMetrics.buttonSize).chromeSurface()
                        }
                            .disabled(browser.carouselOnly)
                            .buttonStyle(SonoQueueButtonStyle(normal: SonoGeneratedColors.toolIcon, light: colorScheme == .light))
                            .accessibilityLabel(layoutSwitchHelp)
                    }
                        .sonoTooltip(layoutSwitchHelp)
                        .onHover { inside in (inside && !browser.carouselOnly ? NSCursor.pointingHand : NSCursor.arrow).set() }
                    Button { session.settingsOpen = true } label: {
                        Image(systemName: "slider.horizontal.3").font(.system(size: SonoDesktopTokens.SymbolSize.control)).sonoIconFrame(SonoDesktopTokens.IconFrame.s24)
                            .frame(width: 36, height: 36).chromeSurface()
                    }.buttonStyle(SonoQueueButtonStyle(normal: SonoGeneratedColors.toolIcon, light: colorScheme == .light)).help("打开设置").accessibilityLabel("打开设置")
                        .onHover { inside in (inside ? NSCursor.pointingHand : NSCursor.arrow).set() }
                    Button { accountOpen.toggle() } label: {
                        Image(systemName: "person.fill").font(.system(size: SonoDesktopTokens.SymbolSize.control)).sonoIconFrame(SonoDesktopTokens.IconFrame.s24)
                            .frame(width: 36, height: 36).chromeSurface()
                    }.buttonStyle(SonoQueueButtonStyle(normal: accountOpen ? (colorScheme == .light ? SonoGeneratedColors.queuePressedLight : SonoGeneratedColors.queuePressedDark) : SonoGeneratedColors.toolIcon, light: colorScheme == .light, active: !accountOpen)).help("用户信息").accessibilityLabel("用户信息")
                        .onHover { inside in (inside ? NSCursor.pointingHand : NSCursor.arrow).set() }
                }.position(x: geometry.size.width - SonoChromeMetrics.horizontalInset - 66, y: topControlsY)
                }
                if !browser.quickListOpen && !session.sidebarOpen && !session.directoryManagerOpen && !session.settingsOpen {
                    capsule(height: geometry.size.height).frame(width: capsuleThickness).position(x: SonoChromeMetrics.horizontalInset + capsuleThickness / 2, y: geometry.size.height / 2)
                    if let capsuleTip {
                        let width = min(260, max(80, SonoTypography.width(capsuleTip.title, size: SonoDesktopTokens.FontSize.caption) + 24))
                        Text(capsuleTip.title).font(SonoTypography.font(size: SonoDesktopTokens.FontSize.caption)).lineSpacing(3).padding(.horizontal, SonoDesktopTokens.Spacing.s12).padding(.vertical, SonoDesktopTokens.Spacing.s8)
                            .frame(width: width).glass(radius: 12).position(x: 64 + width / 2, y: min(geometry.size.height - 96, max(96, capsuleTip.y)))
                    }
                }
                if !browser.quickListOpen {
                homeConsole(scale: scale, horizontalAllowance: (geometry.size.width - consoleWidth) / 2).frame(width: consoleWidth, height: consoleHeight)
                    .position(x: geometry.size.width / 2, y: metrics.consoleTop + consoleHeight / 2)
                }
                }
                sourcePanel.frame(width: sourceWidth, height: geometry.size.height)
                    .overlay(alignment: .trailing) {
                        if session.sidebarOpen {
                            SourceDrawerResizeHandle(width: sourceWidth) { width in
                                sourceWidth = min(SonoChromeMetrics.sourceDrawerMaximumWidth, max(278, width))
                            }
                                .frame(width: SonoDesktopTokens.Spacing.s4)
                                .accessibilityHidden(true)
                        }
                    }
                    .position(x: sourceWidth / 2, y: geometry.size.height / 2)
                    .offset(x: session.sidebarOpen ? 0 : -16)
                    .animation(reduceMotion ? nil : .timingCurve(0.25,0.1,0.25,1,duration:0.3), value: session.sidebarOpen)
                    .opacity(session.sidebarOpen ? 1 : 0)
                    .animation(reduceMotion ? nil : .timingCurve(0.25,0.1,0.25,1,duration:0.24), value: session.sidebarOpen)
                    .allowsHitTesting(session.sidebarOpen).disabled(!session.sidebarOpen).accessibilityHidden(!session.sidebarOpen)
                if !lyricsSettled && session.queueEditingAllowed { QueueContent(session: session, state: queueState, scale: scale, visible: session.queueOpen && !searchSuggestionsOpen).frame(width: drawerWidth, height: geometry.size.height)
                    .position(x: geometry.size.width - drawerWidth / 2, y: geometry.size.height / 2)
                    .offset(x: session.queueOpen ? 0 : 16)
                    .animation(reduceMotion ? nil : .timingCurve(0.25,0.1,0.25,1,duration:0.3), value: session.queueOpen)
                    .opacity(session.queueOpen ? 1 : 0)
                    .animation(reduceMotion ? nil : .timingCurve(0.25,0.1,0.25,1,duration:0.24), value: session.queueOpen)
                    .allowsHitTesting(session.queueOpen).disabled(!session.queueOpen).accessibilityHidden(!session.queueOpen) }
                if let track = artistChoice {
                    Color.clear.contentShape(Rectangle()).onTapGesture { artistChoiceClosing = true }
                    let rect = BrowseMetrics(viewport: geometry.size, count: browser.roundWall ? session.browseTracks.count : max(session.browseTracks.count, browser.sourceTotal), source: browser.sourceKey).centerRect
                    ArtistChoiceView(track: track, online: online, scale: scale, showTitle: browser.layout == .wall, reduced: reduceMotion, closing: artistChoiceClosing,
                                     close: { artistChoice = nil; artistChoiceClosing = false }, select: { artist in
                                         artistChoice = nil; artistChoiceClosing = false; openOnline(.artist(artist.id), artist.name)
                                     }).frame(width: rect.width, height: rect.height).position(x: rect.midX, y: rect.midY)
                }
                // Transparent perimeter surfaces keep browsing gestures inside the content area.
                if !lyricsSettled {
                    if !session.sidebarOpen {
                        WindowDragStrip(draggable: false).frame(width: 16, height: max(0, geometry.size.height - 32)).position(x: 8, y: 32 + (geometry.size.height - 32) / 2)
                    }
                    if !session.queueOpen {
                        WindowDragStrip(draggable: false).frame(width: 16, height: max(0, geometry.size.height - 32)).position(x: geometry.size.width - 8, y: 32 + (geometry.size.height - 32) / 2)
                    }
                    let leftInset = session.sidebarOpen ? sourceWidth : 0
                    let rightInset = session.queueOpen ? drawerWidth : 0
                    WindowDragStrip(draggable: false).frame(width: geometry.size.width - leftInset - rightInset, height: 16)
                        .position(x: (geometry.size.width + leftInset - rightInset) / 2, y: geometry.size.height - 8)
                }
                }.disabled(searchSuggestionsOpen).allowsHitTesting(!searchSuggestionsOpen)
                if searchSuggestionsOpen {
                    Color.clear.contentShape(Rectangle())
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .onTapGesture { collapseSearch() }
                        .accessibilityLabel("收起搜索建议").zIndex(1)
                }
                }
                .allowsHitTesting(!lyricsMounted && !session.lyricsOpen)
                .accessibilityHidden(lyricsMounted || session.lyricsOpen)
                ZStack {
                    if lyricsMounted {
                        LyricsPage(session:session,lyrics:session.lyrics,queueState:queueState,
                                   backgroundCanStart: lyricsBackgroundCanStart,
                                   controlsPinned:homeVolumeExpanded || homeVolumeDragging || progressDragging,
                                   controls:{ visible in LyricsConsoleContent { ink in lyricsConsole(scale: 1, controlsVisible: visible, ink: ink) } },
                                   openAlbum: { track in session.closeLyrics(); openCatalog(track, album: true) },
                                   openArtist: { artist in session.closeLyrics(); openOnline(.artist(artist.id), artist.name) },
                                   close:{ session.closeLyrics() })
                            .modifier(LyricsEntranceOffset(progress: lyricsAtTop ? 1 : 0,
                                                            height: geometry.size.height,
                                                            transition: lyricsTransition) { transition in
                                guard lyricsTransition == transition, session.lyricsOpen else { return }
                                lyricsBackgroundCanStart = true
                            })
                            .transition(.identity)
                    }
                }
                .frame(width: geometry.size.width, height: geometry.size.height)
                .allowsHitTesting(session.lyricsOpen)
                .accessibilityHidden(!session.lyricsOpen)
                .clipped()
                .zIndex(3)
                titlebar.frame(height: SonoDesktopTokens.Spacing.s32)
                    .frame(maxHeight: .infinity, alignment: .top)
                    .zIndex(5)
                if accountOpen {
                    ZStack(alignment: .topTrailing) {
                        WindowDragStrip(draggable: false, clicked: { accountOpen = false })
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                            .accessibilityLabel("关闭账号列表")
                        OnlineAccountPanel(online: online, order: $accountRowOrder) {
                            accountOpen = false
                            addAccountOpen = true
                        }
                        .padding(.top, topControlsY + SonoChromeMetrics.buttonSize / 2 + SonoDesktopTokens.Spacing.s8)
                        .padding(.trailing, SonoChromeMetrics.horizontalInset)
                    }
                    .onExitCommand { accountOpen = false }
                    .onDisappear { accountOpen = false }
                    .zIndex(6)
                }
                if session.directoryManagerOpen {
                    ZStack {
                        modalBackdrop { if !session.scanning { session.directoryManagerOpen = false } }
                        directoryManager.scaleEffect(scale).position(x: geometry.size.width / 2, y: geometry.size.height / 2)
                    }.zIndex(4)
                }
                if session.settingsOpen {
                    ZStack {
                        modalBackdrop { session.settingsOpen = false }
                        settings.frame(width: min(960, geometry.size.width - 48), height: min(720, geometry.size.height - 64)).position(x: geometry.size.width / 2, y: geometry.size.height / 2)
                    }.zIndex(4)
                }
            }
                .coordinateSpace(name: "sonoScene").foregroundStyle(Color(nsColor: SonoGeneratedColors.navigationText)).buttonStyle(ConsoleButtonStyle())
                .onAppear {
                    browser.onInteraction = { browser.afterFocus = nil; session.stopFollowing() }
                    session.onDismissFloating = {
                        homeVolumeExpanded = false
                        collapseSearch(); capsuleTip = nil
                    }
                    online.onPageChange = {
                        session.onlineShowing = browser.sourceKey != "local"
                        finishCollectionSearchIfReady()
                    }
                    session.onBrowseFollow = { track, locate in
                        if locate {
                            if track.online == nil { online.showLocal(intent: browser.hasSearchTrail ? .root : .push); session.onlineShowing = false }
                            else {
                                let pending = session.recovery
                                online.openPlaybackSnapshot(pending?.source?.map(\.track) ?? session.playbackSourceTracks,
                                                            title: pending?.title ?? session.queueTitle, kind: session.playbackSourceKind, focus: track.id)
                                session.onlineShowing = true
                            }
                        }
                        return browser.follow(track, allTracks: session.browseTracks, locate: locate)
                    }
                }
                .onChange(of: browser.visit, initial: true) { _, _ in
                    capsuleTip = nil
                    if browser.searching {
                        let count = browser.filtered(session.browseTracks).count
                        showToast("「\(session.browseTitle)」· 找到 \(count) 首", from: .search)
                    }
                }
                .onChange(of: visiblePlayerNotice, initial: true) { _, notice in
                    if OnlineError.isNonRetryablePlaybackMessage(notice) {
                        showToast(nil, from: .player)
                        showToast(notice, from: .membership)
                    } else {
                        showToast(nil, from: .membership)
                        showToast(notice, from: .player)
                    }
                }
                .onChange(of: visibleAudioNotice, initial: true) { _, notice in
                    showToast(notice, from: .audio)
                }
                .onChange(of: visibleLoadingNotice, initial: true) { _, message in
                    showToast(message, from: .loading)
                }
                .onChange(of: visibleOnlineNotice, initial: true) { _, notice in
                    showToast(notice, from: .online)
                }
                .onChange(of: session.lyricsOpen, initial: true) { _, open in presentLyrics(open) }
                .onChange(of: searchSuggestionsOpen) { _, open in if open { capsuleTip = nil; NSCursor.arrow.set() } }
                .onChange(of: online.suggestions.map(\.id)) { _, _ in suggestionIndex = -1 }
                .onChange(of: geometry.size.width) { _, width in if width < 900 && session.queueOpen { session.sidebarOpen = false } }
                .onChange(of: session.directoryManagerOpen) { _, open in if open { capsuleTip = nil; selectedFolders = session.activeFolderIDs } }
                .onChange(of: session.sidebarOpen) { _, _ in capsuleTip = nil }
                .onChange(of: session.settingsOpen) { _, _ in capsuleTip = nil }
                .onChange(of: geometry.size.height) { _, _ in capsuleTip = nil }
                .onChange(of: online.account) { _, value in if value == nil { browser.clearOnlineLocations() } }
        }
        .disabled(addAccountOpen)
        .accessibilityHidden(addAccountOpen)
        .overlay {
            if addAccountOpen {
                ZStack {
                    Color.black.opacity(0.20).ignoresSafeArea()
                        .accessibilityHidden(true)
                    AddOnlineAccountPanel(online: online) { addAccountOpen = false }
                }
                .overlay(alignment: .top) {
                    if case .failed(_, let message) = online.qrState {
                        QRLoginToast(message: message)
                            .id(message)
                            .padding(.top, SonoDesktopTokens.Spacing.s36)
                            .padding(.horizontal, SonoDesktopTokens.Spacing.s16)
                            .allowsHitTesting(false)
                    }
                }
            }
        }
        .environment(\.songActions, SongActions(items: songActions, browseItems: browseSongActions, removal: browseSongRemoval))
        .task(id: online.authentication == .verified ? online.account?.id : nil) {
            online.loadFavorites { showToast($0, from: .song) }
        }
        .onChange(of: online.account?.id) { _, _ in playlistSong = nil; favoriteRemoval = nil }
        .onChange(of: online.authentication) { _, state in if state != .verified { playlistSong = nil; favoriteRemoval = nil } }
        .sheet(isPresented: $session.fmModePickerOpen) { PersonalFMModePicker(session: session) }
        .sheet(item: $playlistSong) { track in
            SongPlaylistPicker(online: online, select: { playlist in
                guard let id = track.online?.songID else { return }
                playlistSong = nil
                Task { if let message = await online.addSong(id, to: playlist) { showToast(message, from: .song) } }
            }, cancel: { playlistSong = nil })
        }
        .sheet(item: $favoriteRemoval) { track in
            SonoConfirmationDialog(title: "确认取消收藏该歌曲？", cancel: { favoriteRemoval = nil }) {
                favoriteRemoval = nil
                guard let id = track.online?.songID, online.favoriteIDs?.contains(id) == true else { return }
                updateFavorite(id)
            }
        }
        .alert("从歌单中删除", isPresented: $confirmsSongRemoval, presenting: songRemoval) { removal in
            Button("取消", role: .cancel) { songRemoval = nil }
            Button("删除", role: .destructive) {
                songRemoval = nil
                guard online.account?.id == removal.owner else { return }
                Task {
                    if let message = await online.removeSong(removal.song, from: removal.playlist) {
                        showToast(message, from: .song)
                    }
                }
            }
        } message: { removal in
            Text("从『" + removal.name + "』中删除《" + removal.title + "》？")
        }
        .environment(\.sonoGlassDensity, glassDensity)
        .environment(\.sonoTheme, theme)
        .environment(\.sonoWindowContentVisible, session.windowContentVisible)
        .tint(Color(nsColor: theme.accent))
            .ignoresSafeArea().environment(\.sonoAppearance, appearance)
            .onChange(of: appearance) { _, next in next.apply() }
    }
    private func openPersonalFM() {
        guard online.authentication == .verified else { accountOpen = true; session.notice = "请先登录网易云音乐后使用私人FM"; return }
        session.startPersonalFM()
    }
    private func openDailyRecommendations() {
        guard online.authentication == .verified else { accountOpen = true; session.notice = "请先登录网易云音乐后使用每日推荐"; return }
        session.closeLyrics(); session.dismissPanels(); online.openRecommendations()
    }
    private func browseSongActions(_ track: LocalTrack) -> [SongAction] {
        let playable = (track.playable || track.online != nil)
        return [
            SongAction(title: "播放", enabled: playable) { session.playQuickTrack(track, ensurePlaying: true) },
            SongAction(title: "下一首播放", enabled: playable && session.queueEditingAllowed) {
                session.queueTrackNext(track)
            }
        ]
    }

    private func browseSongRemoval(_ track: LocalTrack) -> SongAction? {
        guard let song = track.online?.songID, let owner = online.account?.id,
              case .playlist(let id) = online.page?.kind, browser.sourceKey == "playlist/" + id,
              let playlist = online.editablePlaylists.first(where: { $0.id == id }) else { return nil }
        return SongAction(title: "从歌单中删除", enabled: !online.songOperations.contains("playlist/" + id)) {
            songRemoval = (song, id, track.title, playlist.name, owner)
            confirmsSongRemoval = true
        }
    }

    private func updateFavorite(_ id: String) {
        Task {
            if let message = await online.toggleFavorite(id) { showToast(message, from: .song) }
        }
    }

    private func songActions(_ track: LocalTrack) -> [SongAction] {
        guard let id = track.online?.songID else { return [] }
        let verified = online.authentication == .verified
        let favorite = online.favoriteIDs.map { $0.contains(id) }
        let label = favorite.map { $0 ? "取消收藏" : "收藏" }
            ?? (verified ? (online.favoritesLoading ? "正在读取收藏…" : "重新读取收藏") : "收藏（需登录）")
        var actions = [
            SongAction(kind: .favorite, title: label, enabled: verified && !online.favoritesLoading && !online.songOperations.contains("favorites")) {
                if online.favoriteIDs == nil { online.loadFavorites { showToast($0, from: .song) } }
                else if online.favoriteIDs?.contains(id) == true { favoriteRemoval = track }
                else { updateFavorite(id) }
            },
            SongAction(kind: .addToPlaylist, title: "添加到歌单", enabled: verified) { playlistSong = track }
        ]
        if online.activePlatform == .netease && online.page?.kind == .dailyRecommendations && online.page?.tracks.contains(where: { $0.id == track.id }) == true {
            actions.append(SongAction(title: online.recommendationFeedbackLimited ? "不感兴趣（今日已达上限）" : "不感兴趣", enabled: verified && !online.recommendationFeedbackPending && !online.recommendationFeedbackLimited) {
                Task { if let message = await online.dislikeRecommendation(track) { showToast(message, from: .song) } }
            })
        }
        return actions
    }

    private func consoleFeedback(for track: LocalTrack) -> SongAction? {
        guard track.online?.platform != .qq else { return nil }
        let verified = online.authentication == .verified
        let current = session.audio.current?.id == track.id && !session.audio.isLoading && session.recovery == nil
        if session.isPersonalFM {
            return SongAction(title: "减少推荐", enabled: verified && current) {
                if session.audio.current?.id == track.id { session.dislikePersonalFM() }
            }
        }
        if session.playbackSourceKind == .dailyRecommendations {
            return SongAction(title: online.recommendationFeedbackLimited ? "不感兴趣（今日已达上限）" : "不感兴趣",
                              enabled: verified && current && !online.recommendationFeedbackPending && !online.recommendationFeedbackLimited) {
                Task {
                    if let message = await online.dislikeRecommendation(track, playbackSource: .dailyRecommendations) {
                        showToast(message, from: .song)
                    }
                }
            }
        }
        return nil
    }

    private var showsPlaybackNotices: Bool { !session.directoryManagerOpen && session.recovery == nil }
    private var blockedPlaybackNotice: String? {
        guard !session.directoryManagerOpen, session.playbackBlocked, let track = session.displayedTrack else { return nil }
        return session.audio.failures[track.id]
    }
    private var visiblePlayerNotice: String? { session.playbackBlocked ? (session.notice ?? blockedPlaybackNotice) : (showsPlaybackNotices ? session.notice : nil) }
    private var visibleAudioNotice: String? {
        guard showsPlaybackNotices, session.audio.notice != visiblePlayerNotice else { return nil }
        return session.audio.notice
    }
    private var visibleOnlineNotice: String? { !session.lyricsOpen && session.onlineShowing ? online.notice : nil }
    private var visibleLoadingNotice: String? {
        guard !session.lyricsOpen, !titleCapsuleVisible else { return nil }
        if online.loading || online.restoringAccount { return "正在加载" }
        return nil
    }
    private var toastExit: Animation { .easeIn(duration: reduceMotion ? 0.10 : 0.22) }

    private func showToast(_ message: String?, from source: SonoToast.Source) {
        if source != .search {
            withAnimation(toastExit) { toasts.removeAll { $0.source == source } }
        }
        guard let message else { return }
        let expires = (source == .song || source == .membership) ? ContinuousClock.now.advanced(by: .seconds(4)) : (source == .search ? ContinuousClock.now.advanced(by: .seconds(2.5)) : nil)
        let entrance: Animation = reduceMotion ? .easeOut(duration: 0.14) : .snappy(duration: 0.38)
        withAnimation(entrance) {
            toasts.append(SonoToast(source: source, message: message, expires: expires))
        }
    }

    private var toastStack: some View {
        let visible = toasts.filter { $0.source != .search || !session.lyricsOpen }
        let slide = AnyTransition.offset(y: -10)
        let transition: AnyTransition = reduceMotion ? .opacity : .asymmetric(
            insertion: .scale(scale: 0.90).combined(with: .opacity).combined(with: slide),
            removal: .scale(scale: 0.97).combined(with: .opacity).combined(with: slide)
        )
        return VStack(spacing: SonoDesktopTokens.Spacing.s8) {
            ForEach(visible) { toast in
                HStack(alignment: .top, spacing: SonoDesktopTokens.Spacing.s8) {
                    Text(toast.message)
                        .font(SonoTypography.font(size: SonoDesktopTokens.FontSize.label, weight: SonoDesktopTokens.FontWeight.semibold))
                        .multilineTextAlignment(.center).lineLimit(toast.source == .search ? 2 : 4)
                    switch toast.source {
                    case .search, .song, .loading:
                        EmptyView()
                    case .membership:
                        EmptyView()
                    case .player, .audio:
                        Button {
                            if toast.source == .player { session.notice = nil }
                            else { session.audio.notice = nil }
                        } label: {
                            Image(systemName: "xmark").font(.system(size: SonoDesktopTokens.SymbolSize.small)).sonoIconFrame(SonoDesktopTokens.IconFrame.s16)
                                .frame(width: SonoDesktopTokens.Component.compactAction, height: SonoDesktopTokens.Component.compactAction)
                                .contentShape(Rectangle())
                        }.accessibilityLabel("关闭提示")
                    case .online:
                        Button("重试") {
                            if online.authentication == .offlineCache { online.restore() }
                            else { online.loadPage() }
                        }.font(SonoTypography.font(size: SonoDesktopTokens.FontSize.caption))
                    }
                }
                .padding(.horizontal, SonoDesktopTokens.Spacing.s20).padding(.vertical, SonoDesktopTokens.Spacing.s8)
                .glass(radius: 16)
                .opacity(toast.id == visible.last?.id ? 1 : 0.68)
                .allowsHitTesting(toast.source != .search)
                .transition(transition)
                .task {
                    guard let expires = toast.expires else { return }
                    do { try await ContinuousClock().sleep(until: expires) }
                    catch { return }
                    guard !Task.isCancelled else { return }
                    withAnimation(toastExit) { toasts.removeAll { $0.id == toast.id } }
                }
            }
        }
    }

    @State private var titlebarDragging = false

    private var titlebar: some View {
        WindowDragStrip()
            .overlay {
                if titlebarDragging {
                    ZStack {
                        Color(nsColor: SonoGeneratedColors.floatingBackground)
                        Text("SONO MUSIC")
                            .font(SonoTypography.font(size: SonoDesktopTokens.FontSize.caption, weight: SonoDesktopTokens.FontWeight.semibold))
                            .foregroundStyle(Color(nsColor: SonoGeneratedColors.navigationText))
                    }
                    .allowsHitTesting(false)
                }
            }
            .onReceive(NotificationCenter.default.publisher(for: NSWindow.didMoveNotification)) { notification in
                guard let window = notification.object as? NSWindow, window === session.window,
                      NSEvent.pressedMouseButtons & 1 != 0 else { return }
                titlebarDragging = true
            }
            .task(id: titlebarDragging) {
                guard titlebarDragging else { return }
                // Window Server can consume the mouse-up during a native window drag.
                while NSEvent.pressedMouseButtons & 1 != 0 {
                    do { try await Task.sleep(for: .milliseconds(33)) }
                    catch { return }
                }
                titlebarDragging = false
            }
    }
    private func openCatalog(_ track: LocalTrack, album: Bool) {
        guard let info = track.online else { return }
        if album {
            guard !info.albumID.isEmpty else { session.notice = "这首歌暂无专辑信息"; return }
            openOnline(.album(info.albumID), track.album, focus: track.id)
        } else if (info.artists?.count ?? 0) > 1 { artistChoice = track }
        else if !info.artistID.isEmpty { openOnline(.artist(info.artistID), track.artist) }
        else { session.notice = "这首歌暂无歌手信息" }
    }
    private func showLocal() {
        online.cancelStartupSelection()
        if browser.sourceKey != "local" || online.loading { online.showLocal() }
        session.onlineShowing = false; session.stopFollowing()
    }
    private func showSearch() {
        session.localSourceView = false; session.sidebarOpen = false
        guard !(online.pendingSourceKey ?? browser.sourceKey).hasPrefix("search/") else { return }
        if online.restoreLastSearch() {
            collapseSearch()
        } else {
            globalSearch = true
            searchExpanded = true
            keepSearchFocused()
        }
    }
    private func openBrowseEntity(_ entity: BrowseEntity) {
        if entity.kind != .playlist { pendingCollectionSearch = entity.destination.key }
        online.openEntity(entity)
        session.localSourceView = false; session.sidebarOpen = false
        if entity.kind == .playlist { collapseSearch() }
        else { finishCollectionSearchIfReady() }
    }
    private func openOnline(_ kind: OnlinePageKind, _ title: String, focus: String? = nil, keepSourcePanelOpen: Bool = false) {
        online.open(kind, title: title, focus: focus)
        session.localSourceView = false
        if !keepSourcePanelOpen { session.sidebarOpen = false }
    }
    private func modalBackdrop(_ dismiss: @escaping () -> Void) -> some View { Color(nsColor: SonoGeneratedColors.interfaceBackdrop).contentShape(Rectangle()).onTapGesture(perform: dismiss) }
    private var searchSuggestionsOpen: Bool { !session.lyricsOpen && searchExpanded && globalSearch && searchFocused && !online.suggestions.isEmpty }
    private var layoutSwitchHelp: String {
        guard browser.carouselOnly else { return "切换为" + (browser.layout == .wall ? "卡片轮播" : "照片墙") }
        return "当前页面不支持照片墙模式"
    }
    private var collectionPage: Bool { browser.sourceKey.hasPrefix("album/") || browser.sourceKey.hasPrefix("artist/") }
    @ViewBuilder
    private func resultCategories(scale: CGFloat) -> some View {
        if let kind = online.page?.kind, kind.key == browser.sourceKey {
            if let selected = kind.searchCategory {
                HStack(alignment: .bottom, spacing: SonoDesktopTokens.Spacing.s0) {
                    ForEach(SearchCategory.allCases, id: \.self) { category in
                        categoryButton(category.title, selected: selected == category, scale: scale) { online.selectSearchCategory(category) }
                    }
                }.fixedSize().accessibilityElement(children: .contain).accessibilityLabel("搜索结果分类")
            } else if kind.artistID != nil {
                let albums: Bool = { if case .artistAlbums = kind { return true }; return false }()
                HStack(alignment: .bottom, spacing: SonoDesktopTokens.Spacing.s0) {
                    categoryButton("单曲", selected: !albums, scale: scale) { online.selectArtistAlbums(false) }
                    categoryButton("专辑", selected: albums, scale: scale) { online.selectArtistAlbums(true) }
                }.fixedSize().accessibilityElement(children: .contain).accessibilityLabel("歌手作品分类")
            }
        }
    }
    private func categoryButton(_ title: String, selected: Bool, scale: CGFloat, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            BrowseCategoryTitle(title: title, selected: selected, scale: scale)
        }.buttonStyle(SonoQueueButtonStyle(
            normal: selected ? SonoGeneratedColors.searchCategorySelectedForeground : SonoGeneratedColors.searchCategoryForeground,
            light: colorScheme == .light, active: !selected
        ))
            .accessibilityAddTraits(selected ? [.isSelected] : [])
    }
    private var searchValue: Binding<String> {
        Binding(get: { globalSearch ? online.searchDraft : browser.location.query }, set: { value in
            suggestionIndex = -1
            pendingCollectionSearch = nil
            if globalSearch { online.suggest(value) } else { browser.editDraft(value, in: session.browseTracks) }
        })
    }
    private func submitSearch() {
        if globalSearch, online.suggestions.indices.contains(suggestionIndex) {
            selectSearchSuggestion(online.suggestions[suggestionIndex])
            return
        } else {
            pendingCollectionSearch = nil
            let value = searchValue.wrappedValue
            guard !value.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
            if browser.quickListOpen && !globalSearch {
                browser.quickListQuery = value.trimmingCharacters(in: .whitespacesAndNewlines)
                keepSearchFocused()
                return
            }
            if globalSearch { online.search(value, category: .combined) } else if session.onlineShowing { online.filterCurrentSource(value) } else { browser.search(value, in: session.browseTracks) }
        }
        keepSearchFocused()
    }
    private func selectSearchSuggestion(_ suggestion: SearchSuggestion) {
        pendingCollectionSearch = suggestion.destination?.key
        online.selectSuggestion(suggestion)
        if pendingCollectionSearch != nil {
            finishCollectionSearchIfReady()
            if pendingCollectionSearch != nil { keepSearchFocused() }
        } else if searchExpanded {
            keepSearchFocused()
        }
    }
    private func finishCollectionSearchIfReady() {
        guard let target = pendingCollectionSearch,
              browser.sourceKey == target, online.page?.kind.key == target,
              online.page?.cachedAt != nil, collectionPage else { return }
        pendingCollectionSearch = nil
        collapseSearch()
    }
    private func keepSearchFocused() {
        suggestionIndex = -1
        searchFocused = true
        searchCaretRequest &+= 1
    }
    private func searchScope(_ global: Bool) {
        guard global != globalSearch else { return }
        pendingCollectionSearch = nil
        let draft = searchValue.wrappedValue
        online.cancelSearchWork()
        globalSearch = global
        if global { online.suggest(draft) } else { browser.location.query = draft }
        searchFocused = true; suggestionIndex = -1
    }
    private func collapseSearch() {
        pendingCollectionSearch = nil
        searchFocused = false
        searchExpanded = false
        suggestionIndex = -1
    }
    private var searchBackButton: some View {
        Button {
            if browser.quickListOpen {
                if let exit = browser.onQuickListExit { exit() } else { browser.dismissQuickList() }
            } else { browser.back() }
        } label: {
            Image(systemName: "chevron.backward").font(.system(size: SonoDesktopTokens.SymbolSize.control)).sonoIconFrame(SonoDesktopTokens.IconFrame.s24)
                .frame(width: capsuleThickness, height: capsuleThickness).chromeSurface()
        }.buttonStyle(SonoQueueButtonStyle(normal: SonoGeneratedColors.toolIcon, light: colorScheme == .light)).help("返回上一页").accessibilityLabel("返回上一页")
            .onHover { inside in (inside ? NSCursor.pointingHand : NSCursor.arrow).set() }
    }
    private func searchChrome(width: CGFloat, spacing: CGFloat) -> some View {
        HStack(alignment: .top, spacing: spacing) {
            if browser.backStack.isEmpty && !browser.quickListOpen {
                SonoIcon(name: "sono-logo", size: capsuleThickness)
                    .allowsHitTesting(false)
            } else {
                searchBackButton
            }
            Group {
                if searchExpanded {
                    searchField.frame(width: width)
                        .transition(.offset(x: -12).combined(with: .opacity))
                } else {
                    Button {
                        searchExpanded = true
                        searchFocused = true
                    } label: {
                        Image(systemName: "magnifyingglass").font(.system(size: SonoDesktopTokens.SymbolSize.control)).sonoIconFrame(SonoDesktopTokens.IconFrame.s24)
                            .frame(width: capsuleThickness, height: capsuleThickness).chromeSurface()
                    }
                    .buttonStyle(SonoQueueButtonStyle(normal: SonoGeneratedColors.toolIcon, light: colorScheme == .light))
                    .help("展开搜索").accessibilityLabel("展开搜索")
                    .onHover { inside in (inside ? NSCursor.pointingHand : NSCursor.arrow).set() }
                    .transition(.opacity)
                }
            }
            .frame(height: capsuleThickness, alignment: .topLeading)
            .overlay(alignment: .topLeading) {
                Group {
                    if searchSuggestionsOpen {
                        searchSuggestions
                    } else if let filterError = online.filterError {
                        Text(filterError)
                            .font(SonoTypography.font(size: SonoDesktopTokens.FontSize.caption)).padding(.horizontal, SonoDesktopTokens.Spacing.s12).padding(.vertical, SonoDesktopTokens.Spacing.s8)
                            .frame(maxWidth: .infinity, alignment: .leading).glass(radius: 12)
                    }
                }
                .frame(width: width)
                .offset(y: capsuleThickness + 8)
            }
        }
        .animation(reduceMotion ? nil : .easeInOut(duration: 0.2), value: searchExpanded)
    }
    private var searchField: some View {
        HStack(spacing: SonoDesktopTokens.Spacing.s12) {
            SearchScopeInteraction(selectedGlobal: globalSearch, allowsGlobalSearch: !browser.quickListOpen, select: searchScope)
            BrowseSearchField(text: searchValue, scope: globalSearch, placeholder: globalSearch ? "搜索曲库" : "搜索当前页", focused: searchFocused, caretRequest: searchCaretRequest,
                focusChanged: { searchFocused = $0 }, move: { direction in
                    guard globalSearch, !online.suggestions.isEmpty else { return false }
                    suggestionIndex = (suggestionIndex + direction + online.suggestions.count) % online.suggestions.count
                    suggestionScrollIndex = suggestionIndex
                    return true
                }, submit: submitSearch, close: collapseSearch, edited: { value, composing in
                    suggestionIndex = -1
                    pendingCollectionSearch = nil
                    if globalSearch { online.suggest(value) }
                    else { browser.editDraft(value, in: session.browseTracks) }
                }, clicked: { value in
                    guard globalSearch, pendingCollectionSearch == nil, online.suggestions.isEmpty,
                          !value.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
                    online.suggest(value)
                })
                .frame(height: 18)
            if online.filtering || (globalSearch && online.loading && online.pendingKind?.key.hasPrefix("search/") == true) { SonoLoadingSpinner(size: SonoDesktopTokens.IndicatorSize.micro, lineWidth: 1, tint: Color(nsColor: SonoGeneratedColors.loadingIcon), baseOpacity: 0.25) }
            if !searchValue.wrappedValue.isEmpty {
                Button { browser.quickListQuery = ""; online.cancelFilter(); if !globalSearch { browser.clearSearch(in: session.browseTracks) }; searchValue.wrappedValue = ""; searchFocused = true } label: { Image(systemName: "xmark").font(.system(size: SonoDesktopTokens.SymbolSize.small)).sonoIconFrame(SonoDesktopTokens.IconFrame.s16).frame(width: SonoDesktopTokens.Component.control, height: SonoDesktopTokens.Component.control).contentShape(Circle()) }.buttonStyle(.plain).accessibilityLabel("清空搜索输入")
            }
        }.padding(.horizontal, SonoDesktopTokens.Spacing.s2).frame(height: capsuleThickness)
            .glass(radius: capsuleThickness / 2)
            .background {
                Capsule().fill(Color(nsColor: SonoGeneratedColors.searchFieldFill))
                    .environment(\.colorScheme, colorScheme == .light ? .dark : .light)
                    .allowsHitTesting(false)
            }
            .overlay { SonoSearchFocusRing(focused: searchFocused) }
            .background {
                SearchClickRegion {
                    if !searchSuggestionsOpen { collapseSearch() }
                }
            }
    }
    private func actOnSearchSong(_ suggestion: SearchSuggestion, play: Bool) {
        Task {
            do {
                let track = try await online.resolveReferencedSong("netease/" + suggestion.id.dropFirst("song/".count))
                if play { session.playSuggestedTrack(track) }
                else { session.queueTrackNext(track) }
            } catch {
                NSLog("Could not resolve search result: %@", error.localizedDescription)
                session.notice = "暂时无法读取这首歌"
            }
        }
    }
    private var searchSuggestions: some View {
        ScrollViewReader { proxy in
            ScrollView {
                VStack(alignment: .leading, spacing: SonoDesktopTokens.Spacing.s0) {
                    ForEach(Array(online.suggestions.enumerated()), id: \.element.id) { index, value in
                        Button { selectSearchSuggestion(value) } label: {
                            SearchSuggestionRow(value: value, query: online.searchDraft, selected: suggestionIndex == index)
                        }.buttonStyle(.plain).id(index)
                            .onHover { if $0 { suggestionIndex = index } }
                            .contextMenu {
                                if value.kind == .song {
                                    Button("播放") { actOnSearchSong(value, play: true) }
                                    Button("下一首播放") { actOnSearchSong(value, play: false) }
                                        .disabled(!session.queueEditingAllowed)
                                }
                            }
                    }
                }
                .padding(.horizontal, SonoDesktopTokens.Spacing.s8)
                .background(PanelScrollConfiguration(usesCustomIndicator: true))
            }.panelOverlayScrollbar().frame(height: min(420, CGFloat(online.suggestions.reduce(0) { $0 + ($1.kind == .keyword ? 36 : 62) })))
                .font(SonoTypography.font(size: SonoDesktopTokens.FontSize.label))
                .padding(.vertical, SonoDesktopTokens.Spacing.s8).glass(radius: 16)
                .onChange(of: suggestionScrollIndex) { _, index in
                    guard let index else { return }
                    proxy.scrollTo(index)
                    suggestionScrollIndex = nil
                }
        }
    }
    private var welcome: some View {
        let localEmpty = !session.onlineShowing && !online.restoringAccount && !online.loading
        let showLocalEmpty = localEmpty && !browser.searching
        let classified = session.onlineShowing && (online.page?.kind.searchCategory != nil || { if case .artistAlbums = online.page?.kind { return true }; return false }())
        let canRetryOnline = classified || (session.onlineShowing && online.notice != nil)
        let message = showLocalEmpty ? "本地音频暂无歌曲"
            : browser.searching ? "没有找到「\(browser.location.submittedQuery)」相关歌曲"

            : canRetryOnline && online.notice != nil ? "结果加载失败，请重试"
            : classified ? "当前分类暂无结果"

            : "「\(session.browseTitle)」暂无歌曲"
        return VStack(spacing: SonoDesktopTokens.Spacing.s0) {
            if showLocalEmpty {
                SonoIcon(name: "sono-logo", size: SonoDesktopTokens.Spacing.s60)
            } else {
                SonoWordmark(height: 40)
            }
            Text(message).font(SonoTypography.font(size: SonoDesktopTokens.FontSize.sectionTitle)).padding(.top, SonoDesktopTokens.Spacing.s24)
            if !showLocalEmpty {
                Text(browser.searching ? "仅搜索「\(session.browseTitle)」，可清空搜索返回歌单。" : "让喜欢的音乐，铺满整个空间。").font(SonoTypography.font(size: SonoDesktopTokens.FontSize.caption)).foregroundStyle(Color(nsColor: SonoGeneratedColors.footerText)).padding(.top, SonoDesktopTokens.Spacing.s12)
            }
            Button(canRetryOnline ? "重新加载" : showLocalEmpty ? "导入本地音乐" : "打开歌单") {
                if canRetryOnline { online.retryCurrentPage() }
                else if showLocalEmpty { session.directoryManagerOpen = true }
                else { online.cancelStartupSelection(); session.localSourceView = false; session.sidebarOpen = true }
            }.font(SonoTypography.font(size: SonoDesktopTokens.FontSize.caption)).buttonStyle(.glass).controlSize(.large).padding(.top, SonoDesktopTokens.Spacing.s20).disabled(classified && online.loading)
            if showLocalEmpty && online.authentication != .verified {
                Button("连接音乐账号") {
                    addAccountOpen = true
                }
                    .font(SonoTypography.font(size: SonoDesktopTokens.FontSize.caption))
                    .buttonStyle(.glass).controlSize(.large)
                    .padding(.top, SonoDesktopTokens.Spacing.s8)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .contentShape(Rectangle())
        .onTapGesture { session.dismissPanels() }
    }
    private func capsuleItem<Content: View>(_ title: String, id: String, selected: Bool,
                                           artwork: Bool = false,
                                           pending: Bool = false, playingSource: Bool = false,
                                           warm: @escaping () -> Void = {}, action: @escaping () -> Void,
                                           @ViewBuilder content: @escaping () -> Content) -> some View {
        let hovered = capsuleTip?.id == id
        return GeometryReader { geometry in
            Button {
                capsuleTip = nil
                action()
            } label: {
                content()
                    .opacity(playingSource && !artwork ? 0 : 1)
                    .frame(width: 28, height: 28)
                    .foregroundStyle(Color(nsColor: selected && !artwork ? theme.color(pink: SonoGeneratedColors.capsuleSelectedIcon) : SonoGeneratedColors.navigationText))
                    .background {
                        if selected && artwork {
                            // Solid colour behind the 28 pt cover also fills its antialiased edge.
                            let diameter = SonoDesktopTokens.Cover.navigation + 2 * SonoGeneratedColors.capsuleSelectionRingWidth
                            Circle().fill(Color(nsColor: theme.color(pink: SonoGeneratedColors.capsuleSelectedRing)))
                                .frame(width: diameter, height: diameter)
                        }
                    }
                    .overlay {
                        if playingSource {
                            CapsulePlaybackIndicator(
                                playing: session.audio.isPlaying,
                                foreground: artwork ? nil : SonoGeneratedColors.navigationText,
                                size: SonoDesktopTokens.IndicatorSize.control
                            )
                            .sonoIconFrame(SonoDesktopTokens.IconFrame.s28)
                        }
                    }
                    .frame(width: 32, height: 32)
                    .background {
                        if hovered {
                            Circle().fill(Color(nsColor: (appearance.colorScheme ?? colorScheme) == .light ? SonoGeneratedColors.modeHover : SonoGeneratedColors.modeHoverDark))
                        }
                    }
                    .overlay {
                        if pending {
                            SonoLoadingSpinner(size: SonoDesktopTokens.IndicatorSize.sourceLoading, tint: Color(nsColor: SonoGeneratedColors.loadingIcon), baseOpacity: 0.188)
                        }
                    }
                    .frame(width: capsuleThickness, height: 48)
                    .contentShape(Rectangle())
            }
            .onHover { inside in
                if inside {
                    capsuleTip = (id, title, geometry.frame(in: .named("sonoScene")).midY)
                    warm()
                } else if capsuleTip?.id == id {
                    capsuleTip = nil
                }
            }
            .accessibilityLabel(title)
            .accessibilityAddTraits(selected ? [.isSelected] : [])
        }
        .frame(width: capsuleThickness, height: 48)
    }
    private var capsulePlayingKind: OnlinePageKind? { session.playbackSourceKind }
    private var hasCapsulePlaybackSource: Bool { session.recovery != nil || !session.queue.isEmpty || session.audio.current != nil }
    private var capsulePlayingLocal: Bool {
        guard hasCapsulePlaybackSource, capsulePlayingKind == nil else { return false }
        let track = session.targetedTrack ?? session.audio.current ?? session.queue.first?.track
        return track != nil && track?.online == nil
    }
    private var capsuleSelectionID: String? {
        if session.fmStarting { return "personal-fm" }
        let source = online.pendingSourceKey ?? browser.sourceKey
        if source.hasPrefix("daily-recommendations") { return "daily-recommendations" }
        return CapsuleSourceSelection.resolve(requested: online.pendingSourceKey, displayed: browser.sourceKey,
                                              fromSearch: browser.location.isSearchDetail || online.pendingSearchSuggestion)
    }
    private var sourceFMIcon: some View {
        Image(systemName: "dot.radiowaves.left.and.right")
            .font(.system(size: SonoDesktopTokens.SymbolSize.compact, weight: SonoDesktopTokens.FontWeight.semibold))
            .symbolRenderingMode(.monochrome)
            .scaleEffect(x: 0.88, y: 1)
    }

    private func capsule(height: CGFloat) -> some View {
        let visible = min(online.playlists.count + 4, 10, max(1, Int(floor((height - 240) / 48))))
        let endTrim = (48 - capsuleThickness) / 2
        return VStack(spacing: SonoDesktopTokens.Spacing.s0) {
            ScrollView(.vertical) {
                VStack(spacing: SonoDesktopTokens.Spacing.s0) {
                    capsuleItem("搜索", id: "search", selected: capsuleSelectionID == "search", action: showSearch) {
                        CapsuleSearchIcon(selected: capsuleSelectionID == "search")
                    }
                    capsuleItem("私人FM", id: "personal-fm", selected: capsuleSelectionID == "personal-fm", pending: session.fmStarting, playingSource: session.isPersonalFM, action: openPersonalFM) {
                        sourceFMIcon
                    }
                    capsuleItem("每日推荐", id: "daily-recommendations", selected: capsuleSelectionID == "daily-recommendations", pending: online.pendingSourceKey?.hasPrefix("daily-recommendations") == true, playingSource: capsulePlayingKind?.isDailyRecommendation == true, action: openDailyRecommendations) {
                        Image(systemName: capsuleSelectionID == "daily-recommendations" ? "star.fill" : "star")
                            .font(.system(size: SonoDesktopTokens.SymbolSize.compact, weight: SonoDesktopTokens.FontWeight.regular))
                            .symbolRenderingMode(.monochrome)
                    }
                    capsuleItem("本地音频", id: "local", selected: capsuleSelectionID == "local",
                                playingSource: capsulePlayingLocal, action: { showLocal(); session.localSourceView = false }) {
                        Image(systemName: capsuleSelectionID == "local" ? "music.note.square.stack.fill" : "music.note.square.stack")
                            .font(.system(size: SonoDesktopTokens.SymbolSize.compact, weight: SonoDesktopTokens.FontWeight.regular))
                            .symbolRenderingMode(.monochrome)
                    }
                    ForEach(online.playlistsByPlayback) { playlist in
                        let id = "playlist/" + playlist.id
                        let playing = hasCapsulePlaybackSource && capsulePlayingKind == .playlist(playlist.id)
                        let cover = playlist.isFavorites == true ? online.firstCover(playlistID: playlist.id) ?? playlist.cover : playlist.cover
                        capsuleItem(playlist.name, id: id, selected: capsuleSelectionID == id, artwork: true,
                                    pending: online.pendingSourceKey == id, playingSource: playing,
                                    warm: { online.warmPlaylist(playlist) },
                                    action: { openOnline(.playlist(playlist.id), playlist.name) }) {
                            SourcePlaylistArtwork(url: cover)
                                .clipShape(Circle())
                        }
                    }
                }
            }
            .frame(width: capsuleThickness, height: CGFloat(visible) * 48)
            .scrollIndicators(.never)
            capsuleItem("打开歌单列表", id: "menu", selected: false,
                        action: { session.localSourceView = false; session.toggleSidebar() }) {
                Image(systemName: "text.justify").font(.system(size: SonoDesktopTokens.SymbolSize.compact))
            }
        }.padding(.vertical, -endTrim)
            .frame(width: capsuleThickness, height: CGFloat(visible * 48 + 48) - endTrim * 2)
            .clipShape(Capsule())
            .glass(radius: capsuleThickness / 2)
    }
    private func consoleSongButton(_ action: SongAction?, icon: String, fallback: String, scale: CGFloat, alignment: Alignment = .center, ink: LyricsInk? = nil) -> some View {
        let enabled = action?.enabled == true
        return Button { action?.perform() } label: {
            Image(systemName: icon).font(.system(size: SonoDesktopTokens.SymbolSize.control * scale, weight: SonoDesktopTokens.FontWeight.medium))
                .sonoIconFrame(SonoDesktopTokens.IconFrame.s24 * scale)
                .frame(width: 32 * scale, height: 32 * scale, alignment: alignment)
                .contentShape(Rectangle())
                .opacity(enabled || ink == nil || icon.hasPrefix("heart") ? 1 : 0.25)
        }.buttonStyle(ConsoleControlStyle(color: icon == "heart.fill" ? SonoPalette.favorite : ink?.primary, ordinary: ink == nil, preservesHue: icon == "heart.fill" || (icon == "heart" && action?.title == "收藏"))).disabled(!enabled)
            .help(action?.title ?? fallback).accessibilityLabel(action?.title ?? fallback)
    }

    private func homeConsole(scale: CGFloat, horizontalAllowance: CGFloat) -> some View {
        let track = session.displayedTrack
        let details = track != nil
        let targeting = session.targetedTrack != nil
        let failed = session.targetedTrack.map { session.audio.failures[$0.id] != nil } == true
        let loading = session.audio.isLoading || session.recovery?.running == true || (targeting && !failed)
        let actions = track.map(songActions) ?? []
        let favorite = track?.online.flatMap { info in online.favoriteIDs.map { $0.contains(info.songID) } }
        return ZStack {
            HStack(spacing: SonoDesktopTokens.Spacing.s12 * scale) {
                Button {
                    session.closeLyrics(); session.locatePlaying()
                } label: {
                    Group {
                        if let image = ArtworkCache.shared.image(track?.coverURL) {
                            Image(nsImage: image).resizable().scaledToFill()
                        } else {
                            SourcePlaylistArtwork(url: track?.coverURL, size: SonoDesktopTokens.Cover.console * scale)
                        }
                    }
                    .frame(width: SonoDesktopTokens.Cover.console * scale, height: SonoDesktopTokens.Cover.console * scale).clipShape(Circle())
                    .modifier(ConsoleArtworkRotation(playing: session.audio.isPlaying && !loading))
                    .contentShape(Circle())
                }.buttonStyle(ConsoleButtonStyle()).disabled(!details)
                    .help(track?.title ?? "选择一首音乐")
                    .accessibilityLabel(track?.title ?? "当前歌曲封面")
                HStack(spacing: SonoDesktopTokens.Spacing.s8 * scale) {
                    consoleSongButton(actions.first { $0.kind == .favorite }, icon: favorite.map { $0 ? "heart.fill" : "heart" } ?? "heart.slash", fallback: "收藏", scale: scale)
                    consoleSongButton(actions.first { $0.kind == .addToPlaylist }, icon: "plus.app", fallback: "添加到歌单", scale: scale)
                }
                Spacer(minLength: 0)
            }.padding(.leading, SonoDesktopTokens.Spacing.s16 * scale)
            HStack(spacing: SonoDesktopTokens.Spacing.s0) {
                Button { session.step(-1) } label: {
                    Image(systemName: "backward.end.fill").font(.system(size: SonoDesktopTokens.SymbolSize.control * scale))
                        .sonoIconFrame(SonoDesktopTokens.IconFrame.s24 * scale)
                        .frame(width: SonoDesktopTokens.Component.tool * scale, height: 48 * scale).contentShape(Rectangle())
                }.buttonStyle(ConsoleControlStyle()).disabled(!details).accessibilityLabel("上一首")
                Button { session.togglePlayback() } label: {
                    ZStack {
                        if loading { SonoLoadingSpinner(size: SonoDesktopTokens.IndicatorSize.loader * scale, tint: Color(nsColor: SonoGeneratedColors.loadingIcon)) }
                        else { Image(systemName: session.audio.isPlaying ? "pause.fill" : "play.fill").font(.system(size: SonoDesktopTokens.SymbolSize.playback * scale)) }
                    }.sonoIconFrame(SonoDesktopTokens.IconFrame.s36 * scale)
                        .frame(width: SonoDesktopTokens.Component.mainPlayback * scale, height: 48 * scale)
                        .contentShape(Rectangle())
                }.buttonStyle(ConsoleControlStyle(loading: loading)).disabled(!details || targeting || loading || session.playbackBlocked)
                    .accessibilityLabel(loading ? "正在加载歌曲" : session.audio.isPlaying ? "暂停当前歌曲" : "播放当前歌曲")
                Button { session.step(1) } label: {
                    Image(systemName: "forward.end.fill").font(.system(size: SonoDesktopTokens.SymbolSize.control * scale))
                        .sonoIconFrame(SonoDesktopTokens.IconFrame.s24 * scale)
                        .frame(width: SonoDesktopTokens.Component.tool * scale, height: 48 * scale).contentShape(Rectangle())
                }.buttonStyle(ConsoleControlStyle()).disabled(!details).accessibilityLabel("下一首")
            }.fixedSize(horizontal: true, vertical: false)
            HStack(spacing: SonoDesktopTokens.Spacing.s0) {
                Spacer(minLength: 0)
                HStack(spacing: SonoDesktopTokens.Spacing.s8 * scale) {
                homeVolumeControls(scale: scale, compact: true)
                    .overlay(alignment: .leading) { consoleVolumeOverlay(scale: scale, docked: false, ink: LyricsInk()) }
                    .onHover(perform: updateVolumeHover)
                consoleLyrics(scale: scale, docked: false)
                    .opacity(homeVolumeExpanded ? 0 : 1)
                    .allowsHitTesting(!homeVolumeExpanded).accessibilityHidden(homeVolumeExpanded)
                if session.isPersonalFM { consoleFMMode(scale: scale, docked: false) }
                if session.queueEditingAllowed {
                    Button { session.toggleQueue() } label: {
                        Image(systemName: "list.dash").font(.system(size: SonoDesktopTokens.SymbolSize.control * scale, weight: SonoDesktopTokens.FontWeight.medium))
                            .sonoIconFrame(SonoDesktopTokens.IconFrame.s24 * scale)
                            .frame(width: 32 * scale, height: 32 * scale).contentShape(Rectangle())
                    }.buttonStyle(ConsoleControlStyle(selected: session.queueOpen)).accessibilityLabel("播放队列")
                }
                }
            }.padding(.trailing, SonoDesktopTokens.Spacing.s32 * scale)
        }
        .padding(.vertical, SonoDesktopTokens.Spacing.s8 * scale)
        .opacity(homeProgressExpanded ? 0 : 1).allowsHitTesting(!homeProgressExpanded)
        .accessibilityHidden(homeProgressExpanded)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background { Color.clear.glass(radius: 32 * scale) }
        .clipShape(Capsule())
        .overlay {
            PlaybackProgress(audio: session.audio, chorus: session.chorus, scale: scale, targeting: targeting,
                             trackColor: SonoGeneratedColors.progressTrack, capsule: true, bubbleHorizontalAllowance: horizontalAllowance,
                             expandedChanged: { homeProgressExpanded = $0 },
                             draggingChanged: { progressDragging = $0 })
        }
    }

    private func lyricsConsole(scale: CGFloat, controlsVisible: Bool, ink: LyricsInk) -> some View {
        GeometryReader { geometry in
            let iconScale: CGFloat = 1
            let details = session.displayedTrack != nil
            let targeting = session.targetedTrack != nil
            let failed = session.targetedTrack.map { session.audio.failures[$0.id] != nil } == true
            let loading = session.audio.isLoading || session.recovery?.running == true || (targeting && !failed)
            let playDisabled = !details || targeting || loading || session.playbackBlocked
            let transportWidth: CGFloat = 177.5
            let halfDockWidth = (geometry.size.width - transportWidth) / 2
            let coverScale = LyricsPageLayout.queueScale(for: geometry.size.width)
            let leadingInset = LyricsPageLayout.contentInset
                + (SonoDesktopTokens.Cover.listCover * coverScale - SonoDesktopTokens.Component.control) / 2
            let trailingInset = LyricsPageLayout.contentInset
            VStack(spacing: SonoDesktopTokens.Spacing.s0) {

                PlaybackProgress(audio: session.audio, chorus: session.chorus, scale: scale, targeting: targeting,
                                 trackColor:ink.light ? SonoGeneratedColors.lyricsProgressTrack : SonoGeneratedColors.lyricsProgressTrackDark,
                                 trackHeight:LyricsDockMetrics.progressHeight,
                                 squareOuterEnds:true,
                                 draggingChanged:{ progressDragging = $0 })
                    .frame(height: LyricsDockMetrics.progressTargetHeight)
                HStack(spacing: SonoDesktopTokens.Spacing.s0) {

                    HStack(spacing: SonoDesktopTokens.Spacing.s8) {
                        let track = session.displayedTrack
                        let actions = track.map(songActions) ?? []
                        let favorite = track?.online.flatMap { info in online.favoriteIDs.map { $0.contains(info.songID) } }
                        consoleSongButton(actions.first { $0.kind == .favorite }, icon: favorite.map { $0 ? "heart.fill" : "heart" } ?? "heart", fallback: "收藏", scale: 1, ink: ink)
                        consoleSongButton(actions.first { $0.kind == .addToPlaylist }, icon: "plus.app", fallback: "添加到歌单", scale: 1, ink: ink)
                        if session.isPersonalFM { consoleFMMode(scale: 1, docked: true) }
                        Spacer(minLength: 0)
                    }.frame(width: max(0, halfDockWidth - leadingInset), alignment: .leading)

                    HStack(spacing: SonoDesktopTokens.Spacing.s0) {
                        Button { session.step(-1) } label: {
                            Image(systemName: "backward.end.fill").font(.system(size: SonoDesktopTokens.SymbolSize.control * iconScale)).sonoIconFrame(SonoDesktopTokens.IconFrame.s24).frame(width: SonoDesktopTokens.Component.tool, height: 48).contentShape(Rectangle())
                        }.buttonStyle(ConsoleControlStyle(color: ink.titleTransport, ordinary: false)).disabled(!details).accessibilityLabel("上一首")
                        Button { session.togglePlayback() } label: {
                            ZStack {
                                if loading { SonoLoadingSpinner(size: SonoDesktopTokens.IndicatorSize.loader * scale, tint: Color(nsColor: ink.titleTransport)) }
                                else if session.audio.isPlaying {
                                    Image(systemName: "pause.fill").font(.system(size: SonoDesktopTokens.SymbolSize.playback * iconScale))
                                }
                                else { Image(systemName: "play.fill").font(.system(size: SonoDesktopTokens.SymbolSize.playback * iconScale)) }
                            }.sonoIconFrame(SonoDesktopTokens.IconFrame.s36).frame(width: SonoDesktopTokens.Component.mainPlayback, height: 48).contentShape(Rectangle())
                        }.buttonStyle(ConsoleControlStyle(color: session.playbackBlocked ? nil : ink.titleTransport, ordinary: session.playbackBlocked, loading: loading)).disabled(playDisabled).accessibilityLabel(loading ? "正在加载歌曲" : session.audio.isPlaying ? "暂停当前歌曲" : "播放当前歌曲")
                        Button { session.step(1) } label: {
                            Image(systemName: "forward.end.fill").font(.system(size: SonoDesktopTokens.SymbolSize.control * iconScale)).sonoIconFrame(SonoDesktopTokens.IconFrame.s24).frame(width: SonoDesktopTokens.Component.tool, height: 48).contentShape(Rectangle())
                        }.buttonStyle(ConsoleControlStyle(color: ink.titleTransport, ordinary: false)).disabled(!details).accessibilityLabel("下一首")
                    }.frame(width: transportWidth, height: 48)
                    HStack(spacing: SonoDesktopTokens.Spacing.s8) {
                        homeVolumeControls(scale: iconScale, docked: true, ink: ink)
                        consoleLyrics(scale: iconScale, docked: true)
                            .opacity(homeVolumeExpanded ? 0 : 1)
                            .allowsHitTesting(!homeVolumeExpanded)
                            .accessibilityHidden(homeVolumeExpanded)

                        if session.queueEditingAllowed {
                            Button { session.toggleQueue() } label: {
                                Image(systemName: "list.dash").font(.system(size: SonoDesktopTokens.SymbolSize.control * iconScale, weight: SonoDesktopTokens.FontWeight.medium))
                                    .sonoIconFrame(SonoDesktopTokens.IconFrame.s24 * iconScale)
                                    .frame(width: 32 * iconScale, height: 32 * iconScale, alignment: .center)
                                    .contentShape(Rectangle())
                            }.buttonStyle(ConsoleControlStyle(ordinary: false, selected: session.queueOpen)).accessibilityLabel("播放队列")
                        }

                        Menu {
                            if let track = session.audio.current {
                                SongInfoMenu(track: track, feedback: consoleFeedback(for: track), openAlbum: {
                                    session.closeLyrics(); openCatalog(track, album: true)
                                }, openArtist: { artist in
                                    session.closeLyrics(); openOnline(.artist(artist.id), artist.name)
                                })
                            }
                        } label: {
                            Image(systemName: "ellipsis").font(.system(size: SonoDesktopTokens.SymbolSize.control, weight: SonoDesktopTokens.FontWeight.medium))
                                .foregroundStyle(Color(nsColor: ink.primary))
                                .frame(width: 32, height: 32).contentShape(Rectangle())
                        }.menuStyle(.borderlessButton).menuIndicator(.hidden).frame(width: 32, height: 32)
                            .tint(Color(nsColor: ink.primary))
                            .disabled(playDisabled).help("更多歌曲操作").accessibilityLabel("更多歌曲操作")

                    }.overlay(alignment: .leading) {
                        consoleVolumeOverlay(scale: iconScale, docked: true, ink: ink)
                    }.onHover(perform: updateVolumeHover)
                        .fixedSize(horizontal: true, vertical: false)
                        .frame(width: max(0, halfDockWidth - trailingInset), alignment: .trailing)

                }.foregroundStyle(Color(nsColor: ink.primary))
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.leading, leadingInset)
                    .padding(.trailing, trailingInset)
                    .frame(height: LyricsDockMetrics.controlsHeight)
                    .allowsHitTesting(controlsVisible).accessibilityHidden(!controlsVisible)
            }
            .frame(width: geometry.size.width, height: geometry.size.height, alignment: .top)
        }.buttonStyle(ConsoleButtonStyle())
    }
    @ViewBuilder
    private func consoleModeIcon(scale: CGFloat, tint: Color?) -> some View {
        switch session.mode {
        case .sequential:
            SonoIcon(name: "new-play-in-order", size: SonoDesktopTokens.SvgSize.s24 * scale, tint: tint, inheritsForeground: tint == nil)
        case .shuffle:
            Image(systemName: "shuffle").font(.system(size: SonoDesktopTokens.SymbolSize.control * scale, weight: SonoDesktopTokens.FontWeight.medium))
        case .repeatOne:
            Image(systemName: "repeat.1").font(.system(size: SonoDesktopTokens.SymbolSize.control * scale, weight: SonoDesktopTokens.FontWeight.medium))
        }
    }

    private var volumeSymbol: String {
        switch session.audio.volume {
        case 0: "speaker.slash"
        case ..<(1.0 / 3): "speaker.wave.1"
        case ..<(2.0 / 3): "speaker.wave.2"
        default: "speaker.wave.3"
        }
    }

    private func consoleFMMode(scale: CGFloat, docked: Bool) -> some View {
        Button { session.fmModePickerOpen = true } label: {
            Image(systemName: "dot.radiowaves.left.and.right").font(.system(size: SonoDesktopTokens.SymbolSize.control * scale))
                .sonoIconFrame(SonoDesktopTokens.IconFrame.s24 * scale)
                .frame(width: 32 * scale, height: 32 * scale, alignment: docked ? .center : .trailing)
                .contentShape(Rectangle())
        }.buttonStyle(ConsoleControlStyle(ordinary: !docked, selected: session.fmModePickerOpen)).accessibilityLabel("私人FM模式：" + session.fm.selection.title)
            .disabled(online.activePlatform == .qq)
            .opacity(online.activePlatform == .qq ? 0 : 1)
            .accessibilityHidden(online.activePlatform == .qq)
    }

    private func consolePlaybackOrder(scale: CGFloat, docked: Bool, ink: LyricsInk) -> some View {
        Button {
            if session.isPersonalFM { session.toggleFMRepeat() }
            else { session.cycleMode() }
        } label: {
            Group {
                if session.isPersonalFM {
                    Image(systemName: session.fmRepeatOne ? "repeat.1" : "infinity")
                        .font(.system(size: SonoDesktopTokens.SymbolSize.control * scale, weight: SonoDesktopTokens.FontWeight.medium))
                } else { consoleModeIcon(scale: scale, tint: docked ? Color(nsColor: ink.primary) : nil) }
            }.sonoIconFrame(SonoDesktopTokens.IconFrame.s24 * scale).frame(width: 32 * scale, height: 32 * scale).contentShape(Rectangle())
        }.buttonStyle(ConsoleControlStyle(color: docked ? ink.primary : nil, ordinary: !docked)).help(session.isPersonalFM ? (session.fmRepeatOne ? "单曲循环" : "无限播放") : session.mode.title)
            .accessibilityLabel(session.isPersonalFM ? (session.fmRepeatOne ? "单曲循环" : "无限播放") : "播放模式：" + session.mode.title)
    }

    private func homeVolumeControls(scale: CGFloat, docked: Bool = false, compact: Bool = false, ink: LyricsInk = LyricsInk()) -> some View {
        let volume = session.audio.volume
        return HStack(spacing: (docked || compact ? 6 : 12) * scale) {
            Button { homeVolumeExpanded.toggle() } label: {
                Image(systemName: volumeSymbol)
                    .font(.system(size: SonoDesktopTokens.SymbolSize.control * scale, weight: SonoDesktopTokens.FontWeight.medium))
                    .sonoIconFrame(SonoDesktopTokens.IconFrame.s24 * scale)
                    .frame(width: 32 * scale, height: 32 * scale, alignment: docked || compact ? .center : .leading)
                    .contentShape(Rectangle())
            }
            .buttonStyle(ConsoleControlStyle(ordinary: !docked, selected: homeVolumeExpanded))
            .accessibilityLabel(homeVolumeExpanded ? "收起音量" : "音量设置")
            .contextMenu { Button(volume == 0 ? "取消静音" : "静音", action: toggleMute) }
            consolePlaybackOrder(scale: scale, docked: docked, ink: ink)
                .opacity(homeVolumeExpanded ? 0 : 1)
                .allowsHitTesting(!homeVolumeExpanded).accessibilityHidden(homeVolumeExpanded)
        }
        .onExitCommand { homeVolumeExpanded = false }
    }

    @ViewBuilder
    private func consoleVolumeOverlay(scale: CGFloat, docked: Bool, ink: LyricsInk) -> some View {
        if homeVolumeExpanded {
            ConsoleVolumeSlider(volume: Binding(get: { session.audio.volume }, set: { session.audio.volume = $0 }), scale: scale, tint: Color(nsColor: ink.primary), trackColor: docked ? (ink.light ? SonoGeneratedColors.lyricsVolumeTrack : SonoGeneratedColors.lyricsVolumeTrackDark) : SonoGeneratedColors.volumeTrack) { dragging in
                homeVolumeDragging = dragging
                if !dragging && !homeVolumeHovered { homeVolumeExpanded = false }
            }.frame(width: 65 * scale, height: 32 * scale)
                .offset(x: (docked ? 38 : 36) * scale)
        }
    }

    private func updateVolumeHover(_ inside: Bool) {
        homeVolumeHovered = inside
        if !inside && !homeVolumeDragging { homeVolumeExpanded = false }
    }

    private func toggleMute() {
        if session.audio.volume > 0 {
            previousVolume = session.audio.volume
            session.audio.volume = 0
        } else {
            session.audio.volume = previousVolume
        }
    }

    private func consoleLyrics(scale:CGFloat,docked:Bool) -> some View {
        Button { session.toggleLyrics(); session.stopFollowing() } label: {
            Image(systemName: "quote.bubble")
                .font(.system(size: SonoDesktopTokens.SymbolSize.control * scale, weight: SonoDesktopTokens.FontWeight.medium))
                .offset(y: 1 * scale)
                .sonoIconFrame(SonoDesktopTokens.IconFrame.s24 * scale)
                .frame(width:docked ? 32 : 32 * scale,height:docked ? 32 : 32 * scale).contentShape(Rectangle())
        }.buttonStyle(ConsoleControlStyle(ordinary: !docked, selected: session.lyricsOpen)).disabled(session.audio.current == nil).accessibilityLabel("歌词")
    }
    private func panelHeader(_ title: String, scale: CGFloat = 1, close: @escaping () -> Void) -> some View {
        HStack { Text(title).font(SonoTypography.font(size: SonoDesktopTokens.FontSize.sectionTitle * scale, weight: SonoDesktopTokens.FontWeight.semibold)).tracking(-0.5); Spacer(); Button(action: close) { Image(systemName: "xmark").font(.system(size: SonoDesktopTokens.SymbolSize.control)).sonoIconFrame(SonoDesktopTokens.IconFrame.s24).frame(width: 32, height: 32) }.buttonStyle(SonoPanelCloseStyle()).accessibilityLabel("关闭" + title) }.frame(height: 31)
    }
    private var sourcePanel: some View {
        VStack(spacing: SonoDesktopTokens.Spacing.s12) {
            HStack(spacing: SonoDesktopTokens.Spacing.s12) {
                if session.localSourceView {
                    Button { session.localSourceView = false } label: {
                        Image(systemName: "chevron.backward")
                            .font(.system(size: SonoDesktopTokens.SymbolSize.control))
                            .frame(width: SonoDesktopTokens.IconFrame.s24, height: SonoDesktopTokens.IconFrame.s24, alignment: .leading)
                            .frame(width: SonoDesktopTokens.Component.control, height: SonoDesktopTokens.Component.control, alignment: .leading)
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(SonoPanelCloseStyle(usesIconOpacity: true))
                    .accessibilityLabel("返回歌曲来源")
                } else {
                    SonoWordmark(height: 16)
                }
                Spacer(minLength: 12)
                Button { session.sidebarOpen = false } label: {
                    Image(systemName: "xmark")
                        .font(.system(size: SonoDesktopTokens.SymbolSize.control))
                            .sonoIconFrame(SonoDesktopTokens.IconFrame.s24)
                        .frame(width: 32, height: 32)
                        .contentShape(Circle())
                }
                .buttonStyle(SonoQueueButtonStyle(normal: colorScheme == .light ? SonoGeneratedColors.queueCloseLight : SonoGeneratedColors.queueCloseDark, light: colorScheme == .light))
                .accessibilityLabel("关闭歌曲来源")
            }
            .frame(height: SonoChromeMetrics.buttonSize)

            if session.localSourceView {
                VStack(spacing: SonoDesktopTokens.Spacing.s16) {
                    sourceDrawerScroll {
                        LazyVStack(spacing: SonoDesktopTokens.Spacing.s12) {
                            ForEach(session.folders) { folder in
                                if let tracks = session.tracksByFolder[folder.id] {
                                    SourceDrawerSection(title: folder.name, expanded: !collapsedLocalFolders.contains(folder.id)) {
                                        if !collapsedLocalFolders.insert(folder.id).inserted { collapsedLocalFolders.remove(folder.id) }
                                    } rows: {
                                        ForEach(tracks) { track in
                                            SourcePlaylistRow(title: track.title, selected: session.displayedTrack?.id == track.id,
                                                              action: { session.playLibrary(track) }) {
                                                Image(systemName: "music.note")
                                                    .font(.system(size: SonoDesktopTokens.SymbolSize.compact, weight: SonoDesktopTokens.FontWeight.medium))
                                            }
                                            .accessibilityLabel("播放 " + track.title)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    directoryButton
                }
            } else {
                VStack(spacing: SonoDesktopTokens.Spacing.s4) {
                    SourcePlaylistRow(title: "搜索", selected: capsuleSelectionID == "search", action: showSearch) {
                        Image(systemName: "magnifyingglass").font(.system(size: SonoDesktopTokens.SymbolSize.compact, weight: SonoDesktopTokens.FontWeight.medium))
                    }
                    SourcePlaylistRow(title: "私人FM", count: nil, selected: capsuleSelectionID == "personal-fm", playbackActive: session.isPersonalFM ? session.audio.isPlaying : nil, action: openPersonalFM) {
                        sourceFMIcon
                            .overlay { if session.fmStarting { SonoLoadingSpinner(size: SonoDesktopTokens.IconFrame.s16) } }
                    }
                    SourcePlaylistRow(title: "每日推荐", count: online.page?.kind.isDailyRecommendation == true ? online.page?.total : nil, selected: capsuleSelectionID == "daily-recommendations", playbackActive: capsulePlayingKind?.isDailyRecommendation == true ? session.audio.isPlaying : nil, action: openDailyRecommendations) {
                        Image(systemName: capsuleSelectionID == "daily-recommendations" ? "star.fill" : "star")
                            .font(.system(size: SonoDesktopTokens.SymbolSize.compact, weight: SonoDesktopTokens.FontWeight.medium))
                            .overlay { if online.pendingSourceKey?.hasPrefix("daily-recommendations") == true { SonoLoadingSpinner(size: SonoDesktopTokens.IconFrame.s16) } }
                    }
                    SourcePlaylistRow(title: "本地音频", count: session.tracks.count,
                                      selected: capsuleSelectionID == "local",
                                      action: { session.localSourceView = true; showLocal() }) {
                        Image(systemName: capsuleSelectionID == "local" ? "music.note.square.stack.fill" : "music.note.square.stack")
                            .font(.system(size: SonoDesktopTokens.SymbolSize.compact, weight: SonoDesktopTokens.FontWeight.medium))
                    }
                }
                .fixedSize(horizontal: false, vertical: true)
                .padding(.horizontal, SonoDesktopTokens.Spacing.s8)
                sourceDrawerScroll {
                    LazyVStack(spacing: SonoDesktopTokens.Spacing.s12) {
                        ForEach(SourcePlaylistSection.allCases, id: \.self) { section in
                            SourceDrawerSection(title: section.title, expanded: !collapsedPlaylistSections.contains(section)) {
                                if !collapsedPlaylistSections.insert(section).inserted { collapsedPlaylistSections.remove(section) }
                            } rows: {
                                sourcePlaylistRows(online.playlistsByPlayback.filter {
                                    ($0.subscribed == true) == (section == .subscribed)
                                })
                            }
                        }
                    }
                    .padding(.bottom, SonoDesktopTokens.Spacing.s12)
                }
                if online.playlistsLoading { ProgressView().controlSize(.small) }
            }
        }
        .padding(.horizontal, SonoDesktopTokens.Spacing.s16)
        .padding(.top, SonoChromeMetrics.topInset)
        .padding(.bottom, SonoDesktopTokens.Spacing.s16)
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
        .clipped()
        .glass(radius: 0)
    }
    private var directoryButton: some View {
        let shape = RoundedRectangle(cornerRadius: SonoDesktopTokens.Radius.medium)
        return Button { session.directoryManagerOpen = true } label: {
            Text("选择目录")
                .font(SonoTypography.font(size: SonoDesktopTokens.FontSize.body, weight: SonoDesktopTokens.FontWeight.medium))
                .frame(maxWidth: .infinity)
                .frame(height: SonoDesktopTokens.Spacing.s40)
                .contentShape(shape)
        }
        .buttonStyle(RecommendationChoiceStyle(kind: .confirm, shape: AnyShape(shape)))
    }

    private func sourceDrawerScroll<Content: View>(@ViewBuilder content: () -> Content) -> some View {
        ScrollView {
            content()
                .frame(width: sourceWidth - 2 * SonoDesktopTokens.Spacing.s24)
                .padding(.horizontal, SonoDesktopTokens.Spacing.s24)
                .background(PanelScrollConfiguration(usesCustomIndicator: true))
        }
        .panelOverlayScrollbar()
        .frame(width: sourceWidth)
        .padding(.horizontal, -SonoDesktopTokens.Spacing.s16)
    }
    private func sourcePlaylistRows(_ playlists: [OnlinePlaylist]) -> some View {
        ForEach(playlists) { playlist in
            let playing = hasCapsulePlaybackSource && capsulePlayingKind == .playlist(playlist.id)
            let cover = playlist.isFavorites == true ? online.firstCover(playlistID: playlist.id) ?? playlist.cover : playlist.cover
            SourcePlaylistRow(title: playlist.name, count: playlist.count, isPlaylistCover: true,
                              selected: capsuleSelectionID == "playlist/" + playlist.id,
                              playbackActive: playing ? session.audio.isPlaying : nil,
                              warm: { online.warmPlaylist(playlist) },
                              action: { openOnline(.playlist(playlist.id), playlist.name, keepSourcePanelOpen: true) }) {
                SourcePlaylistArtwork(url: cover)
                    .clipShape(RoundedRectangle(cornerRadius: 4))
            }
        }
    }
    private var directoryManager: some View {
        let buttonHeight = SonoDesktopTokens.Component.recommendationButton
        let footerInset = SonoDesktopTokens.Spacing.s8
        let light = (appearance.colorScheme ?? colorScheme) == .light
        return VStack(spacing: SonoDesktopTokens.Spacing.s12) {
            VStack(spacing: SonoDesktopTokens.Spacing.s4) {
                Text("选择本地文件夹")
                    .font(SonoTypography.font(size: SonoDesktopTokens.FontSize.sectionTitle, weight: SonoDesktopTokens.FontWeight.semibold))
                Text("将自动扫描选中的文件目录")
                    .font(SonoTypography.font(size: SonoDesktopTokens.FontSize.body))
                    .foregroundStyle(Color(nsColor: SonoGeneratedColors.queueSecondary))
            }
            .padding(.top, SonoDesktopTokens.Spacing.s28)
            .padding(.horizontal, SonoDesktopTokens.Spacing.s44)
            .frame(maxWidth: .infinity)
            .overlay(alignment: .topTrailing) {
                Button { session.directoryManagerOpen = false } label: {
                    Image(systemName: "xmark")
                        .font(.system(size: SonoDesktopTokens.SymbolSize.control))
                        .sonoIconFrame(SonoDesktopTokens.IconFrame.s24)
                        .frame(width: SonoDesktopTokens.Component.tool, height: SonoDesktopTokens.Component.tool)
                        .contentShape(Rectangle())
                }
                .buttonStyle(SonoPanelCloseStyle())
                .disabled(session.scanning)
                .accessibilityLabel("关闭目录管理")
                .padding(footerInset)
            }

            ScrollView {
                LazyVStack(spacing: SonoDesktopTokens.Spacing.s4) {
                    ForEach(session.folders) { folder in
                        HStack(spacing: SonoDesktopTokens.Spacing.s12) {
                            Toggle(isOn: Binding(get: { selectedFolders.contains(folder.id) }, set: { selected in
                                if selected { selectedFolders.insert(folder.id) } else { selectedFolders.remove(folder.id) }
                            })) {
                                Text(folder.name)
                                    .font(SonoTypography.font(size: SonoDesktopTokens.FontSize.body))
                                    .lineLimit(1)
                                    .help(folder.name)
                            }
                            .toggleStyle(.checkbox)
                            .frame(maxWidth: .infinity, alignment: .leading)

                            if session.unavailable.contains(folder.id) {
                                Button("重新授权") { session.chooseFolders(replacing: folder.id) }
                                    .font(SonoTypography.font(size: SonoDesktopTokens.FontSize.caption))
                            }

                            Button {
                                selectedFolders.remove(folder.id)
                                session.removeFolder(folder.id)
                            } label: {
                                Image(systemName: "trash")
                                    .font(.system(size: SonoDesktopTokens.SymbolSize.compact))
                                    .sonoIconFrame(SonoDesktopTokens.IconFrame.s20)
                                    .frame(width: SonoDesktopTokens.Component.tool, height: SonoDesktopTokens.Component.tool)
                                    .contentShape(Rectangle())
                            }
                            .buttonStyle(SonoQueueButtonStyle(normal: SonoGeneratedColors.queueSecondary, light: light))
                            .help("移除记录，不删除本地文件")
                            .accessibilityLabel("移除目录记录 " + folder.name)
                        }
                        .frame(minHeight: SonoDesktopTokens.Component.tool)
                        .disabled(session.scanning)
                    }
                }
            }
            .padding(.horizontal, SonoDesktopTokens.Spacing.s24)

            if let status = session.notice ?? (session.scanning ? "正在扫描…" : nil) {
                Text(status)
                    .font(SonoTypography.font(size: SonoDesktopTokens.FontSize.label))
                    .foregroundStyle(Color(nsColor: SonoGeneratedColors.notificationText))
                    .padding(.horizontal, SonoDesktopTokens.Spacing.s24)
            }

            HStack(spacing: SonoDesktopTokens.Spacing.s8) {
                Button { session.chooseFolders(activate: false) } label: {
                    Text("添加文件夹")
                        .frame(maxWidth: .infinity)
                        .frame(height: buttonHeight)
                        .overlay(Capsule().strokeBorder(Color(nsColor: SonoGeneratedColors.interfaceBorder), lineWidth: SonoDesktopTokens.Border.standard))
                        .contentShape(Capsule())
                }
                .buttonStyle(RecommendationChoiceStyle(kind: .cancel))

                Button { session.activateFolders(selectedFolders) } label: {
                    Text("确认")
                        .frame(maxWidth: .infinity)
                        .frame(height: buttonHeight)
                        .contentShape(Capsule())
                }
                .buttonStyle(RecommendationChoiceStyle(kind: .confirm))
            }
            .font(SonoTypography.font(size: SonoDesktopTokens.FontSize.body))
            .disabled(session.scanning)
            .padding(.horizontal, footerInset)
            .padding(.bottom, footerInset)
        }
        .frame(width: 480, height: 360)
        .background(
            Color(nsColor: SonoGeneratedColors.recommendationPanel),
            in: RoundedRectangle(cornerRadius: buttonHeight * SonoDesktopTokens.Radius.circle + footerInset)
        )
        .shadow(color: Color(nsColor: SonoGeneratedColors.interfaceBackdrop), radius: 20, y: 8)
    }
    private var settings: some View {
        SonoSettingsView(session: session, appearance: $appearance, glassDensity: $glassDensity, theme: $theme)
    }

}

struct WindowDragStrip: NSViewRepresentable {
    var draggable = true
    var clicked: () -> Void = {}
    func makeNSView(context: Context) -> DragStrip { let view = DragStrip(); view.draggable = draggable; view.clicked = clicked; return view }
    func updateNSView(_ nsView: DragStrip, context: Context) { nsView.draggable = draggable; nsView.clicked = clicked }
    final class DragStrip: NSView {
        var draggable = true
        var clicked: () -> Void = {}
        override var mouseDownCanMoveWindow: Bool { false }
        override func mouseDown(with event: NSEvent) { if draggable { window?.performDrag(with: event) } else { clicked() } }
        override func mouseDragged(with event: NSEvent) { }
        override func mouseUp(with event: NSEvent) { }
        override func rightMouseDown(with event: NSEvent) { }
        override func rightMouseUp(with event: NSEvent) { }
        override func otherMouseDown(with event: NSEvent) { }
        override func otherMouseUp(with event: NSEvent) { }
        override func scrollWheel(with event: NSEvent) { }
        override func magnify(with event: NSEvent) { }
        override func rotate(with event: NSEvent) { }
        override func swipe(with event: NSEvent) { }
    }
}

@MainActor
final class SonoWindow: NSWindow, NSWindowDelegate {
    let session = PlayerSession()
    weak var searchClickRegion: SearchClickRegion.Region?
    var browser: MusicBrowser { session.online.browser }
    override func sendEvent(_ event: NSEvent) {
        if event.type == .leftMouseDown, let region = searchClickRegion, region.window === self,
           !region.bounds.contains(region.convert(event.locationInWindow, from: nil)) {
            region.onOutsideClick?()
        }
        if event.type == .keyDown && event.keyCode == 49,
           event.modifierFlags.intersection([.command, .control, .option, .shift]).isEmpty,
           !(firstResponder is NSTextView), !(firstResponder is NSControl), (firstResponder as? BrowseCanvas)?.hasKeyboardControl != true {
            if !event.isARepeat { session.togglePlayback() }; return
        }
        if event.type == .keyDown && event.keyCode == 53 {
            if session.directoryManagerOpen { if !session.scanning { session.directoryManagerOpen = false }; return }
            if session.settingsOpen { session.settingsOpen = false; return }
            if firstResponder is NSTextView { super.sendEvent(event); return }
            if session.queueOpen && session.onQueueEscape?() == true { return }
            if session.queueOpen || session.sidebarOpen { session.dismissPanels(); return }
            if session.lyricsOpen { return }
        }
        super.sendEvent(event)
    }
    private func legalFrameSize(_ proposed: NSSize) -> NSSize? {
        guard let screen = screen ?? NSScreen.main else { return nil }
        let content = contentRect(forFrameRect: NSRect(origin: .zero, size: proposed)).size
        let limit = contentRect(forFrameRect: screen.visibleFrame).size
        return BrowseViewport.constrain(content, within: limit).map {
            frameRect(forContentRect: NSRect(origin: .zero, size: $0)).size
        }
    }
    func windowWillResize(_ sender: NSWindow, to frameSize: NSSize) -> NSSize {
        legalFrameSize(frameSize) ?? frame.size
    }
    func windowDidChangeOcclusionState(_ notification: Notification) {
        let visible = occlusionState.contains(.visible)
        if session.windowContentVisible != visible { session.windowContentVisible = visible }
    }
    override func setFrame(_ frameRect: NSRect, display flag: Bool) {
        var target = frameRect
        if !styleMask.contains(.fullScreen), let size = legalFrameSize(frameRect.size) {
            target.origin.y += target.height - size.height; target.size = size
        }
        super.setFrame(target, display: flag)
    }
    func windowDidChangeScreen(_ notification: Notification) {
        guard let screen else { return }
        if styleMask.contains(.fullScreen) {
            if !BrowseViewport(screen.frame.size).valid { toggleFullScreen(nil) }
            return
        }
        guard let size = legalFrameSize(frame.size) else {
            let alert = NSAlert(); alert.messageText = "此屏幕无法容纳最小窗口"
            alert.informativeText = "SONO MUSIC需要至少800×650的可用内容区。请调整显示器缩放或移回较大的屏幕。"; alert.runModal(); return
        }
        let area = screen.visibleFrame
        var target = frame; target.size = size
        target.origin.x = max(area.minX, min(target.minX, area.maxX - size.width))
        target.origin.y = max(area.minY, min(target.minY, area.maxY - size.height))
        if target != frame { setFrame(target, display: true) }
    }
    func windowDidExitFullScreen(_ notification: Notification) { windowDidChangeScreen(notification) }
    override func toggleFullScreen(_ sender: Any?) {
        if !styleMask.contains(.fullScreen), let screen, !BrowseViewport(screen.frame.size).valid {
            let alert = NSAlert(); alert.messageText = "此屏幕尺寸不足以全屏浏览"
            alert.informativeText = "请使用普通窗口，以保证中央封面完整显示并与播放器保持间隔。"; alert.runModal(); return
        }
        super.toggleFullScreen(sender)
    }
    func resize(to requested: NSSize) {
        guard !styleMask.contains(.fullScreen), let screen else { return }
        let proposed = frameRect(forContentRect: NSRect(origin: .zero, size: requested)).size
        guard let size = legalFrameSize(proposed) else { return }
        let area = screen.visibleFrame
        setFrame(NSRect(x: area.midX - size.width / 2, y: area.midY - size.height / 2, width: size.width, height: size.height), display: true)
    }
}

@MainActor
final class AppDelegate: NSObject, NSApplicationDelegate, NSMenuItemValidation {
    private var window: SonoWindow?
    private var systemMedia: SystemMedia?
    func applicationDidFinishLaunching(_ notification: Notification) {
        let defaults = PerformanceEnvironment.defaults
        (SonoAppearance(rawValue: defaults.string(forKey: "appearance") ?? "") ?? .initialValue).apply()
        let window = SonoWindow(contentRect: NSRect(x: 0, y: 0, width: 1440, height: 900), styleMask: [.titled, .closable, .miniaturizable, .resizable, .fullSizeContentView], backing: .buffered, defer: false)
        window.title = "SONO MUSIC"
        window.titlebarAppearsTransparent = true; window.titleVisibility = .hidden
        window.isMovableByWindowBackground = false
        window.contentMinSize = NSSize(width: 800, height: 650)
        window.delegate = window
        window.session.window = window
        window.contentView = NSHostingView(rootView: SonoScene(session: window.session, browser: window.browser, online: window.session.online))
        window.isReleasedWhenClosed = false; window.center(); window.makeKeyAndOrderFront(nil)
        self.window = window; window.session.restore(); window.session.online.restore()
        systemMedia = SystemMedia(session: window.session)
        installMenu(); NSApp.setActivationPolicy(.regular); NSApp.activate(ignoringOtherApps: true)
    }
    func applicationWillTerminate(_ notification: Notification) {
        if BrowseDiagnostics.shared.enabled, let path = ProcessInfo.processInfo.environment["SONO_BROWSE_DIAGNOSTICS"] {
            do { try BrowseDiagnostics.shared.write(to: URL(fileURLWithPath: path), frameBudgetMs: (window?.screen?.minimumRefreshInterval ?? 1 / 60) * 1000) }
            catch { NSLog("Sono browse diagnostic report failed: %@", error.localizedDescription) }
        }
        systemMedia?.shutdown(); window?.session.shutdown()
    }
    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { true }
    @objc private func standardWindowSize() { window?.resize(to: NSSize(width: 1440, height: 900)) }
    @objc private func compactWindowSize() { window?.resize(to: NSSize(width: 800, height: 650)) }
    @objc private func toggleSources() { window?.session.toggleSidebar() }
    @objc private func toggleQueue() { window?.session.toggleQueue() }
    func validateMenuItem(_ menuItem: NSMenuItem) -> Bool {
        if menuItem.action == #selector(toggleQueue) { return window?.session.queueEditingAllowed == true }
        return true
    }
    @objc private func playPause() { window?.session.togglePlayback() }
    @objc private func nextTrack() { window?.session.step(1) }
    @objc private func previousTrack() { window?.session.step(-1) }
    @objc private func seekForward() { if let audio = window?.session.audio { audio.seek(audio.elapsed + 10) } }
    @objc private func seekBackward() { if let audio = window?.session.audio { audio.seek(audio.elapsed - 10) } }
    @objc private func importFolders() { window?.session.chooseFolders() }
    @objc private func showSettings() { window?.session.settingsOpen = true }
    private func installMenu() {
        let menu = NSMenu()
        let appItem = NSMenuItem(); let appMenu = NSMenu(title: "SONO MUSIC")
        appMenu.addItem(withTitle: "关于 SONO MUSIC", action: #selector(NSApplication.orderFrontStandardAboutPanel(_:)), keyEquivalent: "")
        let settings = appMenu.addItem(withTitle: "设置…", action: #selector(showSettings), keyEquivalent: ","); settings.target = self
        appMenu.addItem(.separator()); appMenu.addItem(withTitle: "隐藏 SONO MUSIC", action: #selector(NSApplication.hide(_:)), keyEquivalent: "h")
        appMenu.addItem(withTitle: "退出 SONO MUSIC", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q")
        appItem.submenu = appMenu; menu.addItem(appItem)
        let fileItem = NSMenuItem(); let fileMenu = NSMenu(title: "文件")
        let open = fileMenu.addItem(withTitle: "导入音频目录…", action: #selector(importFolders), keyEquivalent: "o"); open.target = self
        fileItem.submenu = fileMenu; menu.addItem(fileItem)
        let playbackItem = NSMenuItem(); let playback = NSMenu(title: "播放")
        for (title, action, key) in [("播放 / 暂停", #selector(playPause), "p"), ("下一首", #selector(nextTrack), "\u{f703}"), ("上一首", #selector(previousTrack), "\u{f702}"), ("快进 10 秒", #selector(seekForward), "\u{f703}"), ("后退 10 秒", #selector(seekBackward), "\u{f702}")] {
            let item = playback.addItem(withTitle: title, action: action, keyEquivalent: key); item.target = self
            if action == #selector(seekForward) || action == #selector(seekBackward) { item.keyEquivalentModifierMask = [.command, .option] }
        }
        playbackItem.submenu = playback; menu.addItem(playbackItem)
        let editItem = NSMenuItem(); let edit = NSMenu(title: "编辑")
        for (title, action, key) in [("撤销", "undo:", "z"), ("剪切", "cut:", "x"), ("复制", "copy:", "c"), ("粘贴", "paste:", "v"), ("全选", "selectAll:", "a")] {
            edit.addItem(withTitle: title, action: Selector(action), keyEquivalent: key)
        }
        editItem.submenu = edit; menu.addItem(editItem)
        let windowItem = NSMenuItem(); let windowMenu = NSMenu(title: "窗口")
        windowMenu.addItem(withTitle: "最小化", action: #selector(NSWindow.performMiniaturize(_:)), keyEquivalent: "m")
        windowMenu.addItem(withTitle: "缩放", action: #selector(NSWindow.performZoom(_:)), keyEquivalent: "")
        for (title, action, key) in [("标准尺寸 1440 × 900", #selector(standardWindowSize), "1"), ("紧凑尺寸 800 × 650", #selector(compactWindowSize), "2")] {
            let item = windowMenu.addItem(withTitle: title, action: action, keyEquivalent: key)
            item.target = self; item.keyEquivalentModifierMask = [.command, .option]
        }
        let sources = windowMenu.addItem(withTitle: "歌曲来源", action: #selector(toggleSources), keyEquivalent: "s"); sources.target = self
        let queue = windowMenu.addItem(withTitle: "播放队列", action: #selector(toggleQueue), keyEquivalent: "l"); queue.target = self
        windowItem.submenu = windowMenu; menu.addItem(windowItem)
        NSApp.mainMenu = menu; NSApp.windowsMenu = windowMenu
    }
}

#if !SONO_VALIDATION
@main
struct SonoPlayerMain {
    static func main() {
        PerformanceEnvironment.configureSharedNetworkCache()
        #if !SONO_RELEASE_CANDIDATE
        if CommandLine.arguments.contains("--online-probe") {
            Task { exit(await OnlineProbe.run() ? 0 : 1) }; dispatchMain()
        }
        if CommandLine.arguments.dropFirst().first == "--verify-access" { AccessProbe.run(arguments: CommandLine.arguments); return }
        if ProcessInfo.processInfo.environment["SONO_BROWSE_DIAGNOSTICS"] != nil { BrowseDiagnostics.shared.begin(metadata: ["mode": "application startup and interaction"]) }
        #endif
        let app = NSApplication.shared; let delegate = AppDelegate(); app.delegate = delegate
        withExtendedLifetime(delegate) { app.run() }
    }
}

#endif

private struct LyricsEntranceOffset: AnimatableModifier {
    nonisolated var progress: CGFloat
    let height: CGFloat
    let transition: UUID
    let reachedThreshold: (UUID) -> Void

    nonisolated var animatableData: CGFloat {
        get { progress }
        set { progress = newValue }
    }

    func body(content: Content) -> some View {
        let reached = progress >= 0.8
        content.offset(y: height * (1 - progress))
            .task(id: reached ? transition : nil) {
                if reached, !Task.isCancelled { reachedThreshold(transition) }
            }
    }
}
