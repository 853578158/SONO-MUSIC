import SwiftUI

struct LibraryStage: View {
    @ObservedObject var session: PlayerSession
    @ObservedObject var browser: MusicBrowser
    let presented: Bool
    var catalog: (LocalTrack, Bool) -> Void = { _, _ in }
    var openEntity: (BrowseEntity) -> Void = { _ in }
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    var body: some View {
        let source = browser.sourceKey
        let tracks = browser.filtered(session.browseTracks)
        let items = session.onlineShowing && !browser.searching ? session.online.page?.items : nil
        let allEntries = session.onlineShowing && !browser.searching ? session.online.quickListEntries() : tracks.map { QuickListEntry(id: $0.id, track: $0) }
        let listQuery = browser.quickListQuery
        let entries = listQuery.isEmpty ? allEntries : allEntries.filter {
            guard let item = $0.browseItem else { return false }
            return item.title.localizedStandardContains(listQuery) || item.artist.localizedStandardContains(listQuery)
        }
        let highlight = listQuery.isEmpty ? (session.online.page?.kind.searchQuery ?? browser.location.submittedQuery) : listQuery
        let displayed = browser.layout == .carousel ? allEntries.compactMap(\.track) : tracks
        GeometryReader { proxy in
            let itemCount = items?.count ?? displayed.count
            let metrics = BrowseMetrics(viewport: proxy.size,
                                        count: browser.roundWall ? itemCount : max(itemCount, browser.sourceTotal),
                                        source: source)
            let categoryY = browser.layout == .carousel && !browser.quickListOpen && itemCount > 0
                ? metrics.carouselCategoryCenterY : metrics.categoryCenterY
            ZStack {
            NativeBrowseScene(tracks: displayed, items: items, activateEntity: openEntity, browser: browser, reduceMotion: reduceMotion,
                              presented: presented,
                              excludedInteractionRect: session.online.page?.kind.isDailyRecommendation == true ?
                                (session.online.dailyStylePickerOpen ? CGRect(origin: .zero, size: proxy.size) :
                                    CGRect(x: 0, y: categoryY - 22 * metrics.scale, width: proxy.size.width, height: 44 * metrics.scale)) : nil,
                              orderedIDs: allEntries.map(\.id), detailDemand: { ids in if session.onlineShowing { session.online.requestQuickDetails(ids) } },
                              priorityDetailDemand: { ids in if session.onlineShowing { session.online.requestQuickDetails(ids, priority: true) } },
                              unresolvedPlay: { id in Task { await playUnresolved(id) } },
                              currentID: session.audio.current?.id, playing: session.audio.isPlaying, pendingID: session.audio.pendingID, failures: session.audio.failures.merging(Dictionary(displayed.compactMap { track in track.online?.unavailableReason.map { (track.id, $0) } }, uniquingKeysWith: { first, _ in first })) { _, restriction in restriction }, hasMore: session.onlineShowing && session.online.page?.more == true,
                              dismiss: { session.dismissPanels() }, catalog: catalog, play: { playCarouselTrack($0, tracks: tracks) })
                .onAppear { prepare(tracks, proxy.size) }
                .onChange(of: tracks) { prepare(tracks, proxy.size) }
                .onChange(of: items) { _, items in if let items { browser.prepare(items: items, viewport: proxy.size) } }
                .onChange(of: browser.layout) { prepare(tracks, proxy.size) }
                .onChange(of: browser.location.anchor) { _, id in
                    if session.onlineShowing, browser.sourceKey == source, session.online.page?.kind.key == source, let index = (items ?? tracks.map(BrowseItem.song)).firstIndex(where: { $0.id == id }) { session.online.loadMoreIfNeeded(visibleIndex: index) }
                }
                .onChange(of: browser.location.camera) { _, camera in
                    if session.onlineShowing, browser.layout == .wall {
                        let field = browser.geometry(tracks: tracks, viewport: proxy.size, expanded: tracks.firstIndex { $0.id == browser.location.expanded })
                        if let index = field.visibleIndices(camera: camera).max() { session.online.loadMoreIfNeeded(visibleIndex: index) }
                    }
                }
                .opacity(browser.quickListOpen ? 0 : 1)
                .allowsHitTesting(!browser.quickListOpen)
                .accessibilityHidden(browser.quickListOpen)
            if browser.quickListOpen {
                QuickListScene(entries: entries, query: highlight,
                               rowWidth: BrowseMetrics(viewport: proxy.size, count: browser.roundWall ? tracks.count : max(session.browseTracks.count, browser.sourceTotal)).consoleWidth,
                               dismiss: { if let id = browser.quickListCenter { Task { try? await selectQuick(id, play: false, size: proxy.size, activateEntity: false) } } else { browser.dismissQuickList() } }, initial: browser.quickListCenter,
                               centerChanged: { id in
                                   browser.quickListCenter = id
                               },
                               demand: { if session.onlineShowing { session.online.requestQuickDetails($0.filter { $0.hasPrefix(session.online.activePlatform.rawValue + "/") }) } },
                               select: { id, play in try await selectQuick(id, play: play, size: proxy.size) })
                    .id(source + listQuery)
                    .onAppear { browser.onQuickListExit = { if let id = browser.quickListCenter { Task { try? await selectQuick(id, play: false, size: proxy.size, activateEntity: false) } } else { browser.dismissQuickList() } } }
                    .onDisappear { browser.onQuickListExit = nil }
                    .task(id: source + "|" + listQuery) {
                        if session.onlineShowing { await session.online.completeQuickListSearch() }
                    }
                    .overlay {
                        if entries.isEmpty || (!listQuery.isEmpty && session.online.quickSearchLoading) || (!listQuery.isEmpty && session.online.quickSearchError != nil) {
                            let top = 167 * BrowseMetrics(viewport: proxy.size).scale + 24
                            VStack(spacing: SonoDesktopTokens.Spacing.s12) {
                                if session.online.quickSearchLoading && !listQuery.isEmpty {
                                    ProgressView().controlSize(.small)
                                    Text("正在搜索完整列表…")
                                } else if let error = session.online.quickSearchError, !listQuery.isEmpty {
                                    Text(error)
                                    Button("重试") { Task { await session.online.completeQuickListSearch() } }
                                } else if session.online.loading {
                                    ProgressView().controlSize(.small)
                                } else if let error = session.online.notice {
                                    Text(error)
                                } else {
                                    Text("暂无相关信息")
                                }
                            }
                            .font(SonoTypography.font(size: SonoDesktopTokens.FontSize.body))
                            .foregroundStyle(Color(nsColor: SonoGeneratedColors.queueSecondary))
                            .frame(width: proxy.size.width, height: max(64, proxy.size.height - 76 - top))
                            .background(Color(nsColor: SonoGeneratedColors.pageBackground))
                            .position(x: proxy.size.width / 2, y: (top + proxy.size.height - 76) / 2)
                        }
                    }

            }
            }
        }
    }
    private func playCarouselTrack(_ track: LocalTrack, tracks: [LocalTrack]) {
        if session.onlineShowing && session.online.page?.ids.isEmpty == false {
            session.playQuickTrack(track)
        } else { session.playBrowser(track, tracks: tracks) }
    }
    private func playUnresolved(_ id: String) async {
        let source = browser.sourceKey, visit = browser.visit
        do {
            guard let track = try await session.online.resolveQuickDetails([id]).first,
                  browser.sourceKey == source, browser.visit == visit else { return }
            session.playQuickTrack(track)
        } catch { session.notice = "读取歌曲信息失败：" + error.localizedDescription }
    }
    private func prepare(_ tracks: [LocalTrack], _ size: CGSize) {
        if session.onlineShowing, !browser.searching, let items = session.online.page?.items { browser.prepare(items: items, viewport: size) }
        else { browser.prepare(tracks: tracks, viewport: size) }
    }
    private func selectQuick(_ id: String, play: Bool, size: CGSize, activateEntity: Bool = true) async throws {
        if let items = session.online.page?.items, let item = items.first(where: { $0.id == id }), let entity = item.entity {
            browser.expand(id, items: items, viewport: size)
            browser.dismissQuickList()
            if activateEntity { openEntity(entity) }
            return
        }
        browser.quickSelectionRevision += 1
        let selection = browser.quickSelectionRevision
        let source = browser.sourceKey, visit = browser.visit
        do {
                let track: LocalTrack?
                if let local = session.browseTracks.first(where: { $0.id == id }) { track = local }
                else { track = try await session.online.resolveQuickDetails([id]).first }
                guard browser.quickListOpen, browser.quickSelectionRevision == selection, browser.sourceKey == source, browser.visit == visit, let track else { return }
                if session.onlineShowing { session.online.revealQuickTrack(track) }
                browser.expand(id, tracks: browser.filtered(session.browseTracks), viewport: size)
                browser.dismissQuickList()
                if play {
                    if session.audio.current?.id == id { session.setPlayback(true) }
                    else { session.playQuickTrack(track) }
                }
        } catch { session.notice = "读取歌曲信息失败：" + error.localizedDescription; throw error }
    }
}
