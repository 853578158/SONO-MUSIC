import AppKit
import SwiftUI

enum SonoScrollbarStyle {
    static let thumbWidth: CGFloat = 8
    static let minimumThumbHeight: CGFloat = 36
    static let darkOpacity = 0.35
    static let lightOpacity = 0.42
}

// Compact dimensions with a vertical track fade, as refined after Figma review.
enum QuickListScrollbarStyle {
    static let width: CGFloat = 8
    static let trackWidth: CGFloat = width
    static let minimumThumbHeight: CGFloat = 36
    static let thumbOpacity = 0.6
}

struct QuickListEntry {
    let id: String
    let track: LocalTrack?
    var item: BrowseItem? = nil
    var browseItem: BrowseItem? { item ?? track.map(BrowseItem.song) }
}

struct QuickListScene: NSViewRepresentable {
    @Environment(\.sonoTheme) private var theme
    @Environment(\.songActions) private var songActions
    let entries: [QuickListEntry]
    var query = ""
    var rowWidth: CGFloat? = nil
    var dismiss: (() -> Void)? = nil
    let initial: String?
    let centerChanged: (String) -> Void
    let demand: ([String]) -> Void
    let select: (String, Bool) async throws -> Void
    func makeNSView(context: Context) -> QuickListView { QuickListView() }
    func updateNSView(_ view: QuickListView, context: Context) {
        view.theme = theme
        view.query = query
        view.rowWidth = rowWidth
        view.dismiss = dismiss
        view.songActions = songActions
        view.update(entries, initial: initial, centerChanged: centerChanged, demand: demand, select: select)
    }
    static func dismantleNSView(_ view: QuickListView, coordinator: ()) { view.dispose() }
}

@MainActor
final class QuickListView: NSView, NSTableViewDataSource, NSTableViewDelegate {
    var theme = SonoTheme.pink { didSet { if theme != oldValue { table.reloadData() } } }
    var query = "" { didSet { if query != oldValue { table.reloadData() } } }
    var rowWidth: CGFloat?
    var dismiss: (() -> Void)?
    private let scroll = NSScrollView(), table = QuickListTable(), document = FlippedListDocument()
    private let rail = QuickListRail()
    private var entries: [QuickListEntry] = []
    var songActions = SongActions()
    fileprivate func songMenu(row: Int) -> NSMenu? {
        guard entries.indices.contains(row), let track = entries[row].track else { return nil }
        return songActions.menu(for: track)
    }
    private var centerChanged: (String) -> Void = { _ in }
    private var demand: ([String]) -> Void = { _ in }
    private var select: (String, Bool) async throws -> Void = { _, _ in }
    private var observers: [NSObjectProtocol] = []
    private var liveScrolling = false
    private var snapTask: Task<Void, Never>?
    private var requestTask: Task<Void, Never>?
    private var hideTask: Task<Void, Never>?
    private var initialID: String?
    private var initialized = false
    private var pinch: CGFloat = 0
    private let edgeMask = CAGradientLayer()
    private var lastDemand: [String] = []
    private var focus = 0
    private var exiting = false
    private weak var hoveredCell: QuickListCell?
    private var blankPress: NSPoint?
    private var lastSize = CGSize.zero
    private var lastScrollOffset: CGFloat?
    private let positionBadge = NSView()
    private let positionLabel = NSTextField(labelWithString: "")
    override func viewDidChangeEffectiveAppearance() {
        super.viewDidChangeEffectiveAppearance()
        layer?.backgroundColor = SonoGeneratedColors.pageBackground.sonoCGColor(in: effectiveAppearance)
        positionLabel.textColor = SonoProgressBubbleColors(appearance: effectiveAppearance).text
        positionBadge.layer?.backgroundColor = SonoProgressBubbleColors(appearance: effectiveAppearance, fillColor: SonoGeneratedColors.positionBadge).fill.cgColor
        table.reloadData(); rail.needsDisplay = true
    }
    override var isFlipped: Bool { true }
    override var acceptsFirstResponder: Bool { true }
    override init(frame: NSRect) {
        super.init(frame: frame)
        wantsLayer = true
        layer?.backgroundColor = SonoGeneratedColors.pageBackground.sonoCGColor(in: effectiveAppearance)
        scroll.drawsBackground = false; scroll.borderType = .noBorder
        scroll.wantsLayer = true
        edgeMask.colors = [NSColor.clear.cgColor, NSColor.white.cgColor, NSColor.white.cgColor, NSColor.clear.cgColor]
        scroll.layer?.mask = edgeMask
        scroll.hasVerticalScroller = false; scroll.hasHorizontalScroller = false
        scroll.horizontalScrollElasticity = .none
        scroll.contentView.postsBoundsChangedNotifications = true
        table.style = .plain
        table.headerView = nil; table.backgroundColor = .clear; table.rowHeight = 64
        table.intercellSpacing = .zero; table.selectionHighlightStyle = .none
        table.addTableColumn(NSTableColumn(identifier: .init("song")))
        table.dataSource = self; table.delegate = self
        table.owner = self
        document.addSubview(table); scroll.documentView = document
        addSubview(scroll); addSubview(rail)
        rail.indicatorVisible = false
        rail.identifier = NSUserInterfaceItemIdentifier("quick-list-scrollbar")
        rail.setAccessibilityElement(true); rail.setAccessibilityRole(.scrollBar); rail.setAccessibilityLabel("歌单滚动条")
        positionBadge.wantsLayer = true
        positionBadge.layer?.backgroundColor = SonoProgressBubbleColors(appearance: effectiveAppearance, fillColor: SonoGeneratedColors.positionBadge).fill.cgColor
        positionBadge.layer?.cornerRadius = 8
        positionBadge.isHidden = true
        positionLabel.font = SonoTypography.native(size: SonoDesktopTokens.FontSize.caption, weight: SonoDesktopTokens.FontWeight.medium); positionLabel.textColor = SonoProgressBubbleColors(appearance: effectiveAppearance).text
        positionLabel.alignment = .right
        positionBadge.addSubview(positionLabel); addSubview(positionBadge)
        rail.changed = { [weak self] fraction in self?.jump(fraction) }
        rail.activity = { [weak self] in self?.showRail() }
        rail.began = { [weak self] in self?.cancelSnap() }
        rail.ended = { [weak self] in self?.snapToTop() }
        let notifications = NotificationCenter.default
        observers.append(notifications.addObserver(forName: NSView.boundsDidChangeNotification, object: scroll.contentView, queue: .main) { [weak self] _ in
            MainActor.assumeIsolated { self?.scrolled() }
        })
        observers.append(notifications.addObserver(forName: NSScrollView.willStartLiveScrollNotification, object: scroll, queue: .main) { [weak self] _ in
            MainActor.assumeIsolated { self?.liveScrolling = true; self?.cancelSnap() }
        })
        observers.append(notifications.addObserver(forName: NSScrollView.didLiveScrollNotification, object: scroll, queue: .main) { [weak self] _ in
            MainActor.assumeIsolated {
                guard let self, !self.liveScrolling else { return }
                // Legacy wheel events have no gesture-end notification.
                self.snapToTop(after: .milliseconds(180))
            }
        })
        observers.append(notifications.addObserver(forName: NSScrollView.didEndLiveScrollNotification, object: scroll, queue: .main) { [weak self] _ in
            MainActor.assumeIsolated { self?.liveScrolling = false; self?.snapToTop() }
        })
    }
    required init?(coder: NSCoder) { fatalError() }
    func dispose() {
        requestTask?.cancel(); hideTask?.cancel()
        cancelSnap()
        for observer in observers { NotificationCenter.default.removeObserver(observer) }; observers = []
        for row in table.subviews { (row as? QuickListCell)?.dispose() }
    }
    func update(_ values: [QuickListEntry], initial: String?, centerChanged: @escaping (String) -> Void, demand: @escaping ([String]) -> Void, select: @escaping (String, Bool) async throws -> Void) {
        self.centerChanged = centerChanged; self.demand = demand; self.select = select
        let changed = values.count != entries.count || zip(values, entries).contains { $0.id != $1.id || $0.track != $1.track }
        entries = values; initialID = initial
        if changed { table.reloadData() }
        needsLayout = true
    }
    override func layout() {
        super.layout()
        let oldAnchor = anchorIndex
        let resized = lastSize != .zero && lastSize != bounds.size
        if resized { cancelSnap() }
        lastSize = bounds.size
        let width = rowWidth ?? BrowseMetrics(viewport: bounds.size).consoleWidth
        let top = 167 * BrowseMetrics(viewport: bounds.size).scale + 24
        let bottom = bounds.height - 76
        let viewportHeight = max(64, bottom - top)
        let fits = CGFloat(entries.count) * 64 <= viewportHeight
        let hitWidth: CGFloat = 32
        let safeGap: CGFloat = 24
        let contentWidth = width
        // Center the visible group: cover left edge through thumb right edge.
        // Invisible hit padding must not pull the music content to the left.
        let originX = (bounds.width - width) / 2
        scroll.frame = NSRect(x: originX, y: top, width: contentWidth, height: viewportHeight)
        edgeMask.frame = scroll.bounds
        let edge = min(0.2, 24 / max(1,scroll.bounds.height))
        edgeMask.locations = [0, NSNumber(value: Double(edge)), NSNumber(value: Double(1-edge)), 1]
        // A partial final page gets less than one row of trailing space so its
        // top can align without clipping the final song at the bottom.
        let height = scroll.bounds.height + ceil(max(0, CGFloat(entries.count) * 64 - scroll.bounds.height) / 64) * 64
        document.frame = NSRect(x: 0, y: 0, width: contentWidth, height: height)
        table.frame = NSRect(x: 0, y: 0, width: contentWidth, height: CGFloat(entries.count)*64)
        table.tableColumns.first?.width = table.bounds.width
        rail.frame = NSRect(x: scroll.frame.maxX + safeGap, y: top, width: hitWidth, height: scroll.frame.height)
        rail.isHidden = fits
        rail.proportion = min(1, scroll.bounds.height / max(1, height))
        if !initialized && !entries.isEmpty {
            focus = initialID.flatMap { id in entries.firstIndex { $0.id == id } } ?? 0
            initialized = true; move(to: focus)
            window?.makeFirstResponder(self)
            animateEntry()
        } else if oldAnchor >= 0, !rail.dragging { if resized { move(to: oldAnchor) }; updateRail() }
        window?.invalidateCursorRects(for: self)
        scrolled()
    }
    override func hitTest(_ point: NSPoint) -> NSView? {
        let local = convert(point, from: superview)
        if !rail.isHidden && rail.frame.contains(local) { return rail }
        return super.hitTest(point)
    }
    override func resetCursorRects() {
        super.resetCursorRects()
        if !rail.isHidden { addCursorRect(rail.frame, cursor: rail.dragging ? .closedHand : .pointingHand) }
    }
    private var anchorIndex: Int {
        guard !entries.isEmpty else { return -1 }
        let y = scroll.contentView.bounds.minY - table.frame.minY
        let first = min(entries.count - 1, max(0, Int(y / 64)))
        // A row's outer padding may be clipped while its cover and metadata
        // remain complete. Advance only after the content itself is clipped.
        let contentTop = table.rect(ofRow: first).minY + QuickListCell.contentTopInset
        return contentTop < y ? min(entries.count - 1, first + 1) : first
    }
    private func move(to index: Int) {
        cancelSnap()
        scroll(to: CGFloat(index)*64)
    }
    private func jump(_ fraction: CGFloat) {
        scroll(to: fraction * max(0, document.bounds.height - scroll.bounds.height))
    }
    private func scroll(to y: CGFloat) {
        scroll.contentView.scroll(to: NSPoint(x: 0, y: max(0, min(max(0, document.bounds.height-scroll.bounds.height), y))))
        scroll.reflectScrolledClipView(scroll.contentView); scrolled()
    }
    private func cancelSnap() { snapTask?.cancel(); snapTask = nil }
    private func snapToTop(after delay: Duration = .zero) {
        cancelSnap()
        guard !entries.isEmpty, !exiting, !rail.dragging else { return }
        snapTask = Task { @MainActor [weak self] in
            do { if delay > .zero { try await Task.sleep(for: delay) } } catch { return }
            guard let self else { return }
            let from = scroll.contentView.bounds.minY
            let row = min(entries.count - 1, max(0, Int(from / 64)))
            let contentBottom = CGFloat(row) * 64 + QuickListCell.contentTopInset + QuickListCell.contentHeight
            let keepCurrent = contentBottom - from >= QuickListCell.contentHeight / 2
            let target = min(entries.count - 1, row + (keepCurrent ? 0 : 1))
            let destination = min(CGFloat(target) * 64, max(0, document.bounds.height - scroll.bounds.height))
            if abs(destination - from) > 0.1 && !NSWorkspace.shared.accessibilityDisplayShouldReduceMotion {
                let start = CACurrentMediaTime()
                while true {
                    let progress = min(1, (CACurrentMediaTime() - start) / 0.18)
                    scroll(to: from + (destination - from) * (1 - pow(1 - progress, 3)))
                    if progress == 1 { break }
                    do { try await Task.sleep(for: .milliseconds(16)) } catch { return }
                }
            } else { scroll(to: destination) }
            focus = target; snapTask = nil
        }
    }
    private func updateRail() {
        rail.fraction = scroll.contentView.bounds.minY / max(1, document.bounds.height - scroll.bounds.height)
        rail.needsDisplay = true
    }
    private func scrolled() {
        setHoveredCell(nil)
        updateRail()
        let index = anchorIndex
        rail.label = index >= 0 ? "\(index + 1) / \(entries.count)" : ""
        let offset = scroll.contentView.bounds.minY
        if let lastScrollOffset, abs(offset - lastScrollOffset) > 0.01 { showRail() }
        lastScrollOffset = offset
        guard entries.indices.contains(anchorIndex) else { return }
        centerChanged(entries[anchorIndex].id)
        let half = min(15, Int(ceil(scroll.bounds.height/64)))
        let ids = Array(entries[max(0,index-half)..<min(entries.count,index+half+1)].map(\.id))
        if ids != lastDemand {
            lastDemand = ids; requestTask?.cancel()
            requestTask = Task { @MainActor [weak self] in
                do { try await Task.sleep(for: .milliseconds(120)) } catch { return }
                self?.demand(ids)
            }
        }
    }
    private func showRail() {
        // Resize from the fixed trailing edge without layer interpolation.
        CATransaction.begin(); CATransaction.setDisableActions(true)
        defer { CATransaction.commit() }
        rail.indicatorVisible = true; hideTask?.cancel()
        positionBadge.isHidden = !rail.dragging
        positionLabel.stringValue = rail.label
        let labelSize = positionLabel.intrinsicContentSize
        let badgeWidth = ceil((labelSize.width + 16) / 4) * 4
        let knob = rail.convert(rail.knob, to: self)
        let trailingEdge = rail.frame.midX - QuickListScrollbarStyle.trackWidth / 2 - SonoDesktopTokens.Spacing.s8
        positionBadge.frame = NSRect(x: trailingEdge - badgeWidth, y: max(rail.frame.minY, min(rail.frame.maxY - 28, knob.midY - 14)), width: badgeWidth, height: 28)
        positionLabel.frame = NSRect(x: 8, y: (28 - labelSize.height) / 2, width: badgeWidth - 16, height: labelSize.height)
        hideTask = Task { @MainActor [weak self] in
            do { try await Task.sleep(for: .seconds(3)) } catch { return }
            guard let self, !rail.dragging else { return }
            positionBadge.isHidden = true
            rail.indicatorVisible = false
        }
    }
    func numberOfRows(in tableView: NSTableView) -> Int { entries.count }
    func tableView(_ tableView: NSTableView, viewFor tableColumn: NSTableColumn?, row: Int) -> NSView? {
        let cell = tableView.makeView(withIdentifier: .init("quick-song"), owner: self) as? QuickListCell ?? QuickListCell()
        cell.identifier = .init("quick-song")
        let entry = entries[row]
        cell.hoverChanged = { [weak self, weak cell] inside in
            guard let self, let cell else { return }
            if inside { setHoveredCell(cell) }
            else if hoveredCell === cell { setHoveredCell(nil) }
        }
        cell.configure(entry, query: query, accent: theme.accent, action: { [weak self] play in self?.finish(entry.id, play: play) })
        return cell
    }
    private func setHoveredCell(_ cell: QuickListCell?) {
        hoveredCell?.setHovered(false)
        hoveredCell = cell
        cell?.setHovered(true)
    }
    override func updateTrackingAreas() {
        super.updateTrackingAreas(); trackingAreas.forEach(removeTrackingArea)
        addTrackingArea(NSTrackingArea(rect: .zero, options: [.activeInKeyWindow, .mouseMoved, .mouseEnteredAndExited, .inVisibleRect], owner: self))
    }
    override func mouseMoved(with event: NSEvent) {
        let overRail = !rail.isHidden && rail.frame.contains(convert(event.locationInWindow, from: nil))
        rail.setHovered(overRail)
        if overRail { rail.updateCursor() }
        let point = table.convert(event.locationInWindow, from: nil)
        let row = table.row(at: point)
        let inside = scroll.frame.contains(convert(event.locationInWindow, from: nil))
        setHoveredCell(inside && row >= 0 ? table.view(atColumn: 0, row: row, makeIfNecessary: false) as? QuickListCell : nil)
    }
    override func mouseExited(with event: NSEvent) { setHoveredCell(nil); rail.setHovered(false) }
    private func animateEntry() {
        guard !NSWorkspace.shared.accessibilityDisplayShouldReduceMotion else { return }
        let fade = CABasicAnimation(keyPath: "opacity")
        fade.fromValue = 0; fade.toValue = 1; fade.duration = 0.12
        scroll.layer?.add(fade, forKey: "list-entry")
    }
    private func commit(_ id: String, play: Bool) {
        Task { @MainActor [weak self] in
            guard let self else { return }
            do { try await select(id, play) }
            catch { exiting = false; scroll.alphaValue = 1; rail.indicatorVisible = true }
        }
    }
    private func finish(_ id: String, play: Bool) {
        guard !exiting else { return }
        cancelSnap()
        exiting = true; requestTask?.cancel(); setHoveredCell(nil)
        commit(id, play: play)
    }
    override func mouseDown(with event: NSEvent) {
        cancelSnap()
        let point = convert(event.locationInWindow, from: nil)
        let gutter = NSRect(x: scroll.frame.maxX, y: scroll.frame.minY, width: rail.frame.maxX-scroll.frame.maxX, height: scroll.frame.height)
        blankPress = !rail.isHidden && gutter.contains(point) ? nil : point
    }
    override func mouseUp(with event: NSEvent) {
        defer { blankPress = nil }
        let point = convert(event.locationInWindow, from: nil)
        if let origin = blankPress, hypot(point.x-origin.x, point.y-origin.y) <= 6 { dismissList() }
    }
    private func dismissList() {
        if let dismiss { dismiss() }
        else if entries.indices.contains(anchorIndex) { finish(entries[anchorIndex].id, play: false) }
    }
    override func magnify(with event: NSEvent) {
        guard !exiting else { return }
        if event.phase.contains(.began) { cancelSnap(); pinch = 0; setHoveredCell(nil) }
        pinch += event.magnification
        let progress = min(1, max(0, (pinch - 0.03) / 0.22))
        CATransaction.begin(); CATransaction.setDisableActions(true)
        scroll.layer?.opacity = Float(1 - progress * 0.25)
        CATransaction.commit()
        if event.phase.contains(.ended) || event.phase.contains(.cancelled) {
            scroll.layer?.opacity = 1
            if !event.phase.contains(.cancelled) && pinch >= 0.15 { dismissList() }
            pinch = 0
        }
    }
    override func keyDown(with event: NSEvent) {
        if event.keyCode == 53 { dismissList(); return }
        guard !entries.isEmpty else { return }
        switch event.keyCode {
        case 125: focus = min(entries.count-1, max(focus, anchorIndex)+1); move(to: focus)
        case 126: focus = max(0, min(focus, anchorIndex)-1); move(to: focus)
        case 36, 76: finish(entries[min(focus, entries.count-1)].id, play: false)
        case 49: finish(entries[min(focus, entries.count-1)].id, play: true)
        case 53: dismissList()
        default: super.keyDown(with: event)
        }
    }
}

private final class FlippedListDocument: NSView { override var isFlipped: Bool { true } }
private final class QuickListTable: NSTableView {
    weak var owner: QuickListView?
    override func menu(for event: NSEvent) -> NSMenu? {
        owner?.songMenu(row: row(at: convert(event.locationInWindow, from: nil)))
    }
    override func magnify(with event: NSEvent) { owner?.magnify(with: event) }
    override func keyDown(with event: NSEvent) { owner?.keyDown(with: event) }
}

@MainActor
private final class QuickListCell: NSTableCellView {
    static let contentTopInset: CGFloat = 8
    static let contentHeight: CGFloat = 48
    private let cover = NSImageView(), title = NSTextField(labelWithString: ""), artist = NSTextField(labelWithString: "")
    private let play = QuickListPlayButton(title: "", target: nil, action: nil)
    private var action: (Bool) -> Void = { _ in }
    private var token: UUID?
    private var imageTask: Task<Void, Never>?
    var hoverChanged: (Bool) -> Void = { _ in }
    func setHovered(_ hovered: Bool) {
        layer?.backgroundColor = hovered ? SonoGeneratedColors.quickHover.sonoCGColor(in: effectiveAppearance) : NSColor.clear.cgColor
        play.alphaValue = hovered ? 1 : 0
        play.setCoverHovered(hovered)
    }
    override func viewDidChangeEffectiveAppearance() {
        super.viewDidChangeEffectiveAppearance()
        cover.layer?.backgroundColor = SonoGeneratedColors.quickPlaceholder.sonoCGColor(in: effectiveAppearance)
        setHovered(play.alphaValue > 0)
    }
    private var songID = ""
    private var pressed: NSPoint?
    override var isFlipped: Bool { true }
    override init(frame: NSRect) {
        super.init(frame: frame); wantsLayer = true; layer?.cornerRadius = 8
        title.font = SonoTypography.native(size: SonoDesktopTokens.FontSize.sectionTitle, weight: SonoDesktopTokens.FontWeight.medium)
        artist.font = SonoTypography.native(size: SonoDesktopTokens.FontSize.caption, weight: SonoDesktopTokens.FontWeight.regular); artist.textColor = SonoGeneratedColors.queueSecondary
        for field in [title, artist] { field.lineBreakMode = .byTruncatingTail; field.isSelectable = false; addSubview(field) }
        cover.imageScaling = .scaleProportionallyUpOrDown; cover.wantsLayer = true; cover.layer?.backgroundColor = SonoGeneratedColors.quickPlaceholder.sonoCGColor(in: effectiveAppearance)
        cover.layer?.cornerRadius = 2; cover.layer?.masksToBounds = true
        addSubview(cover); addSubview(play)
        play.wantsLayer = true; play.layer?.cornerRadius = 2; play.layer?.masksToBounds = true

        play.isBordered = false; play.target = self; play.action = #selector(playClicked); play.alphaValue = 0
        setAccessibilityElement(true); setAccessibilityRole(.button)
    }
    required init?(coder: NSCoder) { fatalError() }
    func dispose() { imageTask?.cancel(); imageTask = nil; BrowseArtworkStore.shared.cancel(token); token = nil }
    override func viewDidMoveToWindow() { super.viewDidMoveToWindow(); if window == nil { dispose() } }
    func configure(_ entry: QuickListEntry, query: String = "", accent: NSColor, action: @escaping (Bool) -> Void) {
        self.action = action
        play.isHidden = entry.browseItem?.song == nil
        title.stringValue = entry.browseItem?.title ?? "正在读取歌曲信息…"
        artist.stringValue = entry.browseItem?.artist ?? ""; toolTip = entry.browseItem.map { $0.title + " · " + $0.artist }
        for field in [title, artist] {
            let text = field.stringValue
            let value = NSMutableAttributedString(string: text, attributes: [.font: field.font!, .foregroundColor: field === title ? SonoGeneratedColors.primaryText : SonoGeneratedColors.queueSecondary])
            if !query.isEmpty {
                let source = text as NSString
                var remaining = NSRange(location: 0, length: source.length)
                while remaining.length > 0 {
                    let match = source.range(of: query, options: [.caseInsensitive, .diacriticInsensitive], range: remaining)
                    if match.location == NSNotFound { break }
                    value.addAttribute(.foregroundColor, value: accent, range: match)
                    remaining = NSRange(location: NSMaxRange(match), length: source.length - NSMaxRange(match))
                }
            }
            field.attributedStringValue = value
        }
        setAccessibilityLabel(toolTip ?? "正在读取歌曲信息")
        if songID != entry.id || cover.image == nil {
            dispose(); songID = entry.id; cover.image = nil
            if let url = entry.browseItem?.coverURL {
                let id = entry.id
                if let bitmap = BrowseArtworkStore.shared.availablePreview(url, presentation: nil) {
                    cover.image = NSImage(cgImage: bitmap.image,size: NSSize(width:32,height:32))
                } else {
                    imageTask = Task { @MainActor [weak self] in
                        do { try await Task.sleep(for: .milliseconds(120)) } catch { return }
                        guard let self, songID == id, window != nil else { return }
                        token = BrowseArtworkStore.shared.request(url, pixels: 128, center: false, visible: true) { [weak self] bitmap in
                            guard let self, songID == id else { return }
                            if let bitmap { cover.image = NSImage(cgImage: bitmap.image, size: NSSize(width: 32, height: 32)) }
                        }
                    }
                }
            }
        }
        setHovered(false)
    }
    override func layout() {
        super.layout()
        let side = SonoDesktopTokens.Cover.listCover
        cover.frame = NSRect(x: 8, y: Self.contentTopInset + (Self.contentHeight - side) / 2, width: side, height: side)
        play.frame = cover.frame
        play.layoutGlyph()
        title.frame = NSRect(x: 68, y: Self.contentTopInset, width: max(0,bounds.width-76), height: 28)
        artist.frame = NSRect(x: 68, y: Self.contentTopInset + Self.contentHeight - 18, width: max(0,bounds.width-76), height: 18)
    }
    override func updateTrackingAreas() {
        super.updateTrackingAreas(); trackingAreas.forEach(removeTrackingArea)
        addTrackingArea(NSTrackingArea(rect: .zero, options: [.activeInKeyWindow,.mouseEnteredAndExited,.inVisibleRect], owner: self))
    }
    override func mouseEntered(with event: NSEvent) { hoverChanged(true) }
    override func mouseExited(with event: NSEvent) { hoverChanged(false) }
    override func mouseDown(with event: NSEvent) { pressed = convert(event.locationInWindow, from: nil) }
    override func mouseUp(with event: NSEvent) {
        defer { pressed = nil }; let point = convert(event.locationInWindow, from: nil)
        if let pressed, hypot(point.x-pressed.x,point.y-pressed.y) <= 6, bounds.contains(point) { action(false) }
    }
    @objc private func playClicked() { action(true) }
    override func accessibilityPerformPress() -> Bool { action(false); return true }
}

@MainActor
final class QuickListRail: NSControl {
    var fraction: CGFloat = 0, proportion: CGFloat = 0.1
    var changed: (CGFloat) -> Void = { _ in }, activity: () -> Void = {}
    var began: () -> Void = {}, ended: () -> Void = {}
    var dragging = false, hovered = false, label = ""
    var indicatorVisible = false { didSet { needsDisplay = true } }
    private var offset: CGFloat = 0
    override var isFlipped: Bool { true }
    fileprivate var knob: NSRect {
        let height = min(bounds.height, max(QuickListScrollbarStyle.minimumThumbHeight,bounds.height*proportion))
        return NSRect(x: (bounds.width-QuickListScrollbarStyle.width)/2, y: fraction*(bounds.height-height), width: QuickListScrollbarStyle.width, height: height)
    }
    override func draw(_ dirtyRect: NSRect) {
        guard indicatorVisible else { return }
        let track = NSRect(x: bounds.midX - QuickListScrollbarStyle.trackWidth / 2, y: 0, width: QuickListScrollbarStyle.trackWidth, height: bounds.height)
        NSGradient(colorsAndLocations:
            (NSColor.white.withAlphaComponent(0), 0),
            (SonoGeneratedColors.volumeTrack, 0.5),
            (NSColor.white.withAlphaComponent(0), 1))?.draw(in: track, angle: 90)
        SonoGeneratedColors.quickScrollbar.setFill()
        NSBezierPath(roundedRect: knob, xRadius: QuickListScrollbarStyle.width / 2, yRadius: QuickListScrollbarStyle.width / 2).fill()
    }
    override func updateTrackingAreas() { super.updateTrackingAreas(); trackingAreas.forEach(removeTrackingArea); addTrackingArea(NSTrackingArea(rect: .zero,options:[.activeInKeyWindow,.mouseEnteredAndExited,.mouseMoved,.cursorUpdate,.inVisibleRect],owner:self)) }
    override func resetCursorRects() { addCursorRect(bounds, cursor: dragging ? .closedHand : .pointingHand) }
    func updateCursor() { (dragging ? NSCursor.closedHand : NSCursor.pointingHand).set() }
    override func cursorUpdate(with event: NSEvent) { updateCursor() }
    override func mouseMoved(with event: NSEvent) { updateCursor() }
    func setHovered(_ value: Bool) {
        guard hovered != value else { return }
        hovered = value
    }
    override func mouseEntered(with event: NSEvent) { setHovered(true); updateCursor() }
    override func mouseExited(with event: NSEvent) { setHovered(false) }
    override func mouseDown(with event: NSEvent) {
        began()
        let point = convert(event.locationInWindow,from:nil); dragging = true
        offset = knob.contains(point) ? point.y-knob.minY : knob.height/2
        mouseDragged(with:event)
    }
    override func mouseDragged(with event: NSEvent) { let point = convert(event.locationInWindow,from:nil); changed(max(0,min(1,(point.y-offset)/max(1,bounds.height-knob.height)))); activity(); needsDisplay = true; updateCursor() }
    override func mouseUp(with event: NSEvent) {
        mouseDragged(with: event)
        dragging = false; activity(); needsDisplay = true
        ended()
        window?.invalidateCursorRects(for: self)
        window?.invalidateCursorRects(for: superview ?? self)
        if bounds.contains(convert(event.locationInWindow, from: nil)) { updateCursor() } else { NSCursor.arrow.set() }
    }
}

@MainActor
private final class QuickListPlayButton: NSButton {
    private let glyph = NSImageView()

    func layoutGlyph() {
        if glyph.superview == nil {
            glyph.image = NSImage(systemSymbolName: "play.fill", accessibilityDescription: nil)?
                .withSymbolConfiguration(.init(pointSize: SonoDesktopTokens.SymbolSize.listPlay, weight: SonoDesktopTokens.NativeFontWeight.medium))
            glyph.contentTintColor = .white
            glyph.imageScaling = .scaleProportionallyDown
            glyph.wantsLayer = true
            glyph.layer?.masksToBounds = true
            addSubview(glyph)
            setAccessibilityLabel("播放")
        }
        let side = SonoDesktopTokens.IconFrame.s24
        glyph.frame = NSRect(x: bounds.midX - side / 2, y: bounds.midY - side / 2, width: side, height: side)
    }

    override func hitTest(_ point: NSPoint) -> NSView? {
        super.hitTest(point) == nil ? nil : self
    }

    override func updateTrackingAreas() {
        super.updateTrackingAreas(); trackingAreas.forEach(removeTrackingArea)
        addTrackingArea(NSTrackingArea(rect: .zero, options: [.activeInKeyWindow,.mouseEnteredAndExited,.inVisibleRect], owner: self))
    }
    override func mouseEntered(with event: NSEvent) {
        NSCursor.pointingHand.set()
    }
    func setCoverHovered(_ hovered: Bool) {
        wantsLayer = true
        layer?.backgroundColor = hovered ? SonoGeneratedColors.quickPlayScrim.sonoCGColor(in: effectiveAppearance) : NSColor.clear.cgColor
    }
    override func mouseExited(with event: NSEvent) { NSCursor.arrow.set() }
}
