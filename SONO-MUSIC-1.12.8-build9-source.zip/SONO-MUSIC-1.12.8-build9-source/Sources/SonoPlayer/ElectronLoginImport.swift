import Foundation
import CommonCrypto
import Security

// One-time, explicit migration of Sono's own encrypted login. It reads no browser
// database, does not launch Electron, and never writes a plaintext export.
enum ElectronLoginImport {
    static var sessionURL: URL {
        FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent("Library/Application Support/sono-player/netease-session.enc")
    }
    static func read() throws -> String {
        let encrypted = try Data(contentsOf: sessionURL)
        guard encrypted.starts(with: Data("v10".utf8)) else { throw OnlineError.protocolFailure("Electron 登录文件版本不受支持，请保留原文件。") }
        // These names come from the mainline package.json app name and its
        // existing Keychain item, not from the Electron executable bundle name.
        let query = [kSecClass as String: kSecClassGenericPassword,
                     kSecAttrService as String: "sono-player Safe Storage",
                     kSecAttrAccount as String: "sono-player Key",
                     kSecReturnData as String: true,
                     kSecMatchLimit as String: kSecMatchLimitOne] as CFDictionary
        var value: CFTypeRef?
        let status = SecItemCopyMatching(query, &value)
        guard status == errSecSuccess, let password = value as? Data else { throw OnlineError.credential(status) }
        return try decrypt(encrypted, password: password)
    }

    static func decrypt(_ encrypted: Data, password: Data) throws -> String {
        guard encrypted.starts(with: Data("v10".utf8)), encrypted.count > 3, (encrypted.count - 3) % 16 == 0 else { throw OnlineError.protocolFailure("Electron 登录文件无效") }
        var key = Data(count: 16)
        let salt = Data("saltysalt".utf8)
        let status = key.withUnsafeMutableBytes { destination in password.withUnsafeBytes { secret in salt.withUnsafeBytes { salt in
            CCKeyDerivationPBKDF(CCPBKDFAlgorithm(kCCPBKDF2), secret.bindMemory(to: Int8.self).baseAddress, password.count, salt.bindMemory(to: UInt8.self).baseAddress, 9, CCPseudoRandomAlgorithm(kCCPRFHmacAlgSHA1), 1003, destination.bindMemory(to: UInt8.self).baseAddress, 16)
        } } }
        guard status == kCCSuccess else { throw OnlineError.protocolFailure("无法解密 Electron 登录态") }
        let data = try NeteaseCrypto.aes(Data(encrypted.dropFirst(3)), key: key, iv: Data(repeating: 32, count: 16), decrypt: true)
        guard let cookie = String(data: data, encoding: .utf8), NeteaseClient.cookies(cookie)["MUSIC_U"] != nil else { throw OnlineError.protocolFailure("Electron 登录态未包含有效账号凭据") }
        return cookie
    }
}
