import AppKit
import Combine
import Foundation

struct QueueEntry: Identifiable, Codable {
    var id = UUID()
    let track: LocalTrack
}

enum PlayMode: String, Codable, CaseIterable {
    case sequential, shuffle, repeatOne
    var title: String { switch self { case .sequential: "顺序播放"; case .shuffle: "随机播放"; case .repeatOne: "单曲循环" } }
}
struct ListeningRecord: Identifiable, Codable {
    var id = UUID()
    let playedAt: Date
    let track: LocalTrack
}
struct SessionDocument: Codable {
    var version = 1
    var queue: [QueueEntry] = []
    var active: UUID?
    var history: [QueueEntry] = []
    var cursor: Int = -1
    var mode: PlayMode = .sequential
    // Optional additions preserve existing v1 documents and their entry identities.
    var sourceOrder: [QueueEntry]?
    var listeningRecords: [ListeningRecord]?
    var persistHistory: Bool?
    var historyLimit: Int?
    var enabledFolders: [UUID]?
    var queueTitle: String?
    var queueSourceKind: OnlinePageKind?
    var manuallyQueued: [UUID]?
    var referenceResumeTrack: String?
    var referenceOrder: [String]?
    var referencePlayOrder: [String]?
    var personalFMSelection: PersonalFMSelection?
}
struct SessionStore {
    let url: URL
    func load() throws -> SessionDocument {
        guard FileManager.default.fileExists(atPath: url.path) else { return SessionDocument() }
        let state = try JSONDecoder().decode(SessionDocument.self, from: RecommendationPersistenceMigration.data(Data(contentsOf: url), cache: false))
        guard state.version == 1 else { throw LibraryError.unsupportedVersion }
        guard state.cursor >= -1, state.cursor < state.history.count,
              Set(state.queue.map(\.id)).count == state.queue.count else { throw CocoaError(.fileReadCorruptFile) }
        return state
    }
    func save(_ state: SessionDocument) throws {
        try FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
        try JSONEncoder().encode(state).write(to: url, options: .atomic)
    }
}

struct PlaybackRecovery {
    var entries: [QueueEntry]
    var source: [QueueEntry]?
    var title: String?
    var kind: OnlinePageKind?
    var queueIndex: Int
    var targetIndex: Int
    var running: Bool
}

@MainActor
final class PlayerSession: ObservableObject {
    private var referenceOrder: [String]?
    private var referencePlayOrder: [String]?
    private var referenceStep: Task<Void, Never>?
    private var preparationChanges: AnyCancellable?
    private var nextPreparation: Task<Void, Never>?
    private var nextPreparationID: String?
    private func refreshPreparation() {
        guard audio.isPlaying, !audio.isLoading, recovery == nil, let current = audio.current else { return }
        let reference = isPersonalFM ? nil : (mode == .shuffle ? (referencePlayOrder ?? referenceOrder) : referenceOrder)
        let id: String?
        if isPersonalFM ? fmRepeatOne : mode == .repeatOne { id = current.id }
        else if let reference, let index = reference.firstIndex(of:current.id) {
            id = reference.dropFirst(index+1).first(where:{ audio.failures[$0] == nil })
        } else if let index = queue.firstIndex(where:{ $0.id == activeEntry }) {
            id = queue.dropFirst(index+1).first(where:{ audio.failures[$0.track.id] == nil })?.track.id
        } else { id = nil }
        guard nextPreparationID != id else { return }
        cancelPreparation(); nextPreparationID = id
        guard let id else { return }
        nextPreparation = Task { @MainActor [weak self] in
            guard let self else { return }
            do {
                let track: LocalTrack
                if let known = queue.first(where:{ $0.track.id == id })?.track { track = known }
                else { track = try await online.resolveReferencedSong(id) }
                try Task.checkCancellation()
                guard nextPreparationID == id, audio.isPlaying else { return }
                if let info = track.online { audio.prewarm(track,resolve:{ [prewarmOnlineAudioSource] in try await prewarmOnlineAudioSource(info) }) }
                else if let access = accesses[track.folderID] { audio.prewarm(track,access:access) }
                prepareVisuals(track)
            } catch { /* Speculative work never publishes playback failures. */ }
        }
    }
    private func cancelPreparation() {
        nextPreparation?.cancel(); nextPreparation = nil; nextPreparationID = nil; audio.cancelPrewarm()
        lyrics.cancelPreparation(); LyricsArtworkPreparation.shared.setWarmTargets([])
    }
    private func prepareVisuals(_ track: LocalTrack) {
        lyrics.prepare(track,online:online)
        var targets = [track]
        if let current = audio.current, current.id != track.id { targets.insert(current,at:0) }
        LyricsArtworkPreparation.shared.setWarmTargets(targets)
    }
    private var pendingReferenceOrder: [String]?
    func playQuickTrack(_ track: LocalTrack, ensurePlaying: Bool = false) {
        let order = track.online == nil ? nil : online.page?.ids.map { online.activePlatform.rawValue + "/" + $0 }
        if track.online != nil { online.revealQuickTrack(track) }
        playBrowser(track, tracks: browseTracks, ensurePlaying: ensurePlaying)
        if recovery?.running == true {
            pendingReferenceOrder = order
        }
    }
    @Published var lyricsOpen = false
    #if !SONO_RELEASE_CANDIDATE
    @Published var lyricsCoverFade = true
    @Published var lyricsCoverCustomEdges: LyricsCoverEdges?
    #endif
    let lyrics = LyricsState()
    let chorus = ChorusState()
    @Published var sidebarOpen = false
    @Published var queueOpen = false
    @Published var directoryManagerOpen = false
    @Published var settingsOpen = false
    @Published var localSourceView = false
    @Published private(set) var enabledFolders: Set<UUID>?
    @Published private(set) var listeningRecords: [ListeningRecord] = []
    @Published private(set) var persistHistory = true
    @Published private(set) var historyLimit = 500
    @Published private(set) var following = false
    @Published private(set) var recovery: PlaybackRecovery?
    @Published private(set) var targetedTrack: LocalTrack?
    private var recoveryRevision: UInt64 = 0
    private let onlineAudioSource: @MainActor (OnlineTrackInfo) async throws -> OnlineAudioSource
    private let prewarmOnlineAudioSource: @MainActor (OnlineTrackInfo) async throws -> OnlineAudioSource
    var onDismissFloating: (() -> Void)?
    var onQueueEscape: (() -> Bool)?
    var onBrowseFollow: ((LocalTrack, Bool) -> Bool)?
    private var sourceOrder: [QueueEntry] = []
    var upcoming: [QueueEntry] {
        if let recovery { return Array(recovery.entries.dropFirst(max(0, recovery.queueIndex))) }
        guard let index = queue.firstIndex(where: { $0.id == activeEntry }) else { return queue }
        return Array(queue[index...])
    }
    var historyPath: String { sessionStore.url.path }
    var activeFolderIDs: Set<UUID> { enabledFolders ?? Set(folders.map(\.id)) }
    @Published private(set) var folders: [FolderRecord] = []
    @Published private(set) var unavailable: Set<UUID> = []
    @Published private(set) var tracks: [LocalTrack] = []
    private(set) var tracksByFolder: [UUID: [LocalTrack]] = [:]
    @Published private(set) var queue: [QueueEntry] = []
    @Published private(set) var queueTitle = "本地音频"
    private(set) var queueSourceKind: OnlinePageKind?
    var playbackSourceTracks: [LocalTrack] { sourceOrder.map(\.track) }
    private func orderedEntries(_ entries: [QueueEntry], by ids: [String]) -> [QueueEntry] {
        let positions = Dictionary(ids.enumerated().map { ($0.element, $0.offset) }, uniquingKeysWith: { first, _ in first })
        return entries.sorted { (positions[$0.track.id] ?? Int.max) < (positions[$1.track.id] ?? Int.max) }
    }
    @Published private(set) var activeEntry: UUID?
    @Published private(set) var scanning = false
    @Published var notice: String?
    let audio = PlaybackController()
    let online: OnlineSession
    let fm = PersonalFMController()
    @Published var fmModePickerOpen = false
    @Published private(set) var fmStarting = false
    @Published private(set) var fmRepeatOne = false
    @Published private(set) var fmRefillNotice: String?
    private var fmChanges: AnyCancellable?
    private var fmStartTask: Task<Void, Never>?
    private var fmRefillTask: Task<Void, Never>?
    private var fmIntent = UUID()
    private var pendingFMSelection: PersonalFMSelection?
    private var fmRefillBlocked = false
    private var fmExcluded: Set<String> = []
    private var fmFeedbackTasks: [UUID: Task<Void, Never>] = [:]
    var isPersonalFM: Bool { queueSourceKind == .personalFM }
    var playbackSourceKind: OnlinePageKind? { recovery == nil ? queueSourceKind : recovery?.kind }
    var queueEditingAllowed: Bool { !isPersonalFM && !fmStarting }
    @Published var onlineShowing = false
    var browseTracks: [LocalTrack] { onlineShowing ? (online.page?.tracks ?? []) : tracks }
    var browseTitle: String { onlineShowing ? (online.page?.title ?? "网易云音乐") : "本地音频" }
    weak var window: NSWindow?
    @Published var windowContentVisible = true
    @Published private(set) var mode: PlayMode = .sequential
    @Published private(set) var history: [QueueEntry] = []
    @Published private(set) var canUndoClear = false
    var displayedTrack: LocalTrack? {
        if !audio.isPlaying, let targetedTrack { return targetedTrack }
        return audio.current ?? queue.first(where: { $0.id == activeEntry })?.track
    }
    private var persistenceAllowed = true
    private var historyCursor = -1
    private var clearedQueue: [QueueEntry]?
    private let sessionStore: SessionStore
    private let store: FolderStore
    private var accesses: [UUID: FolderAccess] = [:]
    private var scan: Task<Void, Never>?
    private var scanRevision: UInt64 = 0
    private var audioChanges: AnyCancellable?
    private var onlineChanges: AnyCancellable?
    private struct PendingPlayback {
        let trackID: String
        var entries: [QueueEntry]
        let selected: UUID
        var sourceOrder: [QueueEntry]?
        let historyCursor: Int?
        let appendNavigation: Bool
        var sourceTitle: String? = nil
        var sourceKind: OnlinePageKind? = nil
    }
    private var pendingQueue: PendingPlayback?
    private var compact: Bool { (window?.contentLayoutRect.width ?? 1440) < 900 }
    init(store: FolderStore = FolderStore(), online: OnlineSession = OnlineSession(), onlineAudioSource: (@MainActor (OnlineTrackInfo) async throws -> (url: URL, expires: Date))? = nil) {
        self.online = online
        if let onlineAudioSource {
            let resolve: @MainActor (OnlineTrackInfo) async throws -> OnlineAudioSource = { info in
                let source = try await onlineAudioSource(info)
                return OnlineAudioSource(url: source.url, expires: source.expires)
            }
            self.onlineAudioSource = resolve
            self.prewarmOnlineAudioSource = resolve
        } else {
            self.onlineAudioSource = { try await online.resolveSource($0) }
            self.prewarmOnlineAudioSource = { try await online.resolveSource($0, reportingFailure: false) }
        }
        self.store = store
        sessionStore = SessionStore(url: store.url.deletingLastPathComponent().appendingPathComponent("session-v1.json"))
        // Progress ticks belong to the progress view, not the entire browser/queue.
        audioChanges = Publishers.MergeMany([
            audio.$current.map { _ in () }.eraseToAnyPublisher(),
            audio.$isPlaying.removeDuplicates().map { _ in () }.eraseToAnyPublisher(),
            audio.$isLoading.removeDuplicates().map { _ in () }.eraseToAnyPublisher(),
            audio.$pendingID.removeDuplicates().map { _ in () }.eraseToAnyPublisher(),
            audio.$failures.removeDuplicates().map { _ in () }.eraseToAnyPublisher(),
            audio.$notice.removeDuplicates().map { _ in () }.eraseToAnyPublisher(),
            audio.$volume.removeDuplicates().map { _ in () }.eraseToAnyPublisher()
        ]).sink { [weak self] _ in self?.objectWillChange.send() }
        fmChanges = fm.objectWillChange.sink { [weak self] _ in self?.objectWillChange.send() }
        onlineChanges = online.objectWillChange.sink { [weak self] _ in self?.objectWillChange.send() }
        online.onAuthenticationChange = { [weak self] in self?.cancelFMRequests(); self?.cancelPreparation(); self?.cancelRecovery(); self?.audio.cancelCandidate(); self?.pendingQueue = nil }
        online.onAccountReset = { [weak self] in
            guard let self else { return }
            cancelFMRequests(); fmExcluded = []; fmModePickerOpen = false
            for task in fmFeedbackTasks.values { task.cancel() }; fmFeedbackTasks = [:]
            cancelPreparation(); referenceStep?.cancel(); referenceOrder = nil
            cancelRecovery(); audio.cancelCandidate(); pendingQueue = nil
            audio.clearFailures(Set(audio.failures.keys.filter { $0.hasPrefix("netease/") || $0.hasPrefix("qq/") }))
            if audio.current?.online != nil { audio.stopCurrent(); activeEntry = nil }
            queue.removeAll { $0.track.online != nil }; history.removeAll { $0.track.online != nil }
            if !queue.contains(where: { $0.id == activeEntry }) { activeEntry = nil }
            sourceOrder.removeAll { $0.track.online != nil }; historyCursor = history.count - 1
            listeningRecords.removeAll { $0.track.online != nil }
            queueSourceKind = nil; queueTitle = "本地音频"; fm.commit(.init())
            clearedQueue = nil; canUndoClear = false; persist()
        }
        preparationChanges = audio.$isPlaying.removeDuplicates().sink { [weak self] playing in
            if playing { Task { @MainActor [weak self] in self?.refreshPreparation(); self?.refillFMIfNeeded() } }
        }
        audio.onUserPause = { [weak self] in self?.cancelFMRequests(); self?.cancelPreparation(); self?.cancelRecovery() }
        audio.onSeekRequested = { [weak self] in self?.cancelFMRequests(); self?.cancelRecovery() }
        audio.onCandidateCancelled = { [weak self] in self?.pendingQueue = nil }
        audio.onCommit = { [weak self] track in
            if let self {
                self.lyrics.load(track,online:self.online)
                let neteaseSongID = track.online.flatMap { $0.platform == .netease ? $0.songID : nil }
                self.chorus.load(songID: neteaseSongID) { [online = self.online] in try await online.chorus($0) }
            }
            guard let self, let pending = self.pendingQueue, pending.trackID == track.id else { return }
            // Commit the recovery intent together with the queue. Waiting until
            // its suspended task resumes leaves a committed song looking pending
            // to an immediately following Previous/Next action.
            self.recovery = nil; self.targetedTrack = nil
            let changedEntry = self.activeEntry != pending.selected
            self.queue = pending.entries
            if let order = self.pendingReferenceOrder {
                self.referenceOrder = order.isEmpty ? nil : order
                self.referencePlayOrder = self.mode == .shuffle ? [track.id] + order.filter { $0 != track.id }.shuffled() : order
                self.pendingReferenceOrder = nil
            } else if pending.sourceOrder != nil && pending.sourceKind != self.queueSourceKind {
                self.referenceOrder = nil; self.referencePlayOrder = nil
            }
            if let source = pending.sourceOrder {
                self.sourceOrder = source; self.history = []; self.historyCursor = -1
                if let title = pending.sourceTitle { self.queueTitle = title }
                self.queueSourceKind = pending.sourceKind
            }
            self.online.recordPlaylistPlayback(source: self.queueSourceKind)
            self.activeEntry = pending.selected
            if self.queueSourceKind == .personalFM {
                self.queueOpen = false
                if let selection = self.pendingFMSelection { self.referenceOrder = nil; self.referencePlayOrder = nil; self.fm.commit(selection); self.pendingFMSelection = nil; self.fmExcluded = []; self.following = false; self.lyricsOpen = true; self.dismissPanels() }
                self.fmStarting = false; self.fmStartTask = nil
                self.queue.removeAll { self.fmExcluded.contains($0.track.id) && $0.id != self.activeEntry }
                self.sourceOrder.removeAll { self.fmExcluded.contains($0.track.id) && $0.id != self.activeEntry }
                self.trimFMHistory()
            } else { self.cancelFMRequests(); self.fmExcluded = [] }
            self.pendingQueue = nil
            if let cursor = pending.historyCursor { self.historyCursor = cursor }
            else if changedEntry || pending.appendNavigation, let entry = self.queue.first(where: { $0.id == self.activeEntry }) {
                self.history = Array(self.history.prefix(self.historyCursor + 1))
                self.history.append(entry)
                if self.history.count > 500 { self.history.removeFirst(self.history.count - 500) }
                self.historyCursor = self.history.count - 1
            }
            self.listeningRecords.removeAll { $0.track.id == track.id }
            self.listeningRecords.insert(ListeningRecord(playedAt: Date(), track: track), at: 0)
            self.listeningRecords = Array(self.listeningRecords.prefix(self.historyLimit))
            if self.following { _ = self.followPlaybackInBrowser(track, locate: false) }
            self.persist()
            self.refillFMIfNeeded()
        }
        audio.onEnded = { [weak self] in
            guard let self, !self.audio.isLoading, self.recovery?.running != true else { return }
            self.step(1, automatic: true)
        }
    }
    func restore() {
        do {
            folders = try store.load()
            do {
                let state = try sessionStore.load()
                queue = state.queue; activeEntry = state.active; history = state.history
                historyCursor = state.cursor; mode = state.mode
                sourceOrder = state.sourceOrder ?? state.queue
                queueSourceKind = state.queueSourceKind
                if let selection = state.personalFMSelection, selection.valid { fm.commit(selection) }
                if let originalOrder = state.referenceOrder {
                    sourceOrder = orderedEntries(sourceOrder, by: originalOrder)
                }
                manuallyQueued = state.manuallyQueued ?? []
                referenceResumeTrack = state.referenceResumeTrack
                referenceOrder = state.referenceOrder
                referencePlayOrder = state.referencePlayOrder
                queueTitle = state.queueTitle ?? (state.queue.contains { $0.track.online != nil } ? "网易云音乐" : "本地音频")
                var seenTracks = Set<String>()
                listeningRecords = (state.listeningRecords ?? []).sorted { $0.playedAt > $1.playedAt }
                    .filter { seenTracks.insert($0.track.id).inserted }
                persistHistory = state.persistHistory ?? true
                historyLimit = [100, 500, 1000].contains(state.historyLimit ?? 500) ? (state.historyLimit ?? 500) : 500
                enabledFolders = state.enabledFolders.map(Set.init)
            } catch { persistenceAllowed = false; rescan(); notice = "读取队列记录失败，原文件已保留：\(error.localizedDescription)"; return }
            rescan()
        }
        catch { persistenceAllowed = false; notice = "读取目录记录失败：\(error.localizedDescription)" }
    }
    func toggleSidebar() {
        if !sidebarOpen { localSourceView = false }
        sidebarOpen.toggle(); if compact && sidebarOpen { queueOpen = false } }
    func toggleQueue() {
        guard queueEditingAllowed else { queueOpen = false; return }
        queueOpen.toggle(); if compact && queueOpen { sidebarOpen = false }
    }
    func toggleLyrics() {
        if lyricsOpen && queueOpen { queueOpen = false; return }
        guard !lyricsOpen else { return }
        lyricsOpen = true; dismissPanels()
    }
    func closeLyrics() { queueOpen = false; lyricsOpen = false }
    func dismissPanels() { sidebarOpen = false; queueOpen = false; onDismissFloating?() }
    func stopFollowing() {
        guard following else { return }
        following = false
    }
    private func followPlaybackInBrowser(_ track: LocalTrack, locate: Bool) -> Bool {
        guard playbackSourceKind != .personalFM else { return false }
        return onBrowseFollow?(track, locate) == true
    }
    func locatePlaying(completion: (() -> Void)? = nil) {
        guard let track = displayedTrack else { return }
        online.browser.afterFocus = nil
        if playbackSourceKind == .personalFM {
            following = false
            if let completion { completion() }
            else if !fmStarting { lyricsOpen = true; dismissPanels() }
            return
        }
        guard followPlaybackInBrowser(track, locate: true) else { return }
        let browser = online.browser
        let source = browser.sourceKey, visit = browser.visit
        browser.afterFocus = completion.map { action in
            (track.id, { [weak browser] in
                guard browser?.sourceKey == source, browser?.visit == visit else { return }
                action()
            })
        }
        following = true
    }
    func cycleMode() {
        let all = PlayMode.allCases
        setMode(all[(all.firstIndex(of: mode)! + 1) % all.count])
    }
    func toggleFMRepeat() {
        fmRepeatOne.toggle()
        refreshPreparation()
    }
    func configureHistory(persist enabled: Bool, limit: Int) {
        guard [100, 500, 1000].contains(limit) else { return }
        persistHistory = enabled; historyLimit = limit
        listeningRecords = Array(listeningRecords.prefix(limit)); persist()
    }
    func replayListeningRecord(_ id: UUID) {
        guard queueEditingAllowed, let record = listeningRecords.first(where: { $0.id == id }) else { return }
        if audio.current?.id == record.track.id, pendingQueue == nil, !audio.isLoading,
           audio.failures[record.track.id] == nil {
            if !audio.isPlaying { audio.toggle() }
            return
        }
        let index: Int
        if let current = queue.firstIndex(where: { $0.id == activeEntry }), queue[current].track.id == record.track.id {
            cancelQueueCandidate()
            index = current
        } else { index = insertHistoryTrackNext(record.track) }
        following = false
        startRecovery(entries: queue, index: index, title: queueTitle, kind: queueSourceKind, forceFollow: false)
    }
    private var manuallyQueued: [UUID] = []
    private var referenceResumeTrack: String?

    func queueListeningRecordNext(_ id: UUID) {
        guard let record = listeningRecords.first(where: { $0.id == id }) else { return }
        queueTrackNext(record.track)
    }

    func queueTrackNext(_ track: LocalTrack) {
        guard queueEditingAllowed, track.playable || track.online != nil else { return }
        let index = insertHistoryTrackNext(track)
        let id = queue[index].id
        manuallyQueued.removeAll { $0 == id }
        manuallyQueued.insert(id, at: 0)
        persist()
    }
    /// Reuse a matching future entry; an explicit repeat of the current song gets its own slot.
    private func insertHistoryTrackNext(_ track: LocalTrack) -> Int {
        cancelQueueCandidate()
        referenceStep?.cancel(); pendingReferenceOrder = nil
        clearedQueue = nil; canUndoClear = false
        let next = queue.firstIndex(where: { $0.id == activeEntry }).map { $0 + 1 } ?? 0
        let entry: QueueEntry
        if let existing = queue.indices.dropFirst(next).first(where: { queue[$0].track.id == track.id }) {
            entry = queue.remove(at: existing)
        } else {
            entry = QueueEntry(track: track)
            sourceOrder.append(entry)
        }
        queue.insert(entry, at: next)
        return next
    }
    func activateFolders(_ ids: Set<UUID>) {
        guard !scanning else { return }
        rescan(activating: ids.intersection(Set(folders.map(\.id))))
    }
    func chooseFolders(replacing id: UUID? = nil, activate: Bool = true) {
        let panel = NSOpenPanel()
        panel.title = id == nil ? "添加本地音乐目录" : "重新授权音乐目录"
        panel.canChooseDirectories = true; panel.canChooseFiles = false
        panel.allowsMultipleSelection = id == nil && activate
        panel.prompt = activate ? "授权并扫描" : "添加"
        guard let window else { notice = "请先激活音乐窗口，再选择目录。"; return }
        panel.beginSheetModal(for: window) { [weak self] response in
            guard response == .OK else { return }
            do { try self?.importDirectories(panel.urls, replacing: id, activate: activate) }
            catch { self?.notice = "目录授权未完成：\(error.localizedDescription)" }
        }
    }
    func importDirectories(_ urls: [URL], replacing id: UUID? = nil, activate: Bool = true) throws {
        let previouslyEnabled = activeFolderIDs
        var updated = folders
        var additions: [UUID: FolderAccess] = [:]
        for url in urls {
            let path = url.resolvingSymlinksInPath().standardizedFileURL
            let known = accesses.merging(additions) { _, new in new }
            let duplicate = known.first { $0.key != id && $0.value.url.resolvingSymlinksInPath().standardizedFileURL.path == path.path }
            if duplicate != nil {
                if id != nil { throw LibraryError.duplicateDirectory }
                continue
            }
            let access = try FolderStore.authorize(url, id: id ?? UUID())
            if let index = updated.firstIndex(where: { $0.id == access.record.id }) { updated[index] = access.record }
            else { updated.append(access.record) }
            additions[access.record.id] = access
        }
        guard !additions.isEmpty else { return }
        try store.save(updated)
        folders = updated
        enabledFolders = activate ? previouslyEnabled.union(additions.keys) : previouslyEnabled
        for (id, access) in additions { accesses[id] = access; unavailable.remove(id) }
        // Reauthorization may point to a moved or replacement directory. Old URLs
        // must not borrow the replacement directory's scope while it is scanning.
        guard activate else { persist(); return }
        let replaced = Set(additions.keys)
        tracks.removeAll { replaced.contains($0.folderID) }
        queue.removeAll { replaced.contains($0.track.folderID) }
        audio.cancelCandidate(); pendingQueue = nil
        notice = nil
        persist()
        rescan()
    }
    func removeFolder(_ id: UUID) {
        cancelPreparation()
        do {
            let remaining = folders.filter { $0.id != id }
            try store.save(remaining)
            cancelScan()
            audio.cancelCandidate(); pendingQueue = nil
            folders = remaining; unavailable.remove(id); enabledFolders?.remove(id)
            tracks.removeAll { $0.folderID == id }
            queue.removeAll { $0.track.folderID == id }
            // Active audio owns its lease until it is replaced or the app quits.
            accesses[id] = nil
            persist()
            rescan()
        } catch { notice = "移除目录记录失败：\(error.localizedDescription)" }
    }
    func rescan(activating selection: Set<UUID>? = nil) {
        cancelScan()
        let revision = scanRevision
        // Resolve again on refresh so moved folders and restored permissions are
        // reflected without restarting. Existing audio retains its original lease.
        var refreshed: [UUID: FolderAccess] = [:]
        var refreshWarnings: [String] = []
        var records = folders
        for index in records.indices {
            do {
                let access = try FolderStore.resolve(records[index])
                refreshed[records[index].id] = access
                records[index] = access.record
            } catch { refreshWarnings.append("\(records[index].name)：目录无法访问，请重新授权（\(error.localizedDescription)）") }
        }
        accesses = refreshed
        unavailable = Set(folders.map(\.id)).subtracting(refreshed.keys)
        notice = refreshWarnings.isEmpty ? nil : refreshWarnings.prefix(3).joined(separator: "\n")
        if records != folders {
            do { try store.save(records); folders = records }
            catch { refreshWarnings.append("已读取移动后的目录，但书签更新保存失败：\(error.localizedDescription)"); notice = refreshWarnings.joined(separator: "\n") }
        }
        let selected = selection ?? activeFolderIDs
        if selection != nil && !selected.isSubset(of: Set(accesses.keys)) {
            notice = "请重新授权无法访问的目录，再点击确认。"; return
        }
        if selection?.isEmpty == true {
            enabledFolders = []; directoryManagerOpen = false
            applyScanResult(ScanResult()); persist(); return
        }
        let sources = folders.filter { selected.contains($0.id) }.compactMap { accesses[$0.id] }
        guard !sources.isEmpty else { applyScanResult(ScanResult()); return }
        scanning = true
        let sourceWarnings = refreshWarnings
        let cache = PerformanceEnvironment.cacheDirectory(default: FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0].appendingPathComponent("SonoPlayerMacOS/Artwork", isDirectory: true), subdirectory: "Artwork")
        scan = Task { [weak self] in
            let worker = Task.detached(priority: .userInitiated) { try await LibraryScanner.scan(sources, cache: cache) }
            do {
                let result = try await withTaskCancellationHandler { try await worker.value } onCancel: { worker.cancel() }
                guard let self, !Task.isCancelled, self.scanRevision == revision else { return }
                self.scanning = false
                if let selection {
                    guard !result.tracks.isEmpty && result.inaccessibleFolderIDs.isEmpty else {
                        self.notice = result.inaccessibleFolderIDs.isEmpty ? "所选目录及其子目录没有可识别的歌曲文件" : "所选目录无法访问，请重新授权后确认。"
                        return
                    }
                    self.enabledFolders = selection; self.directoryManagerOpen = false
                }
                self.applyScanResult(result)
                let warnings = sourceWarnings + result.warnings
                if !warnings.isEmpty { self.notice = warnings.prefix(3).joined(separator: "\n") }
                else if result.tracks.isEmpty { self.notice = "目录及其子目录没有可识别的音频。" }
            } catch is CancellationError { }
            catch {
                guard let self, !Task.isCancelled, self.scanRevision == revision else { return }
                self.scanning = false; self.notice = "扫描失败：\(error.localizedDescription)"
            }
        }
    }
    // One commit point for the library, existing queue and pending queue snapshot.
    func applyScanResult(_ result: ScanResult) {
        cancelPreparation()
        tracks = result.tracks
        tracksByFolder = Dictionary(grouping: result.tracks, by: \.folderID)
        let availableIDs = Set(result.tracks.map(\.id))
        if var context = recovery {
            let old = context.entries
            let target = old.indices.contains(context.targetIndex) ? old[context.targetIndex] : nil
            let remaining = old.filter { $0.track.online != nil || availableIDs.contains($0.track.id) }
            if let target, let index = remaining.firstIndex(where: { $0.id == target.id }) {
                let preceding = Set(old.prefix(max(0, context.queueIndex + 1)).map(\.id))
                context.entries = remaining; context.targetIndex = index
                context.queueIndex = remaining.lastIndex(where: { preceding.contains($0.id) }) ?? -1
                context.source = context.source?.filter { $0.track.online != nil || availableIDs.contains($0.track.id) }
                recovery = context
            } else { cancelRecovery(); audio.cancelCandidate() }
        }
        queue.removeAll { $0.track.online == nil && !availableIDs.contains($0.track.id) }
        if var pending = pendingQueue {
            if pending.entries.first(where: { $0.track.id == pending.trackID })?.track.online != nil || availableIDs.contains(pending.trackID) {
                pending.entries = pending.entries.filter { $0.track.online != nil || availableIDs.contains($0.track.id) }
                pending.sourceOrder = pending.sourceOrder?.filter { $0.track.online != nil || availableIDs.contains($0.track.id) }
                pendingQueue = pending
            } else {
                audio.cancelCandidate(); pendingQueue = nil
            }
        }
        let refreshed = Dictionary(uniqueKeysWithValues: result.tracks.map { ($0.id, $0) })
        queue = queue.map { QueueEntry(id: $0.id, track: refreshed[$0.track.id] ?? $0.track) }
        persist()
        unavailable = Set(folders.map(\.id)).subtracting(accesses.keys).union(result.inaccessibleFolderIDs)
    }
    func cancelScan() { cancelPreparation(); scanRevision &+= 1; scan?.cancel(); scan = nil; scanning = false }
    func playSuggestedTrack(_ track: LocalTrack) {
        guard track.playable || track.online != nil else {
            notice = "这首歌暂时无法播放"
            return
        }
        if track.online == nil, audio.current?.id == track.id, pendingQueue == nil, !audio.isLoading, audio.failures[track.id] == nil {
            if !audio.isPlaying { audio.toggle() }
            return
        }
        cancelFMRequests()
        referenceStep?.cancel()
        referenceOrder = nil; referencePlayOrder = nil; referenceResumeTrack = nil; manuallyQueued = []
        let entries = [QueueEntry(track: track)]
        startRecovery(entries: entries, index: 0, source: entries, title: "搜索", retry: true)
    }

    func playLibrary(_ track: LocalTrack) {
        playBrowser(track, tracks: tracks)
    }
    func playBrowser(_ track: LocalTrack, tracks: [LocalTrack], ensurePlaying: Bool = false) {
        if audio.current?.id == track.id, pendingQueue == nil, !audio.isLoading,
           recovery == nil, !playbackBlocked, audio.failures[track.id] == nil {
            if !ensurePlaying || !audio.isPlaying { togglePlayback() }
            return
        }
        cancelFMRequests()
        referenceStep?.cancel(); referenceOrder = nil
        manuallyQueued = []; referenceResumeTrack = nil
        // The argument is the visible page. A filtered page never becomes the queue source.
        let sourceTracks = track.online == nil ? self.tracks : browseTracks
        guard sourceTracks.contains(where: { $0.id == track.id }) else { return }
        let retry = track.online != nil || audio.failures[track.id] != nil
        cancelRecovery()
        clearedQueue = nil; canUndoClear = false
        following = true
        let original = sourceTracks.map { QueueEntry(track: $0) }
        let entries: [QueueEntry]
        if mode == .shuffle, let selected = original.first(where: { $0.track.id == track.id }) {
            entries = [selected] + original.filter { $0.id != selected.id }.shuffled()
        } else { entries = original }
        guard let selected = entries.first(where: { $0.track.id == track.id }) else { return }
        startRecovery(entries: entries, index: entries.firstIndex(where: { $0.id == selected.id })!, source: original, title: track.online == nil ? "本地音频" : browseTitle, kind: track.online == nil ? nil : online.page?.kind, retry: retry)
    }
    func playQueue(_ entry: QueueEntry) {
        if entry.track.online == nil, entry.id == activeEntry, audio.current != nil, pendingQueue == nil, audio.failures[entry.track.id] == nil {
            if !audio.isPlaying { audio.toggle() }
            return
        }
        manuallyQueued.removeAll { $0 == entry.id }
        referenceResumeTrack = nil
        cancelFMRequests()
        referenceStep?.cancel(); referenceOrder = nil
        let entries = recovery?.entries ?? queue
        let (title, kind) = recovery.map { ($0.title, $0.kind) } ?? (queueTitle, queueSourceKind)
        cancelRecovery()
        let retry = entry.track.online != nil || audio.failures[entry.track.id] != nil
        if !retry, entry.id == activeEntry, audio.current != nil {
            if !audio.isPlaying { audio.toggle() }
            return
        }
        // startRecovery establishes the selected entry's source before following it.
        if let index = entries.firstIndex(where: { $0.id == entry.id }) { startRecovery(entries: entries, index: index, title: title, kind: kind, retry: retry) }
    }
    private func play(_ entry: QueueEntry, entries: [QueueEntry], source: [QueueEntry]? = nil, cursor: Int? = nil, appendNavigation: Bool = true, sourceTitle: String? = nil, sourceKind: OnlinePageKind? = nil, fresh: Bool = false, completion: ((PlaybackAttemptOutcome) -> Void)? = nil) {
        audio.cancelCandidate(); pendingQueue = nil
        prepareVisuals(entry.track)
        let access = accesses[entry.track.folderID]
        guard entry.track.online != nil || access != nil else { let message = "歌曲来源已移除或未授权，请重新添加目录。"; notice = message; audio.recordFailure(entry.track.id, message: message); completion?(.failed(message)); return }
        notice = nil
        pendingQueue = PendingPlayback(trackID: entry.track.id, entries: entries, selected: entry.id, sourceOrder: source, historyCursor: cursor, appendNavigation: appendNavigation, sourceTitle: sourceTitle, sourceKind: sourceKind)
        if let info = entry.track.online {
            audio.play(entry.track, resolveSource: { [onlineAudioSource] in try await onlineAudioSource(info) }, fresh: fresh, completion: completion)
        } else { audio.play(entry.track, access: access, completion: completion) }
    }
    func setPlayback(_ playing: Bool) {
        if !playing { cancelFMRequests(); cancelPreparation(); referenceStep?.cancel(); cancelRecovery(); audio.setPlaying(false); pendingQueue = nil }
        else if !audio.isPlaying && !audio.isLoading { togglePlayback() }
    }
    @Published private var stopAtUnavailableEnd = false
    var playbackBlocked: Bool {
        !audio.isPlaying && (stopAtUnavailableEnd || recovery?.running == false || audio.current.map { audio.failures[$0.id] != nil } == true)
    }
    func togglePlayback() {
        if audio.isPlaying { cancelPreparation() }
        if recovery?.running == true || playbackBlocked { return }
        if audio.isLoading { cancelFMRequests(); cancelRecovery(); audio.cancelCandidate(); pendingQueue = nil; return }
        pendingQueue = nil
        if audio.current == nil { if let entry = queue.first(where: { $0.id == activeEntry }) ?? queue.first { playQueue(entry) } else if let first = tracks.first { playLibrary(first) } }
        else { audio.toggle() }
    }
    func step(_ direction: Int, automatic: Bool = false) {
        if isPersonalFM && direction > 0 && !automatic, let stopped = recovery,
           !stopped.running, stopped.kind == .personalFM, stopped.targetIndex == stopped.entries.count - 1 {
            cancelRecovery()
            fmRefillBlocked = false
            refillFMIfNeeded(advance: true)
            return
        }
        if isPersonalFM && direction > 0 && recovery == nil {
            if automatic && fmRepeatOne, let index = queue.firstIndex(where: { $0.id == activeEntry }) {
                startRecovery(entries: queue, index: index, title: queueTitle, kind: .personalFM, forceFollow: false)
                return
            }
            if !automatic { fmRefillBlocked = false }
            let index = queue.firstIndex { $0.id == activeEntry } ?? -1
            if index + 1 >= queue.count ||
                (online.activePlatform == .qq && !queue.dropFirst(index + 1).contains { !isUnavailable($0.track) }) {
                refillFMIfNeeded(advance: true)
                return
            }
        }
        if direction > 0 && queueEditingAllowed {
            while let id = manuallyQueued.first {
                manuallyQueued.removeFirst()
                guard let index = queue.firstIndex(where: { $0.id == id }), !isUnavailable(queue[index].track) else { continue }
                if referenceResumeTrack == nil, let current = audio.current, referenceOrder?.contains(current.id) == true {
                    referenceResumeTrack = current.id
                }
                referenceStep?.cancel()
                startRecovery(entries: queue, index: index, title: queueTitle, kind: queueSourceKind, forceFollow: !automatic)
                return
            }
        }
        let repeatsCurrent = automatic && mode == .repeatOne
        if !isPersonalFM, let canonical = referenceOrder, let current = targetedTrack ?? audio.current,
           let currentID = (!repeatsCurrent ? referenceResumeTrack : nil) ?? (canonical.contains(current.id) ? current.id : nil) {
            if !repeatsCurrent { referenceResumeTrack = nil }
            let order = mode == .shuffle ? (referencePlayOrder ?? canonical) : canonical
            guard let index = order.firstIndex(of: currentID), !order.isEmpty else { return }
            let destination: Int
            if automatic && mode == .repeatOne { destination = index }
            else { destination = index + direction }
            guard order.indices.contains(destination) else {
                if targetedTrack != nil || stopAtUnavailableEnd { notice = "当前队列暂无可播放的歌曲" }
                return
            }
            referenceStep?.cancel()
            referenceStep = Task { @MainActor [weak self] in
                guard let self else { return }
                do {
                    var slot = destination
                    var candidate: LocalTrack?
                    while order.indices.contains(slot) {
                        let track = try await online.resolveReferencedSong(order[slot])
                        try Task.checkCancellation()
                        if !isUnavailable(track) { candidate = track; break }
                        if automatic && mode == .repeatOne { break }
                        slot += direction
                    }
                    guard let track = candidate else {
                        notice = "当前队列暂无可播放的歌曲"
                        if !audio.isPlaying { stopAtUnavailableEnd = true }
                        return
                    }
                    var entries = sourceOrder
                    if !entries.contains(where: { $0.track.id == track.id }) { entries.append(QueueEntry(track: track)) }
                    let playbackEntries = orderedEntries(entries, by: order)
                    if let target = playbackEntries.firstIndex(where: { $0.track.id == track.id }) {
                        startRecovery(entries: playbackEntries, index: target, source: orderedEntries(entries, by: canonical),
                                      title: queueTitle, kind: queueSourceKind, forceFollow: !automatic)
                    }
                } catch {
                    if !Task.isCancelled {
                        NSLog("Could not resolve queued song: %@", error.localizedDescription)
                        notice = "暂时无法读取待播歌曲"
                    }
                }
            }
            return
        }
        let hadTarget = targetedTrack != nil
        let entries = recovery?.entries ?? pendingQueue?.entries ?? queue
        let selected = recovery.flatMap { $0.entries.indices.contains($0.targetIndex) ? $0.entries[$0.targetIndex].id : nil } ?? pendingQueue?.selected ?? activeEntry
        // A nil kind is an explicit local source, not a missing value to fill
        // from the previously committed online queue.
        let (source, sourceTitle, sourceKind) = recovery.map { ($0.source, $0.title, $0.kind) }
            ?? pendingQueue.map { ($0.sourceOrder, $0.sourceTitle, $0.sourceKind) }
            ?? (nil, queueTitle, queueSourceKind)
        cancelRecovery()
        guard !entries.isEmpty else { return }
        if direction < 0 {
            var cursor = historyCursor - (hadTarget || audio.isLoading ? 0 : 1)
            while cursor >= 0 {
                if let entry = entries.first(where: { $0.id == history[cursor].id }), !isUnavailable(entry.track) {
                    startRecovery(entries: entries, index: entries.firstIndex(where: { $0.id == entry.id })!, source: source, title: sourceTitle, kind: sourceKind, cursor: cursor); return
                }
                cursor -= 1
            }
            return
        }
        if automatic && mode == .repeatOne && !isPersonalFM, let index = entries.firstIndex(where: { $0.id == selected }) {
            startRecovery(entries: [entries[index]], index: 0, source: source, title: sourceTitle, kind: sourceKind, forceFollow: false, preserveQueue: entries)
            return
        }
        let next = (entries.firstIndex(where: { $0.id == selected }) ?? -1) + 1
        guard entries.indices.contains(next) else { if automatic { notice = "已播放到队列末尾" }; return }
        startRecovery(entries: entries, index: next, source: source, title: sourceTitle, kind: sourceKind, forceFollow: !automatic)
    }
    func cancelRecovery() {
        stopAtUnavailableEnd = false
        pendingReferenceOrder = nil
        recoveryRevision &+= 1
        recovery = nil; targetedTrack = nil; audio.notice = nil
    }
    func retryStoppedTrack() {
        if let context = recovery, !context.running, context.entries.indices.contains(context.targetIndex),
           audio.failures[context.entries[context.targetIndex].track.id] != nil {
            startRecovery(entries: context.entries, index: context.targetIndex, source: context.source,
                          title: context.title, kind: context.kind, retry: true)
        } else if let entry = queue.first(where: { $0.id == activeEntry }), audio.failures[entry.track.id] != nil {
            playQueue(entry)
        }
    }

    private func isUnavailable(_ track: LocalTrack) -> Bool {
        audio.failures[track.id] != nil
    }

    private func startRecovery(entries: [QueueEntry], index: Int, source: [QueueEntry]? = nil, title: String? = nil, kind: OnlinePageKind? = nil, cursor: Int? = nil, forceFollow: Bool = true, retry: Bool = false, retryNextFMBatch: Bool = false, preserveQueue: [QueueEntry]? = nil) {
        cancelRecovery()
        audio.cancelCandidate()
        guard let target = entries.indices.dropFirst(index).first(where: {
            retry ? $0 == index : !isUnavailable(entries[$0].track)
        }) else {
            if retryNextFMBatch, let selection = pendingFMSelection {
                startPersonalFM(selection: selection, retryNextBatch: false)
                return
            }
            notice = "当前队列暂无可播放的歌曲"
            if pendingFMSelection != nil { pendingFMSelection = nil; fmStarting = false }
            if !audio.isPlaying, let last = entries.indices.last {
                recovery = PlaybackRecovery(entries: entries, source: source, title: title, kind: kind,
                                            queueIndex: last, targetIndex: last, running: false)
            }
            return
        }
        let entry = entries[target]
        LyricsPerformanceDiagnostics.shared.begin(entry.track, source: "session.candidate")
        nextPreparation?.cancel(); nextPreparation = nil; nextPreparationID = nil
        let revision = recoveryRevision
        recovery = PlaybackRecovery(entries: entries, source: source, title: title, kind: kind,
                                    queueIndex: entries.firstIndex(where: { $0.id == activeEntry }) ?? (target - 1),
                                    targetIndex: target, running: true)
        targetedTrack = entry.track
        if (forceFollow || following) && followPlaybackInBrowser(entry.track, locate: false) { following = true }
        play(entry, entries: preserveQueue ?? entries, source: source, cursor: cursor, appendNavigation: cursor == nil, sourceTitle: title, sourceKind: kind, fresh: retry) { [weak self] outcome in
            guard let self, recoveryRevision == revision else { return }
            switch outcome {
            case .committed, .cancelled:
                recovery = nil; targetedTrack = nil
            case .failed(let message):
                if (!forceFollow && message == OnlineError.qqFullTrackUnavailableMessage) ||
                    (kind == .personalFM && !retry && online.activePlatform == .qq && target + 1 < entries.count) {
                    audio.notice = nil
                    startRecovery(entries: entries, index: target + 1, source: source, title: title,
                                  kind: kind, cursor: cursor, forceFollow: forceFollow, retryNextFMBatch: retryNextFMBatch)
                    return
                }
                if retryNextFMBatch, let selection = pendingFMSelection {
                    startPersonalFM(selection: selection, retryNextBatch: false)
                    return
                }
                notice = message
                if pendingFMSelection != nil { pendingFMSelection = nil; fmStarting = false }
                if audio.isPlaying {
                    recovery = nil; targetedTrack = nil
                } else {
                    recovery?.running = false
                }
            }
        }
    }
    private func cancelQueueCandidate() { cancelPreparation(); cancelRecovery(); audio.cancelCandidate(); pendingQueue = nil }
    func setMode(_ value: PlayMode) {
        guard queueEditingAllowed else { return }
        if value != mode {
            referenceStep?.cancel()
            if value == .shuffle, let order = referenceOrder, let id = audio.current?.id { referencePlayOrder = [id] + order.filter { $0 != id }.shuffled() }
        }
        guard value != mode else { return }
        mode = value
        if value != .repeatOne {
            cancelQueueCandidate()
            let index = queue.firstIndex { $0.id == activeEntry } ?? -1
            let past = Array(queue.prefix(index + 1))
            var future = Array(queue.dropFirst(index + 1))
            if value == .shuffle { future.shuffle() }
            else {
                let order = Dictionary(uniqueKeysWithValues: sourceOrder.enumerated().map { ($0.element.id, $0.offset) })
                future.sort { (order[$0.id] ?? Int.max) < (order[$1.id] ?? Int.max) }
            }
            queue = past + future
            clearedQueue = nil; canUndoClear = false
        }
        persist()
    }
    func removeEntry(_ id: UUID) {
        guard queueEditingAllowed else { return }
        guard id != activeEntry else { return }
        cancelQueueCandidate()
        clearedQueue = nil; canUndoClear = false
        queue.removeAll { $0.id == id }
        manuallyQueued.removeAll { $0 == id }
        persist()
    }
    func moveEntry(_ id: UUID, by offset: Int) {
        guard let index = queue.firstIndex(where: { $0.id == id }), queue.indices.contains(index + offset) else { return }
        let destination = index + offset
        moveEntry(id, before: destination > index ? (queue.indices.contains(destination + 1) ? queue[destination + 1].id : nil) : queue[destination].id)
    }
    func moveEntry(_ id: UUID, before beforeID: UUID?) {
        guard queueEditingAllowed else { return }
        guard id != activeEntry, id != beforeID,
              let current = queue.firstIndex(where: { $0.id == activeEntry }),
              let index = queue.firstIndex(where: { $0.id == id }), index > current else { return }
        if let beforeID, let destination = queue.firstIndex(where: { $0.id == beforeID }), destination <= current { return }
        if let beforeID, !queue.contains(where: { $0.id == beforeID }) { return }
        cancelQueueCandidate(); clearedQueue = nil; canUndoClear = false
        let entry = queue.remove(at: index)
        let destination = beforeID.flatMap { id in queue.firstIndex { $0.id == id } } ?? queue.count
        queue.insert(entry, at: destination); persist()
    }
    func appendTrack(_ track: LocalTrack) {
        guard queueEditingAllowed else { return }
        cancelQueueCandidate()
        let entry = QueueEntry(track: track)
        queue.append(entry); sourceOrder.append(entry); clearedQueue = nil; canUndoClear = false; persist()
    }
    func clearQueue() {
        guard queueEditingAllowed else { return }
        guard let index = queue.firstIndex(where: { $0.id == activeEntry }), index + 1 < queue.count else { return }
        cancelQueueCandidate()
        clearedQueue = queue; canUndoClear = true; queue = Array(queue.prefix(index + 1)); persist()
    }
    func undoClear() {
        guard queueEditingAllowed else { return }
        guard let entries = clearedQueue else { return }
        cancelQueueCandidate()
        let available = Dictionary(uniqueKeysWithValues: tracks.map { ($0.id, $0) })
        let savedIDs = Set(entries.map(\.id))
        queue = entries.compactMap { entry in (entry.track.online != nil ? entry.track : available[entry.track.id]).map { QueueEntry(id: entry.id, track: $0) } } + queue.filter { !savedIDs.contains($0.id) }
        clearedQueue = nil; canUndoClear = false; persist()
    }
    private func persist() {
        refreshPreparation()
        guard persistenceAllowed else { return }
        do { try sessionStore.save(SessionDocument(queue: queue, active: activeEntry, history: history, cursor: historyCursor, mode: mode, sourceOrder: sourceOrder, listeningRecords: persistHistory ? listeningRecords : [], persistHistory: persistHistory, historyLimit: historyLimit, enabledFolders: enabledFolders.map(Array.init), queueTitle: queueTitle, queueSourceKind: queueSourceKind, manuallyQueued: manuallyQueued, referenceResumeTrack: referenceResumeTrack, referenceOrder: referenceOrder, referencePlayOrder: referencePlayOrder, personalFMSelection: fm.selection)) }
        catch { notice = "保存队列失败：\(error.localizedDescription)" }
    }
    private func cancelFMRequests() {
        fmIntent = UUID(); fmStartTask?.cancel(); fmStartTask = nil; fmRefillTask?.cancel(); fmRefillTask = nil
        fm.cancel(); fmStarting = false; pendingFMSelection = nil; fmRefillNotice = nil; fmRefillBlocked = false
    }
    func startPersonalFM(selection: PersonalFMSelection? = nil, retryNextBatch: Bool = true) {
        guard online.authentication == .verified else { notice = "请先登录网易云音乐后使用私人FM"; return }
        if isPersonalFM && selection == nil && audio.current != nil {
            lyricsOpen = true; dismissPanels(); if !audio.isPlaying { togglePlayback() }; return
        }
        let requested = selection ?? fm.selection
        guard requested.valid else { return }
        queueOpen = false
        if isPersonalFM && requested == fm.selection && audio.current != nil { fmModePickerOpen = false; return }
        cancelFMRequests(); cancelRecovery(); audio.cancelCandidate(); pendingQueue = nil
        let token = fmIntent
        fmStarting = true; fmModePickerOpen = false
        fmStartTask = Task { [weak self] in
            guard let self else { return }
            defer { if token == fmIntent && pendingFMSelection == nil { fmStarting = false } }
            do {
                let songs = try await fm.load(requested) { [online] in try await online.requestPersonalFM($0) }
                try Task.checkCancellation(); guard token == fmIntent else { return }
                guard !songs.isEmpty else { notice = "该私人FM模式没有返回歌曲"; return }
                pendingFMSelection = requested
                referenceStep?.cancel()
                let entries = songs.map { QueueEntry(track: $0) }
                startRecovery(entries: entries, index: 0, source: entries, title: "私人FM", kind: .personalFM, forceFollow: false,
                              retryNextFMBatch: online.activePlatform == .qq && retryNextBatch)
            } catch { if !Task.isCancelled && token == fmIntent { notice = "无法开启私人FM：" + error.localizedDescription } }
        }
    }
    private func refillFMIfNeeded(advance: Bool = false) {
        guard isPersonalFM, !fmStarting, !fmRefillBlocked, recovery == nil,
              online.authentication == .verified, let index = queue.firstIndex(where: { $0.id == activeEntry }) else { return }
        let remaining = queue.dropFirst(index + 1)
        let availableCount = online.activePlatform == .qq
            ? remaining.lazy.filter { !self.isUnavailable($0.track) }.prefix(2).count
            : remaining.count
        guard availableCount <= 1 else { return }
        let token = fmIntent
        if let task = fmRefillTask {
            if advance { Task { [weak self] in await task.value; guard let self, token == fmIntent, isPersonalFM else { return }; advanceFMFromEnd() } }
            return
        }
        let selection = fm.selection
        fmRefillTask = Task { [weak self] in
            guard let self else { return }
            defer { if token == fmIntent { fmRefillTask = nil } }
            do {
                let songs = try await fm.load(selection) { [online] in try await online.requestPersonalFM($0) }
                try Task.checkCancellation(); guard token == fmIntent, isPersonalFM else { return }
                let current = queue.firstIndex { $0.id == activeEntry } ?? 0
                var known = Set(queue.dropFirst(current).map { $0.track.id }).union(fmExcluded)
                let additions = songs.filter { known.insert($0.id).inserted }.map { QueueEntry(track: $0) }
                guard !additions.isEmpty else { fmRefillBlocked = true; fmRefillNotice = "暂无新的FM歌曲，可播放下一首以获取更多歌曲"; notice = fmRefillNotice; return }
                queue += additions; sourceOrder += additions
                if var pending = pendingQueue, pending.sourceKind == .personalFM {
                    pending.entries += additions
                    if pending.sourceOrder != nil { pending.sourceOrder! += additions }
                    pendingQueue = pending
                }
                if recovery?.kind == .personalFM {
                    recovery?.entries += additions
                    if recovery?.source != nil { recovery?.source! += additions }
                }
                fmRefillNotice = nil; trimFMHistory(); persist()
                if advance { advanceFMFromEnd() }
            } catch { if !Task.isCancelled && token == fmIntent { fmRefillBlocked = true; fmRefillNotice = "FM补歌失败，可播放下一首以获取更多歌曲：" + error.localizedDescription; notice = fmRefillNotice } }
        }
    }
    private func advanceFMFromEnd() {
        guard isPersonalFM, recovery == nil, let index = queue.firstIndex(where: { $0.id == activeEntry }), queue.indices.contains(index + 1) else { return }
        startRecovery(entries: queue, index: index + 1, title: queueTitle, kind: .personalFM, forceFollow: false)
    }
    private func trimFMHistory() {
        guard let index = queue.firstIndex(where: { $0.id == activeEntry }), index > 500 else { return }
        queue.removeFirst(index - 500); let retained = Set(queue.map(\.id))
        sourceOrder = sourceOrder.filter { retained.contains($0.id) }
    }
    func dislikePersonalFM() {
        guard isPersonalFM, let track = audio.current, let song = track.online?.songID, recovery == nil, !audio.isLoading else { return }
        let owner = online.account?.id, elapsed = Int(audio.elapsed), feedbackID = UUID()
        fmExcluded.insert(track.id)
        history.removeAll { $0.track.id == track.id }; historyCursor = history.count - 1
        // The current entry stays protected until its successor commits; remove it there.
        step(1)
        fmFeedbackTasks[feedbackID] = Task { [weak self] in
            guard let self else { return }
            defer { fmFeedbackTasks.removeValue(forKey: feedbackID) }
            do { try await online.trashPersonalFM(song, playedSeconds: elapsed) }
            catch { if !Task.isCancelled && owner == online.account?.id { notice = "已跳过，但不喜欢反馈未保存：" + error.localizedDescription } }
        }
    }
    func shutdown() { chorus.cancel(); cancelFMRequests(); for task in fmFeedbackTasks.values { task.cancel() }; cancelPreparation(); cancelRecovery(); persist(); cancelPreparation(); cancelScan(); online.shutdown(); audio.shutdown() }
}
