import SwiftUI
import AppKit

struct LyricsInk: Equatable {
    var light = false
    var contentAdaptive = false
    var primary:NSColor { contentAdaptive ? (light ? SonoGeneratedColors.lyricsLightPrimary : SonoGeneratedColors.lyricsDarkPrimary) : SonoGeneratedColors.primaryText }
    var titleTransport:NSColor { light ? SonoGeneratedColors.lyricsLightTitleTransport : SonoGeneratedColors.lyricsDarkTitleTransport }
    var secondary:NSColor { contentAdaptive ? (light ? SonoGeneratedColors.lyricsLightSecondary : SonoGeneratedColors.lyricsDarkSecondary) : SonoGeneratedColors.queueSecondary }


}
private struct LyricsInkKey:EnvironmentKey { static let defaultValue = LyricsInk() }
extension EnvironmentValues {
    var lyricsInk:LyricsInk { get { self[LyricsInkKey.self] } set { self[LyricsInkKey.self] = newValue } }
}

enum LyricsLightPaletteStyle: String, CaseIterable {
    case artwork, texture

    var title: String {
        switch self {
        case .artwork: "封面原色"
        case .texture: "彩色律动"
        }
    }
}

enum LyricsTextureStyle: String, CaseIterable {
    case clear, web

    var title: String {
        switch self {
        case .clear: "浅色"
        case .web: "深色"
        }
    }
}

/// CPU-only color conversion; the Metal pipeline continues sampling small RGB textures.
enum LyricsColor {
    static func blurSigma(wide: Bool, scale: Float) -> Float { (wide ? 120 : 85)*scale/4 }

    static func linear(_ c:Float) -> Float { c <= 0.04045 ? c/12.92 : pow((c+0.055)/1.055,2.4) }
    static func encoded(_ c:Float) -> Float { c <= 0.0031308 ? 12.92*c : 1.055*pow(c,1/2.4)-0.055 }
    static func lab(_ c:SIMD3<Float>) -> SIMD3<Float> {
        let r = linear(c.x), g = linear(c.y), b = linear(c.z)
        let l = cbrt(0.4122214708*r+0.5363325363*g+0.0514459929*b)
        let m = cbrt(0.2119034982*r+0.6806995451*g+0.1073969566*b)
        let s = cbrt(0.0883024619*r+0.2817188376*g+0.6299787005*b)
        return SIMD3(0.2104542553*l+0.793617785*m-0.0040720468*s,1.9779984951*l-2.428592205*m+0.4505937099*s,0.0259040371*l+0.7827717662*m-0.808675766*s)
    }
    static func rgb(_ c:SIMD3<Float>) -> SIMD3<Float> {
        let l = pow(c.x+0.3963377774*c.y+0.2158037573*c.z,3)
        let m = pow(c.x-0.1055613458*c.y-0.0638541728*c.z,3)
        let s = pow(c.x-0.0894841775*c.y-1.291485548*c.z,3)
        return SIMD3(encoded(4.0767416621*l-3.3077115913*m+0.2309699292*s),encoded(-1.2684380046*l+2.6097574011*m-0.3413193965*s),encoded(-0.0041960863*l-0.7034186147*m+1.707614701*s))
    }
    static func luminance(_ c:SIMD3<Float>) -> Float { 0.2126*linear(c.x)+0.7152*linear(c.y)+0.0722*linear(c.z) }
    static let lightFloor: Float = 0.36
    static func lightCeiling(_ brightNeutral: Float) -> Float { 0.72 + 0.11*brightNeutral }

    static func lightness(atLuminance target: Float, hue: SIMD2<Float>) -> Float {
        var lower: Float = 0, upper: Float = 1
        for _ in 0..<14 {
            let lightness = (lower+upper)/2
            if luminance(gamutRGB(SIMD3(lightness, hue.x, hue.y))) < target { lower = lightness }
            else { upper = lightness }
        }
        return (lower+upper)/2
    }

    static func lightBackground(_ source: SIMD3<Float>, brightNeutral: Float) -> SIMD3<Float> {
        var lab = source
        let ceiling = lightCeiling(brightNeutral)
        let rgb = gamutRGB(lab)
        let y = luminance(rgb)
        if y < lightFloor || y > ceiling {
            lab.x = lightness(atLuminance: min(ceiling, max(lightFloor, y)), hue: SIMD2(lab.y, lab.z))
            return gamutRGB(lab)
        }
        return rgb
    }

    static func gamutRGB(_ lab: SIMD3<Float>) -> SIMD3<Float> {
        let result = rgb(lab)
        if min(result.x,result.y,result.z) >= 0 && max(result.x,result.y,result.z) <= 1 { return result }
        var lower: Float = 0, upper: Float = 1
        for _ in 0..<14 {
            let scale = (lower+upper)/2
            let candidate = rgb(SIMD3(lab.x,lab.y*scale,lab.z*scale))
            if min(candidate.x,candidate.y,candidate.z) >= 0 && max(candidate.x,candidate.y,candidate.z) <= 1 { lower = scale }
            else { upper = scale }
        }
        return rgb(SIMD3(lab.x,lab.y*lower,lab.z*lower))
    }
}

struct LyricsConsoleContent<Content:View>:View {
    @Environment(\.lyricsInk) private var ink
    let content:(LyricsInk)->Content
    var body:some View { content(ink) }
}
