import SwiftUI
import MetalKit
import MetalPerformanceShaders

struct LyricsMetalBackground:NSViewRepresentable {
    let analysis:LyricsArtworkAnalysis?; let artworkRect:CGRect; let feather:SIMD4<Float>; let reduced:Bool; let contrast:Bool
    let backgroundDynamic: Bool
    let musicMotion:LyricsMusicMotionSettings; let audio:PlaybackController
    let paletteStyle: LyricsLightPaletteStyle
    let textureStyle: LyricsTextureStyle
    let darkWebBackground: Bool
    let backgroundCanStart: Bool
    let appearanceRendered: (Float) -> Void

    func makeCoordinator() -> Renderer { Renderer() }
    func makeNSView(context:Context) -> MTKView {
        let view = LyricsBackgroundSurface(frame:.zero,device:MTLCreateSystemDefaultDevice())
        view.framebufferOnly = false // Cache each background before its drawable is presented.
        view.colorPixelFormat = .bgra8Unorm; view.colorspace = CGColorSpace(name:CGColorSpace.sRGB)
        (view.layer as? CAMetalLayer)?.wantsExtendedDynamicRangeContent = false
        view.clearColor = MTLClearColor(red:0.08,green:0.09,blue:0.12,alpha:1); view.preferredFramesPerSecond = 60
        context.coordinator.prepare(view); view.delegate = context.coordinator
        view.visibilityChanged = { [weak renderer = context.coordinator, weak view] in if let view { renderer?.updateActivity(view) } }
        return view
    }
    func updateNSView(_ view:MTKView,context:Context) {
        let renderer = context.coordinator
        renderer.audio = audio; renderer.reduced = reduced; renderer.contrast = contrast; renderer.musicMotion = musicMotion
        renderer.backgroundDynamic = backgroundDynamic
        renderer.artworkRect = artworkRect; renderer.feather = feather
        renderer.backgroundCanStart = backgroundCanStart
        renderer.appearanceRendered = appearanceRendered
        renderer.update(analysis, paletteStyle: paletteStyle, lightTextureStyle: textureStyle, darkWebBackground: darkWebBackground)
        renderer.updateActivity(view); view.setNeedsDisplay(view.bounds)
    }
    static func dismantleNSView(_ view:MTKView,coordinator:Renderer) {
        view.isPaused = true; view.delegate = nil; coordinator.stop()
        (view as? LyricsBackgroundSurface)?.stop()
    }
    @MainActor final class Renderer:NSObject,MTKViewDelegate {
        var backgroundCanStart = false
        private var waitingForEntrance = false
        struct Vertex { var uv:SIMD2<Float>; var from:SIMD2<Float>; var to:SIMD2<Float> }
        struct Uniforms { var control:SIMD4<Float>; var spectrum:SIMD4<Float>; var geometry:SIMD4<Float>; var edge:SIMD4<Float> = .zero; var tint:SIMD4<Float> = .zero; var artwork:SIMD4<Float> = .zero; var appearance:SIMD4<Float> = .zero; var flow:SIMD4<Float> = .zero; var scene:SIMD4<Float> = .zero; var feather:SIMD4<Float> = .zero }
        // Immutable GPU programs are shared; mutable frame textures stay renderer-owned.
        private struct SharedResources {
            let blend:MTLRenderPipelineState, rotation:MTLRenderPipelineState, output:MTLRenderPipelineState
            let field:MTLRenderPipelineState, fieldOutput:MTLRenderPipelineState
            let lut:MTLTexture?
            let texturePipelines: LyricsTextureBackdrop.Pipelines
            init(device:MTLDevice) throws {
                let library = try device.makeLibrary(source:LyricsBackdropShaders.source,options:nil)
                func pipeline(_ vertex:String,_ fragment:String,_ format:MTLPixelFormat) throws -> MTLRenderPipelineState {
                    let descriptor = MTLRenderPipelineDescriptor()
                    descriptor.vertexFunction = library.makeFunction(name:vertex); descriptor.fragmentFunction = library.makeFunction(name:fragment)
                    descriptor.colorAttachments[0].pixelFormat = format
                    return try device.makeRenderPipelineState(descriptor:descriptor)
                }
                blend = try pipeline("fullscreen","blendArtwork",.rgba16Float)
                rotation = try pipeline("rotateArtwork","colorArtwork",.rgba16Float)
                output = try pipeline("warpArtwork","displayArtwork",.bgra8Unorm)
                field = try pipeline("fullscreen","flowArtwork",.rgba16Float)
                fieldOutput = try pipeline("fullscreen","displayArtwork",.bgra8Unorm)
                lut = LyricsBackdropLUT.texture(device:device)
                texturePipelines = try .init(
                    layers: pipeline("fullscreen","layerTextureArtwork",.rgba8Unorm),
                    twist: pipeline("fullscreen","twistTextureArtwork",.rgba8Unorm),
                    blur: pipeline("fullscreen","blurTextureArtwork",.rgba8Unorm),
                    display: pipeline("fullscreen","displayTextureArtwork",.bgra8Unorm))
            }
        }
        private static var resources:[UInt64:SharedResources] = [:]
        private var mixedTransition:Float?
        weak var audio:PlaybackController?
        var reduced = false, contrast = false
        var backgroundDynamic = true
        var musicMotion = LyricsMusicMotionSettings(enabled:false)
        var appearanceRendered: ((Float) -> Void)?
        private var textureStyle: LyricsTextureStyle = .clear
        private var submittedLight: Float?
        private var texturePipelines: LyricsTextureBackdrop.Pipelines?
        private var textureBackdrop: LyricsTextureBackdrop?
        private var textureImage: CGImage?
        private var pendingTextureArtwork: LyricsTextureBackdrop.Artwork?
        private var textureArtwork: LyricsTextureBackdrop.Artwork?
        private var appearanceFrameTime: CFTimeInterval = 0
        private var positionRevision:UInt64?
        private var diagnosticArtwork: LyricsPerformanceDiagnostics.Switch?
        private var image:CGImage?, trackID:String?
        var artworkRect = CGRect.zero
        var feather = SIMD4<Float>.zero
        private var profile = LyricsArtworkProfile(), fromProfile = LyricsArtworkProfile(), targetProfile = LyricsArtworkProfile()
        private var pendingProfile:LyricsArtworkProfile?
        private var flow = SIMD4<Float>.zero
        private var previousFrame: MTLTexture?, sceneSnapshot: MTLTexture?
        private var pendingFlow: SIMD4<Float>?

        private var queue:MTLCommandQueue?, blend:MTLRenderPipelineState?, rotation:MTLRenderPipelineState?, output:MTLRenderPipelineState?, field:MTLRenderPipelineState?, fieldOutput:MTLRenderPipelineState?
        private var source:MTLTexture?, destination:MTLTexture?, pending:MTLTexture?, mixed:MTLTexture?, lut:MTLTexture?
        private var rotated:MTLTexture?, blurred:MTLTexture?, lightField:MTLTexture?, mesh:MTLBuffer?, indices:MTLBuffer?, indexCount = 0
        private var wide:Bool?, size = CGSize.zero, phase:Float = 0, transition:Float = 1
        private var lastFrameTime:CFTimeInterval?
        private var response = LyricsSpectrumResponse(), lastSamples = 0, inFlight = 0
        private var spectrum = SIMD4<Float>.zero
        private var redrawAfterCompletion = false
        private var gaussian:MPSImageGaussianBlur?, sigma:Float = -1
        private weak var view:MTKView?
        private let drawableQueue = DispatchQueue(label:"app.sono.lyrics.drawable",qos:.userInteractive)
        private var acquiring = false, visible = false
        private var generation:UInt64 = 0
        private struct DrawableSource:@unchecked Sendable { let layer:CAMetalLayer }
        private struct DrawableResult:@unchecked Sendable { let drawable:CAMetalDrawable? }
        func stop() {
            generation &+= 1; audio?.setAnalysisEnabled(false); view = nil
            previousFrame = nil; sceneSnapshot = nil
        }
        func updateActivity(_ view:MTKView) {
            let visible = view.window != nil && !view.isHiddenOrHasHiddenAncestor && view.window?.isMiniaturized != true && view.window?.occlusionState.contains(.visible) == true
            let visibilityChanged = self.visible != visible
            if visibilityChanged { generation &+= 1; self.visible = visible; lastFrameTime = nil; submittedLight = nil; response.reset(); lastSamples = 0 }
            view.isPaused = !visible || contrast || !backgroundDynamic
            view.enableSetNeedsDisplay = view.isPaused
            if visibilityChanged && visible && view.isPaused { view.setNeedsDisplay(view.bounds) }
            if positionRevision != audio?.positionRevision {
                positionRevision = audio?.positionRevision; response.reset(); lastSamples = 0
                audio?.setAnalysisEnabled(false)
            }
            let analyze = shouldAnalyzeMusic
            audio?.setAnalysisEnabled(analyze)
            if !analyze { response.reset(); lastSamples = 0 }
            if trackID != audio?.current?.id { trackID = audio?.current?.id; response.reset(); lastSamples = 0 }
        }
        func prepare(_ view:MTKView) {
            self.view = view
            guard let device = view.device else { return }
            do {
                let resources: SharedResources
                if let cached = Self.resources[device.registryID] { resources = cached }
                else {
                    resources = try SharedResources(device:device)
                    Self.resources[device.registryID] = resources
                }
                blend = resources.blend; rotation = resources.rotation; output = resources.output
                field = resources.field; fieldOutput = resources.fieldOutput; lut = resources.lut
                texturePipelines = resources.texturePipelines
                queue = device.makeCommandQueue()
                mixed = texture(device,128,128); source = neutral(device); destination = source
            } catch { NSLog("Lyrics background pipeline: %@",error.localizedDescription) }
        }
        private func texture(_ device:MTLDevice,_ width:Int,_ height:Int,_ format:MTLPixelFormat = .rgba16Float) -> MTLTexture? {
            let descriptor = MTLTextureDescriptor.texture2DDescriptor(pixelFormat:format,width:width,height:height,mipmapped:false)
            descriptor.usage = [.renderTarget,.shaderRead,.shaderWrite]; descriptor.storageMode = .private
            return device.makeTexture(descriptor:descriptor)
        }
        private func neutral(_ device:MTLDevice) -> MTLTexture? {
            let descriptor = MTLTextureDescriptor.texture2DDescriptor(pixelFormat:.rgba8Unorm,width:1,height:1,mipmapped:false)
            descriptor.usage = .shaderRead
            let texture = device.makeTexture(descriptor:descriptor); var pixel:[UInt8] = [43,48,63,255]
            pixel.withUnsafeMutableBytes { texture?.replace(region:MTLRegionMake2D(0,0,1,1),mipmapLevel:0,withBytes:$0.baseAddress!,bytesPerRow:4) }
            return texture
        }
        private var shouldAnalyzeMusic: Bool {
            visible && backgroundDynamic && musicMotion.active && !reduced && !contrast && audio?.isPlaying == true
        }
        func update(_ analysis: LyricsArtworkAnalysis?, paletteStyle: LyricsLightPaletteStyle, lightTextureStyle: LyricsTextureStyle, darkWebBackground: Bool) {
            diagnosticArtwork = LyricsPerformanceDiagnostics.shared.token(for:analysis)
            let thumbnail = analysis?.background
            let darkCover = analysis?.profile.light == 0
            textureStyle = darkCover ? .web : lightTextureStyle
            let usesTexture = darkCover ? darkWebBackground : paletteStyle == .texture
            let original = usesTexture && !contrast ? analysis?.textureArtwork?.image : nil
            guard image !== thumbnail || textureImage !== original, let device = view?.device else { return }
            let measurement = BrowseDiagnostics.shared.start()
            defer { BrowseDiagnostics.shared.end("lyrics.backgroundTexturePrepareCPU", measurement) }
            do {
                let loader = MTKTextureLoader(device:device)
                let options: [MTKTextureLoader.Option: Any] = [.SRGB:false,.generateMipmaps:false]
                let next = try thumbnail.map { try loader.newTexture(cgImage:$0,options:options) } ?? neutral(device)
                let texture: LyricsTextureBackdrop.Artwork?
                if let original {
                    texture = .init(texture:try loader.newTexture(cgImage:original,options:options))
                } else { texture = nil }
                if texture != nil, textureBackdrop == nil, let texturePipelines {
                    textureBackdrop = LyricsTextureBackdrop(pipelines:texturePipelines)
                }
                pending = next
                pendingTextureArtwork = textureBackdrop == nil ? nil : texture
                textureImage = original
                image = thumbnail
                pendingProfile = analysis?.profile ?? LyricsArtworkProfile()
                pendingFlow = analysis?.flow ?? .zero
            } catch { NSLog("Lyrics artwork texture: %@",error.localizedDescription) }
        }
        private func resize(_ view:MTKView) {
            guard let device = view.device else { return }
            let width = Int(view.drawableSize.width)/4, height = Int(view.drawableSize.height)/4
            guard width > 0, height > 0 else { return }
            if size != view.drawableSize {
                size = view.drawableSize; rotated = texture(device,width,height); blurred = texture(device,width,height); lightField = texture(device,width,height)
            }
            let nextWide = view.drawableSize.width > view.drawableSize.height
            if wide != nextWide {
                wide = nextWide
                let table = LyricsBackdropControlPoints.tables[nextWide ? 0 : 1], pair = table.pairs.randomElement()!
                let from = LyricsBackdropMesh.subdivide(pair[0],segments:table.segments), to = LyricsBackdropMesh.subdivide(pair[1],segments:table.segments)
                let segments = table.segments*4, edge = segments+1
                var vertices:[Vertex] = [], triangles:[UInt16] = []
                for y in 0...segments { for x in 0...segments {
                    let i = y*edge+x
                    vertices.append(Vertex(uv:SIMD2(Float(x),Float(y))/Float(segments),from:from[i],to:to[i]))
                } }
                for y in 0..<segments { for x in 0..<segments {
                    let i = UInt16(y*edge+x), e = UInt16(edge)
                    triangles += [i,i+1,i+e,i+1,i+e+1,i+e]
                } }
                mesh = device.makeBuffer(bytes:vertices,length:vertices.count*MemoryLayout<Vertex>.stride)
                indices = device.makeBuffer(bytes:triangles,length:triangles.count*2); indexCount = triangles.count
            }
            // Sono's visual intensity mode is fixed at 1 and is independent of
            // the music-response preference. Current 1.7.2 environment row.
            let nextSigma = LyricsColor.blurSigma(wide:nextWide,scale:Float(view.window?.backingScaleFactor ?? 1))
            if sigma != nextSigma { sigma = nextSigma; gaussian = MPSImageGaussianBlur(device:device,sigma:sigma); gaussian?.edgeMode = .clamp }
        }
        func mtkView(_ view:MTKView,drawableSizeWillChange size:CGSize) {
            resize(view)
            if view.isPaused { view.setNeedsDisplay(view.bounds) }
        }
        func draw(in view:MTKView) {
            guard visible, !acquiring, let layer = view.layer as? CAMetalLayer else { return }
            if inFlight >= 3 {
                redrawAfterCompletion = view.isPaused
                return
            }
            acquiring = true
            let token = generation, source = DrawableSource(layer:layer)
            let measurement = BrowseDiagnostics.shared.start()
            // nextDrawable may wait for WindowServer to return a surface. This
            // serialized wait must never hold AppKit or the lyrics display link.
            drawableQueue.async { [weak self] in
                let result = DrawableResult(drawable:source.layer.nextDrawable())
                BrowseDiagnostics.shared.end("lyrics.drawableAcquire",measurement)
                Task { @MainActor [weak self] in
                    guard let self else { return }; self.acquiring = false
                    guard let view = self.view, self.visible, let drawable = result.drawable else { return }
                    guard token == self.generation, drawable.texture.width == Int(view.drawableSize.width),
                          drawable.texture.height == Int(view.drawableSize.height) else {
                        if view.isPaused { view.setNeedsDisplay(view.bounds) }
                        return
                    }
                    self.encode(in:view,drawable:drawable)
                }
            }
        }
        private func encode(in view:MTKView,drawable:CAMetalDrawable) {
            updateActivity(view)
            let measurement = BrowseDiagnostics.shared.start()
            defer { BrowseDiagnostics.shared.end("lyrics.backgroundCPU",measurement) }
            guard view.window != nil, !view.isHiddenOrHasHiddenAncestor, view.window?.isMiniaturized != true,
                  view.window?.occlusionState.contains(.visible) == true, inFlight < 3 else { return }
            resize(view)
            guard let device = view.device, let queue, let blend, let rotation, let output, let field, let fieldOutput, let lightField, let mixed, let rotated, let blurred, let lut,
                  let mesh, let indices, let command = queue.makeCommandBuffer() else { return }
            let pass = MTLRenderPassDescriptor()
            pass.colorAttachments[0].texture = drawable.texture; pass.colorAttachments[0].loadAction = .clear; pass.colorAttachments[0].storeAction = .store
            pass.colorAttachments[0].clearColor = view.clearColor
            let encodingMeasurement = BrowseDiagnostics.shared.start()
            if let pending {
                if !backgroundDynamic { spectrum = .zero }
                waitingForEntrance = image != nil && !backgroundCanStart
                let changesCoverOwner = (textureArtwork == nil) != (pendingTextureArtwork == nil)
                textureArtwork = pendingTextureArtwork; pendingTextureArtwork = nil
                if textureArtwork == nil { textureBackdrop = nil }
                // Freeze the last complete background, including any interrupted fade.
                // Keep the destination's random parameters fixed instead of sweeping
                // rotation/phase through unrelated seeds during the color transition.
                if !changesCoverOwner, textureArtwork == nil, let previousFrame,
                   let snapshot = texture(device,previousFrame.width,previousFrame.height,.bgra8Unorm),
                   let blit = command.makeBlitCommandEncoder() {
                    blit.copy(from:previousFrame,to:snapshot); blit.endEncoding()
                    sceneSnapshot = snapshot
                } else { sceneSnapshot = nil }
                // Retain the existing color-profile retargeting under the scene fade.
                if transition < 1, let snapshot = texture(device,128,128), let blit = command.makeBlitCommandEncoder() {
                    blit.copy(from:mixed,to:snapshot); blit.endEncoding(); source = snapshot
                } else { source = destination }
                destination = pending; self.pending = nil; mixedTransition = nil; fromProfile = profile; targetProfile = pendingProfile ?? profile; pendingProfile = nil; transition = changesCoverOwner ? 1 : 0
                flow = pendingFlow ?? flow; pendingFlow = nil
            }
            guard let source, let destination else { return }
            let now = CACurrentMediaTime()
            let elapsed = Float(min(0.1,lastFrameTime.map { now-$0 } ?? 1/60))
            lastFrameTime = backgroundDynamic ? now : nil
            let dt:Float = contrast ? 0 : reduced ? elapsed/10 : elapsed
            transition = !backgroundDynamic || reduced || contrast ? 1 : min(1,transition+(waitingForEntrance && !backgroundCanStart ? 0 : elapsed/0.6))
            if shouldAnalyzeMusic {
                if let audio {
                    let count = audio.analyzedSampleCount
                    if count != lastSamples { response.append(audio.audioSpectrum); lastSamples = count }
                }
                spectrum = response.advance(deltaTime:elapsed,settings:musicMotion)
            } else if backgroundDynamic || reduced || contrast { spectrum = .zero }
            // Ambient time keeps advancing while paused; only the spectrum is gated.
            if backgroundDynamic { phase += dt*(1+0.6*spectrum.w) }
            if transition >= 1 { sceneSnapshot = nil }
            // Retarget the small color profile with the same artwork transition.
            profile.light = fromProfile.light+(targetProfile.light-fromProfile.light)*transition
            profile.base = fromProfile.base+(targetProfile.base-fromProfile.base)*transition
            profile.edge = fromProfile.edge+(targetProfile.edge-fromProfile.edge)*transition
            profile.tint = fromProfile.tint+(targetProfile.tint-fromProfile.tint)*transition
            profile.bright = fromProfile.bright+(targetProfile.bright-fromProfile.bright)*transition
            profile.saturation = fromProfile.saturation+(targetProfile.saturation-fromProfile.saturation)*transition
            profile.tintAmount = fromProfile.tintAmount+(targetProfile.tintAmount-fromProfile.tintAmount)*transition
            var uniforms = Uniforms(control:SIMD4(phase,transition,(sin(phase/3.5)+1)/2,profile.saturation),spectrum:spectrum,geometry:SIMD4(Float(view.drawableSize.width/max(1,view.drawableSize.height)),1,0.1,0.35),
                edge:SIMD4((profile.edge+(profile.tint-profile.edge)*profile.tintAmount)*0.82,profile.bright*0.42),tint:SIMD4(profile.tint*0.48,profile.tintAmount*0.55),
                artwork:SIMD4(Float(artworkRect.width/max(1,view.bounds.width)),Float(artworkRect.height/max(1,view.bounds.height)),Float(artworkRect.minY/max(1,view.bounds.height)),Float(artworkRect.minX/max(1,view.bounds.width))),appearance:SIMD4(profile.base,profile.light),flow:flow,scene:SIMD4(transition,sceneSnapshot == nil ? 0 : 1,0,0),feather:feather)
            func offscreen(_ texture:MTLTexture) -> MTLRenderPassDescriptor {
                let pass = MTLRenderPassDescriptor(); pass.colorAttachments[0].texture = texture
                pass.colorAttachments[0].loadAction = .clear; pass.colorAttachments[0].storeAction = .store
                pass.colorAttachments[0].clearColor = MTLClearColor(red:0.08,green:0.09,blue:0.12,alpha:1); return pass
            }
            if let textureArtwork, let textureBackdrop {
                guard textureBackdrop.encode(command,artwork:textureArtwork,style:textureStyle,
                    size:SIMD2(max(1,Int(view.bounds.width)),max(1,Int(view.bounds.height))),
                    elapsed:elapsed,reduced:reduced,dynamic:backgroundDynamic, canFade:backgroundCanStart,uniforms:&uniforms,output:pass) else { return }
            } else {
                if mixedTransition != transition {
                    guard let first = command.makeRenderCommandEncoder(descriptor:offscreen(mixed)) else { return }
                    first.setRenderPipelineState(blend); first.setFragmentTexture(source,index:0); first.setFragmentTexture(destination,index:1)
                    first.setFragmentBytes(&uniforms,length:MemoryLayout<Uniforms>.stride,index:0)
                    first.drawPrimitives(type:.triangle,vertexStart:0,vertexCount:3); first.endEncoding()
                    mixedTransition = transition
                }
                if profile.light < 1 {
                    let rotationPass = offscreen(rotated)
                    let base = SIMD3<Float>(0.08,0.09,0.12)
                    let clear = base+(profile.base-base)*profile.light
                    rotationPass.colorAttachments[0].clearColor = MTLClearColor(red:Double(clear.x),green:Double(clear.y),blue:Double(clear.z),alpha:1)
                    guard let second = command.makeRenderCommandEncoder(descriptor:rotationPass) else { return }
                    second.setRenderPipelineState(rotation); second.setFragmentTexture(mixed,index:0)
                    second.setVertexBytes(&uniforms,length:MemoryLayout<Uniforms>.stride,index:0); second.setFragmentBytes(&uniforms,length:MemoryLayout<Uniforms>.stride,index:0)
                    second.drawPrimitives(type:.triangle,vertexStart:0,vertexCount:6,instanceCount:3); second.endEncoding()
                    let blurMeasurement = BrowseDiagnostics.shared.start()
                    gaussian?.encode(commandBuffer:command,sourceTexture:rotated,destinationTexture:blurred)
                    BrowseDiagnostics.shared.end("lyrics.blurEncode",blurMeasurement)
                }
                if profile.light > 0 {
                    guard let colorField = command.makeRenderCommandEncoder(descriptor:offscreen(lightField)) else { return }
                    colorField.setRenderPipelineState(field)
                    colorField.setFragmentTexture(mixed,index:0)
                    colorField.setFragmentBytes(&uniforms,length:MemoryLayout<Uniforms>.stride,index:0)
                    colorField.drawPrimitives(type:.triangle,vertexStart:0,vertexCount:3)
                    colorField.endEncoding()
                }
                guard let final = command.makeRenderCommandEncoder(descriptor:pass) else { return }
                final.setRenderPipelineState(profile.light >= 1 ? fieldOutput : output); final.setVertexBuffer(mesh,offset:0,index:0)
                final.setVertexBytes(&uniforms,length:MemoryLayout<Uniforms>.stride,index:1); final.setFragmentBytes(&uniforms,length:MemoryLayout<Uniforms>.stride,index:0)
                final.setFragmentTexture(blurred,index:0); final.setFragmentTexture(lut,index:1); final.setFragmentTexture(lightField,index:2); final.setFragmentTexture(sceneSnapshot ?? blurred,index:3)
                if profile.light >= 1 { final.drawPrimitives(type:.triangle,vertexStart:0,vertexCount:3) }
                else { final.drawIndexedPrimitives(type:.triangle,indexCount:indexCount,indexType:.uint16,indexBuffer:indices,indexBufferOffset:0) }
                final.endEncoding()
            }
            // Drawable surfaces are pooled. Preserve pixels in an app-owned
            // cache before presentation, never by retaining a presented surface.
            let frame = drawable.texture
            if previousFrame?.width != frame.width || previousFrame?.height != frame.height {
                previousFrame = texture(device,frame.width,frame.height,.bgra8Unorm)
            }
            guard let previousFrame, let cache = command.makeBlitCommandEncoder() else { return }
            cache.copy(from:frame,to:previousFrame); cache.endEncoding()
            inFlight += 1
            BrowseDiagnostics.shared.peak("lyrics.backgroundFramesInFlightPeak", inFlight)
            BrowseDiagnostics.shared.set("lyrics.backgroundFramesInFlightLast", String(inFlight))
            let diagnosticArtwork = self.diagnosticArtwork
            let diagnosticTransitionComplete = transition >= 1
            let submitted = BrowseDiagnostics.shared.start()
            if let diagnosticArtwork {
                drawable.addPresentedHandler { drawable in
                    // CAMetalDrawable reports actual presentation time; completion alone does not.
                    guard drawable.presentedTime > 0 else { return }
                    LyricsPerformanceDiagnostics.shared.milestone("backgroundDrawablePresented", token:diagnosticArtwork, fields:["boundary":"CAMetalDrawable.presentedTime; background drawable only"], at:drawable.presentedTime)
                    if diagnosticTransitionComplete {
                        LyricsPerformanceDiagnostics.shared.milestone("backgroundTransitionPresented",token:diagnosticArtwork,fields:["boundary":"first presented background frame with transition=1"],at:drawable.presentedTime)
                    }
                    if let submitted { BrowseDiagnostics.shared.record("lyrics.backgroundPreCommitToPresentation", max(0, drawable.presentedTime-submitted)*1000) }
                }
            }
            let light: Float = textureArtwork != nil && textureStyle == .web ? 0 : profile.light
            let changedAppearance = submittedLight != light
            submittedLight = light
            let token = generation
            command.addCompletedHandler { [weak self] buffer in
                if let error = buffer.error { NSLog("Lyrics background GPU: %@",error.localizedDescription) }
                if buffer.gpuEndTime > buffer.gpuStartTime { BrowseDiagnostics.shared.record("lyrics.backgroundGPU",(buffer.gpuEndTime-buffer.gpuStartTime)*1000) }
                let completed = buffer.status == .completed
                if completed {
                    BrowseDiagnostics.shared.end("lyrics.backgroundPreCommitToCompleted", submitted)
                    LyricsPerformanceDiagnostics.shared.milestone("backgroundGPUCompleted", token:diagnosticArtwork, fields:["boundary":"MTLCommandBuffer completed; not presentation"])
                }
                Task { @MainActor [weak self] in
                    guard let self else { return }
                    self.inFlight -= 1
                    if self.redrawAfterCompletion {
                        self.redrawAfterCompletion = false
                        if let view = self.view { view.setNeedsDisplay(view.bounds) }
                    }
                    BrowseDiagnostics.shared.set("lyrics.backgroundFramesInFlightLast", String(self.inFlight))
                    guard self.generation == token else { return }
                    if !completed {
                        self.submittedLight = nil
                    } else if changedAppearance && now > self.appearanceFrameTime {
                        self.appearanceFrameTime = now
                        self.appearanceRendered?(light)
                    }
                }
            }
            BrowseDiagnostics.shared.end("lyrics.backgroundEncode",encodingMeasurement)
            let commitMeasurement = BrowseDiagnostics.shared.start()
            command.present(drawable); command.commit()
            if textureArtwork != nil { textureBackdrop?.didSubmit() }
            LyricsPerformanceDiagnostics.shared.milestone("backgroundCommandSubmitted", token:diagnosticArtwork, fields:["boundary":"command buffer committed with current prepared cover input; fade may still be starting"])
            BrowseDiagnostics.shared.end("lyrics.backgroundCommit",commitMeasurement)
            if contrast && transition < 1 { view.setNeedsDisplay(view.bounds) }
        }
    }
}

/// Visibility owns drawing. Keyboard focus is independent of occlusion.
@MainActor final class LyricsBackgroundSurface:MTKView {
    var visibilityChanged:(() -> Void)?
    private var observations:[NSObjectProtocol] = []
    override func viewDidMoveToWindow() {
        super.viewDidMoveToWindow(); stop()
        if let window {
            for name in [NSWindow.didChangeOcclusionStateNotification,NSWindow.didMiniaturizeNotification,NSWindow.didDeminiaturizeNotification] {
                observations.append(NotificationCenter.default.addObserver(forName:name,object:window,queue:.main) { [weak self] _ in MainActor.assumeIsolated { self?.visibilityChanged?() } })
            }
        }
        visibilityChanged?()
    }
    override func viewDidHide() { super.viewDidHide(); visibilityChanged?() }
    override func viewDidUnhide() { super.viewDidUnhide(); visibilityChanged?() }
    func stop() { for token in observations { NotificationCenter.default.removeObserver(token) }; observations = [] }
}
