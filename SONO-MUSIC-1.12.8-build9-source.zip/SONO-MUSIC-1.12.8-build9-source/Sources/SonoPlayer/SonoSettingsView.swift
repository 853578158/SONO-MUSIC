import AppKit
import SwiftUI

private enum SettingsSection: String, CaseIterable, Identifiable {
    case wall = "照片墙"
    case appearance = "外观", desktop = "桌面窗口", lyrics = "歌词", history = "播放历史"
    case about = "关于"
    var id: Self { self }
    var icon: String {
        switch self {
        case .wall: "photo.on.rectangle"
        case .appearance: "circle.lefthalf.filled"
        case .desktop: "macwindow"
        case .lyrics: "text.alignleft"
        case .history: "clock.arrow.circlepath"
        case .about: "info.circle"
        }
    }
    var keywords: String {
        switch self {
        case .wall: "照片墙 开灯 封面 歌曲信息 歌名 歌手"
        case .appearance: "外观 浅色 深色 跟随系统 主题色 粉 蓝 黑白 Liquid Glass 玻璃透明度 清透 标准 浓厚"
        case .desktop: "桌面 窗口 尺寸 大小"
        case .lyrics: "歌词 自动 逐字 来源 QQ 网易"
        case .history: "播放历史 记录 保存 条数 上限 存储 路径"
        case .about: "关于 软件版本 构建号 SONO MUSIC Version"
        }
    }
}

struct SonoSettingsView: View {
    @AppStorage("wallLightLightsOn", store: PerformanceEnvironment.defaults) private var wallLightLightsOn = true
    @AppStorage("wallLightAlwaysShowInfo", store: PerformanceEnvironment.defaults) private var wallLightAlwaysShowInfo = false
    @AppStorage("wallDarkLightsOn", store: PerformanceEnvironment.defaults) private var wallDarkLightsOn = false
    @AppStorage("wallDarkAlwaysShowInfo", store: PerformanceEnvironment.defaults) private var wallDarkAlwaysShowInfo = true
    @ObservedObject var session: PlayerSession
    @Binding var appearance: SonoAppearance
    @Binding var glassDensity: SonoGlassDensity
    @Binding var theme: SonoTheme
    @State private var selected = SettingsSection.appearance
    @State private var query = ""

    private var matches: [SettingsSection] {
        let term = query.trimmingCharacters(in: .whitespacesAndNewlines)
        return SettingsSection.allCases.filter { term.isEmpty || $0.keywords.localizedCaseInsensitiveContains(term) }
    }

    var body: some View {
        HStack(spacing: SonoDesktopTokens.Spacing.s0) {
            sidebar.frame(width: 190)
            Divider()
            VStack(spacing: SonoDesktopTokens.Spacing.s0) {
                HStack {
                    Text(matches.isEmpty ? "搜索设置" : selected.rawValue)
                        .font(SonoTypography.font(size: SonoDesktopTokens.FontSize.pageTitle, weight: SonoDesktopTokens.FontWeight.semibold))
                    Spacer()
                    Button { session.settingsOpen = false } label: {
                        Image(systemName: "xmark").font(.system(size: SonoDesktopTokens.SymbolSize.control)).sonoIconFrame(SonoDesktopTokens.IconFrame.s24).frame(width: 32, height: 32)
                    }.buttonStyle(SonoPanelCloseStyle()).accessibilityLabel("关闭设置")
                }.padding(SonoDesktopTokens.Spacing.s24)
                Divider()
                ScrollView {
                    VStack(alignment: .leading, spacing: SonoDesktopTokens.Spacing.s24) {
                        if matches.isEmpty {
                            Text("没有找到相关设置").font(SonoTypography.font(size: SonoDesktopTokens.FontSize.itemTitle, weight: SonoDesktopTokens.FontWeight.medium))
                            description("尝试搜索外观、窗口、歌词或历史。")
                        } else {
                            sectionContent
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.leading, SonoDesktopTokens.Spacing.s28).padding(.vertical, SonoDesktopTokens.Spacing.s24)
                    .padding(.trailing, max(SonoDesktopTokens.Spacing.s28, PanelScrollConfiguration.contentClearance))
                    .background(PanelScrollConfiguration())
                }.padding(.trailing, SonoDesktopTokens.Spacing.s2)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(nsColor: SonoGeneratedColors.settingsSurface))
        }
        .font(SonoTypography.font(size: SonoDesktopTokens.FontSize.body))
        .foregroundStyle(Color(nsColor: SonoGeneratedColors.navigationText))
        .background(Color(nsColor: SonoGeneratedColors.settingsSurface))
        .clipShape(RoundedRectangle(cornerRadius: SonoDesktopTokens.Radius.window))
        .overlay(RoundedRectangle(cornerRadius: SonoDesktopTokens.Radius.window).strokeBorder(Color(nsColor: SonoGeneratedColors.interfaceBorder), lineWidth: SonoDesktopTokens.Border.standard))
        .onChange(of: query) { _, _ in
            if !matches.contains(selected), let first = matches.first { selected = first }
        }
    }

    private var sidebar: some View {
        VStack(alignment: .leading, spacing: SonoDesktopTokens.Spacing.s20) {
            HStack(spacing: SonoDesktopTokens.Spacing.s8) {
                Image(systemName: "magnifyingglass").font(.system(size: SonoDesktopTokens.SymbolSize.small)).sonoIconFrame(SonoDesktopTokens.IconFrame.s16).accessibilityHidden(true)
                TextField("搜索设置", text: $query).textFieldStyle(.plain).accessibilityLabel("搜索设置")
                if !query.isEmpty {
                    Button { query = "" } label: { Image(systemName: "xmark.circle.fill").font(.system(size: SonoDesktopTokens.SymbolSize.small)).sonoIconFrame(SonoDesktopTokens.IconFrame.s16) }
                        .buttonStyle(SonoPanelCloseStyle()).accessibilityLabel("清除设置搜索")
                }
            }.padding(SonoDesktopTokens.Spacing.s12).background(Color(nsColor: SonoGeneratedColors.settingsSurface), in: RoundedRectangle(cornerRadius: SonoDesktopTokens.Radius.medium))
            ScrollView {
                VStack(alignment: .leading, spacing: SonoDesktopTokens.Spacing.s8) {
                    navigationGroup("界面", sections: [.appearance, .wall, .desktop])
                    navigationGroup("音乐", sections: [.lyrics, .history])
                    navigationGroup("应用", sections: [.about])
                }
            }
            Spacer(minLength: 0)
            Text("SONO MUSIC 设置").font(SonoTypography.font(size: SonoDesktopTokens.FontSize.caption)).foregroundStyle(Color(nsColor: SonoGeneratedColors.settingsDescription))
        }
        .padding(SonoDesktopTokens.Spacing.s16).frame(maxHeight: .infinity, alignment: .top)
        .background(Color(nsColor: SonoGeneratedColors.settingsSidebar))
    }

    @ViewBuilder private func navigationGroup(_ title: String, sections: [SettingsSection]) -> some View {
        let visible = sections.filter { matches.contains($0) }
        if !visible.isEmpty {
            Text(title).font(SonoTypography.font(size: SonoDesktopTokens.FontSize.caption, weight: SonoDesktopTokens.FontWeight.medium))
                .foregroundStyle(Color(nsColor: SonoGeneratedColors.settingsDescription))
                .padding(.leading, SonoDesktopTokens.Spacing.s8).padding(.top, SonoDesktopTokens.Spacing.s12).padding(.bottom, SonoDesktopTokens.Spacing.s4)
            ForEach(visible) { section in
                Button { selected = section } label: {
                    HStack(spacing: SonoDesktopTokens.Spacing.s8) {
                        Image(systemName: section.icon).font(.system(size: SonoDesktopTokens.SymbolSize.compact)).sonoIconFrame(SonoDesktopTokens.IconFrame.s20).frame(width: 24, height: 24)
                        Text(section.rawValue)
                        Spacer(minLength: 0)
                    }.padding(SonoDesktopTokens.Spacing.s8).frame(maxWidth: .infinity, alignment: .leading)
                }
                .buttonStyle(SettingsNavigationStyle(selected: selected == section))
                .accessibilityLabel(section.rawValue + "设置")
                .accessibilityAddTraits(selected == section ? .isSelected : [])
            }
        }
    }

    private func wallSettingsCard(_ title: String, lights: Binding<Bool>, info: Binding<Bool>) -> some View {
        card(title) {
            HStack { Text("开灯"); Spacer(); SonoSwitch(value: lights, label: title + "开灯") }
            description("恢复封面原图亮度；浅色模式悬停时保留阅读遮罩。")
            Divider()
            HStack { Text("始终显示歌曲信息"); Spacer(); SonoSwitch(value: info, label: title + "始终显示歌曲信息") }
            description("关闭后仅悬停、键盘聚焦或中央大卡显示歌名、歌手及标题渐变。")
        }
    }

    @ViewBuilder private var sectionContent: some View {
        switch selected {
        case .about:
            VStack(spacing: SonoDesktopTokens.Spacing.s8) {
                Image(nsImage: NSApp.applicationIconImage)
                    .resizable().scaledToFit().frame(width: 64, height: 64)
                    .accessibilityHidden(true)
                Text(Bundle.main.object(forInfoDictionaryKey: "CFBundleDisplayName") as? String ?? "SONO MUSIC")
                    .font(SonoTypography.font(size: SonoDesktopTokens.FontSize.pageTitle, weight: SonoDesktopTokens.FontWeight.semibold))
                if let version = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String,
                   let build = Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String {
                    Text(verbatim: "Version \(version) (\(build))")
                        .foregroundStyle(Color(nsColor: SonoGeneratedColors.settingsDescription))
                        .textSelection(.enabled)
                }
            }
            .frame(maxWidth: .infinity)
        case .wall:
            wallSettingsCard("浅色模式", lights: $wallLightLightsOn, info: $wallLightAlwaysShowInfo)
            wallSettingsCard("深色模式", lights: $wallDarkLightsOn, info: $wallDarkAlwaysShowInfo)
            description("两种模式分别保存，切换外观时自动使用对应设置。浅色模式悬停或键盘聚焦时会加深封面，方便阅读。")
        case .appearance:
            card("主题") {
                SonoThemeSegments("外观", selection: $appearance, options: SonoAppearance.allCases, title: \.title)
                description("跟随系统自动切换，或为 SONO MUSIC 单独选择浅色与深色。更改立即生效并在重启后保留。")
                SonoThemeSegments("主题色", selection: $theme, options: SonoTheme.allCases, title: \.title)
            }
            card("Liquid Glass") {
                SonoThemeSegments("玻璃透明度", selection: $glassDensity, options: SonoGlassDensity.allCases, title: \.title)
                description("用于应用内保留玻璃材质的区域，设置面板始终使用实色。清透与标准使用 Apple 原生材质，浓厚在标准材质上增加暗色遮底。")
            }
        case .desktop:
            card("窗口尺寸") {
                HStack {
                    Text("当前尺寸"); Spacer()
                    Menu(currentWindowSize) {
                        ForEach(["1024×720", "1280×800", "1440×900", "1600×1000", "1920×1080"], id: \.self) { size in
                            Button(size) {
                                let dimensions = size.split(separator: "×").compactMap { Double($0) }
                                (session.window as? SonoWindow)?.resize(to: NSSize(width: dimensions[0], height: dimensions[1]))
                            }
                        }
                    }.menuStyle(.borderlessButton).modifier(SettingsMenuFill()).fixedSize()
                }
                description("选择后立即生效；超过屏幕可用区域时自动缩小。下次启动使用默认 1440 × 900。")
            }
        case .lyrics:
            card("歌词匹配") {
                Toggle("自动寻找逐字歌词", isOn: Binding(get: { session.lyrics.automatic }, set: {
                    session.lyrics.automatic = $0
                    reloadLyrics()
                }))
                Divider()
                HStack {
                    Text("首选歌词来源")
                    Spacer()
                    Menu(session.lyrics.preferred.title) {
                        ForEach(LyricSource.allCases, id: \.self) { source in
                            Button(source.title) {
                                session.lyrics.preferred = source
                                reloadLyrics()
                            }
                        }
                    }.menuStyle(.borderlessButton).modifier(SettingsMenuFill()).fixedSize()
                }
            }
        case .history:
            card("播放历史") {
                HStack {
                    Text("跨重启保存播放历史"); Spacer()
                    SonoSwitch(value: Binding(get: { session.persistHistory }, set: { session.configureHistory(persist: $0, limit: session.historyLimit) }), label: "跨重启保存播放历史")
                }
                description("关闭后清空磁盘历史；本次仍可查看，退出后不保留。")
                Divider()
                HStack {
                    Text("最大历史条数"); Spacer()
                    Menu("\(session.historyLimit) 条") {
                        ForEach([100, 500, 1000], id: \.self) { limit in
                            Button("\(limit) 条") { session.configureHistory(persist: session.persistHistory, limit: limit) }
                        }
                    }.menuStyle(.borderlessButton).modifier(SettingsMenuFill()).fixedSize()
                }
                description("达到上限时自动移除最旧记录，条数上限适用于全部本地历史。")
            }
            card("存储位置") {
                Text(session.historyPath).font(SonoTypography.font(size: SonoDesktopTokens.FontSize.caption)).textSelection(.enabled)
                    .padding(SonoDesktopTokens.Spacing.s12).frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color(nsColor: SonoGeneratedColors.settingsPath), in: RoundedRectangle(cornerRadius: SonoDesktopTokens.Radius.medium))
                description("此文件保存歌曲信息，不保存音频文件。")
            }
        }
    }

    private func reloadLyrics() {
        if let track = session.audio.current {
            session.lyrics.stop()
            session.lyrics.load(track, online: session.online)
        }
    }

    private var currentWindowSize: String {
        let size = session.window?.frame.size ?? CGSize(width: 1440, height: 900)
        return "\(Int(size.width)) × \(Int(size.height))" + (size.width == 1440 && size.height == 900 ? "（默认）" : "")
    }

    private func card<Content: View>(_ title: String, @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: SonoDesktopTokens.Spacing.s12) {
            Text(title).font(SonoTypography.font(size: SonoDesktopTokens.FontSize.label, weight: SonoDesktopTokens.FontWeight.semibold))
                .foregroundStyle(Color(nsColor: SonoGeneratedColors.settingsDescription))
                .padding(.leading, SonoDesktopTokens.Spacing.s4)
            VStack(alignment: .leading, spacing: SonoDesktopTokens.Spacing.s16, content: content)
                .padding(SonoDesktopTokens.Spacing.s20).frame(maxWidth: .infinity, alignment: .leading)
                .background(Color(nsColor: SonoGeneratedColors.settingsCard), in: RoundedRectangle(cornerRadius: SonoDesktopTokens.Radius.large))
        }
    }

    private func description(_ text: String) -> some View {
        Text(text).font(SonoTypography.font(size: SonoDesktopTokens.FontSize.caption))
            .foregroundStyle(Color(nsColor: SonoGeneratedColors.settingsDescription))
            .lineSpacing(5).fixedSize(horizontal: false, vertical: true)
    }
}

private struct SettingsNavigationStyle: ButtonStyle {
    let selected: Bool
    @Environment(\.isEnabled) private var enabled
    @Environment(\.colorScheme) private var colorScheme
    @State private var hovered = false

    func makeBody(configuration: Configuration) -> some View {
        let shape = RoundedRectangle(cornerRadius: SonoDesktopTokens.Radius.small)
        let pressed = enabled && configuration.isPressed
        let foreground = !enabled ? SonoGeneratedColors.interfaceDisabled
            : pressed ? (colorScheme == .light ? SonoGeneratedColors.queuePressedLight : SonoGeneratedColors.queuePressedDark)
            : SonoGeneratedColors.navigationText
        return configuration.label
            .foregroundStyle(Color(nsColor: foreground))
            .background {
                shape.fill(selected ? Color(nsColor: SonoGeneratedColors.settingsSurface) : Color.clear)
                shape.fill(pressed ? Color(nsColor: SonoGeneratedColors.settingsControlPressed)
                    : enabled && !selected && hovered ? Color(nsColor: SonoGeneratedColors.settingsControlHover) : Color.clear)
            }
            .contentShape(shape)
            .pointerStyle(enabled && !selected ? .link : .default)
            .onHover { hovered = $0 }
    }
}

private struct SettingsMenuFill: ViewModifier {
    @State private var hovered = false
    @GestureState private var pressed = false
    func body(content: Content) -> some View {
        content
            .padding(.horizontal, SonoDesktopTokens.Spacing.s12).padding(.vertical, SonoDesktopTokens.Spacing.s8)
            .background {
                RoundedRectangle(cornerRadius: SonoDesktopTokens.Radius.small)
                    .fill(Color(nsColor: SonoGeneratedColors.settingsControlFill))
                    .overlay {
                        RoundedRectangle(cornerRadius: SonoDesktopTokens.Radius.small).fill(pressed
                            ? Color(nsColor: SonoGeneratedColors.settingsControlPressed)
                            : hovered ? Color(nsColor: SonoGeneratedColors.settingsControlHover) : .clear)
                    }
            }
            .onHover { hovered = $0 }
            .simultaneousGesture(DragGesture(minimumDistance: 0).updating($pressed) { _, state, _ in state = true })
    }
}
