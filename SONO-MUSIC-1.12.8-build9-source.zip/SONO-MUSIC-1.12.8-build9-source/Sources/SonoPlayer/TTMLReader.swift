import Foundation

/// XML structure is retained until the document is complete: callback fragments
/// are never mistaken for separate timed words or separate voices.
final class TTMLReader: NSObject, XMLParserDelegate {
    final class Node {
        let name:String; let attributes:[String:String]
        var children:[Node] = []; var content:[Part] = []
        enum Part { case text(String), node(Node) }
        init(_ name:String,_ attributes:[String:String]) { self.name = name; self.attributes = attributes }
        var text:String { content.map { switch $0 { case .text(let t): return t; case .node(let n): return n.text } }.joined() }
        func attribute(_ name:String) -> String? { attributes[name] ?? attributes.first { $0.key.split(separator:":").last.map(String.init) == name }?.value }
        var role:String { attribute("role") ?? "" }
        var isRomanization:Bool { role == "x-roman" || role.contains("transliteration") }
        var isTranslation:Bool { role.contains("translation") }
        var isBackground:Bool { role == "x-bg" || role.contains("background") }
        func all(_ name:String) -> [Node] { children.flatMap { ($0.name == name ? [$0] : []) + $0.all(name) } }
    }
    private var stack:[Node] = []; private var root:Node?
    private(set) var lines:[LyricLine] = []
    private(set) var plain = ""
    func parser(_ parser:XMLParser,didStartElement name:String,namespaceURI:String?,qualifiedName:String?,attributes:[String:String]) {
        let node = Node(name,attributes)
        if let parent = stack.last { parent.children.append(node); parent.content.append(.node(node)) } else { root = node }
        stack.append(node)
    }
    func parser(_ parser:XMLParser,foundCharacters text:String) { stack.last?.content.append(.text(text)) }
    func parser(_ parser:XMLParser,didEndElement name:String,namespaceURI:String?,qualifiedName:String?) { if !stack.isEmpty { stack.removeLast() } }
    func parserDidEndDocument(_ parser:XMLParser) {
        guard let root else { return }
        let body = root.all("body").first ?? root
        for p in body.all("p") {
            let start = LyricsParser.time(p.attribute("begin") ?? "0")
            let end = p.attribute("end").map(LyricsParser.time) ?? (start + LyricsParser.time(p.attribute("dur") ?? "0"))
            var line = LyricLine(start:start,end:end,words:words(p,start:start,end:end),voice:p.attribute("agent") ?? "",endSource:p.attribute("end") != nil || p.attribute("dur") != nil ? .explicit : .inferred)
            line.translation = auxiliary(p, romanization:false)
            line.romanization = auxiliary(p, romanization:true)
            let timedNodes = ([p]+p.all("span")).contains { $0.attribute("begin") != nil || $0.attribute("end") != nil || $0.attribute("dur") != nil }
            if !timedNodes {
                let text = [line.text,line.translation,line.romanization].filter { !$0.isEmpty }.joined(separator:"\n")
                if !text.isEmpty { plain += (plain.isEmpty ? "" : "\n")+text }
                continue
            }
            if p.attribute("begin") == nil, let begin = line.words.filter(\.timed).map(\.start).min() { line.start = begin }
            if p.attribute("end") == nil && p.attribute("dur") == nil,
               !line.words.isEmpty && line.words.allSatisfy({ $0.timed && $0.endSource == .explicit }),
               let end = line.words.map(\.end).max() { line.end = end; line.endSource = .explicit }
            if !line.words.isEmpty { lines.append(line) }
            for bg in p.all("span").filter(\.isBackground) {
                let begin = bg.attribute("begin").map(LyricsParser.time) ?? start
                let finish = bg.attribute("end").map(LyricsParser.time) ?? end
                lines.append(.init(start:begin,end:finish,words:words(bg,start:begin,end:finish),translation:auxiliary(bg,romanization:false),romanization:auxiliary(bg,romanization:true),voice:line.voice,background:true,endSource:bg.attribute("end") != nil ? .explicit : line.endSource))
            }
        }
    }
    private func auxiliary(_ node:Node, romanization:Bool) -> String {
        node.children.filter { !$0.isBackground }.map {
            (romanization ? $0.isRomanization : $0.isTranslation) ? $0.text : auxiliary($0,romanization:romanization)
        }.joined()
    }
    private func words(_ node:Node,start:Double,end:Double) -> [LyricWord] {
        var result:[LyricWord] = []
        for part in node.content {
            switch part {
            case .text(let text):
                if !text.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty { result.append(.init(text:text,start:start,end:end)) }
                else if !result.isEmpty { result[result.count-1].text += text }
            case .node(let child):
                if child.isTranslation || child.isRomanization || child.isBackground { continue }
                let begin = child.attribute("begin").map(LyricsParser.time) ?? start
                let finish = child.attribute("end").map(LyricsParser.time) ?? child.attribute("dur").map { begin + LyricsParser.time($0) } ?? end
                if child.attribute("begin") != nil && !child.text.isEmpty && child.all("span").allSatisfy({ $0.attribute("begin") == nil }) {
                    result.append(.init(text:child.text,start:begin,end:finish,timed:true,emphasis:child.attribute("emphasis").map { $0 == "true" || $0 == "1" } ?? (child.role.contains("emphasis") ? true : nil),endSource:child.attribute("end") != nil || child.attribute("dur") != nil ? .explicit : .inferred))
                } else { result += words(child,start:begin,end:finish) }
            }
        }
        return result
    }
}
