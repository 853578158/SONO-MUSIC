import SwiftUI

extension OnlinePlatform {
    var title: String { self == .qq ? "QQ 音乐" : "网易云音乐" }
}

private extension OnlinePlatform {
    var accent: Color { self == .qq ? Color(red: 13 / 255, green: 188 / 255, blue: 113 / 255) : Color(red: 221 / 255, green: 0, blue: 27 / 255) }

    @MainActor func mark(size: CGFloat) -> some View {
        Group {
            if let image = SonoAssets.image(self == .qq ? "account-qq" : "account-netease") {
                Image(nsImage: image).resizable().renderingMode(.original).scaledToFit()
            }
        }.frame(width: size, height: size).accessibilityHidden(true)
    }
}

private struct AccountEntry: Identifiable {
    let account: OnlineAccount
    let platform: OnlinePlatform
    var id: String { platform.rawValue + "/" + account.id }
}

struct OnlineAccountPanel: View {
    @ObservedObject var online: OnlineSession
    @Binding var order: [String]
    let addAccount: () -> Void
    @Environment(\.sonoTheme) private var theme
    @State private var loadedAvatars: [String: URL] = [:]

    @State private var confirming: String?

    private var activeKey: String? {
        online.account.map { online.activePlatform.rawValue + "/" + $0.id }
    }

    private var entries: [AccountEntry] {
        var accounts = online.savedAccounts.map { AccountEntry(account: $0, platform: .netease) }
            + online.qqAccounts.map { AccountEntry(account: $0, platform: .qq) }
        if let current = online.account {
            accounts.removeAll { $0.id == activeKey }
            accounts.insert(AccountEntry(account: current, platform: online.activePlatform), at: 0)
        }
        let byID = Dictionary(uniqueKeysWithValues: accounts.map { ($0.id, $0) })
        var rows = order.compactMap { byID[$0] } + accounts.filter { !order.contains($0.id) }
        if online.connectingAccountKey == nil, let index = rows.firstIndex(where: { $0.id == activeKey }) {
            rows.swapAt(0, index)
        }
        return rows
    }

    var body: some View {
        let rows = entries
        return VStack(spacing: SonoDesktopTokens.Spacing.s12) {
            Text("账号列表")
                .font(SonoTypography.font(size: SonoDesktopTokens.FontSize.sectionTitle, weight: .bold))
                .frame(height: 32)
            ScrollView {
                VStack(spacing: SonoDesktopTokens.Spacing.s12) {
                    ForEach(rows) { entry in
                        row(entry.account, platform: entry.platform)
                        if entry.id == rows.first?.id, activeKey != nil, rows.count > 1 { Divider() }
                    }
                }.padding(.horizontal, SonoDesktopTokens.Spacing.s16)
            }.frame(height: min(240, CGFloat(rows.count * 54 + max(0, rows.count - 1) * 12 + (rows.count > 1 && activeKey != nil ? 13 : 0))))
            if online.authentication == .offlineCache {
                Button("重试恢复登录") { online.restore() }.disabled(online.accountLoading)
            }
            if online.account == nil {
                Button("从 Electron 版导入登录") { online.importElectronLogin() }.disabled(online.accountLoading)
            }
            if let message = online.qqAccountNotice ?? online.notice {
                Text(message).font(.caption).foregroundStyle(.secondary).lineLimit(2)
            }
            Button(action: addAccount) {
                Text("添加账号").font(SonoTypography.font(size: SonoDesktopTokens.FontSize.label, weight: .bold))
                    .frame(maxWidth: .infinity, minHeight: SonoDesktopTokens.Component.recommendationButton)
                    .foregroundStyle(Color(nsColor: theme.foreground()))
                    .background(Color(nsColor: theme.accent), in: Capsule())
                    .contentShape(Capsule())
            }.buttonStyle(.plain)
        }
        .padding(.horizontal, SonoDesktopTokens.Spacing.s8)
        .padding(.top, SonoDesktopTokens.Spacing.s36)
        .padding(.bottom, SonoDesktopTokens.Spacing.s8)
        .frame(width: 380)
        .glass(radius: 24)
        .onAppear { online.refreshQQAccounts() }
        .onChange(of: rows.map(\.id), initial: true) { _, ids in order = ids }
    }

    private func row(_ account: OnlineAccount, platform: OnlinePlatform) -> some View {
        let active = online.account?.id == account.id && online.activePlatform == platform
        let avatarKey = platform.rawValue + "/" + account.id
        return HStack(spacing: SonoDesktopTokens.Spacing.s12) {
            RoundedRectangle(cornerRadius: 8)
                .fill(Color(nsColor: SonoGeneratedColors.quickPlaceholder))
                .overlay {
                    AsyncImage(url: account.avatar ?? loadedAvatars[avatarKey]) { image in
                        image.resizable().scaledToFill()
                    } placeholder: {
                        Image(systemName: "person.fill").foregroundStyle(.secondary)
                    }
                }.clipShape(RoundedRectangle(cornerRadius: 8))
                .frame(width: 42, height: 42)
                .overlay(alignment: .bottomTrailing) {
                    if online.connectingAccountKey == avatarKey {
                        ProgressView().controlSize(.mini).frame(width: 14, height: 14).padding(2)
                            .accessibilityLabel("正在连接")
                    } else { platform.mark(size: 14).padding(2) }
                }
            Text(account.name)
                .font(SonoTypography.font(size: SonoDesktopTokens.FontSize.label))
                .lineLimit(1).truncationMode(.tail)
                .frame(maxWidth: .infinity, alignment: .leading)
                .help(account.name)
            HStack(spacing: SonoDesktopTokens.Spacing.s4) {
                if confirming == avatarKey {
                    Button("取消") { confirming = nil }
                        .buttonStyle(AccountActionStyle(kind: .cancel))
                    Button("确认") {
                        confirming = nil
                        online.logout(id: account.id, platform: platform)
                    }.buttonStyle(AccountActionStyle(kind: .confirm))
                        .accessibilityLabel("确认退出 " + account.name)
                } else {
                    Button { confirming = avatarKey } label: {
                        Image(systemName: "rectangle.portrait.and.arrow.forward")
                    }.buttonStyle(AccountActionStyle(kind: .icon))
                        .accessibilityLabel("退出 " + account.name).help("退出账号")
                    Button {
                        guard !active else { return }
                        confirming = nil
                        if platform == .qq { online.verifySavedQQAccount(account.id) }
                        else { online.switchAccount(to: account.id) }
                    } label: {
                        Image(systemName: "link")
                    }.buttonStyle(AccountActionStyle(kind: active ? .connected : .icon))
                        .accessibilityLabel(active ? "当前账号" : "连接 " + account.name)
                }
            }.fixedSize().disabled(online.accountLoading)
        }.padding(6)
            .task(id: avatarKey) {
                guard account.avatar == nil, loadedAvatars[avatarKey] == nil else { return }
                // Avatar lookup is optional. The row keeps its placeholder if the saved session is unavailable.
                let avatar = try? await online.savedAccountAvatar(account.id, platform: platform)
                guard !Task.isCancelled else { return }
                loadedAvatars[avatarKey] = avatar
            }
    }
}

private struct AccountActionStyle: ButtonStyle {
    enum Kind { case icon, connected, cancel, confirm }
    let kind: Kind
    @State private var hovering = false

    func makeBody(configuration: Configuration) -> some View {
        let emphasized = hovering || configuration.isPressed
        let fill: NSColor = switch kind {
        case .icon: emphasized ? SonoGeneratedColors.settingsControlHover : .clear
        case .connected: NSColor.systemGreen.withAlphaComponent(emphasized ? 0.80 : 1)
        case .cancel: SonoGeneratedColors.settingsControlFill
        case .confirm: SonoGeneratedColors.settingsSurface
        }
        let ink: NSColor = switch kind {
        case .connected: .white
        case .confirm: SonoGeneratedColors.interfaceError
        default: SonoGeneratedColors.toolIcon
        }
        return configuration.label
            .foregroundStyle(Color(nsColor: ink))
            .frame(width: kind == .confirm || kind == .cancel ? 68 : 32, height: 32)
            .background {
                Capsule().fill(Color(nsColor: fill))
                    .overlay {
                        if kind == .confirm {
                            Capsule().fill(Color(nsColor: SonoGeneratedColors.interfaceError)
                                .opacity(emphasized ? 0.32 : 0.20))
                        } else if kind == .cancel && emphasized {
                            Capsule().fill(Color(nsColor: SonoGeneratedColors.settingsControlHover))
                        }
                    }
            }
            .contentShape(Capsule())
            .onHover { hovering = $0 }
    }
}

struct AddOnlineAccountPanel: View {
    @ObservedObject var online: OnlineSession
    let dismiss: () -> Void
    @State private var platform: OnlinePlatform = .netease
    private var scanSucceeded: Bool { online.qrState == .succeeded }

    private var statusText: String {
        switch online.qrState {
        case .idle, .generating, .connecting: "正在生成二维码…"
        case .refreshing: "二维码已过期，正在换一张…"
        case .waiting: "等待扫码…"
        case .confirming: "请在手机上确认登录"
        case .verifying: "正在验证账号…"
        case .succeeded: "登录成功"
        case .failed(let status, _): status
        }
    }

    private var scanInstructions: String {
        platform == .qq ? "支持QQ音乐、QQ、微信扫码" : "支持网易云音乐扫码"
    }

    var body: some View {
        VStack(spacing: 0) {
            Text("添加账号")
                .font(SonoTypography.font(size: SonoDesktopTokens.FontSize.sectionTitle, weight: .bold))
                .frame(height: 32).padding(.top, SonoDesktopTokens.Spacing.s36)
            HStack(spacing: 48) {
                tab(.netease)
                tab(.qq)
            }.padding(.top, 24).disabled(scanSucceeded)
            RoundedRectangle(cornerRadius: 14)
                .fill(Color(nsColor: SonoGeneratedColors.quickPlaceholder))
                .overlay {
                    if online.qrState == .waiting, let qr = online.qrImage {
                        Image(nsImage: qr).interpolation(.none).resizable().scaledToFit()
                            .padding(12).background(.white)
                            .accessibilityLabel("登录二维码")
                    } else {
                        VStack(spacing: SonoDesktopTokens.Spacing.s8) {
                            Text(statusText)
                                .font(SonoTypography.font(size: scanSucceeded
                                    ? SonoDesktopTokens.FontSize.sectionTitle : SonoDesktopTokens.FontSize.label))
                                .multilineTextAlignment(.center)
                            if case .failed = online.qrState {
                                Button("重新生成", action: begin)
                            }
                        }.padding(SonoDesktopTokens.Spacing.s12)
                    }
                }
                .clipShape(RoundedRectangle(cornerRadius: 14))
                .overlay { RoundedRectangle(cornerRadius: 14).strokeBorder(platform.accent, lineWidth: 2) }
                .frame(width: 163, height: 163).padding(.top, 19)
            Text(scanInstructions)
                .font(SonoTypography.font(size: SonoDesktopTokens.FontSize.label))
                .foregroundStyle(.secondary).padding(.top, 32)
            Spacer(minLength: 0)
        }
        .frame(width: 380, height: 416)
        .overlay(alignment: .topTrailing) {
            Button { online.cancelLogin(); dismiss() } label: {
                Image(systemName: "xmark")
                    .frame(width: SonoDesktopTokens.Component.control, height: SonoDesktopTokens.Component.control)
            }.buttonStyle(SonoPanelCloseStyle()).accessibilityLabel("关闭")
                .keyboardShortcut(.cancelAction)
                .padding(SonoDesktopTokens.Spacing.s16)
        }
        .background(Color(nsColor: SonoGeneratedColors.recommendationPanel),
                    in: RoundedRectangle(cornerRadius: SonoDesktopTokens.Radius.window))
        .shadow(color: .black.opacity(0.18), radius: 22, y: 10)
        .onAppear { begin() }
        .task(id: scanSucceeded) {
            guard scanSucceeded else { return }
            do { try await Task.sleep(for: .seconds(1)) } catch { return }
            dismiss()
        }
        .onDisappear { online.cancelLogin() }
    }

    private func begin() {
        if platform == .qq { online.beginQQLogin() } else { online.beginLogin() }
    }

    private func tab(_ value: OnlinePlatform) -> some View {
        Button {
            guard value != platform else { return }
            platform = value
            begin()
        } label: {
            VStack(spacing: 4) {
                value.mark(size: 32)
                Capsule().fill(platform == value ? value.accent : .clear).frame(width: 16, height: 4)
            }.contentShape(Rectangle())
        }.buttonStyle(.plain).accessibilityLabel(value.title)
            .accessibilityAddTraits(platform == value ? .isSelected : [])
    }
}

struct QRLoginToast: View {
    let message: String
    @State private var visible = true

    var body: some View {
        if visible {
            Text(message)
                .font(SonoTypography.font(size: SonoDesktopTokens.FontSize.label, weight: .semibold))
                .multilineTextAlignment(.center)
                .padding(.horizontal, SonoDesktopTokens.Spacing.s20)
                .padding(.vertical, SonoDesktopTokens.Spacing.s8)
                .glass(radius: 16)
                .task {
                    do { try await Task.sleep(for: .seconds(4)) } catch { return }
                    visible = false
                }
        }
    }
}
