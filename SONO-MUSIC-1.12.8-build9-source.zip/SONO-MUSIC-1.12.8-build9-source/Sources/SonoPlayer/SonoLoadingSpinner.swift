import SwiftUI

struct SonoLoadingSpinner: View {
    let size: CGFloat
    var lineWidth: CGFloat = 2
    var tint: Color = Color(nsColor: SonoGeneratedColors.loadingIcon)
    var baseOpacity: Double = 0.2
    var background: Color = .clear
    @Environment(\.accessibilityReduceMotion) private var reduced
    @ViewState private var started = Date()
    var body: some View {
        TimelineView(.animation(paused: reduced)) { timeline in
            Canvas { context, box in
                let bounds = CGRect(origin: .zero, size: box)
                context.fill(Path(ellipseIn: bounds), with: .color(background))
                context.stroke(Path(ellipseIn: bounds.insetBy(dx: lineWidth / 2, dy: lineWidth / 2)), with: .color(tint.opacity(baseOpacity)), lineWidth: lineWidth)
                let angle = reduced ? 0 : timeline.date.timeIntervalSince(started) / 0.8 * 360
                var path = Path()
                path.addArc(center: CGPoint(x: box.width / 2, y: box.height / 2), radius: (min(box.width, box.height) - lineWidth) / 2, startAngle: .degrees(225 + angle), endAngle: .degrees(315 + angle), clockwise: false)
                context.stroke(path, with: .color(tint), lineWidth: lineWidth)
            }
        }.frame(width: size, height: size).accessibilityLabel("正在加载").allowsHitTesting(false)
    }
}
