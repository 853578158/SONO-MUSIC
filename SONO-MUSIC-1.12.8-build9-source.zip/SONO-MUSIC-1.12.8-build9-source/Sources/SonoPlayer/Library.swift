import AppKit
import AVFoundation
import CryptoKit
import ImageIO
import UniformTypeIdentifiers

struct LocalTrack: Identifiable, Codable, Sendable, Equatable {
    let id: String
    let folderID: UUID
    let url: URL
    let title: String
    let artist: String
    let album: String
    let duration: Double
    let coverURL: URL?
    let playable: Bool
    var online: OnlineTrackInfo? = nil
    var searchCoverFallback: Bool? = nil
}

struct FolderRecord: Identifiable, Codable, Sendable, Equatable {
    let id: UUID
    var name: String
    var bookmark: Data
}

// A scan, candidate and active player retain their own lease. Removing a source
// does not revoke access underneath an in-flight scan or the active audio.
final class FolderAccess: @unchecked Sendable {
    let record: FolderRecord
    let url: URL
    private let scoped: Bool
    init(record: FolderRecord, url: URL) {
        self.record = record
        self.url = url
        scoped = url.startAccessingSecurityScopedResource()
    }
    deinit { if scoped { url.stopAccessingSecurityScopedResource() } }
}

struct FolderStore {
    private struct Document: Codable { let version: Int; let folders: [FolderRecord] }
    let url: URL
    init(url: URL? = nil) {
        let ordinary = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("SonoPlayerMacOS", isDirectory: true)
        self.url = url ?? PerformanceEnvironment.applicationSupportDirectory(default: ordinary)
            .appendingPathComponent("folders-v1.json")
    }
    func load() throws -> [FolderRecord] {
        guard FileManager.default.fileExists(atPath: url.path) else { return [] }
        let document = try JSONDecoder().decode(Document.self, from: Data(contentsOf: url))
        guard document.version == 1 else { throw LibraryError.unsupportedVersion }
        return document.folders
    }
    func save(_ records: [FolderRecord]) throws {
        try FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
        try JSONEncoder().encode(Document(version: 1, folders: records)).write(to: url, options: .atomic)
    }
    static func authorize(_ url: URL, id: UUID = UUID()) throws -> FolderAccess {
        // Begin access while constructing the persistent bookmark returned by the panel.
        let started = url.startAccessingSecurityScopedResource()
        defer { if started { url.stopAccessingSecurityScopedResource() } }
        guard try url.resourceValues(forKeys: [.isDirectoryKey]).isDirectory == true else { throw LibraryError.notDirectory }
        let bookmark = try url.bookmarkData(options: [.withSecurityScope, .securityScopeAllowOnlyReadAccess], includingResourceValuesForKeys: nil, relativeTo: nil)
        return FolderAccess(record: .init(id: id, name: url.lastPathComponent, bookmark: bookmark), url: url)
    }
    static func resolve(_ record: FolderRecord) throws -> FolderAccess {
        var stale = false
        let url = try URL(resolvingBookmarkData: record.bookmark, options: [.withSecurityScope, .withoutUI], relativeTo: nil, bookmarkDataIsStale: &stale)
        let access = FolderAccess(record: record, url: url)
        guard try url.checkResourceIsReachable() else { throw LibraryError.inaccessible }
        if stale { return try authorize(access.url, id: record.id) }
        return access
    }
}

enum LibraryError: LocalizedError {
    case unsupportedVersion, inaccessible, notDirectory, duplicateDirectory
    var errorDescription: String? {
        switch self {
        case .unsupportedVersion: "目录记录版本不受支持，请保留文件并重新授权。"
        case .inaccessible: "目录无法访问，请重新授权。"
        case .notDirectory: "请选择文件夹，而不是音频文件。"
        case .duplicateDirectory: "这个文件夹已由其他来源记录使用，请选择原目录或移除重复记录。"
        }
    }
}

struct ScanResult: Sendable {
    var tracks: [LocalTrack] = []
    var warnings: [String] = []
    var inaccessibleFolderIDs: Set<UUID> = []
}

enum LibraryScanner {
    static let extensions: Set<String> = ["mp3", "m4a", "aac", "wav", "wave", "flac", "ogg", "opus", "webm", "aif", "aiff", "aifc", "mp4"]
    static func scan(_ folders: [FolderAccess], cache: URL) async throws -> ScanResult {
        var result = ScanResult()
        try FileManager.default.createDirectory(at: cache, withIntermediateDirectories: true)
        var seen = Set<URL>()
        let scanOrder = folders.sorted { lhs, rhs in
            lhs.url.pathComponents.count > rhs.url.pathComponents.count
        }
        for folder in scanOrder {
            try Task.checkCancellation()
            let keys: Set<URLResourceKey> = [.isRegularFileKey, .isSymbolicLinkKey]
            let urls = try audioURLs(in: folder, keys: keys, result: &result)
            for url in urls {
                try Task.checkCancellation()
                guard let values = try? url.resourceValues(forKeys: keys), values.isRegularFile == true,
                      values.isSymbolicLink != true, seen.insert(url.standardizedFileURL).inserted else { continue }
                let relativePath = url.pathComponents.dropFirst(folder.url.pathComponents.count).joined(separator: "/")
                let asset = AVURLAsset(url: url)
                var title = url.deletingPathExtension().lastPathComponent
                var artist = "本地音频"
                var album = "未知专辑"
                var duration = 0.0
                var cover: URL?
                var playable = false
                do {
                    playable = try await asset.load(.isPlayable)
                    let time = try await asset.load(.duration).seconds
                    if time.isFinite && time > 0 { duration = time }
                    for metadata in try await asset.load(.commonMetadata) {
                        try Task.checkCancellation()
                        switch metadata.commonKey {
                        case .commonKeyTitle:
                            if let value = try? await metadata.load(.stringValue), !value.isEmpty { title = value }
                        case .commonKeyArtist:
                            if let value = try? await metadata.load(.stringValue), !value.isEmpty { artist = value }
                        case .commonKeyAlbumName:
                            if let value = try? await metadata.load(.stringValue), !value.isEmpty { album = value }
                        case .commonKeyArtwork:
                            if let data = try? await metadata.load(.dataValue) {
                                do { cover = try cacheArtwork(data, cache: cache) }
                                catch { result.warnings.append("\(url.lastPathComponent)：封面读取失败，使用默认封面") }
                            }
                        default: break
                        }
                    }
                } catch is CancellationError { throw CancellationError() }
                catch {
                    // Keep the entry available for explicit playback, but do not
                    // surface an individual file's read error during a scan.
                    playable = false
                }
                result.tracks.append(.init(id: "\(folder.record.id.uuidString)/\(relativePath)", folderID: folder.record.id, url: url, title: title, artist: artist, album: album, duration: duration, coverURL: cover, playable: playable))
            }
        }
        return result
    }
    private static func audioURLs(in folder: FolderAccess, keys: Set<URLResourceKey>, result: inout ScanResult) throws -> [URL] {
        var warnings: [String] = []
        var inaccessible = false
        let rootPath = folder.url.standardizedFileURL.path
        defer {
            result.warnings.append(contentsOf: warnings)
            if inaccessible { result.inaccessibleFolderIDs.insert(folder.record.id) }
        }
        guard let enumerator = FileManager.default.enumerator(
            at: folder.url, includingPropertiesForKeys: Array(keys), options: [.skipsHiddenFiles],
            errorHandler: { url, error in
                warnings.append("\(url.path)：\(error.localizedDescription)")
                if url.standardizedFileURL.path == rootPath { inaccessible = true }
                return true
            }
        ) else {
            inaccessible = true
            warnings.append("\(folder.record.name)：目录无法读取")
            return []
        }
        var audioFiles: [URL] = []
        for case let url as URL in enumerator {
            try Task.checkCancellation()
            if extensions.contains(url.pathExtension.lowercased()) { audioFiles.append(url) }
        }
        return audioFiles.sorted {
            $0.path.compare($1.path, options: [.numeric, .forcedOrdering], locale: Locale(identifier: "zh_CN")) == .orderedAscending
        }
    }

    private static func cacheArtwork(_ data: Data, cache: URL) throws -> URL? {
        guard let source = CGImageSourceCreateWithData(data as CFData, [kCGImageSourceShouldCache: false] as CFDictionary),
              CGImageSourceGetCount(source) > 0, let type = CGImageSourceGetType(source) else { return nil }
        let key = SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
        let ext = UTType(type as String)?.preferredFilenameExtension ?? "image"
        let target = cache.appendingPathComponent(key + ".source." + ext)
        if !FileManager.default.fileExists(atPath: target.path) { try data.write(to: target, options: .atomic) }
        // Preserve the original encoded artwork. The bounded two-worker browse
        // decoder chooses screen pixels; an eager lossy 720px JPEG cannot do that.
        return target
    }

}

@MainActor
final class ArtworkCache {
    static let shared = ArtworkCache()
    private let images = NSCache<NSURL, NSImage>()
    private init() { images.totalCostLimit = 48 * 1024 * 1024; images.countLimit = 96 }
    func image(_ url: URL?) -> NSImage? {
        guard let url else { return nil }
        if let image = images.object(forKey: url as NSURL) { return image }
        guard let source = CGImageSourceCreateWithURL(url as CFURL, [kCGImageSourceShouldCache: false] as CFDictionary),
              let bitmap = CGImageSourceCreateThumbnailAtIndex(source, 0, [kCGImageSourceCreateThumbnailFromImageAlways: true, kCGImageSourceCreateThumbnailWithTransform: true, kCGImageSourceThumbnailMaxPixelSize: 144, kCGImageSourceShouldCacheImmediately: true] as CFDictionary) else { return nil }
        let image = NSImage(cgImage: bitmap, size: NSSize(width: bitmap.width, height: bitmap.height))
        images.setObject(image, forKey: url as NSURL, cost: bitmap.width * bitmap.height * 4)
        return image
    }
}
