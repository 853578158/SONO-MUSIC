import Combine
import Foundation

// Owns only recommendation requests and mode selection; PlayerSession owns playback.
@MainActor
final class PersonalFMController: ObservableObject {
    @Published private(set) var selection = PersonalFMSelection()
    @Published private(set) var loading = false
    @Published private(set) var requestedSelection: PersonalFMSelection?
    private var task: Task<[LocalTrack], Error>?
    private var revision = UUID()
    func load(_ selection: PersonalFMSelection, fetch: @escaping @MainActor (PersonalFMSelection) async throws -> [LocalTrack]) async throws -> [LocalTrack] {
        if requestedSelection == selection, let task {
            let token = revision, songs = try await task.value
            try Task.checkCancellation(); guard token == revision else { throw CancellationError() }
            return songs
        }
        cancel()
        let token = revision
        requestedSelection = selection; loading = true
        let work = Task { try await fetch(selection) }; task = work
        defer { if revision == token { loading = false; task = nil; requestedSelection = nil } }
        let songs = try await work.value
        try Task.checkCancellation(); guard revision == token else { throw CancellationError() }
        return songs
    }
    func commit(_ value: PersonalFMSelection) { selection = value }
    func cancel() { revision = UUID(); task?.cancel(); task = nil; requestedSelection = nil; loading = false }
}
