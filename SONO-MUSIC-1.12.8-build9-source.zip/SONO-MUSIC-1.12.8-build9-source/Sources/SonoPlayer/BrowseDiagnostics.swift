import AppKit
import QuartzCore

/// Opt-in, bounded measurements. Callback intervals are NOT GPU/presentation timings.
/// No song titles, URLs, account information or credentials enter the report.
final class BrowseDiagnostics: @unchecked Sendable {
    static let shared = BrowseDiagnostics()
    private let lock = NSLock()
    private var active = false
    private var samples: [String: [Double]] = [:]
    private var counts: [String: Int] = [:]
    private var events: [[String: String]] = []
    private var viewportEvents = 0
    private var importantEvents = 0
    private var wallFrameEvents = 0
    private var metadata: [String: String] = [:]
    private var resourceIDs: [String: String] = [:]
    private var startTime = CACurrentMediaTime()
    private let sampleLimit = 12000
    var enabled: Bool { lock.withLock { active } }
    func begin(metadata: [String: String] = [:]) {
        lock.withLock { samples = [:]; counts = [:]; events = []; viewportEvents = 0; importantEvents = 0; wallFrameEvents = 0; resourceIDs = [:]; self.metadata = metadata; active = true; startTime = CACurrentMediaTime() }
    }
    func resourceID(_ identity: String) -> String {
        lock.withLock {
            if let id = resourceIDs[identity] { return id }
            let id = UUID().uuidString; resourceIDs[identity] = id; return id
        }
    }
    func start() -> CFTimeInterval? { enabled ? CACurrentMediaTime() : nil }
    func end(_ key: String, _ start: CFTimeInterval?) {
        if let start { record(key, (CACurrentMediaTime() - start) * 1000) }
    }
    func mark(_ event: String, fields: [String: String] = [:]) {
        lock.withLock {
            guard active else { return }
            if event == "wall.frame" {
                guard wallFrameEvents < sampleLimit else { return }; wallFrameEvents += 1
            } else if event == "viewport.sample" {
                guard viewportEvents < 2048 else { return }; viewportEvents += 1
            } else if ["carousel.navigationIntent", "artwork.cardReal", "carousel.waitStart", "carousel.waitEnd"].contains(event) {
                guard importantEvents < 4096 else { return }; importantEvents += 1
            } else { guard events.count - viewportEvents - importantEvents - wallFrameEvents < 6144 else { return } }
            events.append(fields.merging(["event": event, "elapsedMs": String((CACurrentMediaTime() - startTime) * 1000)]) { _, new in new })
        }
    }
    func record(_ key: String, _ milliseconds: Double) {
        lock.withLock {
            guard active, milliseconds.isFinite else { return }
            counts[key, default: 0] += 1
            if samples[key, default: []].count < sampleLimit { samples[key, default: []].append(milliseconds) }
            if milliseconds > 8.5, ["input.wallFrame", "scene.render", "scene.accessibility", "artwork.layerAssignmentCPU"].contains(key), events.count - viewportEvents - wallFrameEvents < 6144 {
                events.append(["event": "slowSpan", "metric": key, "durationMs": String(milliseconds), "elapsedMs": String((CACurrentMediaTime() - startTime) * 1000)])
            }
        }
    }
    func count(_ key: String, by value: Int = 1) { lock.withLock { if active { counts[key, default: 0] += value } } }
    func set(_ key: String, _ value: String) { lock.withLock { if active { metadata[key] = value } } }
    func peak(_ key: String, _ value: Int) { lock.withLock { if active { counts[key] = max(counts[key, default: 0], value) } } }
    func report(frameBudgetMs: Double = 1000 / 60, stop: Bool = true) -> [String: Any] {
        lock.withLock {
            if stop { active = false }
            var metrics: [String: Any] = [:]
            for (key, values) in samples where !values.isEmpty {
                let sorted = values.sorted()
                func percentile(_ p: Double) -> Double { sorted[min(sorted.count - 1, Int(ceil(Double(sorted.count) * p)) - 1)] }
                let summary: [String: Any] = ["samples": sorted.count, "p50Ms": percentile(0.5), "p95Ms": percentile(0.95), "p99Ms": percentile(0.99),
                                "maxMs": sorted.last!, "meanMs": sorted.reduce(0, +) / Double(sorted.count),
                                "over1Budget": sorted.filter { $0 > frameBudgetMs }.count,
                                "over2Budgets": sorted.filter { $0 > frameBudgetMs * 2 }.count,
                                "over3Budgets": sorted.filter { $0 > frameBudgetMs * 3 }.count]
                metrics[key] = summary
            }
            return ["metadata": metadata, "seconds": CACurrentMediaTime() - startTime, "frameBudgetMs": frameBudgetMs,
                    "counts": counts, "metrics": metrics, "events": events, "sampleLimitPerMetric": sampleLimit,
                    "boundary": "CPU spans and display-link callbacks unless explicitly labeled GPU completion or CAMetalDrawable presentation; glyph transaction and cover readiness are not screen presentation"]
        }
    }
    func write(to url: URL, frameBudgetMs: Double = 1000 / 60) throws {
        let data = try JSONSerialization.data(withJSONObject: report(frameBudgetMs: frameBudgetMs), options: [.prettyPrinted, .sortedKeys])
        try FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
        try data.write(to: url, options: .atomic)
    }
}

@MainActor
final class BrowseDisplayProbe {
    private var link: CADisplayLink?
    private var last: CFTimeInterval?
    private var finish: Task<Void, Never>?
    private var output: URL?
    private var budget: Double = 1000 / 60
    private var automaticCaptureStarted = false
    private var lastObservation: CFTimeInterval = 0
    var sample: (() -> Void)?
    var wallFrame: ((Double?) -> Void)?
    var observation: (() -> [String: String])?
    func attach(to view: NSView) {
        guard link == nil, let screen = view.window?.screen else { return }
        if !automaticCaptureStarted, let path = ProcessInfo.processInfo.environment["SONO_BROWSE_DIAGNOSTICS"] {
            automaticCaptureStarted = true
            output = URL(fileURLWithPath: path)
            if !BrowseDiagnostics.shared.enabled { BrowseDiagnostics.shared.begin(metadata: ["mode": "real application interaction"]) }
            let seconds = min(180, max(5, Double(ProcessInfo.processInfo.environment["SONO_BROWSE_DIAGNOSTICS_SECONDS"] ?? "60") ?? 60))
            finish = Task { @MainActor [weak self] in
                let deadline = CACurrentMediaTime() + seconds
                let signal = ProcessInfo.processInfo.environment["SONO_BROWSE_DIAGNOSTICS_FINISH"]
                while CACurrentMediaTime() < deadline {
                    if let signal, FileManager.default.fileExists(atPath: signal) { break }
                    do { try await Task.sleep(for: .milliseconds(250)) } catch { return }
                }
                self?.stop()
            }
        }
        guard BrowseDiagnostics.shared.enabled else { return }
        budget = screen.minimumRefreshInterval * 1000
        BrowseDiagnostics.shared.set("screenMaxFPS", String(screen.maximumFramesPerSecond))
        BrowseDiagnostics.shared.set("screenMinRefreshMs", String(budget))
        BrowseDiagnostics.shared.set("screenMaxRefreshMs", String(screen.maximumRefreshInterval * 1000))
        BrowseDiagnostics.shared.set("backingScale", String(describing: view.window?.backingScaleFactor ?? 1))
        last = nil
        let link = view.displayLink(target: self, selector: #selector(frame(_:)))
        self.link = link; link.add(to: .main, forMode: .common)
    }
    @objc private func frame(_ link: CADisplayLink) {
        let arrived = CACurrentMediaTime()
        wallFrame?(last.map { (arrived - $0) * 1000 })
        sample?()
        let now = CACurrentMediaTime()
        if let output, now - lastObservation >= 0.25, let observation {
            lastObservation = now
            let state = observation()
            BrowseDiagnostics.shared.mark("viewport.sample", fields: state)
            // Diagnostic-only live state for verifying real UI routes. File IO is
            // kept off the display callback, and no tracks or account data is saved.
            let stateURL = output.deletingPathExtension().appendingPathExtension("state.json")
            Task.detached(priority: .utility) {
                do { try JSONSerialization.data(withJSONObject: state, options: [.sortedKeys]).write(to: stateURL, options: .atomic) }
                catch { NSLog("Sono diagnostic state: %@", error.localizedDescription) }
            }
        }
        if let last { BrowseDiagnostics.shared.record("display.callbackInterval", (arrived - last) * 1000) }
        self.last = arrived
        BrowseDiagnostics.shared.record("display.callbackLateness", max(0, now - link.timestamp) * 1000)
        BrowseDiagnostics.shared.record("display.targetInterval", (link.targetTimestamp - link.timestamp) * 1000)
    }
    func stop() {
        link?.invalidate(); link = nil; last = nil; finish?.cancel(); finish = nil
        if let output {
            do { try BrowseDiagnostics.shared.write(to: output, frameBudgetMs: budget) }
            catch { NSLog("Sono browse diagnostic report failed: %@", error.localizedDescription) }
            self.output = nil
        }
    }
}
