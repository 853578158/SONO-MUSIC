import Foundation

// Opt-in process isolation for repeatable performance runs. Never migrate the
// ordinary library, preferences or credentials into a measurement directory.
enum PerformanceEnvironment {
    static let root: URL? = {
        guard let path = ProcessInfo.processInfo.environment["SONO_PERFORMANCE_ROOT"] else { return nil }
        precondition(path.hasPrefix("/") && path != "/", "SONO_PERFORMANCE_ROOT must be an absolute measurement directory")
        return URL(fileURLWithPath: path, isDirectory: true).standardizedFileURL
    }()

    static func applicationSupportDirectory(default directory: URL) -> URL {
        root?.appendingPathComponent("ApplicationSupport", isDirectory: true) ?? directory
    }

    static func cacheDirectory(default directory: URL, subdirectory: String) -> URL {
        root?.appendingPathComponent("Caches", isDirectory: true)
            .appendingPathComponent(subdirectory, isDirectory: true) ?? directory
    }

    private static func networkCache(_ root: URL) -> URLCache {
        URLCache(memoryCapacity: 16 * 1024 * 1024, diskCapacity: 64 * 1024 * 1024,
                 directory: root.appendingPathComponent("Caches/Network", isDirectory: true))
    }

    static func configureSharedNetworkCache() {
        guard let root else { return }
        URLCache.shared = networkCache(root)
    }

    static let networkSession: URLSession = {
        guard let root else { return .shared }
        let configuration = URLSessionConfiguration.ephemeral
        configuration.httpCookieStorage = nil
        configuration.httpShouldSetCookies = false
        configuration.urlCache = networkCache(root)
        return URLSession(configuration: configuration)
    }()

    // UserDefaults serializes its own access; Foundation's Swift 6 declaration
    // does not yet expose that guarantee as Sendable.
    nonisolated(unsafe) static let defaults: UserDefaults = {
        guard let root else { return .standard }
        do { try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true) }
        catch { preconditionFailure("Cannot create performance preferences directory: \(error.localizedDescription)") }
        // CFPreferences supports an absolute suite domain; its backing plist is
        // <root>/preferences.plist, also used by SwiftUI's explicit AppStorage.
        guard let defaults = UserDefaults(suiteName: root.appendingPathComponent("preferences").path) else {
            preconditionFailure("Cannot create performance preferences suite")
        }
        return defaults
    }()
}
