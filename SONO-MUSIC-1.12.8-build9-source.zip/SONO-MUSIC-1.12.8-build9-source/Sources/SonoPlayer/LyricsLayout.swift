import AppKit
import CoreText
import QuartzCore

/// Media-time decisions are separate from Core Animation's settling clock.
enum LyricsTimeline {
    // Music 1.7 ordinary pretty preset, recovered in REA pass2/pass9.
    static let lineDelay = 0.05
    static let lineSpacing:CGFloat = 50
    struct Gap { let start: Double; let end: Double }
    static let primaryToAuxiliaryGap: CGFloat = 8
    static let auxiliaryGap: CGFloat = 6
    @MainActor static let compactViewportHeight: CGFloat = {
        func lineHeight(_ size: CGFloat) -> CGFloat {
            let font = NSFont.systemFont(ofSize: size, weight: SonoDesktopTokens.NativeFontWeight.bold)
            return max(size * 1.22, font.ascender - font.descender + font.leading)
        }
        let auxiliaryHeight = lineHeight(SonoDesktopTokens.FontSize.body)
        return ceil(lineHeight(fontSize) + 2 * auxiliaryHeight + primaryToAuxiliaryGap + auxiliaryGap) + 12
    }()

    static func gaps(in document: LyricDocument) -> [Gap] {
        // Unknown/inferred intervals block gaps: a cached duration is not proof
        // of silence. All voices participate, including backing vocals.
        let intervals = document.lines.flatMap { line -> [(Double,Double,Bool)] in
            if line.words.contains(where: { $0.timed }) {
                // True word intervals can expose silence inside a long TTML
                // paragraph. Unknown spans conservatively block that silence.
                return line.words.map { word in
                    word.timed && word.endSource == .explicit ? (word.start,word.end,true) : (line.start,line.end,false)
                }
            }
            return [(line.start,line.end,line.endSource == .explicit)]
        }.sorted { $0.0 < $1.0 }
        guard let first = intervals.first else { return [] }
        var result:[Gap] = [], end = first.1, trusted = first.2
        if first.2 && first.0 >= 5.8 { result.append(Gap(start:0,end:first.0)) }
        for interval in intervals.dropFirst() {
            if interval.0 > end {
                if trusted && interval.2 { result.append(Gap(start:end,end:interval.0)) }
                end = interval.1; trusted = interval.2
            } else if interval.1 >= end { end = interval.1; trusted = interval.2 }
        }
        return result
    }
    static func edgeLength(height:CGFloat,manual:Bool) -> CGFloat { min(manual ? 30 : 128,max(0,height/2)) }
    static let fontSize: CGFloat = SonoDesktopTokens.FontSize.display
    static func emphasized(_ word:LyricWord) -> Bool {
        word.timed && word.end > word.start && (word.emphasis ?? (word.endSource == .explicit && word.end-word.start >= 1))
    }
}

/// A line keeps moving toward its current destination until the next step
/// reaches it. Timing comes from the display clock, independent of vocal timing.
struct LyricsRowMotion {
    private(set) var position:CGFloat = 0, velocity:CGFloat = 0
    private var target:CGFloat = 0
    private var pending:(target:CGFloat,start:Double)?
    var destination:CGFloat { pending?.target ?? target }
    var isMoving:Bool { pending != nil || abs(target-position)>0.05 || abs(velocity)>0.05 }
    func displayPosition(relativeTo scroll:CGFloat) -> CGFloat {
        // Keep the shared scroll unrestricted. Smoothly bound each row's
        // stagger to a fraction of the line spacing so their ink cannot cross
        // during a long return, even when neighboring springs move apart.
        let limit = LyricsTimeline.lineSpacing/3
        return scroll+limit*tanh((position-scroll)/limit)
    }
    mutating func snap(to value:CGFloat) { position = value; target = value; velocity = 0; pending = nil }
    mutating func move(to value:CGFloat,delay:Double,at now:Double) {
        guard destination != value else { return }
        if delay == 0 { target = value; pending = nil }
        else { pending = (value,now+delay) }
    }
    mutating func advance(dt:Double,at now:Double) {
        var elapsed = dt
        if let pending, now >= pending.start {
            // Split a frame at the scheduled onset so the stagger is independent
            // of display refresh rate, including a frame straddling the boundary.
            let before = max(0,min(dt,pending.start-(now-dt)))
            integrate(before); elapsed -= before
            target = pending.target; self.pending = nil
        }
        integrate(elapsed)
    }
    private mutating func integrate(_ dt:Double) {
        guard dt > 0 else { return }
        // Exact underdamped spring: quick travel with a small settling rebound.
        let decay = 9.0, frequency = sqrt(100-decay*decay)
        let displacement = Double(position-target), speed = Double(velocity)
        let c = cos(frequency*dt), s = sin(frequency*dt), envelope = exp(-decay*dt)
        position = target+CGFloat(envelope*(displacement*c+(speed+decay*displacement)/frequency*s))
        velocity = CGFloat(envelope*(speed*c-(decay*speed+100*displacement)/frequency*s))
    }
}

struct LyricGlyph {
    let font:CTFont; let glyph:CGGlyph; let position:CGPoint
}
struct LyricCoverage {
    let word:LyricWord; let start:CGFloat; let end:CGFloat; let wordIndex:Int
    var sweepOffset:CGFloat = 0; var sweepLength:CGFloat = 0
    func progress(at time:Double,active:Bool) -> Double {
        guard word.timed else { return active ? 1 : 0 }
        // A zero-duration timed mark lights at its timestamp, not at line onset.
        guard word.end>word.start else { return time >= word.start ? 1 : 0 }
        let fraction = min(1,max(0,(time-word.start)/(word.end-word.start)))
        let traveled = fraction*Double(sweepLength)
        return min(1,max(0,(traveled-Double(sweepOffset))/Double(max(0.001,end-start))))
    }
}
struct LyricCluster {
    let range:NSRange; let frame:CGRect; let baseline:CGFloat
    let glyphs:[LyricGlyph]; let rtl:Bool; let coverage:[LyricCoverage]
}
struct LyricTextRow {
    let line:CTLine; let baseline:CGPoint; let height:CGFloat; let clusters:[LyricCluster]
}

@MainActor enum LyricsTypesetter {
    static func shape(_ text:String,words:[LyricWord],size:CGFloat,width:CGFloat,right:Bool,regular:Bool = false,centered:Bool = false,centering:CGFloat = 0) -> [LyricTextRow] {
        let attributed = NSAttributedString(string:text,attributes:[.font:NSFont.systemFont(ofSize:size,weight:regular ? SonoDesktopTokens.NativeFontWeight.regular : SonoDesktopTokens.NativeFontWeight.bold),.foregroundColor:NSColor.white])
        let source = text as NSString, typesetter = CTTypesetterCreateWithAttributedString(attributed)
        var timings:[(NSRange,LyricWord)] = [], cursor = 0
        for word in words {
            let range = NSRange(location:cursor,length:(word.text as NSString).length)
            timings.append((range,word)); cursor += range.length
        }
        var result:[LyricTextRow] = [], index = 0, y:CGFloat = 0
        while index < source.length {
            let count = max(1,CTTypesetterSuggestLineBreak(typesetter,index,Double(max(1,width))))
            let line = CTTypesetterCreateLine(typesetter,CFRange(location:index,length:count))
            var ascent:CGFloat = 0, descent:CGFloat = 0, leading:CGFloat = 0
            let measured = CGFloat(CTLineGetTypographicBounds(line,&ascent,&descent,&leading))
            let slack = max(0,width-measured)
            let alignment = centered ? 1 : centering
            let start = right ? slack : 0
            let origin = CGPoint(x:start + (slack / 2 - start) * alignment,y:y+ascent)
            struct Item { let glyph:LyricGlyph; let index:Int; let advance:CGFloat; let rtl:Bool }
            var items:[Item] = []
            for run in CTLineGetGlyphRuns(line) as! [CTRun] {
                let length = CTRunGetGlyphCount(run)
                let font = (CTRunGetAttributes(run) as NSDictionary)[kCTFontAttributeName] as! CTFont
                var glyphs = [CGGlyph](repeating:0,count:length), positions = [CGPoint](repeating:.zero,count:length)
                var indices = [CFIndex](repeating:0,count:length), advances = [CGSize](repeating:.zero,count:length)
                CTRunGetGlyphs(run,CFRange(location:0,length:0),&glyphs)
                CTRunGetPositions(run,CFRange(location:0,length:0),&positions)
                CTRunGetStringIndices(run,CFRange(location:0,length:0),&indices)
                CTRunGetAdvances(run,CFRange(location:0,length:0),&advances)
                for i in 0..<length {
                    items.append(Item(glyph:LyricGlyph(font:font,glyph:glyphs[i],position:positions[i]),index:indices[i],advance:advances[i].width,rtl:CTRunGetStatus(run).contains(.rightToLeft)))
                }
            }
            // CT indices establish ligature ranges; composed-character ranges
            // unite fallback runs and marks. Neither glyph count nor UTF16 count
            // is used as a proxy for visual width.
            let starts = Array(Set(items.map(\.index))).sorted()
            var buckets:[Int:[Item]] = [:], ranges:[Int:NSRange] = [:]
            for item in items {
                let composed = source.rangeOfComposedCharacterSequence(at:min(source.length-1,item.index))
                let next = starts.first { $0 > item.index } ?? index+count
                let range = NSUnionRange(composed,NSRange(location:item.index,length:max(1,next-item.index)))
                let key = composed.location
                buckets[key,default:[]].append(item)
                ranges[key] = ranges[key].map { NSUnionRange($0,range) } ?? range
            }
            var clusters:[LyricCluster] = []
            for key in buckets.keys.sorted() {
                let group = buckets[key]!, range = ranges[key]!, rtl = group[0].rtl
                let left = group.map { $0.glyph.position.x }.min() ?? 0
                let rightEdge = group.map { $0.glyph.position.x + $0.advance }.max() ?? left
                var ink = CGRect.null
                for item in group {
                    var glyph = item.glyph.glyph
                    let rect = CTFontGetBoundingRectsForGlyphs(item.glyph.font,.horizontal,&glyph,nil,1).offsetBy(dx:item.glyph.position.x,dy:item.glyph.position.y)
                    ink = ink.union(rect)
                }
                let minX = min(left,ink.isNull ? left : ink.minX), maxX = max(rightEdge,ink.isNull ? rightEdge : ink.maxX)
                let top = max(ascent,ink.isNull ? ascent : ink.maxY), bottom = min(-descent,ink.isNull ? -descent : ink.minY)
                let frame = CGRect(x:origin.x+minX,y:origin.y-top,width:max(1,maxX-minX),height:top-bottom)
                var coverage:[LyricCoverage] = []
                for (wordIndex,timing) in timings.enumerated() {
                    let (timingRange,word) = timing
                    let overlap = NSIntersectionRange(timingRange,range)
                    guard overlap.length > 0 else { continue }
                    let a:CGFloat = overlap.location == range.location ? (rtl ? rightEdge : left) : CTLineGetOffsetForStringIndex(line,overlap.location,nil)
                    let b:CGFloat = NSMaxRange(overlap) == NSMaxRange(range) ? (rtl ? left : rightEdge) : CTLineGetOffsetForStringIndex(line,NSMaxRange(overlap),nil)
                    coverage.append(LyricCoverage(word:word,start:origin.x+min(a,b)-frame.minX,end:origin.x+max(a,b)-frame.minX,wordIndex:wordIndex))
                }
                clusters.append(LyricCluster(range:range,frame:frame,baseline:origin.y-frame.minY,glyphs:group.map(\.glyph),rtl:rtl,coverage:coverage))
            }
            let height = max(size*1.22,ascent+descent+leading)
            result.append(LyricTextRow(line:line,baseline:origin,height:height,clusters:clusters))
            y += height; index += count
        }
        // Continuous timing-group travel follows the shaped visual advances,
        // including fallback glyphs and wrapped segments. A word is not restarted
        // independently inside each glyph.
        var lengths:[Int:CGFloat] = [:], consumed:[Int:CGFloat] = [:]
        for row in result { for cluster in row.clusters { for piece in cluster.coverage { lengths[piece.wordIndex,default:0] += piece.end-piece.start } } }
        return result.map { row in
            let clusters = row.clusters.map { cluster in
                let coverage = cluster.coverage.map { piece in
                    var next = piece
                    next.sweepOffset = consumed[piece.wordIndex,default:0]; next.sweepLength = lengths[piece.wordIndex,default:0]
                    consumed[piece.wordIndex,default:0] += piece.end-piece.start
                    return next
                }
                return LyricCluster(range:cluster.range,frame:cluster.frame,baseline:cluster.baseline,glyphs:cluster.glyphs,rtl:cluster.rtl,coverage:coverage)
            }
            return LyricTextRow(line:row.line,baseline:row.baseline,height:row.height,clusters:clusters)
        }
    }
    static func image(_ cluster:LyricCluster,scale:CGFloat,color:NSColor = .white) -> CGImage? {
        let width = max(1,Int(ceil(cluster.frame.width*scale))), height = max(1,Int(ceil(cluster.frame.height*scale)))
        guard let context = CGContext(data:nil,width:width,height:height,bitsPerComponent:8,bytesPerRow:0,space:CGColorSpaceCreateDeviceRGB(),bitmapInfo:CGImageAlphaInfo.premultipliedLast.rawValue) else { return nil }
        context.scaleBy(x:scale,y:scale); context.setFillColor(color.cgColor)
        context.translateBy(x:0,y:cluster.frame.height-cluster.baseline)
        // Glyph positions retain the shaping engine's baseline offsets.
        let lineOriginX = cluster.glyphs.map(\.position.x).min() ?? 0
        var minimumInkX = lineOriginX
        for glyph in cluster.glyphs {
            var value = glyph.glyph
            minimumInkX = min(minimumInkX,CTFontGetBoundingRectsForGlyphs(glyph.font,.horizontal,&value,nil,1).minX+glyph.position.x)
        }
        for item in cluster.glyphs {
            var glyph = item.glyph, position = CGPoint(x:item.position.x-minimumInkX,y:item.position.y)
            CTFontDrawGlyphs(item.font,&glyph,&position,1,context)
        }
        return context.makeImage()
    }
}
