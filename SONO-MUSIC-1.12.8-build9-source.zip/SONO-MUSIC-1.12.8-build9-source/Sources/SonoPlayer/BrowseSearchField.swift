import AppKit
import SwiftUI

/// NSTextInputClient owns marked text and editing shortcuts. Navigation only
/// handles commands after the input method has finished composition.
struct BrowseSearchField: NSViewRepresentable {
    @Binding var text: String
    let scope: Bool
    let placeholder: String
    var focused: Bool
    let caretRequest: Int
    let focusChanged: (Bool) -> Void
    let move: (Int) -> Bool
    let submit: () -> Void
    let close: () -> Void
    let edited: (String, Bool) -> Void
    let clicked: (String) -> Void
    func makeNSView(context: Context) -> BrowseSearchControl { BrowseSearchControl() }
    func updateNSView(_ control: BrowseSearchControl, context: Context) {
        control.textChanged = edited
        control.clicked = clicked
        control.focusChanged = focusChanged; control.move = move; control.submit = submit; control.close = close
        let editor = control.currentEditor() as? NSTextView
        let textChanged = editor?.hasMarkedText() != true && (editor?.string ?? control.stringValue) != text
        if textChanged {
            control.stringValue = text
            editor?.string = text
        }
        let moveCaret = control.caretRequest != caretRequest || textChanged
        control.caretRequest = caretRequest
        control.placeholderAttributedString = NSAttributedString(string: placeholder, attributes: [.foregroundColor: SonoGeneratedColors.searchPlaceholder, .font: NSFont.systemFont(ofSize: SonoDesktopTokens.FontSize.caption)])
        control.setAccessibilityLabel(placeholder)
        let scopeChanged = control.scope != scope
        control.scope = scope
        // AppKit copies the placeholder into the field editor when editing begins.
        // Reattach it after a scope change so clearing a populated field cannot
        // reveal the previous scope's placeholder. Never interrupt IME composition.
        if scopeChanged, let editor = control.currentEditor() as? NSTextView, !editor.hasMarkedText() {
            control.abortEditing()
        }
        control.wantsFocus = focused
        if focused, let window = control.window {
            let restoringFocus = control.currentEditor() == nil
            if restoringFocus { window.makeFirstResponder(control) }
            if scopeChanged || restoringFocus || moveCaret, let editor = control.currentEditor() as? NSTextView, !editor.hasMarkedText() {
                editor.setSelectedRange(NSRange(location: editor.string.utf16.count, length: 0))
            }
        }
        else if !focused, control.currentEditor() != nil { control.window?.makeFirstResponder(nil) }
    }
}

@MainActor
final class BrowseSearchControl: NSTextField, NSTextFieldDelegate {
    var textChanged: (String, Bool) -> Void = { _, _ in }
    var clicked: (String) -> Void = { _ in }
    var focusChanged: (Bool) -> Void = { _ in }
    var move: (Int) -> Bool = { _ in false }
    var submit: () -> Void = {}
    var close: () -> Void = {}
    var wantsFocus = false
    var caretRequest = 0
    var scope: Bool?
    override init(frame frameRect: NSRect) {
        super.init(frame: frameRect)
        cell = BrowseSearchCell(textCell: "")
        isBordered = false; isBezeled = false; drawsBackground = false; focusRingType = .none
        isEditable = true; isSelectable = true
        textColor = SonoGeneratedColors.primaryText; font = NSFont.systemFont(ofSize: SonoDesktopTokens.FontSize.caption)
        delegate = self; cell?.usesSingleLineMode = true; cell?.isScrollable = true
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    override func mouseDown(with event: NSEvent) {
        super.mouseDown(with: event)
        if let editor = currentEditor() as? NSTextView, !editor.hasMarkedText() {
            clicked(editor.string)
        }
    }
    override func viewDidMoveToWindow() {
        super.viewDidMoveToWindow()
        if wantsFocus {
            window?.makeFirstResponder(self)
            (currentEditor() as? NSTextView)?.setSelectedRange(NSRange(location: stringValue.utf16.count, length: 0))
        }
    }
    func controlTextDidBeginEditing(_ obj: Notification) { focusChanged(true) }
    func controlTextDidEndEditing(_ obj: Notification) { focusChanged(false) }
    func controlTextDidChange(_ obj: Notification) {
        if (currentEditor() as? NSTextView)?.hasMarkedText() != true && stringValue.count > 200 { stringValue = String(stringValue.prefix(200)) }
        textChanged(stringValue, (currentEditor() as? NSTextView)?.hasMarkedText() == true)
    }
}

/// The field editor receives marked-text updates before NSTextField commits them.
/// Keep IME composition intact while exposing its current draft to suggestions.
@MainActor
private final class BrowseSearchEditor: NSTextView {
    weak var searchControl: BrowseSearchControl?
    override func mouseDown(with event: NSEvent) {
        super.mouseDown(with: event)
        if !hasMarkedText() { searchControl?.clicked(string) }
    }
    override func keyDown(with event: NSEvent) {
        // Let the input method consume keys while it owns marked text.
        if !hasMarkedText(), let searchControl {
            switch event.keyCode {
            case 53:
                searchControl.close()
                return
            case 36, 76:
                searchControl.submit()
                return
            case 125:
                if searchControl.move(1) { return }
            case 126:
                if searchControl.move(-1) { return }
            default:
                break
            }
        }
        super.keyDown(with: event)
    }
    override func setMarkedText(_ string: Any, selectedRange: NSRange, replacementRange: NSRange) {
        super.setMarkedText(string, selectedRange: selectedRange, replacementRange: replacementRange)
        searchControl?.textChanged(self.string, hasMarkedText())
    }
}
@MainActor
private final class BrowseSearchCell: NSTextFieldCell {
    private let searchEditor = BrowseSearchEditor()
    override func fieldEditor(for controlView: NSView) -> NSTextView? {
        searchEditor.isFieldEditor = true
        searchEditor.searchControl = controlView as? BrowseSearchControl
        return searchEditor
    }
}

/// The window observes clicks outside the full search capsule without consuming them.
struct SearchClickRegion: NSViewRepresentable {
    let onOutsideClick: () -> Void

    func makeNSView(context: Context) -> Region { Region() }
    func updateNSView(_ region: Region, context: Context) {
        region.onOutsideClick = onOutsideClick
    }

    final class Region: NSView {
        var onOutsideClick: (() -> Void)?

        override func viewDidMoveToWindow() {
            super.viewDidMoveToWindow()
            (window as? SonoWindow)?.searchClickRegion = self
        }

        override func hitTest(_ point: NSPoint) -> NSView? { nil }
    }
}
