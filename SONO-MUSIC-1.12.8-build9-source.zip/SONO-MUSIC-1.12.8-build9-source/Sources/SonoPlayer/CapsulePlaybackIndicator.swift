import SwiftUI
import AppKit

struct CapsulePlaybackIndicator: View {
    let playing: Bool
    @Environment(\.sonoTheme) private var theme
    var foreground: NSColor? = nil
    var size: CGFloat = SonoDesktopTokens.IndicatorSize.small
    @Environment(\.accessibilityReduceMotion) private var reduced
    @Environment(\.sonoWindowContentVisible) private var windowContentVisible
    @ViewState private var started = Date()
    var body: some View {
        IndicatorBars(size: size, color: foreground ?? theme.accent,
                      moving: playing && !reduced && windowContentVisible, started: started)
            .onChange(of: playing) { _, _ in started = Date() }
            .accessibilityLabel(playing ? "正在播放" : "已暂停").allowsHitTesting(false)
    }
}

/// Animate the bar bounds in the compositor so each frame keeps a circular end cap.
private struct IndicatorBars: NSViewRepresentable {
    let size: CGFloat
    let color: NSColor
    let moving: Bool
    let started: Date

    func makeNSView(context: Context) -> BarsView { BarsView() }
    func updateNSView(_ view: BarsView, context: Context) {
        view.update(size: size, color: color, moving: moving, started: started)
    }

    final class BarsView: NSView {
        private let bars = (0..<3).map { _ in CALayer() }
        private var barSize: CGFloat = 0
        private var animationStart: Date?
        private var foreground: NSColor?
        override init(frame: NSRect) {
            super.init(frame: frame)
            wantsLayer = true
            for bar in bars { layer?.addSublayer(bar) }
            setAccessibilityElement(false)
        }
        required init?(coder: NSCoder) { nil }
        override func hitTest(_ point: NSPoint) -> NSView? { nil }
        override func viewDidChangeEffectiveAppearance() {
            super.viewDidChangeEffectiveAppearance()
            updateBarColor()
        }
        private func updateBarColor() {
            guard let foreground else { return }
            let color = foreground.sonoCGColor(in: effectiveAppearance)
            CATransaction.begin()
            CATransaction.setDisableActions(true)
            for bar in bars { bar.backgroundColor = color }
            CATransaction.commit()
        }
        override func layout() {
            super.layout()
            CATransaction.begin()
            CATransaction.setDisableActions(true)
            for (index, bar) in bars.enumerated() {
                bar.position = CGPoint(x: bounds.midX + CGFloat(index - 1) * 5 * barSize / 14,
                                       y: bounds.midY)
            }
            CATransaction.commit()
        }
        func update(size: CGFloat, color: NSColor, moving: Bool, started: Date) {
            foreground = color
            updateBarColor()
            let restart = animationStart != (moving ? started : nil) || barSize != size
            barSize = size
            animationStart = moving ? started : nil
            CATransaction.begin()
            CATransaction.setDisableActions(true)
            defer { CATransaction.commit() }
            for (index, bar) in bars.enumerated() {
                let width = 3 * size / 14
                bar.cornerRadius = width / 2
                let resting: [CGFloat] = [0.35, 0.75, 0.5]
                bar.bounds = CGRect(x: 0, y: 0, width: width, height: size * resting[index])
                if restart {
                    bar.removeAnimation(forKey: "height")
                    if moving {
                        let animation = CABasicAnimation(keyPath: "bounds.size.height")
                        animation.fromValue = size * 0.25
                        animation.toValue = size
                        animation.duration = 0.8
                        animation.autoreverses = true
                        animation.repeatCount = .infinity
                        animation.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
                        animation.beginTime = bar.convertTime(CACurrentMediaTime(), from: nil)
                            - max(0, Date().timeIntervalSince(started)) - Double(index) * 0.3
                        bar.add(animation, forKey: "height")
                    }
                }
            }
            needsLayout = true
        }
    }
}
