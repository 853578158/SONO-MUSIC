import Foundation

struct AutomaticLyricRecord: Codable, Sendable {
    var date: Date
    var document: LyricDocument?
    var source: String
    var preference: LyricSource
    var parserVersion: Int?
    var localVersion: String? = nil
}

/// One owner serializes both automatic and community cache files off the UI actor.
actor LyricsCacheStorage {
    static let shared = LyricsCacheStorage()
    struct CommunityRecord: Codable, Sendable { let date: Date; let data: Data }
    private let directory: URL
    private var automatic: [String: AutomaticLyricRecord] = [:]
    private var community: [String: CommunityRecord] = [:]
    private var loaded = false
    private let communityFilename: String
    init(directory: URL = FolderStore().url.deletingLastPathComponent(), communityFilename:String = "lyrics-community-cache-v1.json") { self.directory = directory; self.communityFilename = communityFilename }
    private func load() {
        guard !loaded else { return }; loaded = true
        if let data = try? Data(contentsOf: directory.appendingPathComponent("lyrics-auto-v1.json")), let value = try? JSONDecoder().decode([String:AutomaticLyricRecord].self, from:data) { automatic = value }
        if let data = try? Data(contentsOf: directory.appendingPathComponent(communityFilename)), let value = try? JSONDecoder().decode([String:CommunityRecord].self, from:data) { community = value }
        trim()
    }
    func automaticRecord(_ key: String) -> AutomaticLyricRecord? { load(); return automatic[key] }
    func communityRecord(_ key: String) -> CommunityRecord? { load(); return community[key] }
    func setAutomatic(_ record: AutomaticLyricRecord?, for key:String) throws {
        load(); try Task.checkCancellation(); automatic[key] = record; trim(); try persist()
    }
    func setCommunity(_ record: CommunityRecord, for key:String) throws {
        load(); try Task.checkCancellation(); community[key] = record; trim(); try persist()
    }
    private func trim() {
        // Serialized payload size is a conservative, deterministic ownership budget.
        func cost() -> Int { ((try? JSONEncoder().encode(automatic).count) ?? 0) + community.values.reduce(0) { $0 + $1.data.count + 128 } }
        while automatic.count + community.count > 256 || cost() > 16 * 1024 * 1024 {
            let a = automatic.min { $0.value.date < $1.value.date }
            let c = community.min { $0.value.date < $1.value.date }
            if let a, c == nil || a.value.date <= c!.value.date { automatic[a.key] = nil }
            else if let c { community[c.key] = nil }
            else { break }
        }
    }
    private func persist() throws {
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories:true)
        try JSONEncoder().encode(automatic).write(to:directory.appendingPathComponent("lyrics-auto-v1.json"),options:.atomic)
        try JSONEncoder().encode(community).write(to:directory.appendingPathComponent(communityFilename),options:.atomic)
    }
    #if DEBUG
    func validationCounts() -> (automatic:Int, community:Int) { load(); return (automatic.count, community.count) }
    #endif
    func read<T:Decodable & Sendable>(_ type:T.Type, at url:URL) throws -> T? {
        guard FileManager.default.fileExists(atPath:url.path) else { return nil }
        return try JSONDecoder().decode(type,from:Data(contentsOf:url))
    }
    /// A UI state may not have hydrated yet. Merge only its edited key against
    /// the actor-owned disk document rather than replacing unrelated records.
    func updateManual<T:Codable & Sendable>(_ record:T?, for key:String, at url:URL) throws {
        var records = try read([String:T].self,at:url) ?? [:]
        records[key] = record
        try write(records,at:url)
    }
    func write<T:Encodable & Sendable>(_ value:T, at url:URL) throws {
        try FileManager.default.createDirectory(at:url.deletingLastPathComponent(),withIntermediateDirectories:true)
        try JSONEncoder().encode(value).write(to:url,options:.atomic)
    }
}

/// Synchronous filesystem access and format parsing never execute on the UI actor.
actor LyricsParsingWorker {
    static let shared = LyricsParsingWorker()
    struct LocalResult: Sendable { let document:LyricDocument; let error:String? }
    func parse(_ text:String,format:String) throws -> LyricDocument {
        try Task.checkCancellation()
        return try LyricsParser.parse(text,format:format)
    }
    func version(_ track:LocalTrack) -> String {
        ([track.url] + LyricsParser.formats.map { track.url.deletingPathExtension().appendingPathExtension($0) }).map { file in
            let attributes = try? FileManager.default.attributesOfItem(atPath:file.path)
            return file.path + ":" + String(describing:attributes?[.modificationDate]) + ":" + String(describing:attributes?[.size])
        }.joined(separator:"|")
    }
    func local(_ track:LocalTrack) throws -> LocalResult {
        var candidates:[LyricDocument] = [], failure:String?
        for format in LyricsParser.formats {
            try Task.checkCancellation()
            let file = track.url.deletingPathExtension().appendingPathExtension(format)
            guard FileManager.default.fileExists(atPath:file.path) else { continue }
            do {
                let text = format == "krc" ? try LyricProviders.krc(Data(contentsOf:file)) : try String(contentsOf:file,encoding:.utf8)
                candidates.append(try LyricsParser.parse(text,format:format))
            } catch { failure = "已跳过损坏的歌词：" + file.lastPathComponent }
        }
        try Task.checkCancellation()
        return LocalResult(document:candidates.first(where: \.wordTimed) ?? candidates.first ?? .init(),error:failure)
    }
}
