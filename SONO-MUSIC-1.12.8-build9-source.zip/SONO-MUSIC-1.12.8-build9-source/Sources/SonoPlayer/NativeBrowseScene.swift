import AppKit
import SwiftUI
import QuartzCore
import CoreText
import CoreImage

enum BrowseEntranceTiming {
    static func remainingDelay(distance: CGFloat, elapsed: CFTimeInterval) -> CFTimeInterval {
        max(0, Double(max(0, distance)) * 0.0012 - max(0, elapsed))
    }
}

// Distance to actual ready tiles, rather than the bounding box of a loaded region:
// a hole between two separated groups must still be filled from its nearest edge.
enum WallArtworkLoading {
    static func distance(_ rect: CGRect, loaded: [CGRect], fallback: CGPoint) -> CGFloat {
        loaded.map { ready in
            hypot(max(rect.minX - ready.maxX, ready.minX - rect.maxX, 0),
                  max(rect.minY - ready.maxY, ready.minY - rect.maxY, 0))
        }.min() ?? hypot(max(rect.minX - fallback.x, fallback.x - rect.maxX, 0),
                        max(rect.minY - fallback.y, fallback.y - rect.maxY, 0))
    }
}

struct NativeBrowseScene: NSViewRepresentable {
    @AppStorage("wallLightLightsOn", store: PerformanceEnvironment.defaults) private var wallLightLightsOn = true
    @AppStorage("wallLightAlwaysShowInfo", store: PerformanceEnvironment.defaults) private var wallLightAlwaysShowInfo = false
    @AppStorage("wallDarkLightsOn", store: PerformanceEnvironment.defaults) private var wallDarkLightsOn = false
    @AppStorage("wallDarkAlwaysShowInfo", store: PerformanceEnvironment.defaults) private var wallDarkAlwaysShowInfo = true
    @Environment(\.sonoTheme) private var theme
    @Environment(\.colorScheme) private var colorScheme
    @Environment(\.songActions) private var songActions
    @Environment(\.isEnabled) private var enabled
    let tracks: [LocalTrack]
    var items: [BrowseItem]? = nil
    var activateEntity: (BrowseEntity) -> Void = { _ in }
    @ObservedObject var browser: MusicBrowser
    let reduceMotion: Bool
    var presented = true
    var excludedInteractionRect: CGRect? = nil
    var orderedIDs: [String] = []
    var detailDemand: ([String]) -> Void = { _ in }
    var priorityDetailDemand: ([String]) -> Void = { _ in }
    var unresolvedPlay: (String) -> Void = { _ in }
    var currentID: String? = nil
    var playing = false
    var pendingID: String?
    var failures: [String: String] = [:]
    var hasMore = false
    var dismiss: () -> Void = {}
    var catalog: (LocalTrack, Bool) -> Void = { _, _ in }
    let play: (LocalTrack) -> Void
    func makeNSView(context: Context) -> BrowseCanvas { BrowseCanvas() }
    func updateNSView(_ view: BrowseCanvas, context: Context) {
        view.theme = theme
        view.wallLightMode = colorScheme == .light
        view.wallLightsOn = colorScheme == .light ? wallLightLightsOn : wallDarkLightsOn
        view.wallAlwaysShowInfo = colorScheme == .light ? wallLightAlwaysShowInfo : wallDarkAlwaysShowInfo
        view.songActions = songActions
        view.setPresented(presented)
        view.setCarouselCallbacks(demand: detailDemand, play: unresolvedPlay)
        view.priorityDetailDemand = priorityDetailDemand
        view.excludedInteractionRect = excludedInteractionRect
        view.interactionEnabled = enabled
        view.configureItems(tracks: items ?? tracks.map(BrowseItem.song), browser: browser, reduceMotion: reduceMotion, orderedIDs: orderedIDs, currentID: currentID, playing: playing, pendingID: pendingID, failures: failures, hasMore: hasMore, dismiss: dismiss, catalog: { item, album in if let song = item.song { catalog(song, album) } }, play: { item in if let song = item.song { play(song) } else if let entity = item.entity { activateEntity(entity) } })
    }
    static func dismantleNSView(_ view: BrowseCanvas, coordinator: ()) { view.dispose() }
}

@MainActor
final class BrowseCanvas: NSView {
    var theme = SonoTheme.pink {
        didSet {
            guard theme != oldValue else { return }
            CATransaction.begin()
            CATransaction.setDisableActions(true)
            for card in cards.values { card.updateIndicatorColor(theme.accent) }
            CATransaction.commit()
        }
    }
    var wallLightMode = false { didSet { if oldValue != wallLightMode { refreshWallAppearance() } } }
    var wallLightsOn = false { didSet { if oldValue != wallLightsOn { refreshWallAppearance() } } }
    var wallAlwaysShowInfo = true { didSet { if oldValue != wallAlwaysShowInfo { refreshWallAppearance() } } }
    private static let wallLightsOffOpacity: CGFloat = 0.8

    private func browseBackground(wall: Bool) -> CGColor {
        let background = SonoGeneratedColors.pageBackground.sonoResolved(in: effectiveAppearance)
        if wall && wallLightMode && !wallLightsOn {
            return (background.blended(withFraction: Self.wallLightsOffOpacity, of: .black) ?? background).cgColor
        }
        return background.cgColor
    }

    private func refreshWallAppearance() {
        guard browser?.layout == .wall else { return }
        CATransaction.begin(); CATransaction.setDisableActions(true)
        layer?.backgroundColor = browseBackground(wall: true)
        for card in cards.values { applyWallAppearance(card) }
        CATransaction.commit()
    }
    private func wallBlackOpacity(_ card: Card) -> Float {
        let focused = keyboardFocusVisible && window?.firstResponder === self && keyboardTarget.flatMap { cards[$0.id] } === card
        if wallLightMode && (card.hovered || focused) { return 0.4 }
        return wallLightsOn ? 0 : card.expanded ? 0.12 : card.hovered ? 0.3 : Float(Self.wallLightsOffOpacity)
    }
    private func applyWallAppearance(_ card: Card) {
        let visible = wallAlwaysShowInfo || card.expanded || card.hovered || (keyboardFocusVisible && window?.firstResponder === self && keyboardTarget.flatMap { cards[$0.id] } === card)
        card.black.opacity = wallBlackOpacity(card)
        card.titleClip.opacity = visible ? 1 : 0
        card.artistClip.opacity = visible ? 1 : 0
        card.shade.opacity = visible ? 0.5 : 0
    }
    var songActions = SongActions()
    override func menu(for event: NSEvent) -> NSMenu? {
        guard presented, !layoutTransitionActive,
              let hit = target(at: convert(event.locationInWindow, from: nil)),
              let index = trackData?.index[hit.id], tracks.indices.contains(index) else { return nil }
        guard let song = tracks[index].song else { return nil }; return songActions.menu(for: song)
    }

    private var presented = true
    private var presentationRefresh:(() -> Void)?
    func setPresented(_ value:Bool) {
        guard presented != value else { return }
        presented = value; isHidden = !value
        if !value {
            stopCompactPreview(); closeScroll(); cancelDirectionalRequests(); cancelCarouselRequests()
            panLink?.invalidate(); panLink = nil
            snapLink?.invalidate(); snapLink = nil; motion = nil
        } else {
            let refresh = presentationRefresh; presentationRefresh = nil; refresh?()
        }
    }
    private var listMagnification: CGFloat = 0
    private var listPinchActive = false
    private func restoreListPinch() {
        guard listPinchActive else { return }
        CATransaction.begin(); CATransaction.setDisableActions(true); content.opacity = 1; CATransaction.commit()
        listPinchActive = false; listMagnification = 0
    }
    override func magnify(with event: NSEvent) {
        guard browser?.layout == .carousel, ownsPointer(at: convert(event.locationInWindow, from: nil)) else { return }
        if event.phase.contains(.began) { restoreListPinch(); closeScroll(); listPinchActive = true }
        listMagnification += event.magnification
        let progress = min(1, max(0, (-listMagnification - 0.03) / 0.22))
        CATransaction.begin(); CATransaction.setDisableActions(true)
        content.opacity = Float(1 - progress * 0.25)
        CATransaction.commit()
        if event.phase.contains(.cancelled) { restoreListPinch(); return }
        if event.phase.contains(.ended) {
            let open = listMagnification <= -0.15
            restoreListPinch()
            if open { browser?.enterQuickList() }
        }
    }
    var excludedInteractionRect: CGRect?
    override func hitTest(_ point: NSPoint) -> NSView? {
        guard interactionEnabled, excludedInteractionRect?.contains(convert(point, from: superview)) != true else { return nil }
        return super.hitTest(point)
    }
    var interactionEnabled = true {
        didSet { if !interactionEnabled { clearPointerFeedback(); carouselRail.isHidden = true; carouselRail.reset() } }
    }
    @MainActor
    private final class Card {
        let root = CALayer()
        let image = CALayer()
        let placeholder = CALayer()
        let carouselShade = CALayer()
        var reflection: CALayer?
        let artworkReason = CATextLayer()
        let title = CATextLayer()
        let artist = CATextLayer()
        let titleClip = CALayer(), artistClip = CALayer()
        private var readingLine: Int?
        private struct ContentLayout: Equatable {
            let size: CGSize
            let scale: CGFloat
            let sceneScale: CGFloat
            let wall: Bool
            let center: Bool
            let playing: Bool
            let indicated: Bool
            let dark: Bool
            let reduced: Bool
            let hovered: Bool
            let title: String
            let artist: String
        }
        private var contentLayout: ContentLayout?
        let shade = CAGradientLayer()
        let black = CALayer()
        let coverMask = CALayer()
        let failureShade = CALayer()
        let failureTitle = CATextLayer()
        let playback = CAShapeLayer()
        let playbackGlyph = CALayer()
        let indicator = CAShapeLayer()
        private var indicatorColor = SonoTheme.pink.accent

        func updateIndicatorColor(_ color: NSColor) {
            indicatorColor = color
            let fill = color.sonoCGColor(in: NSApp.effectiveAppearance)
            for bar in indicator.sublayers ?? [] { bar.backgroundColor = fill }
        }
        private struct StatusLayout: Equatable {
            let size: CGSize, scale: CGFloat
            let pending: Bool, failed: Bool, wall: Bool, center: Bool, hovered: Bool
        }
        private var statusLayout: StatusLayout?
        var token: UUID?
        var accessibility: BrowseCardAccessibility?
        var accessibilityLabel = ""
        var accessibilitySelected: Bool?
        var accessibilityLinkLabels: [Bool: String] = [:]
        var accessibilityPlayLabel = ""
        var playAccessibility: BrowseCardAccessibility?
        var links: [Bool: BrowseCardAccessibility] = [:]
        var requestedPixels = 0
        var loadedPixels = 0
        var loadedSize = CGSize.zero
        var hasRealArtwork = false
        var artworkGeneration: UInt64 = 0
        var presentationKey: String?
        var url: URL?
        enum ArtworkResult { case pending, complete, failed }
        var artworkResult = ArtworkResult.pending
        var artworkReady = false
        var revealed = false
        var retiring = false
        var retirementGeneration: UInt64 = 0
        var index: Int
        var expanded = false
        var hovered = false
        let playable: Bool
        init(track: BrowseItem, index: Int) {
            playable = track.song != nil
            self.index = index
            placeholder.name = "carousel-placeholder"
            placeholder.contents = SonoAssets.bitmap("local-default", pixels: 720)
            placeholder.contentsGravity = .resizeAspectFill
            placeholder.isHidden = true
            image.name = "artwork"; coverMask.name = "cover-mask"
            root.masksToBounds = true; root.backgroundColor = SonoGeneratedColors.artworkPlaceholder.sonoCGColor(in: NSApp.effectiveAppearance)
            image.contentsGravity = .resizeAspectFill; image.masksToBounds = true
            carouselShade.backgroundColor = NSColor.black.cgColor; carouselShade.opacity = 0
            artworkReason.name = "artwork-reason"; artworkReason.alignmentMode = .right
            artworkReason.font = SonoTypography.native(size: SonoDesktopTokens.FontSize.body, weight: SonoDesktopTokens.FontWeight.regular); artworkReason.fontSize = SonoDesktopTokens.FontSize.body
            artworkReason.foregroundColor = SonoGeneratedColors.artworkReason.sonoCGColor(in: NSApp.effectiveAppearance)
            artworkReason.truncationMode = .end; artworkReason.isHidden = true
            root.addSublayer(artworkReason); artworkReason.zPosition = 10

            for text in [title, artist] { text.truncationMode = .end; text.alignmentMode = .left }
            title.string = track.title; artist.string = track.artist
            shade.colors = [NSColor.black.cgColor, NSColor.clear.cgColor]
            shade.startPoint = CGPoint(x: 0.5, y: 0); shade.endPoint = CGPoint(x: 0.5, y: 1)
            black.backgroundColor = NSColor.black.cgColor
            playback.fillColor = SonoGeneratedColors.artworkControlSurface.sonoCGColor(in: NSApp.effectiveAppearance)
            playbackGlyph.contentsGravity = .resizeAspect
            indicator.fillColor = SonoGeneratedColors.artworkControlSurface.sonoCGColor(in: NSApp.effectiveAppearance)
            titleClip.masksToBounds = true; artistClip.masksToBounds = true
            titleClip.name = "cover-title"; artistClip.name = "cover-artist"
            titleClip.addSublayer(title); artistClip.addSublayer(artist)
            coverMask.addSublayer(shade); coverMask.addSublayer(black)
            // Status layers join the tree only when their content is visible.
            // Ordinary wall cards need neither loading text nor failure overlays.
            for layer in [image, carouselShade, placeholder, coverMask, titleClip, artistClip, playback, playbackGlyph, indicator] { root.addSublayer(layer) }
        }
        private static var playbackSymbols: [String: CGImage] = [:]

        private static func playbackSymbol(playing: Bool, center: Bool, dark: Bool) -> CGImage? {
            let name = playing ? "pause.fill" : "play.fill"
            let pointSize = center ? SonoDesktopTokens.SymbolSize.coverPlaybackCenterGlyph : SonoDesktopTokens.SymbolSize.coverPlaybackGlyph
            let key = "\(name)-\(pointSize)-\(dark)"
            if let cached = playbackSymbols[key] { return cached }

            let side = center ? SonoDesktopTokens.IconFrame.coverPlaybackCenter : SonoDesktopTokens.IconFrame.s28
            let rasterScale: CGFloat = 3
            let pixels = Int(side * rasterScale)
            guard let symbol = NSImage(systemSymbolName: name, accessibilityDescription: nil)?
                .withSymbolConfiguration(.init(pointSize: pointSize, weight: SonoDesktopTokens.NativeFontWeight.regular)),
                  let bitmap = NSBitmapImageRep(bitmapDataPlanes: nil, pixelsWide: pixels, pixelsHigh: pixels,
                                                bitsPerSample: 8, samplesPerPixel: 4, hasAlpha: true,
                                                isPlanar: false, colorSpaceName: .deviceRGB, bytesPerRow: 0, bitsPerPixel: 0),
                  let context = NSGraphicsContext(bitmapImageRep: bitmap) else { return nil }
            let bounds = CGRect(x: 0, y: 0, width: pixels, height: pixels)
            let scale = min(rasterScale, bounds.width / max(symbol.size.width, symbol.size.height))
            let size = CGSize(width: symbol.size.width * scale, height: symbol.size.height * scale)
            // The triangle carries more ink on the left. Scale the optical inset with the glyph.
            let opticalInset = playing ? 0 : pointSize / 22 * rasterScale
            let rect = CGRect(x: bounds.midX - size.width / 2 + opticalInset, y: bounds.midY - size.height / 2,
                              width: size.width, height: size.height)
            let appearance = NSAppearance(named: dark ? .darkAqua : .aqua)!
            NSGraphicsContext.saveGraphicsState()
            NSGraphicsContext.current = context
            symbol.draw(in: rect, from: .zero, operation: .copy, fraction: 1)
            context.cgContext.setBlendMode(.sourceIn)
            context.cgContext.setFillColor(SonoGeneratedColors.artworkControlInk.sonoCGColor(in: appearance))
            context.cgContext.fill(bounds)
            NSGraphicsContext.restoreGraphicsState()
            playbackSymbols[key] = bitmap.cgImage
            return bitmap.cgImage
        }

        func sizeContents(_ size: CGSize, scale: CGFloat, sceneScale: CGFloat, wall: Bool, center: Bool, playing: Bool, indicated: Bool, motionReduced: Bool = false) {
            let dark = NSApp.effectiveAppearance.bestMatch(from: [.darkAqua, .aqua]) == .darkAqua
            let layout = ContentLayout(size: size, scale: scale, sceneScale: sceneScale, wall: wall, center: center,
                                       playing: playing, indicated: indicated, dark: dark, reduced: motionReduced, hovered: hovered,
                                       title: title.string as? String ?? "", artist: artist.string as? String ?? "")
            guard contentLayout != layout else { return }
            contentLayout = layout
            let box = CGRect(origin: .zero, size: size)
            root.cornerRadius = 8 * sceneScale
            placeholder.frame = box
            if wall { carouselShade.opacity = 0 }
            image.frame = box; carouselShade.frame = box; coverMask.frame = box; black.frame = box
            artworkReason.contentsScale = scale
            artworkReason.frame = CGRect(x: 12, y: max(0, size.height - 32), width: max(0, size.width - 24), height: 20)
            shade.frame = CGRect(x: 0, y: 0, width: size.width, height: size.height / 2)
            let inset = center ? 28 * sceneScale : 12
            let width = max(0, size.width - 2 * inset)
            for text in [title, artist] { text.contentsScale = scale }
            title.font = SonoTypography.native(size: SonoDesktopTokens.FontSize.itemTitle, weight: SonoDesktopTokens.FontWeight.semibold); title.fontSize = SonoDesktopTokens.FontSize.itemTitle
            artist.font = SonoTypography.native(size: SonoDesktopTokens.FontSize.body, weight: SonoDesktopTokens.FontWeight.medium); artist.fontSize = SonoDesktopTokens.FontSize.body
            title.foregroundColor = (center || hovered ? SonoGeneratedColors.primaryText : SonoGeneratedColors.noncenterTitle).sonoCGColor(in: .sonoArtwork)
            artist.foregroundColor = (center || hovered ? SonoGeneratedColors.primaryText : SonoGeneratedColors.noncenterArtist).sonoCGColor(in: .sonoArtwork)
            let titleWidth = min(width, ceil(SonoTypography.width(title.string as? String ?? "", size: SonoDesktopTokens.FontSize.itemTitle, weight: SonoDesktopTokens.FontWeight.semibold)))
            let artistWidth = min(width, ceil(SonoTypography.width(artist.string as? String ?? "", size: SonoDesktopTokens.FontSize.body, weight: SonoDesktopTokens.FontWeight.medium)))
            titleClip.frame = CGRect(x: inset, y: inset, width: titleWidth, height: 22.4)
            artistClip.frame = CGRect(x: inset, y: inset + 22.4 + 4 * sceneScale, width: artistWidth, height: 19.6)
            title.frame = CGRect(x: 0, y: 0, width: width, height: 22.4)
            artist.frame = CGRect(x: 0, y: 0, width: width, height: 19.6)
            updateReading(readingLine, reduced: motionReduced)
            titleClip.opacity = wall ? 1 : 0; artistClip.opacity = wall ? 1 : 0
            title.opacity = 1; artist.opacity = 1
            let side = center ? SonoDesktopTokens.Component.coverPlayCenter : SonoDesktopTokens.Component.coverPlay
            // Bounds and position stay independent of the hover transform.
            playback.bounds = CGRect(x: 0, y: 0, width: side, height: side)
            playback.position = CGPoint(x: size.width / 2, y: size.height / 2)
            playback.path = CGPath(ellipseIn: CGRect(x: 0, y: 0, width: side, height: side), transform: nil)
            let glyphSide = center ? SonoDesktopTokens.IconFrame.coverPlaybackCenter : SonoDesktopTokens.IconFrame.s28
            playbackGlyph.bounds = CGRect(x: 0, y: 0, width: glyphSide, height: glyphSide)
            playbackGlyph.position = playback.position
            playbackGlyph.contents = Self.playbackSymbol(playing: playing, center: center, dark: dark)
            playback.opacity = playable && hovered && (wall || center) ? 1 : 0; playbackGlyph.opacity = playback.opacity
            let badgeSide = SonoDesktopTokens.Component.inlineAction
            let waveCanvas = SonoDesktopTokens.SvgSize.s20
            indicator.frame = CGRect(x: 14, y: max(0, size.height - 14 - badgeSide), width: badgeSide, height: badgeSide)
            indicator.path = nil; indicator.backgroundColor = SonoGeneratedColors.artworkPlayScrim.sonoCGColor(in: NSApp.effectiveAppearance); indicator.cornerRadius = 5
            if indicated && indicator.sublayers == nil { for _ in 0..<3 { let bar = CALayer(); bar.backgroundColor = indicatorColor.sonoCGColor(in: NSApp.effectiveAppearance); bar.cornerRadius = 1; indicator.addSublayer(bar) } }
            for (i, height) in (indicator.sublayers == nil ? [] : [9.0, 13, 6]).enumerated() {
                let bar = indicator.sublayers![i]
                bar.bounds = CGRect(x: 0, y: 0, width: 2, height: height); bar.position = CGPoint(x: badgeSide / 2 + CGFloat(i - 1) * waveCanvas / 4, y: badgeSide / 2)
                if indicated && !motionReduced && bar.animation(forKey: "pulse") == nil {
                    let animation = CAKeyframeAnimation(keyPath: "bounds.size.height")
                    animation.values = [height, 3, height]; animation.keyTimes = [0, 0.5, 1]; animation.duration = 1.6; animation.repeatCount = .infinity
                    animation.timingFunctions = [CAMediaTimingFunction(name: .easeInEaseOut), CAMediaTimingFunction(name: .easeInEaseOut)]
                    animation.beginTime = CACurrentMediaTime() - [0.0, 0.4, 0.2][i]; bar.add(animation, forKey: "pulse")
                } else if motionReduced || !indicated { bar.removeAnimation(forKey: "pulse") }
            }
            indicator.opacity = indicated && playing && !center && wall ? 1 : 0
        }
        func updateReflection(in content: CALayer, visible: Bool, following tile: CALayer, backgroundColor: CGColor) {
            guard visible, let bitmap = image.contents as AnyObject? else { reflection?.isHidden = true; return }
            let mirror: CALayer
            if let reflection { mirror = reflection }
            else {
                mirror = CALayer(); mirror.name = "carousel-reflection"
                mirror.masksToBounds = true
                // Each matte occludes farther mirrors before the whole group is dimmed.
                let reveal = CALayer(); reveal.name = "reflection-reveal"
                let revealMask = CALayer(); revealMask.anchorPoint = .zero
                revealMask.backgroundColor = NSColor.black.cgColor; reveal.mask = revealMask
                mirror.addSublayer(reveal)
                let background = CALayer(); background.backgroundColor = backgroundColor
                mirror.insertSublayer(background, above: reveal)
                background.zPosition = -1
                let reflectionContent = CALayer()
                // Clip after filtering so the vertical blur keeps hard side edges.
                reflectionContent.masksToBounds = true
                reveal.addSublayer(reflectionContent)
                let reflectedImage = CALayer(); reflectedImage.contentsGravity = .resizeAspectFill
                reflectedImage.masksToBounds = true
                reflectedImage.transform = CATransform3DMakeScale(1, -1, 1)
                if let blur = CIFilter(name: "CIMotionBlur") {
                    blur.setValue(5, forKey: kCIInputRadiusKey)
                    blur.setValue(Double.pi / 2, forKey: kCIInputAngleKey)
                    reflectedImage.filters = [blur]
                }
                reflectionContent.addSublayer(reflectedImage)
                let dim = CALayer(); dim.backgroundColor = NSColor.black.cgColor
                reflectionContent.addSublayer(dim)
                let fade = CAGradientLayer()
                fade.colors = [NSColor.black.cgColor, NSColor.clear.cgColor, NSColor.clear.cgColor]
                fade.locations = [0, 0.4, 1]
                fade.startPoint = CGPoint(x: 0.5, y: 0); fade.endPoint = CGPoint(x: 0.5, y: 1)
                reflectionContent.mask = fade
                content.addSublayer(mirror); reflection = mirror
            }
            // Keep the target crop throughout the shared-cover handoff. Only
            // the mirror's outer pose follows the borrowed wall layer.
            let size = root.bounds.size
            let reflectionTop = size.height - root.cornerRadius
            let height = reflectionTop + size.height
            mirror.isHidden = false
            mirror.anchorPoint = CGPoint(x: 0.5, y: size.height / 2 / height)
            mirror.bounds = CGRect(x: 0, y: 0, width: size.width, height: height)
            mirror.position = tile.position; mirror.transform = tile.transform
            mirror.zPosition = tile.zPosition; mirror.opacity = tile.opacity
            if let reveal = mirror.sublayers?.first, let mask = reveal.mask,
               let reflectionContent = reveal.sublayers?.last, let reflectedImage = reflectionContent.sublayers?.first {
                // Only the first 40% contains visible reflection pixels. Reveal that
                // range without stretching either the bitmap or its static fade.
                let fraction = reveal.bounds.height > 0 ? mask.bounds.height / (reveal.bounds.height * 0.4) : 1
                reveal.frame = CGRect(x: 0, y: reflectionTop, width: size.width, height: size.height)
                mask.bounds = CGRect(x: 0, y: 0, width: size.width, height: size.height * 0.4 * fraction)
                mirror.sublayers?.last?.frame = reveal.frame
                // Existing mirrors must resolve their occlusion matte again when appearance changes.
                mirror.sublayers?.last?.backgroundColor = backgroundColor
                reflectionContent.frame = reveal.bounds
                reflectionContent.mask?.frame = reflectionContent.bounds
                // Share the decoded bitmap; no reflection download or decode.
                if (reflectedImage.contents as AnyObject?) !== bitmap {
                    if reflectedImage.contents != nil, let upgrade = image.animation(forKey: "quality-upgrade") {
                        reflectedImage.add(upgrade, forKey: "quality-upgrade")
                    }
                    reflectedImage.contents = bitmap
                }
                reflectedImage.bounds = CGRect(origin: .zero, size: size)
                reflectedImage.position = CGPoint(x: size.width / 2, y: size.height / 2)
                if let dim = reflectionContent.sublayers?.last {
                    dim.frame = reflectionContent.bounds; dim.opacity = carouselShade.opacity
                }
            }
        }
        func removeFromScene() { root.removeFromSuperlayer(); reflection?.removeFromSuperlayer() }
        func invalidateAppearance() { statusLayout = nil; contentLayout = nil }
        func updateStatus(pending: Bool, failed: Bool, wall: Bool, center: Bool, scale: CGFloat) {
            let layout = StatusLayout(size: root.bounds.size, scale: scale, pending: pending, failed: failed, wall: wall, center: center, hovered: hovered)
            guard layout != statusLayout else { return }; statusLayout = layout
            playback.isHidden = !wall && center && pending
            playbackGlyph.isHidden = playback.isHidden
            let showFailure = failed && (wall || center)
            failureShade.isHidden = !showFailure
            guard showFailure else { return }
            if failureShade.superlayer == nil {
                root.insertSublayer(failureShade, below: playback)
                failureShade.addSublayer(failureTitle)
            }
            failureShade.frame = root.bounds
            failureShade.backgroundColor = SonoGeneratedColors.artworkErrorShade.sonoCGColor(in: NSApp.effectiveAppearance)
            failureTitle.foregroundColor = SonoGeneratedColors.artworkError.sonoCGColor(in: NSApp.effectiveAppearance)
            failureTitle.string = "无法播放"
            failureTitle.font = SonoTypography.native(size: SonoDesktopTokens.FontSize.label)
            failureTitle.fontSize = SonoDesktopTokens.FontSize.label
            failureTitle.alignmentMode = .center
            failureTitle.contentsScale = scale
            failureTitle.frame = CGRect(x: 0, y: root.bounds.height * 0.25, width: root.bounds.width, height: 24)
        }
        func updateReading(_ line: Int?, reduced: Bool) {
            let next = reduced ? nil : line
            for (index, layer) in [title, artist].enumerated() {
                let measured = next == index ? ceil(SonoTypography.width(layer.string as? String ?? "", size: index == 0 ? SonoDesktopTokens.FontSize.itemTitle : SonoDesktopTokens.FontSize.body, weight: index == 0 ? .semibold : .medium)) : 0
                SonoTextReading.update(layer, width: index == 0 ? titleClip.bounds.width : artistClip.bounds.width, measured: measured, active: next == index)
            }
            readingLine = next
        }
    }
    private let artworkStore: BrowseArtworkStore
    private let displayProbe = BrowseDisplayProbe()
    private var diagnosticIndices: [Int]?
    private var diagnosticNavigation: Int?
    private var diagnosticFirst = false, diagnosticReady = false, diagnosticOpaque = false
    // Cards use world coordinates; the compositor moves the whole wall once.
    private let content = CALayer()
    private let reflections = CALayer()
    private var bufferedViewport = CGRect.null
    private var artworkPresentation: ArtworkPresentation?
    private var panLink: CADisplayLink?
    private var pendingPan = false
    private var pendingBufferPreparation = false
    private var panCommit: Task<Void, Never>?
    private var rendering = false
    private var artworkDemandDirty = true
    private var visibleArtworkIDs: Set<String> = []
    private var hitOrder: [Card] = []
    override func viewDidMoveToWindow() {
        super.viewDidMoveToWindow()
        if let resignObserver { NotificationCenter.default.removeObserver(resignObserver); self.resignObserver = nil }
        if let occlusionObserver { NotificationCenter.default.removeObserver(occlusionObserver); self.occlusionObserver = nil }
        if let window {
            updateArtworkPresentation()
            window.acceptsMouseMovedEvents = true
            displayProbe.attach(to: self)
            BrowseDiagnostics.shared.set("backingColorProfile", artworkPresentation?.key ?? "source")
            resignObserver = NotificationCenter.default.addObserver(forName: NSWindow.didResignKeyNotification, object: window, queue: .main) { [weak self] _ in
                MainActor.assumeIsolated { self?.restoreListPinch(); self?.flushWallPan(); self?.pointerOrigin = nil; self?.pressedTarget = nil; self?.dragging = false; self?.carouselRail.finishInteraction(); self?.stopCompactPreview(); self?.motion?.blur(); self?.render(animated: false) }
            }
            occlusionObserver = NotificationCenter.default.addObserver(forName: NSWindow.didChangeOcclusionStateNotification, object: window, queue: .main) { [weak self] _ in
                MainActor.assumeIsolated {
                    guard let self else { return }
                    if self.window?.occlusionState.contains(.visible) == true {
                        if self.pendingPan || self.pendingBufferPreparation { self.wakePanLink() }
                    } else {
                        self.panLink?.isPaused = true
                    }
                }
            }
        } else { carouselRail.reset(); entrancePreparation?.cancel(); entrancePreparation = nil; displayProbe.stop(); closeScroll() }
    }
    override func viewDidChangeEffectiveAppearance() {
        super.viewDidChangeEffectiveAppearance()
        CATransaction.begin(); CATransaction.setDisableActions(true)
        for card in cards.values {
            card.root.backgroundColor = SonoGeneratedColors.artworkPlaceholder.sonoCGColor(in: effectiveAppearance)
            card.artworkReason.foregroundColor = SonoGeneratedColors.artworkReason.sonoCGColor(in: effectiveAppearance)
            card.invalidateAppearance()
        }
        captionTrack = nil
        compactPreview.reset()
        focusRing.strokeColor = NSColor.keyboardFocusIndicatorColor.sonoCGColor(in: effectiveAppearance)
        if browser != nil { render(animated: false) }
        CATransaction.commit()
    }
    override func viewDidChangeBackingProperties() {
        super.viewDidChangeBackingProperties()
        updateArtworkPresentation()
    }
    private func updateArtworkPresentation() {
        let next = (window?.colorSpace ?? window?.screen?.colorSpace).flatMap { ArtworkPresentation($0) }
        guard next?.key != artworkPresentation?.key else { return }
        artworkPresentation = next
        cancelDirectionalRequests(); cancelCarouselRequests()
        if BrowseDiagnostics.shared.enabled { BrowseDiagnostics.shared.set("backingColorProfile", next?.key ?? "source") }
        if browser != nil && !tracks.isEmpty { render(animated: false) }
    }
    private var cards: [String: Card] = [:]
    private var accessibilityIDs: [String] = []
    private var accessibleCards: Set<String> = []
    private var tracks: [BrowseItem] = []
    private weak var browser: MusicBrowser?
    private var play: (BrowseItem) -> Void = { _ in }
    private var catalog: (BrowseItem, Bool) -> Void = { _, _ in }
    private var pendingArtist: BrowseItem?
    private var reduced = false
    private var currentID: String?
    private var isPlaying = false
    private var pendingID: String?
    private var failures: [String: String] = [:]
    private var hasMore = false
    private var dismiss: () -> Void = {}
    private var tracking: NSTrackingArea?
    private var hoverID: String?
    private struct HoverRegion: Equatable {
        let id: String?
        let title: Bool, artist: Bool, play: Bool, captionTitle: Bool, captionArtist: Bool
        let layout: BrowserLayout?
    }
    private var hoverRegion: HoverRegion?
    private enum StagePhase: String { case idle, preparing, cameraMoving, waiting, sidesIn }
    private var stagePhase = StagePhase.idle
    private var departureScene: Departure?
    private var departure: CALayer? { departureScene?.root }
    private var sharedCenter: CALayer?
    private var retainedCenterID: String?
    private var retainedWallCaption = false
    private var retainedCarouselDetails = false
    private var maskPending = false
    private var entranceFinished = false
    private var entryRequested = false
    private var entryStarted = false
    private var entranceWaveStart: CFTimeInterval?
    private var startupEntrance = false
    private var startupRecoveryKey: String?
    private var preparationGate = ColdEntranceGate()
    private var startupTargets: [String: CGRect] = [:]
    private var startupTargetSize = CGSize.zero
    private var startupResourcesFinished = false
    private var fallbackRevealAt: CFTimeInterval = 0
    private var entrancePreparation: Task<Void, Never>?
    private var foldedCards: [CALayer] = []
    private var wallArrival = true
    private struct BrowseReveal {
        var started: CFTimeInterval
        let delay: CFTimeInterval
        let origin: CGPoint
        var ready = false
        var done = false
    }
    private var browseReveals: [String: BrowseReveal] = [:]
    #if DEBUG
    private var phaseTrace: [(String, Double)] = []
    #endif
    private var targetLayout: BrowserLayout?
    private var lastVisit: UInt64?
    private var lastSource = ""
    private var renderedOwner = ""
    private var lastPointer: CGPoint?
    private var playHovered = false
    private var artistHovered = false
    private var layoutGeneration: UInt64 = 0
    private var layoutTransitionActive = false
    private var deferredConfigure: (() -> Void)?
    private var snapLink: CADisplayLink?
    private var motion: CarouselMotion?
    private var inputSequence = 0, inputGesture = 0, releasedGesture = 0, momentumGesture = 0
    private var lastPhasedScroll: Double?
    private var resignObserver: NSObjectProtocol?
    private var occlusionObserver: NSObjectProtocol?
    private let captionClip = CALayer(), captionArtistClip = CALayer()
    private var captionHovered = false
    private var captionTrack: BrowseItem?
    private var caption = CATextLayer()
    private var captionArtist = CATextLayer()
    private let counterControl = CarouselCounter(frame: .zero)
    private var counter: CALayer { counterControl.layer! }
    private var retainsCarouselCounter = false
    private var transitioningChrome: [CALayer] {
        // The position control updates directly, independently of page artwork
        // and caption entrances, including when the renderer is recreated.
        return [captionClip, captionArtistClip]
    }
    private var renderedField: WallGeometry?
    private var trackData: BrowseItemData?
    private var lastCamera: CGPoint?
    private var renderedMetrics: BrowseMetrics?
    private var renderedSize: CGSize = .zero
    private var lastLayout: BrowserLayout?
    private var lastFocusRevision: UInt64 = 0
    private var lastAnchor: String?
    private var lastExpansion: String?
    private var lastTrackIDs: [String] = []
    private var dragStartCamera = CGPoint.zero
    private var previewCamera: CGPoint?
    private var previousDemandCamera: CGPoint?
    private var directionalRequests: [String: (token: UUID?, pixels: Int)] = [:]
    private var directionalFlush: Task<Void, Never>?
    private var artworkFlush: Task<Void, Never>?
    private var arrivedCards: Set<String> = []
    private var previewPosition: CGFloat?
    private var renderedCarouselCenter: Int?
    private var preparedCarousel: CarouselGeometry.Preparation?
    private var carouselPlanner = CarouselArtworkPlanner()
    private var carouselRefresh: Task<Void, Never>?
    private var carouselResourceRequests: [Int: (generation: UUID, token: UUID)] = [:]
    private var carouselRetryUsed: Set<String> = []
    private var carouselArtworkDemand: CarouselArtworkPlanner.Demand?
    private let compactPreview = CarouselPreview()
    private enum PreviewPhase { case off, moving, waiting, revealing }
    private var previewPhase = PreviewPhase.off
    private var previewOrigin: String?
    private var previewTask: Task<Void, Never>?
    private var previewGeneration = 0
    private struct CompactArtworkRequest {
        let resource: String
        let generation = UUID()
        var token: UUID?
    }
    private var compactArtwork: [Int: CompactArtworkRequest] = [:]
    private func compactPreviewImage(_ index: Int) -> Any? {
        guard let actual = carouselTrackIndices[index] else { return nil }
        let track = tracks[actual]
        if let bitmap = cards[track.id]?.image.contents { return bitmap }
        return track.coverURL.flatMap { artworkStore.availablePreview($0, presentation: artworkPresentation)?.image }
    }
    private func cancelCompactArtwork() {
        for request in compactArtwork.values { artworkStore.cancel(request.token) }
        compactArtwork = [:]
    }
    private func updateCompactArtwork(_ visible: [Int], geometry: CarouselGeometry) {
        guard previewPhase == .moving else { cancelCompactArtwork(); return }
        artworkStore.updateRequests {
            for (index, request) in compactArtwork {
                let resource = carouselTrackIndices[index].flatMap { tracks[$0].coverURL }.map { ArtworkPresentation.identity($0, artworkPresentation) }
                if !visible.contains(index) || resource != request.resource {
                    artworkStore.cancel(request.token); compactArtwork[index] = nil
                }
            }
            for index in visible {
                guard compactArtwork[index] == nil, let actual = carouselTrackIndices[index],
                      let url = tracks[actual].coverURL, !finalCarouselFailure(url),
                      compactPreviewImage(index) == nil else { continue }
                let request = CompactArtworkRequest(resource: ArtworkPresentation.identity(url, artworkPresentation))
                compactArtwork[index] = request
                let rect = compactPreview.coverRect(index, geometry: geometry)
                let pixels = min(320, ArtworkPixelSize.bucket(Int(ceil(rect.width * (window?.backingScaleFactor ?? 2)))))
                let token = artworkStore.request(url, pixels: pixels, center: index == geometry.center,
                    visible: true, presentation: artworkPresentation, centerDistance: abs(CGFloat(index) - geometry.position)) { [weak self] bitmap in
                    guard let self, self.previewPhase == .moving,
                          self.compactArtwork[index]?.generation == request.generation else { return }
                    self.compactArtwork[index]?.token = nil
                    if let bitmap { self.compactPreview.showImage(bitmap.image, at: index) }
                }
                // Cached results may be delivered synchronously; the demand record still prevents duplicate requests.
                if compactArtwork[index]?.generation == request.generation { compactArtwork[index]?.token = token }
            }
        }
    }
    private func updateCompactPreview() {
        guard previewPhase != .off else { return }
        CATransaction.begin(); CATransaction.setDisableActions(true)
        defer { CATransaction.commit() }
        let geometry = carousel
        let visible = compactPreview.visibleIndices(geometry)
        compactPreview.updateItems(geometry, ids: carouselIDs, track: { self.carouselTrackIndices[$0].map { self.tracks[$0] } }, image: { self.compactPreviewImage($0) }, scale: window?.backingScaleFactor ?? 2, reduced: reduced, settling: previewPhase == .waiting)
        updateCompactArtwork(visible, geometry: geometry)
        setAccessibilityChildren([carouselRail])
        content.isHidden = false
        for text in [captionClip, captionArtistClip, counter] { text.isHidden = true }
        let ids = visible.filter { carouselTrackIndices[$0] == nil }.map { carouselIDs[$0] }
        if ids != demandedDetails { demandedDetails = ids; detailDemand(ids) }
    }
    private func stopCompactPreview() {
        previewGeneration += 1; previewTask?.cancel(); previewTask = nil
        cancelCompactArtwork()
        accessibilityIDs = []
        previewPhase = .off; compactPreview.isHidden = true; compactPreview.opacity = 1; compactPreview.removeAllAnimations(); compactPreview.reset(); content.isHidden = false
        content.removeAnimation(forKey: "preview-hide"); content.opacity = 1
    }
    private func restoreCompactPreview(unchanged: Bool = false) {
        cancelCompactArtwork()
        previewPhase = .revealing; content.isHidden = false
        content.removeAnimation(forKey: "preview-hide"); content.opacity = 1
        render(animated: false)
        CATransaction.begin(); CATransaction.setDisableActions(true)
        let visible = Set(compactPreview.visibleIndices(carousel))
        let restoredTiles = cards.values.filter { !$0.retiring }.map { (ordinal($0.index), $0.root) } + unknownCards.map { ($0.key, $0.value) }
        for (index, tile) in restoredTiles {
            if !reduced {
                let start = compactPreview.coverState(index, geometry: carousel, size: tile.bounds.size)
                let duration = unchanged ? 0.22 : 0.46
                animate(tile, key: "position", from: NSValue(point: start.position), to: NSValue(point: tile.position), duration: duration)
                animate(tile, key: "transform", from: NSValue(caTransform3D: start.transform), to: NSValue(caTransform3D: tile.transform), duration: duration)
                if !visible.contains(index) { animate(tile, key: "opacity", from: Float(0), to: tile.opacity, duration: duration) }
            }
        }
        updateCarouselReflections()
        if !reduced { animate(reflections, key: "opacity", from: Float(0), to: Float(0.2), duration: 0.22, delay: unchanged ? 0 : 0.18) }
        CATransaction.commit()
        let fade = CABasicAnimation(keyPath: "opacity"); fade.fromValue = 1; fade.toValue = 0; fade.duration = reduced ? 0 : 0.12
        compactPreview.opacity = 0; compactPreview.add(fade, forKey: "restore")
        let generation = previewGeneration
        previewTask = Task { @MainActor [weak self] in
            do { try await Task.sleep(for: .milliseconds(self?.reduced == true ? 0 : unchanged ? 220 : 480)) } catch { return }
            guard let self, self.previewGeneration == generation else { return }
            self.stopCompactPreview(); self.artworkDemandDirty = true; self.render(animated: false)
        }
    }
    private func waitForCompactCenter() {
        previewPhase = .waiting
        let generation = previewGeneration, deadline = CACurrentMediaTime() + 1
        if carouselIDs.indices.contains(carousel.center) { priorityDetailDemand([carouselIDs[carousel.center]]) }
        demandedDetails = []; updateCompactPreview()
        previewTask = Task { @MainActor [weak self] in
            guard let self else { return }
            while self.previewGeneration == generation && self.previewPhase == .waiting {
                let index = self.carouselCenterIndex
                let track = index.map { self.tracks[$0] }
                if let index, let track {
                    let card = self.cards[track.id] ?? Card(track: track, index: index)
                    card.updateIndicatorColor(self.theme.accent)
                    if self.cards[track.id] == nil { self.cards[track.id] = card; self.content.addSublayer(card.root) }
                    card.index = index; card.root.bounds = CGRect(origin: .zero, size: self.metrics.centerRect.size)
                    self.loadArtwork(card, track: track, center: true, visible: true, progressive: true)
                    if card.image.contents != nil || track.coverURL == nil || track.coverURL.map(self.finalCarouselFailure) == true { break }
                }
                if CACurrentMediaTime() >= deadline { break }
                do { try await Task.sleep(for: .milliseconds(16)) } catch { return }
            }
            guard !Task.isCancelled, self.previewGeneration == generation else { return }
            self.restoreCompactPreview()
        }
    }
    private let carouselRail = CarouselRail()
    private var carouselIDs: [String] = []
    private var pendingAppendReveals: Set<String> = []
    private var carouselOrdinals: [String: Int] = [:]
    private var carouselTrackIndices: [Int: Int] = [:]
    private var detailDemand: ([String]) -> Void = { _ in }
    private var unresolvedPlay: (String) -> Void = { _ in }
    var priorityDetailDemand: ([String]) -> Void = { _ in }
    private var demandedDetails: [String] = []
    private var unknownCards: [Int: CALayer] = [:]
    private var unknownCenterAccessibility: BrowseCardAccessibility?
    private var scrubbing = false
    private var sceneCount: Int { browser?.layout == .carousel ? carouselIDs.count : tracks.count }
    private var carouselCenterIndex: Int? { carouselTrackIndices[carousel.center] }
    private func ordinal(_ index: Int) -> Int { tracks.indices.contains(index) ? carouselOrdinals[tracks[index].id] ?? index : index }
    func setCarouselCallbacks(demand: @escaping ([String]) -> Void, play: @escaping (String) -> Void) {
        detailDemand = demand; unresolvedPlay = play
    }
    private func setCarouselSource(ids: [String], tracks: [BrowseItem]) -> Bool {
        let next = ids.isEmpty ? tracks.map(\.id) : ids
        let changed = next != carouselIDs
        if changed {
            carouselIDs = next
            carouselOrdinals = Dictionary(next.enumerated().map { ($0.element, $0.offset) }, uniquingKeysWith: { first, _ in first })
            demandedDetails = []
        }
        if changed || tracks != self.tracks {
            carouselTrackIndices = Dictionary(tracks.enumerated().compactMap { index, track in carouselOrdinals[track.id].map { ($0, index) } }, uniquingKeysWith: { first, _ in first })
        }
        return changed
    }
    private func updateCarouselRail() {
        let visible = browser?.layout == .carousel && browser?.quickListOpen == false && carouselIDs.count > 1 && interactionEnabled
        carouselRail.isHidden = !visible
        guard visible else { carouselRail.reset(); return }
        // Keep the drag badge above the track, clear of the cover hit area.
        // Keep the first thumb clear of the source capsule, which overlays the
        // canvas and otherwise intercepts most of its hit area at position zero.
        let leading = SonoChromeMetrics.horizontalInset + SonoChromeMetrics.buttonSize + 16
        carouselRail.frame = CGRect(x: leading, y: metrics.centerRect.minY - 24 - carouselRail.knob.maxY, width: max(0, bounds.width - leading - 24), height: 60)
        counterControl.isHidden = scrubbing || carouselRail.indicatorVisible
        carouselRail.position = Double(carousel.position); carouselRail.count = carouselIDs.count; carouselRail.needsDisplay = true
    }
    private func beginScrubbing() {
        cancelPendingFocus(); interruptLayoutForInteraction(); closeScroll()
        stopCompactPreview()
        if carouselRail.thumbPressed {
            previewOrigin = carouselIDs.indices.contains(carousel.center) ? carouselIDs[carousel.center] : nil
            previewPhase = .moving; compactPreview.isHidden = false
            CATransaction.begin(); CATransaction.setDisableActions(true)
            updateCompactPreview()
            compactPreview.enter(carousel, reduced: reduced)
            content.opacity = 0
            if !reduced {
                let fade = CABasicAnimation(keyPath: "opacity")
                fade.fromValue = 1; fade.toValue = 0; fade.duration = 0.12
                fade.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
                content.add(fade, forKey: "preview-hide")
            }
            CATransaction.commit()
        }
        scrubbing = true; ensureMotion().beginDrag(); browser?.onInteraction?()
        artworkStore.updateRequests {
            for card in cards.values { artworkStore.cancel(card.token); card.token = nil; card.requestedPixels = card.loadedPixels }
            for request in carouselResourceRequests.values { artworkStore.cancel(request.token) }
            carouselResourceRequests = [:]
        }
    }
    private func endScrubbing() {
        guard scrubbing else { return }
        scrubbing = false; artworkDemandDirty = true
        if previewPhase != .off {
            motion?.finishScrub()
            let id = carouselIDs.indices.contains(carousel.center) ? carouselIDs[carousel.center] : nil
            if id == previewOrigin {
                restoreCompactPreview(unchanged: true)
            } else { waitForCompactCenter() }
        } else { motion?.endDrag() }
    }
    private var accessibleCarouselCenter: Int?
    private var pointerOrigin: CGPoint?
    private var dragging = false
    private enum ActionKind: String { case select, play, album, artist }
    private struct Target: Equatable { let id: String; let kind: ActionKind }
    private var pressedTarget: Target?
    private var keyboardTarget: Target?
    private var wallKeyboardTarget: String?
    private var keyboardFocusVisible = false
    private var spaceTarget: Target?
    var hasKeyboardControl: Bool { keyboardTarget != nil }
    private let focusRing = CAShapeLayer()
    override var isFlipped: Bool { true }
    override var acceptsFirstResponder: Bool { true }
    override convenience init(frame frameRect: NSRect) {
        self.init(frame: frameRect, artworkStore: .shared)
    }
    init(frame frameRect: NSRect, artworkStore: BrowseArtworkStore) {
        self.artworkStore = artworkStore
        super.init(frame: frameRect)
        displayProbe.sample = { [weak self] in self?.sampleLoadingProgress() }
        displayProbe.observation = { [weak self] in self?.diagnosticViewport() ?? [:] }
        if ProcessInfo.processInfo.environment["SONO_WALL_FRAME_CAPTURE"] == "1" {
            displayProbe.wallFrame = { [weak self] interval in self?.diagnosticWallFrame(interval: interval) }
        }
        wantsLayer = true; layer?.masksToBounds = true
        content.anchorPoint = .zero; layer?.addSublayer(content)
        reflections.name = "carousel-reflections"; reflections.anchorPoint = .zero
        reflections.zPosition = -2000; reflections.opacity = 0.2; reflections.allowsGroupOpacity = true
        content.addSublayer(reflections)
        focusRing.fillColor = nil; focusRing.strokeColor = NSColor.keyboardFocusIndicatorColor.sonoCGColor(in: effectiveAppearance); focusRing.lineWidth = 2; focusRing.zPosition = 6000
        layer?.addSublayer(focusRing)
        // These text layers change width as the centered song changes. Their
        // backing must follow the new bounds, including after the string was
        // already set earlier in the same frame.
        caption.needsDisplayOnBoundsChange = true
        captionArtist.needsDisplayOnBoundsChange = true
        carouselRail.isHidden = true
        carouselRail.visibilityChanged = { [weak self] visible in
            guard let self else { return }
            CATransaction.begin(); CATransaction.setDisableActions(true)
            self.counterControl.isHidden = visible || self.scrubbing || self.previewPhase != .off || self.browser?.layout != .carousel || self.carouselIDs.isEmpty
            CATransaction.commit()
        }
        carouselRail.bubbleVisibilityChanged = { [weak self] in
            Task { @MainActor [weak self] in
                guard let self, let browser else { return }
                let visible = carouselRail.bubbleVisible
                if browser.carouselPositionBubbleVisible != visible {
                    browser.carouselPositionBubbleVisible = visible
                }
            }
        }
        carouselRail.began = { [weak self] in self?.beginScrubbing() }
        carouselRail.changed = { [weak self] value in self?.ensureMotion().scrub(to: value) }
        carouselRail.ended = { [weak self] in self?.endScrubbing() }
        carouselRail.cancelled = { [weak self] in
            guard let self else { return }
            let index = self.previewOrigin.flatMap { self.carouselOrdinals[$0] }
            self.scrubbing = false; self.stopCompactPreview()
            if let index { self.ensureMotion().navigate(Double(index), now: CACurrentMediaTime(), animated: false) }
        }
        layer?.addSublayer(compactPreview)
        addSubview(carouselRail)
        counterControl.openList = { [weak self] in self?.browser?.enterQuickList() }
        addSubview(counterControl)
        setAccessibilityElement(false)
        setAccessibilityRole(.group)
        setAccessibilityLabel("音乐封面浏览")
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    func configure(tracks: [LocalTrack], browser: MusicBrowser, reduceMotion: Bool, orderedIDs: [String]? = nil, currentID: String? = nil, playing: Bool = false, pendingID: String? = nil, failures: [String: String] = [:], hasMore: Bool = false, dismiss: @escaping () -> Void = {}, catalog: @escaping (LocalTrack, Bool) -> Void = { _, _ in }, play: @escaping (LocalTrack) -> Void) {
        configureItems(tracks: tracks.map(BrowseItem.song), browser: browser, reduceMotion: reduceMotion, orderedIDs: orderedIDs, currentID: currentID, playing: playing, pendingID: pendingID, failures: failures, hasMore: hasMore, dismiss: dismiss, catalog: { item, album in if let song = item.song { catalog(song, album) } }, play: { if let song = $0.song { play(song) } })
    }
    func configureItems(tracks: [BrowseItem], browser: MusicBrowser, reduceMotion: Bool, orderedIDs: [String]? = nil, currentID: String? = nil, playing: Bool = false, pendingID: String? = nil, failures: [String: String] = [:], hasMore: Bool = false, dismiss: @escaping () -> Void = {}, catalog: @escaping (BrowseItem, Bool) -> Void = { _, _ in }, play: @escaping (BrowseItem) -> Void) {
        guard presented else {
            presentationRefresh = { [weak self] in
                self?.configureItems(tracks:tracks,browser:browser,reduceMotion:reduceMotion,orderedIDs:orderedIDs,currentID:currentID,playing:playing,pendingID:pendingID,failures:failures,hasMore:hasMore,dismiss:dismiss,catalog:catalog,play:play)
            }
            return
        }
        if browser.quickListOpen { stopCompactPreview(); scrubbing = false; carouselRail.isHidden = true; carouselRail.reset(); closeScroll(); cancelDirectionalRequests(); cancelCarouselRequests(); accessibilityIDs = []; accessibleCards = []; setAccessibilityChildren([]); return }
        let measurement = BrowseDiagnostics.shared.start(); defer { BrowseDiagnostics.shared.end("scene.configure", measurement) }
        BrowseDiagnostics.shared.set("tracks", String(tracks.count))
        if renderedSize != bounds.size { preserveWallPanForResize(browser) }
        browser.prepare(items: tracks, viewport: bounds.size)
        let previousIDs = carouselIDs
        let orderChanged = setCarouselSource(ids: orderedIDs ?? tracks.map(\.id), tracks: tracks)
        let data = browser.data(items: tracks)
        let sourceChanged = lastVisit != browser.visit || lastSource != browser.sourceKey || renderedOwner != browser.sourceOwner
        let appended = !sourceChanged && orderChanged && !previousIDs.isEmpty &&
            carouselIDs.count > previousIDs.count && carouselIDs.starts(with: previousIDs)
        if appended { pendingAppendReveals.formUnion(carouselIDs.dropFirst(previousIDs.count)) }
        else if sourceChanged || orderChanged { pendingAppendReveals.removeAll() }

        let dataChanged = trackData !== data || orderChanged
        let previousLayout = lastLayout
        let layoutChanged = previousLayout != nil && previousLayout != browser.layout
        if sourceChanged || layoutChanged {
            retainsCarouselCounter = !layoutChanged && previousLayout == .carousel &&
                browser.layout == .carousel && renderedOwner == browser.sourceOwner
        }
        let selectionChanged = lastAnchor != browser.location.anchor || lastExpansion != browser.location.expanded || lastFocusRevision != browser.focusRevision
        lastFocusRevision = browser.focusRevision
        defer { finishFocusIfSettled() }
        let playbackChanged = self.currentID != currentID || self.isPlaying != playing || self.pendingID != pendingID || self.failures != failures || self.hasMore != hasMore
        let reducedChanged = self.reduced != reduceMotion
        if sourceChanged || layoutChanged || (reducedChanged && reduceMotion) {
            for card in cards.values where card.root.mask?.name == "pagination-reveal" { card.root.mask = nil }
        }
        let dirty = sourceChanged || layoutChanged || selectionChanged || dataChanged || lastCamera != browser.location.camera || self.reduced != reduceMotion || renderedSize != bounds.size
        let wasEmpty = self.tracks.isEmpty
        if orderChanged && !sourceChanged && !appended { stopCompactPreview(); carouselRail.reset(); closeScroll(); motion = nil; previewPosition = nil }
        if sourceChanged || layoutChanged {
            cancelDirectionalRequests(); cancelCarouselRequests(resetRetry: sourceChanged)
            renderedCarouselCenter = nil
            pendingBufferPreparation = false
            artworkFlush?.cancel(); artworkFlush = nil; arrivedCards = []
            panLink?.invalidate(); panLink = nil; pendingPan = false; panCommit?.cancel(); panCommit = nil; bufferedViewport = .null; visibleArtworkIDs = []; artworkDemandDirty = true
            pendingArtist = nil
        }
        if sourceChanged || layoutChanged {
            stopCompactPreview()
            carouselRail.reset(); scrubbing = false; demandedDetails = []
            closeScroll(); motion = nil; previewPosition = nil; previewCamera = nil; pointerOrigin = nil; pressedTarget = nil; keyboardTarget = nil; dragging = false
        }
        self.browser = browser; self.play = play; self.catalog = catalog
        browser.captureView = { [weak self, weak browser] in
            guard let self, let browser else { return BrowserLocation() }
            guard self.lastSource == browser.sourceKey, self.lastVisit == browser.visit, self.lastLayout == browser.layout else { return browser.location }
            self.flushWallPan()
            var value = browser.location
            if self.lastLayout == .wall {
                value.camera = self.presentedWallCamera()
                if let field = self.renderedField {
                    let anchor = field.metrics.anchor
                    if let i = field.nearest(to: CGPoint(x: anchor.x - value.camera.x, y: anchor.y - value.camera.y)), self.tracks.indices.contains(i) { value.anchor = self.tracks[i].id }
                }
            } else {
                let position = self.previewPosition ?? self.presentedCarouselPosition()
                let i = min(max(0, Int(position.rounded())), max(0, self.carouselIDs.count - 1))
                if self.carouselIDs.indices.contains(i) {
                    value.anchor = self.carouselIDs[i]; value.expanded = value.anchor
                }
            }
            value.positioned = true
            return value
        }
        if layoutTransitionActive && !sourceChanged && targetLayout == browser.layout && !selectionChanged && !reducedChanged && renderedSize == bounds.size {
            // Keep the transition's immutable scene, then reconcile the latest
            // publication. Dropping hydration here loses late metadata/status
            // forever when no further model change occurs after the animation.
            if dataChanged || playbackChanged {
                deferredConfigure = { [weak self] in
                    self?.configureItems(tracks: tracks, browser: browser, reduceMotion: reduceMotion, orderedIDs: orderedIDs, currentID: currentID, playing: playing, pendingID: pendingID, failures: failures, hasMore: hasMore, dismiss: dismiss, catalog: catalog, play: play)
                }
            }
            return
        }
        deferredConfigure = nil
        let keyboardWallSelection = !sourceChanged && !layoutChanged && selectionChanged &&
            wallKeyboardTarget != nil && wallKeyboardTarget == browser.location.expanded
        wallKeyboardTarget = nil
        if sourceChanged { browseReveals.removeAll() }
        if reducedChanged {
            closeScroll(); motion = nil; previewPosition = nil
            if reduceMotion {
                for card in cards.values {
                    for key in ["position", "bounds", "transform", "opacity"] { card.root.removeAnimation(forKey: key) }
                }
            }
        }
        self.currentID = currentID; self.isPlaying = playing; self.pendingID = pendingID; self.failures = failures; self.hasMore = hasMore; self.dismiss = dismiss; self.reduced = reduceMotion
        // A reversal must borrow the cover currently on screen, not the hidden
        // target layer whose presentation opacity may still be zero this frame.
        let interruptedCenter: (id: String, tile: CALayer)? = layoutTransitionActive && dirty ? retainedCenterID.flatMap { id in
            sharedCenter.map { (id, copyLayer($0)) }
        } : nil
        let interruptedDeparture = layoutTransitionActive && dirty ?
            snapshotDeparture(preserving: interruptedCenter) : nil
        if layoutTransitionActive && dirty { cancelLayoutTransition() }
        if dataChanged || sourceChanged { renderedField = nil; artworkDemandDirty = true }
        if sourceChanged || wasEmpty, BrowseDiagnostics.shared.enabled {
            diagnosticIndices = []; diagnosticFirst = false; diagnosticReady = false; diagnosticOpaque = false
            BrowseDiagnostics.shared.mark("scene.begin")
        }
        if !tracks.isEmpty && (sourceChanged || wasEmpty) {
            if startupRecoveryKey != browser.sourceKey {
                startupEntrance = browser.layout == .wall && browser.startupRecoverySource == browser.sourceKey
                startupRecoveryKey = startupEntrance ? browser.sourceKey : nil
                browser.startupRecoverySource = nil
            }
        }
        let shouldTransition = !wasEmpty && (sourceChanged || layoutChanged) && !reduceMotion
        if shouldTransition, let previousLayout {
            self.tracks = tracks; trackData = data; lastVisit = browser.visit; lastSource = browser.sourceKey
            let outgoing = interruptedDeparture ?? snapshotDeparture(preserving: interruptedCenter,
                movingCenter: layoutChanged && previousLayout == .wall ? browser.location.anchor : nil)
            beginSceneTransition(from: outgoing.layout, outgoing: outgoing, layoutChanged: layoutChanged)
            return
        }
        self.tracks = tracks; trackData = data; lastVisit = browser.visit; lastSource = browser.sourceKey
        if selectionChanged && browser.layout == .wall {
            // A click may have frozen the previous camera animation on mouse-down.
            // That gesture preview must not override the new selection's destination.
            previewCamera = nil; pendingPan = false
            panCommit?.cancel(); panCommit = nil
        }
        if sourceChanged || wasEmpty { requestEntrance() }
        if dirty && !sourceChanged && !layoutChanged && !selectionChanged && !dataChanged && !playbackChanged && !reducedChanged && renderedSize == bounds.size && browser.layout == .wall && !wasEmpty {
            previewCamera = previewCamera ?? browser.location.camera
            pendingPan = true
            flushWallPan()
            return
        }
        if selectionChanged && !wasEmpty && !sourceChanged && !layoutChanged && browser.layout == .carousel {
            requestCarouselNavigation(centerIndex)
            return
        }
        if dirty || wasEmpty {
            if selectionChanged && !wasEmpty && !sourceChanged { layoutGeneration &+= 1 }
            let coldSelection = !keyboardWallSelection && !wasEmpty && !sourceChanged && browser.layout == .wall && browser.location.expanded != nil && selectionChanged && !tracks.isEmpty && !(cards[browser.location.expanded ?? ""]?.artworkReady ?? false)
            if coldSelection { requestEntrance(reset: false); wallArrival = false }
            CATransaction.begin()
            if selectionChanged || pendingArtist != nil { let generation = layoutGeneration; CATransaction.setCompletionBlock { [weak self] in
                guard let self, self.layoutGeneration == generation else { return }
                self.wallArrival = true; self.releaseEntrance()
                self.finishFocusIfSettled()
                if !coldSelection && !self.layoutTransitionActive { self.phase(.idle) }
                if let point = self.lastPointer { self.updatePointer(point) }
                if let track = self.pendingArtist, self.browser?.location.expanded == track.id { self.pendingArtist = nil; self.catalog(track, false) }
            } }
            if selectionChanged && !wasEmpty && !sourceChanged && browser.layout == .wall && !reduced {
                if coldSelection { phase(.cameraMoving) }
            }
            // There are no prepared tiles between disjoint keyboard destinations.
            let offset = presentedWallCamera()
            let camera = browser.location.camera
            let crossesEmptySpace = keyboardWallSelection &&
                (abs(offset.x - camera.x) >= bounds.width || abs(offset.y - camera.y) >= bounds.height)
            render(animated: selectionChanged && !wasEmpty && !sourceChanged && !crossesEmptySpace)
            CATransaction.commit()
            releaseEntrance()
        } else if playbackChanged && previewPhase == .off {
            CATransaction.begin(); CATransaction.setDisableActions(true)
            for (id, card) in cards {
                card.sizeContents(card.root.bounds.size, scale: window?.backingScaleFactor ?? 2, sceneScale: metrics.scale,
                                  wall: browser.layout == .wall, center: card.index == (browser.layout == .wall ? expandedIndex : carouselCenterIndex),
                                  playing: playing && id == currentID, indicated: id == currentID, motionReduced: reduceMotion)
                card.updateStatus(pending: id == pendingID, failed: tracks[card.index].online == nil && failures[id] != nil, wall: browser.layout == .wall, center: card.index == (browser.layout == .wall ? expandedIndex : carouselCenterIndex), scale: window?.backingScaleFactor ?? 2)
            }
            CATransaction.commit()
        }
        if previewPhase == .moving || previewPhase == .waiting { updateCompactPreview() }
        if playbackChanged, !layoutTransitionActive {
            hoverRegion = nil
            if let pointer = lastPointer { updatePointer(pointer) }
        }
    }
    override func layout() {
        super.layout()
        guard renderedSize != bounds.size, bounds.width > 0, bounds.height > 0, let browser else { return }
        preserveWallPanForResize(browser)
        // A live resize owns the new geometry. Release any borrowed old-size
        // layers atomically, then paint the same target song in the new viewport.
        if layoutTransitionActive && renderedSize != .zero { cancelLayoutTransition() }
        browser.prepare(items: tracks, viewport: bounds.size)
        render(animated: false)
    }
    private func preserveWallPanForResize(_ browser: MusicBrowser) {
        guard lastLayout == .wall, let previewCamera else { return }
        browser.location.camera = previewCamera
        self.previewCamera = nil
        pendingPan = false
    }
    func dispose() {
        stopCompactPreview()
        carouselRail.reset()
        for tile in unknownCards.values { tile.removeFromSuperlayer() }; unknownCards = [:]
        carouselIDs = []; carouselOrdinals = [:]; carouselTrackIndices = [:]; detailDemand = { _ in }; unresolvedPlay = { _ in }
        pendingBufferPreparation = false
        cancelDirectionalRequests(); cancelCarouselRequests(resetRetry: true); artworkFlush?.cancel(); artworkFlush = nil; arrivedCards = []
        panLink?.invalidate(); panLink = nil; panCommit?.cancel(); panCommit = nil
        displayProbe.stop()
        if let resignObserver { NotificationCenter.default.removeObserver(resignObserver); self.resignObserver = nil }
        if let occlusionObserver { NotificationCenter.default.removeObserver(occlusionObserver); self.occlusionObserver = nil }
        cancelLayoutTransition(); closeScroll(); motion = nil
        for card in cards.values { artworkStore.cancel(card.token); card.root.removeAllAnimations() }
        cards.removeAll(); hitOrder = []; visibleArtworkIDs = []; accessibleCards = []; diagnosticIndices = nil; layer?.sublayers = nil
        renderedField = nil; renderedMetrics = nil; preparedCarousel = nil; carouselArtworkDemand = nil; trackData = nil; tracks = []; browser?.captureView = nil; browser = nil; play = { _ in }; catalog = { _, _ in }; pendingArtist = nil; dismiss = {}
        accessibilityIDs = []; setAccessibilityChildren([])
    }
    private var metrics: BrowseMetrics {
        return BrowseMetrics(viewport: bounds.size,
                             count: browser?.roundWall == true ? tracks.count : max(tracks.count, browser?.sourceTotal ?? 0),
                             source: browser?.sourceKey ?? "local")
    }
    private func finishFocusIfSettled() {
        guard let browser, browser.afterFocus != nil, !layoutTransitionActive,
              !entryRequested, motion?.needsTick != true else { return }
        if browser.layout == .carousel {
            guard carouselIDs.indices.contains(carousel.center) else { return }
            browser.finishFocus(carouselIDs[carousel.center])
        } else if content.animation(forKey: "position") == nil, let id = browser.location.expanded {
            browser.finishFocus(id)
        }
    }
    private func phase(_ value: StagePhase) {
        if value == .idle { finishFocusIfSettled() }
        stagePhase = value; BrowseDiagnostics.shared.mark("stage." + value.rawValue); BrowseDiagnostics.shared.set("stage.phase", value.rawValue)
        #if DEBUG
        phaseTrace.append((value.rawValue, CACurrentMediaTime())); if phaseTrace.count > 200 { phaseTrace.removeFirst() }
        #endif
    }
    private func cancelLayoutTransition() {
        deferredConfigure = nil
        entrancePreparation?.cancel(); entrancePreparation = nil; preparationGate = ColdEntranceGate(); startupTargets = [:]; startupTargetSize = .zero
        let cancelCarouselUnfold = layoutTransitionActive && targetLayout == .carousel
        layoutGeneration &+= 1; layoutTransitionActive = false
        CATransaction.begin(); CATransaction.setDisableActions(true)
        releaseCarouselEdges()
        departure?.removeFromSuperlayer(); departureScene = nil
        sharedCenter?.removeFromSuperlayer(); sharedCenter = nil; retainedCenterID = nil; retainedWallCaption = false; retainedCarouselDetails = false
        if cancelCarouselUnfold { for tile in unknownCards.values { tile.removeAnimation(forKey: "position") } }
        for card in cards.values {
            card.root.removeAnimation(forKey: "opacity"); card.root.removeAnimation(forKey: "transform")
            if cancelCarouselUnfold { card.root.removeAnimation(forKey: "position") }
            card.root.isHidden = card.image.contents == nil; card.root.opacity = 1; card.image.isHidden = false; card.coverMask.isHidden = false
            if let reveal = card.reflection?.sublayers?.first, let mask = reveal.mask {
                mask.removeAnimation(forKey: "bounds.size.height"); mask.bounds.size.height = reveal.bounds.height * 0.4
                reveal.removeAnimation(forKey: "opacity"); reveal.opacity = 1
            }
        }
        for text in transitioningChrome {
            text.removeAnimation(forKey: "opacity"); text.removeAnimation(forKey: "transform"); text.opacity = 0
        }
        CATransaction.commit()
        maskPending = false; entranceFinished = false
        entryRequested = false; entryStarted = false; entranceWaveStart = nil; phase(.idle)
    }
    private func copyLayer(_ source: CALayer, presented: Bool = true) -> CALayer {
        let shown = presented ? (source.presentation() ?? source) : source
        let copy: CALayer
        if let text = source as? CATextLayer {
            let value = CATextLayer(); value.string = text.string; value.font = text.font; value.fontSize = text.fontSize
            value.foregroundColor = text.foregroundColor; value.alignmentMode = text.alignmentMode; value.truncationMode = text.truncationMode
            copy = value
        } else if let shape = source as? CAShapeLayer {
            let value = CAShapeLayer(); value.path = (shown as? CAShapeLayer)?.path ?? shape.path; value.fillColor = shape.fillColor; value.strokeColor = shape.strokeColor; value.lineWidth = shape.lineWidth; value.lineCap = shape.lineCap; copy = value
        } else if let gradient = source as? CAGradientLayer {
            let value = CAGradientLayer(); value.colors = gradient.colors; value.locations = gradient.locations; value.startPoint = gradient.startPoint; value.endPoint = gradient.endPoint; copy = value
        } else { copy = CALayer() }
        copy.name = source.name; copy.zPosition = source.zPosition; copy.anchorPoint = source.anchorPoint
        copy.bounds = shown.bounds; copy.position = shown.position; copy.transform = shown.transform; copy.opacity = shown.opacity
        // Text owns its backing store; copying its rendered contents can retain
        // the previous caption even after the string changes on a reused layer.
        if !(source is CATextLayer) { copy.contents = source.contents }
        copy.contentsGravity = source.contentsGravity; copy.contentsScale = source.contentsScale
        copy.cornerRadius = source.cornerRadius; copy.masksToBounds = source.masksToBounds; copy.backgroundColor = source.backgroundColor
        copy.isHidden = source.isHidden; copy.filters = source.filters; copy.backgroundFilters = source.backgroundFilters
        for child in source.sublayers ?? [] { copy.addSublayer(copyLayer(child, presented: presented)) }
        if let mask = source.mask { copy.mask = copyLayer(mask, presented: presented) }
        if let reading = source.animation(forKey: "reading") { copy.add(reading, forKey: "reading") }
        return copy
    }
    private func captionBlock(title: CALayer, artist: CALayer, from source: CALayer? = nil, into destination: CALayer) -> CALayer {
        let localFrame = title.frame.union(artist.frame)
        func visibleWidth(_ clip: CALayer, size: CGFloat, weight: Font.Weight) -> CGFloat {
            guard let text = clip.sublayers?.first as? CATextLayer, text.alignmentMode == .left else { return clip.bounds.width }
            return min(clip.bounds.width, ceil(SonoTypography.width(text.string as? String ?? "", size: size, weight: weight)))
        }
        let focusWidth = max(1, visibleWidth(title, size: SonoDesktopTokens.FontSize.itemTitle, weight: SonoDesktopTokens.FontWeight.semibold), visibleWidth(artist, size: SonoDesktopTokens.FontSize.body, weight: SonoDesktopTokens.FontWeight.medium))
        let focusFrame = CGRect(x: localFrame.minX, y: localFrame.minY, width: focusWidth, height: localFrame.height)
        let block = CALayer()
        block.name = "layout-caption-block"
        block.frame = source?.convert(focusFrame, to: destination) ?? focusFrame
        for line in [title, artist] {
            let frame = line.frame.offsetBy(dx: -focusFrame.minX, dy: -focusFrame.minY)
            line.removeFromSuperlayer()
            block.addSublayer(line)
            line.frame = frame
        }
        return block
    }
    private struct Departure {
        let layout: BrowserLayout
        let root: CALayer
        let centerID: String?
        let center: CALayer?
        let eligible: Bool
    }
    private func snapshotDeparture(preserving: (id: String, tile: CALayer)? = nil, movingCenter: String? = nil) -> Departure {
        let root = CALayer(); root.frame = bounds; root.zPosition = 4000
        let source = lastLayout ?? .wall
        let id = preserving?.id ?? movingCenter ?? lastExpansion ?? (lastLayout == .carousel ? lastAnchor : nil)
        var center: CALayer?
        if let id, let card = cards[id] {
            let copy: CALayer
            if id == preserving?.id { copy = preserving!.tile }
            else {
                copy = copyLayer(card.root)
                let offset = presentedContentOffset
                copy.position.x += offset.x; copy.position.y += offset.y
            }
            copy.name = id; root.addSublayer(copy); center = copy
        }
        let r = center?.frame ?? .zero
        let sourceMetrics = renderedMetrics ?? metrics
        let centered = abs(r.midX - metrics.anchor.x) < 0.75 && abs(r.midY - metrics.anchor.y) < 0.75 && abs(r.width - sourceMetrics.side) < 0.75
        let eligible = renderedOwner == browser?.sourceOwner && id != nil && cards[id!]?.artworkReady == true && cards[id!]?.image.contents != nil && center?.isHidden == false && (center?.opacity ?? 0) > 0 && r.intersects(bounds) && (centered || movingCenter == id || preserving?.id == id)
        if movingCenter != nil && !centered {
            // Freeze only visible wall neighbors; they leave while the retained
            // cover moves directly into the carousel, without a wall reflow.
            for (other, card) in cards where other != id && !card.root.isHidden && screenFrame(card.root).intersects(bounds) {
                let copy = copyLayer(card.root)
                let offset = presentedContentOffset
                copy.position.x += offset.x; copy.position.y += offset.y
                copy.name = other; root.addSublayer(copy)
            }
        }
        return Departure(layout: source, root: root, centerID: id, center: center, eligible: eligible)
    }
    private func transaction(_ generation: UInt64, animations: () -> Void, completion: @escaping @MainActor () -> Void) {
        CATransaction.begin(); CATransaction.setDisableActions(true)
        CATransaction.setCompletionBlock { [weak self] in
            guard let self, self.layoutGeneration == generation else { return }
            completion()
        }
        animations(); CATransaction.commit()
    }
    private func beginSceneTransition(from source: BrowserLayout, outgoing: Departure, layoutChanged: Bool) {
        let refresh = deferredConfigure
        let departingNeighbors = outgoing.root.sublayers?.contains(where: { $0 !== outgoing.center }) == true
        let preserveCarouselDetails = source == .carousel && browser?.layout == .carousel && outgoing.eligible &&
            outgoing.centerID == (browser?.location.expanded ?? browser?.location.anchor)
        cancelLayoutTransition(); layoutTransitionActive = true; targetLayout = browser?.layout; phase(.preparing)
        deferredConfigure = refresh
        retainedCarouselDetails = preserveCarouselDetails
        if preserveCarouselDetails, let center = outgoing.center {
            // Establish ownership before rendering: the live target is hidden
            // during preparation, while its existing caption and mirror stay visible.
            center.removeFromSuperlayer(); center.zPosition = 5000; layer?.addSublayer(center)
            sharedCenter = center; retainedCenterID = outgoing.centerID
            CATransaction.begin(); CATransaction.setDisableActions(true)
            for text in transitioningChrome { text.opacity = 1 }
            CATransaction.commit()
        }
        let generation = layoutGeneration
        departureScene = outgoing; layer?.addSublayer(outgoing.root)
        // Register the target entrance before rendering so artwork callbacks
        // cannot reveal it before the shared cover has changed ownership.
        requestEntrance(); phase(.preparing)
        render(animated: false)
        let target = browser?.location.expanded ?? browser?.location.anchor
        let card = target.flatMap { cards[$0] }
        let r = card.map { screenFrame($0.root, presented: false) } ?? .zero
        let retain = outgoing.eligible && outgoing.centerID == target && card?.artworkReady == true && abs(r.midX - metrics.anchor.x) < 0.75 && abs(r.midY - metrics.anchor.y) < 0.75
        var departingWallCaption: CALayer?
        if retain, let center = outgoing.center {
            retainedWallCaption = source == .wall && browser?.layout == .wall &&
                center.sublayers?.contains(where: { $0.name == "layout-caption-block" }) != true
            if !retainedWallCaption {
                if source == .wall, let block = center.sublayers?.first(where: { $0.name == "layout-caption-block" }) {
                    departingWallCaption = block
                } else if source == .wall,
                   let title = center.sublayers?.first(where: { $0.name == "cover-title" }),
                   let artist = center.sublayers?.first(where: { $0.name == "cover-artist" }) {
                    // Keep the caption above its retained artwork, just as on
                    // entrance. The departure scene sits below this cover.
                    let block = captionBlock(title: title, artist: artist, into: center)
                    center.addSublayer(block); departingWallCaption = block
                }
                let labels = CALayer(); labels.bounds = center.bounds; labels.position = center.position
                for child in (center.sublayers ?? []).filter({ !["artwork", "cover-mask", "search-gradient", "layout-caption-block"].contains($0.name ?? "") }) { child.removeFromSuperlayer(); labels.addSublayer(child) }
                if labels.sublayers?.isEmpty == false { outgoing.root.addSublayer(labels) }
            }
            if sharedCenter !== center {
                center.removeFromSuperlayer(); center.zPosition = 5000; layer?.addSublayer(center)
                sharedCenter = center; retainedCenterID = target
            }
        }
        for candidate in cards.values { candidate.root.isHidden = true }
        if !retainedCarouselDetails {
            for text in transitioningChrome { text.opacity = 0 }
        }
        if retain && layoutChanged, let center = self.sharedCenter, let card {
            maskPending = true
            transaction(generation, animations: {
                let position = center.position, transform = center.transform, cornerRadius = center.cornerRadius
                center.position = CGPoint(x: r.midX, y: r.midY)
                center.transform = CATransform3DScale(card.root.transform, card.root.bounds.width / center.bounds.width, card.root.bounds.height / center.bounds.height, 1)
                center.cornerRadius = card.root.cornerRadius / max(card.root.bounds.width / center.bounds.width, card.root.bounds.height / center.bounds.height)
                self.animate(center, key: "position", from: NSValue(point: position), to: NSValue(point: center.position), duration: 0.56)
                self.animate(center, key: "transform", from: NSValue(caTransform3D: transform), to: NSValue(caTransform3D: center.transform), duration: 0.56)
                self.animate(center, key: "cornerRadius", from: cornerRadius, to: center.cornerRadius, duration: 0.56)
                self.compensateSharedArtwork(center, from: transform, target: r, cornerRadius: card.root.cornerRadius)
                if let mask = center.sublayers?.first(where: { $0.name == "cover-mask" }) { self.animateMask(mask, wall: self.browser?.layout == .wall) }
            }, completion: { [weak self] in
                guard let self else { return }; self.maskPending = false
                if self.entranceFinished { self.finishEntrance() }
            })
        }
        // Every browse navigation uses the same immediate handoff, including
        // back, search, playlist selection and playback-source restoration.
        releaseCarouselEdges()
        departingWallCaption?.removeFromSuperlayer()
        if departingNeighbors && layoutChanged && source == .wall {
            transaction(generation, animations: {
                outgoing.root.opacity = 0
                self.animate(outgoing.root, key: "opacity", from: Float(1), to: Float(0), duration: 0.24)
            }, completion: { [weak self] in
                outgoing.root.removeFromSuperlayer(); self?.departureScene = nil
            })
        } else { departure?.removeFromSuperlayer(); departureScene = nil }
        requestEntrance(); releaseEntrance()
    }
    private func compensateSharedArtwork(_ center: CALayer, from initial: CATransform3D, target: CGRect, cornerRadius: CGFloat) {
        guard abs(center.bounds.width - center.bounds.height) > 0.01,
              let image = center.sublayers?.first(where: { $0.name == "artwork" }) else { return }
        // Rectangular wall cards change aspect ratio. Keep the bitmap uniformly
        // scaled under that changing crop, including when a switch reverses.
        if image.contentsGravity != .resize {
            let bitmap = image.contents as! CGImage
            let scale = max(center.bounds.width / CGFloat(bitmap.width), center.bounds.height / CGFloat(bitmap.height))
            image.bounds = CGRect(x: 0, y: 0, width: CGFloat(bitmap.width) * scale, height: CGFloat(bitmap.height) * scale)
            image.position = CGPoint(x: center.bounds.midX, y: center.bounds.midY)
            image.contentsGravity = .resize
        }
        let fromScale = initial.m11 * image.transform.m11
        let toScale = max(target.width / image.bounds.width, target.height / image.bounds.height)
        var transforms: [NSValue] = [], corners: [CGPath] = []
        for sample in 0...60 {
            let progress = CGFloat(BrowseCameraMotion.progress(Double(sample) / 60))
            let x = initial.m11 + (center.transform.m11 - initial.m11) * progress
            let y = initial.m22 + (center.transform.m22 - initial.m22) * progress
            let scale = fromScale + (toScale - fromScale) * progress
            transforms.append(NSValue(caTransform3D: CATransform3DMakeScale(scale / x, scale / y, 1)))
            corners.append(CGPath(roundedRect: center.bounds, cornerWidth: cornerRadius / x, cornerHeight: cornerRadius / y, transform: nil))
        }
        let start = center.animation(forKey: "transform")?.beginTime ?? CACurrentMediaTime()
        let artwork = CAKeyframeAnimation(keyPath: "transform")
        artwork.values = transforms; artwork.duration = 0.56; artwork.beginTime = start
        artwork.calculationMode = .linear; artwork.fillMode = .backwards
        image.transform = transforms.last!.caTransform3DValue
        image.add(artwork, forKey: "layoutArtwork")
        let mask = CAShapeLayer(); mask.path = corners.last; mask.fillColor = NSColor.black.cgColor
        let rounding = CAKeyframeAnimation(keyPath: "path")
        rounding.values = corners; rounding.duration = artwork.duration; rounding.beginTime = start
        rounding.calculationMode = .linear; rounding.fillMode = .backwards
        mask.add(rounding, forKey: "layoutCorners")
        center.removeAnimation(forKey: "cornerRadius"); center.cornerRadius = 0; center.mask = mask
    }
    private func distance(_ rect: CGRect) -> CGFloat { hypot(max(rect.minX - metrics.anchor.x, 0, metrics.anchor.x - rect.maxX), max(rect.minY - metrics.anchor.y, 0, metrics.anchor.y - rect.maxY)) }
    private func scaleEntrance(_ tile: CALayer, delay: Double, centered: Bool = false, start: CFTimeInterval? = nil) {
        let rect = screenFrame(tile, presented: false)
        let x = centered ? 0 : min(rect.width, max(0, metrics.anchor.x - rect.minX)) - rect.width / 2
        let y = centered ? 0 : min(rect.height, max(0, metrics.anchor.y - rect.minY)) - rect.height / 2
        let collapsed = CATransform3DScale(CATransform3DMakeTranslation(x * 0.8, y * 0.8, 0), 0.2, 0.2, 1)
        tile.opacity = 1
        let timing = CAMediaTimingFunction(controlPoints: 0.16, 1, 0.3, 1)
        animate(tile, key: "opacity", from: Float(0), to: Float(1), duration: 0.46, delay: delay, timing: timing, start: start)
        animate(tile, key: "transform", from: NSValue(caTransform3D: collapsed), to: NSValue(caTransform3D: tile.transform), duration: 0.46, delay: delay, timing: timing, start: start)
    }
    private func requestEntrance(reset: Bool = true) {
        if browser?.layout == .carousel && !reduced {
            layoutTransitionActive = true; targetLayout = .carousel
        }
        entryRequested = true; entryStarted = false; entranceFinished = false; wallArrival = true
        entrancePreparation?.cancel(); entrancePreparation = nil; preparationGate = ColdEntranceGate(); startupTargets = [:]; startupTargetSize = .zero; startupResourcesFinished = false
        entranceWaveStart = nil
        artworkDemandDirty = true
        phase(.waiting)
        for card in cards.values { card.revealed = !reset && card.artworkReady }
    }
    private func releaseEntrance(ready: Card? = nil) {
        guard entryRequested, !rendering else { return }
        guard wallArrival, let browser, !reduced else {
            if reduced { entrancePreparation?.cancel(); entrancePreparation = nil; entryRequested = false; for card in cards.values { card.root.isHidden = card.image.contents == nil; card.root.opacity = 1; card.revealed = true }; finishEntrance() }
            return
        }
        if layoutTransitionActive && stagePhase != .waiting && stagePhase != .sidesIn { return }
        let id = browser.location.expanded ?? browser.location.anchor
        // An unexpanded wall may initially be published before its central metadata arrives.
        var central = id.flatMap { cards[$0] }
        if central == nil && browser.layout == .wall {
            let initial = field.initialIndex
            if tracks.indices.contains(initial) { central = cards[tracks[initial].id] }
        }
        guard let central = central ?? (startupEntrance ? cards.values.first : nil) else { return }
        if !startupEntrance && !central.artworkReady { if stagePhase == .cameraMoving { phase(.waiting) }; return }
        if !entryStarted {
            if startupEntrance {
                let now = CACurrentMediaTime()
                if startupTargets.isEmpty || startupTargetSize != bounds.size {
                    startupTargetSize = bounds.size
                    startupTargets = Dictionary(uniqueKeysWithValues: field.visibleIndices(camera: camera, margin: 0).compactMap { index in
                        guard tracks.indices.contains(index), tracks[index].coverURL != nil else { return nil }
                        return (tracks[index].id, field.rect(index).offsetBy(dx: camera.x, dy: camera.y))
                    })
                }
                let centerRect = screenFrame(central.root, presented: false)
                var readyCount = 0, available = 0, failed = 0
                var totalArea = 0.0, readyArea = 0.0
                var innerReady = true
                for (id, rect) in startupTargets {
                    let visible = rect.intersection(bounds)
                    let area = Double(max(0, visible.width) * max(0, visible.height))
                    totalArea += area
                    let card = cards[id]
                    let targetReady = card.map(targetArtworkReady) ?? false
                    if targetReady { readyCount += 1; readyArea += area }
                    if let card, card.hasRealArtwork { available += 1 }
                    if card?.artworkResult == .failed && card?.hasRealArtwork != true { failed += 1 }
                    if WallArtworkLoading.distance(rect, loaded: [centerRect], fallback: metrics.anchor) <= field.metrics.pitch && !targetReady { innerReady = false }
                }
                let firstEvaluation = preparationGate.started == nil
                let hadFirstReady = preparationGate.firstReady != nil
                let decision = preparationGate.evaluate(now: now, total: startupTargets.count, ready: readyCount, available: available,
                    failed: failed, readyArea: readyArea, totalArea: totalArea, innerReady: innerReady)
                if !hadFirstReady && preparationGate.firstReady != nil { BrowseDiagnostics.shared.mark("entrance.firstTargetReady") }
                if firstEvaluation {
                    BrowseDiagnostics.shared.mark("entrance.targets", fields: ["cards": String(startupTargets.count)])
                    for id in startupTargets.keys {
                        if let card = cards[id], let url = card.url {
                            BrowseDiagnostics.shared.mark("entrance.resource", fields: ["resource": BrowseDiagnostics.shared.resourceID(ArtworkResource.identity(url)), "requestedPixels": String(card.requestedPixels)])
                        }
                    }
                }
                switch decision {
                case .waiting:
                    if let deadline = preparationGate.deadline, deadline > now {
                        entrancePreparation?.cancel()
                        entrancePreparation = Task { @MainActor [weak self] in
                            do { try await Task.sleep(for: .seconds(deadline - now)) } catch { return }
                            guard let self, self.entryRequested, !self.entryStarted else { return }
                            self.entrancePreparation = nil; self.releaseEntrance()
                        }
                    } else if firstEvaluation || entrancePreparation != nil {
                        BrowseDiagnostics.shared.mark("entrance.emptyDeadline")
                        entrancePreparation = nil
                    }
                    return
                case .emptyFailure, .noResources:
                    entrancePreparation?.cancel(); entrancePreparation = nil
                    entryStarted = true; entranceWaveStart = now; fallbackRevealAt = now
                    for card in cards.values where card.artworkReady {
                        card.root.isHidden = card.image.contents == nil; card.root.opacity = 1; card.revealed = true
                    }
                    BrowseDiagnostics.shared.mark("entrance.noRealWave", fields: ["reason": String(describing: decision)])
                    finishEntrance(); return
                case .release(let reason):
                    BrowseDiagnostics.shared.mark("entrance.released", fields: ["reason": reason, "ready": String(readyCount), "total": String(startupTargets.count),
                        "readyAreaFraction": String(totalArea > 0 ? readyArea / totalArea : 0), "late": String(startupTargets.count - readyCount)])
                    fallbackRevealAt = now + 0.46 + (startupTargets.values.map { Double(distance($0)) * 0.0012 }.max() ?? 0)
                }
            }
            entrancePreparation?.cancel(); entrancePreparation = nil
            entryStarted = true
            if startupEntrance && !startupResourcesFinished && startupTargets.keys.allSatisfy({ cards[$0]?.artworkResult != .pending }) {
                startupResourcesFinished = true
                let source = lastSource, generation = layoutGeneration
                Task { @MainActor [weak self] in
                    await Task.yield()
                    guard let self, self.lastSource == source, self.layoutGeneration == generation, self.startupEntrance else { return }
                    self.render(animated: false)
                }
            }
            let generation = layoutGeneration
            phase(.sidesIn)
            let start = CACurrentMediaTime()
            transaction(generation, animations: {
                if self.retainedCenterID == nil && browser.layout == .carousel {
                    central.root.isHidden = false; central.revealed = true
                    self.scaleEntrance(central.root, delay: 0, centered: true, start: start)
                    self.updateCarouselReflections()
                    if let mirror = central.reflection, let timing = central.root.animation(forKey: "transform") as? CABasicAnimation {
                        self.animateReflectionReveal(mirror, timing: timing)
                    }
                }
                // Center, caption and ready neighbors share one entrance.
                self.revealReadyCards(central: central, startingEntrance: true, entranceStart: start)
            }, completion: { [weak self] in self?.finishEntrance() })
        } else { revealReadyCards(central: central, ready: ready) }
    }
    private func revealReadyCards(central: Card, ready: Card? = nil, startingEntrance: Bool = false, entranceStart: CFTimeInterval? = nil) {
        if browser?.layout == .carousel {
            reconcileCarouselVisibility()
            let centerIndex = ordinal(central.index)
            let sides = cards.values.filter { !$0.retiring && !$0.root.isHidden }.map { ($0.root, ordinal($0.index)) }
                + unknownCards.map { ($0.value, $0.key) }
            if startingEntrance && !retainedCarouselDetails {
                for (tile, index) in sides where index != centerIndex && tile.opacity > 0 {
                    let start = CGPoint(x: central.root.position.x, y: tile.position.y)
                    animate(tile, key: "position", from: NSValue(point: start), to: NSValue(point: tile.position), duration: 0.46, start: entranceStart)
                }
            }
            if layoutTransitionActive && !reduced {
                guardCarouselEdges(center: sharedCenter ?? central.root, centerIndex: centerIndex, cards: sides)
                updateCarouselReflections()
            }
            let revealingCaption = !captionClip.isHidden && captionClip.opacity == 0
            for text in transitioningChrome where !text.isHidden && text.opacity == 0 { scaleEntrance(text, delay: 0, centered: true, start: entranceStart) }
            if revealingCaption, retainedCenterID != nil, let mirror = central.reflection, let timing = captionClip.animation(forKey: "transform") as? CABasicAnimation {
                animateReflectionReveal(mirror, timing: timing)
            }
            return
        }
        let wall = browser?.layout == .wall
        let now = CACurrentMediaTime()
        if entranceWaveStart == nil { entranceWaveStart = now }
        let elapsed = now - (entranceWaveStart ?? now)
        if startupEntrance && ready == nil && entrancePreparation == nil && fallbackRevealAt > now {
            BrowseDiagnostics.shared.mark("entrance.waveStarted")
            entrancePreparation = Task { @MainActor [weak self, weak central] in
                do { try await Task.sleep(for: .seconds(max(0, self.map { $0.fallbackRevealAt - CACurrentMediaTime() } ?? 0))) } catch { return }
                guard let self, let central, self.entryRequested else { return }
                self.entrancePreparation = nil; self.revealReadyCards(central: central)
            }
        }
        let candidates = ready.map { [(tracks[$0.index].id, $0)] } ?? Array(cards)
        let captionEntranceDelay = cards.values.filter { $0 !== central && !$0.retiring }
            .map { distance(screenFrame($0.root, presented: false)) }.min()
            .map { BrowseEntranceTiming.remainingDelay(distance: $0, elapsed: elapsed) } ?? 0
        for (id, card) in candidates where !card.retiring && !card.revealed && card.artworkReady && card.image.contents != nil {
            if startupEntrance {
                let real = card.hasRealArtwork
                let fallback = card.artworkResult != .pending && !real
                guard real || (fallback && now >= fallbackRevealAt) else { continue }
            }
            card.revealed = true; card.root.isHidden = false; card.root.opacity = 1
            browseReveals[id] = BrowseReveal(started: now, delay: 0, origin: .zero, ready: true, done: true)
            if id == retainedCenterID {
                card.root.isHidden = true
                if wall && !retainedWallCaption, let sharedCenter {
                    // This is incoming wall content. Its presentation still belongs
                    // to the carousel's hidden labels until the next compositor frame.
                    let block = captionBlock(title: copyLayer(card.titleClip, presented: false),
                                             artist: copyLayer(card.artistClip, presented: false),
                                             from: card.root, into: sharedCenter)
                    sharedCenter.addSublayer(block)
                    scaleEntrance(block, delay: captionEntranceDelay, centered: true)
                }
                continue
            }
            if wall {
                let radialStart = Double(distance(screenFrame(card.root, presented: false))) * 0.0012
                if startupEntrance && (elapsed > radialStart || card.loadedPixels == 0) {
                    animate(card.root, key: "opacity", from: Float(0), to: Float(1), duration: 0.16)
                    BrowseDiagnostics.shared.mark("entrance.lateFade")
                } else { scaleEntrance(card.root, delay: card === central ? 0 : BrowseEntranceTiming.remainingDelay(distance: distance(screenFrame(card.root, presented: false)), elapsed: elapsed)) }
            }
        }
        for text in transitioningChrome where !text.isHidden && text.opacity == 0 { scaleEntrance(text, delay: 0, centered: true) }
        // Wall batches update accessibility once after all ready cards reveal.
    }
    private func finishEntrance() {
        guard !entranceFinished || layoutTransitionActive else { return }
        entranceFinished = true
        guard !maskPending else { return }
        if browser?.layout == .carousel { entryRequested = false }
        // One atomic ownership transfer. The target already owns the final image,
        // mask and geometry; removing the borrowed layer must not expose opacity 0.
        CATransaction.begin(); CATransaction.setDisableActions(true)
        if let id = retainedCenterID, let card = cards[id] {
            for key in ["opacity", "transform"] { card.root.removeAnimation(forKey: key) }
            card.root.opacity = 1
            card.root.isHidden = false; card.image.isHidden = false; card.coverMask.isHidden = false
            card.revealed = true
            card.coverMask.opacity = browser?.layout == .wall ? 1 : 0
        }
        sharedCenter?.removeFromSuperlayer(); sharedCenter = nil; retainedCenterID = nil; retainedWallCaption = false; retainedCarouselDetails = false
        CATransaction.commit()
        layoutTransitionActive = false; phase(.idle)
        reconcileCarouselVisibility()
        rebuildAccessibility()
        if let pointer = lastPointer { updatePointer(pointer) }
        let refresh = deferredConfigure; deferredConfigure = nil; refresh?()
        // Late covers retain this wave's clock; completed cards never restart.
    }
    private func presentedWallCamera() -> CGPoint { previewCamera ?? presentedContentOffset }
    private var presentedContentOffset: CGPoint {
        content.animation(forKey: "position") == nil ? content.position : (content.presentation()?.position ?? content.position)
    }
    private func screenFrame(_ tile: CALayer, presented: Bool = true) -> CGRect {
        let frame = presented ? (tile.presentation()?.frame ?? tile.frame) : tile.frame
        guard tile.superlayer === content else { return frame }
        let offset = presented ? presentedContentOffset : content.position
        return frame.offsetBy(dx: offset.x, dy: offset.y)
    }
    private func localPoint(_ point: CGPoint, in tile: CALayer) -> CGPoint {
        let shown = tile.presentation() ?? tile
        let offset = presentedContentOffset
        return shown.convert(CGPoint(x: point.x - offset.x, y: point.y - offset.y), from: shown.superlayer)
    }

    private func queueWallPan(_ point: CGPoint) {
        if diagnosticIndices != nil && !diagnosticOpaque { BrowseDiagnostics.shared.mark("scene.loadingInterruptedByPan"); diagnosticIndices = nil }
        let target = field.clamp(point, from: expandedIndex == nil ? nil : presentedWallCamera())
        previewCamera = target; pendingPan = true
        // Already-mounted tiles can follow input in this transaction. Membership,
        // artwork priorities and reveals still consume only the latest point per tick.
        if canTranslateWall(to: target) { translateWall(to: target) }
        wakePanLink()
    }
    private func canTranslateWall(to point: CGPoint) -> Bool {
        let viewport = CGRect(x: -point.x, y: -point.y, width: bounds.width, height: bounds.height)
        return renderedSize == bounds.size && bufferedViewport.contains(viewport) && !layoutTransitionActive
    }
    private func translateWall(to point: CGPoint) {
        guard content.position != point || content.animation(forKey: "position") != nil else { return }
        CATransaction.begin(); CATransaction.setDisableActions(true)
        content.removeAnimation(forKey: "position"); content.position = point
        CATransaction.commit()
    }
    private func wakePanLink() {
        guard window?.occlusionState.contains(.visible) == true else { return }
        if let panLink { panLink.isPaused = false; return }
        let link = displayLink(target: self, selector: #selector(panFrame(_:)))
        panLink = link; link.add(to: .main, forMode: .common)
    }
    @objc private func panFrame(_ link: CADisplayLink) {
        guard panLink === link else { return }
        guard window?.occlusionState.contains(.visible) == true else { link.isPaused = true; return }
        let measurement = BrowseDiagnostics.shared.start()
        defer { BrowseDiagnostics.shared.end("input.wallDisplayTick", measurement) }
        let moving = pendingPan
        flushWallPan(commit: false)
        // Input keeps its own frame budget. Prepare the screen-edge buffer on
        // idle display ticks, without delaying the latest camera or visible tiles.
        if !moving && pendingBufferPreparation && browser?.layout == .wall && !layoutTransitionActive {
            let preparation = BrowseDiagnostics.shared.start()
            render(animated: false, membershipOnly: true, preparationLimit: 8)
            BrowseDiagnostics.shared.end("scene.bufferPreparation", preparation)
        }
        link.isPaused = !pendingPan && !pendingBufferPreparation
    }
    private func flushWallPan(commit: Bool = true) {
        panLink?.isPaused = !pendingBufferPreparation || window?.occlusionState.contains(.visible) != true
        guard let point = previewCamera, browser?.layout == .wall else { return }
        if pendingPan {
            pendingPan = false
            let measurement = BrowseDiagnostics.shared.start()
            if canTranslateWall(to: point) {
                translateWall(to: point)
                BrowseDiagnostics.shared.count("scene.cameraOnly")
                updateArtworkPriorities()
                revealBrowsingCards()
                updateAccessibilityMembership()
            } else { render(animated: false, membershipOnly: renderedSize == bounds.size && renderedField === field && lastLayout == .wall, preparationLimit: 0) }
            // Prefetch never delays the camera's transaction. Coalesce to the
            // latest presented camera, at utility priority after input handling.
            if directionalFlush == nil {
                directionalFlush = Task(priority: .utility) { @MainActor [weak self] in
                    await Task.yield()
                    guard !Task.isCancelled, let self else { return }
                    self.directionalFlush = nil
                    self.updateDirectionalRequests(camera: self.presentedWallCamera())
                }
            }
            if let pointer = lastPointer { updatePointer(pointer) }
            updateFocusRing()
            BrowseDiagnostics.shared.end("input.wallFrame", measurement)
        }
        if commit { commitPan() }
    }
    private func animateMask(_ mask: CALayer, wall: Bool) {
        let initial = mask.presentation()?.opacity ?? mask.opacity
        mask.removeAnimation(forKey: "layoutMask")
        let target: Float = wall ? 1 : 0
        mask.opacity = target
        let animation = CAKeyframeAnimation(keyPath: "opacity")
        animation.values = SonoCoverMask.values(showing: wall).map { sample in initial + (target - initial) * (wall ? sample : 1 - sample) }
        animation.duration = 1; animation.calculationMode = .linear
        mask.add(animation, forKey: "layoutMask")
    }
    private var centerIndex: Int {
        browser?.location.anchor.flatMap { browser?.layout == .carousel ? carouselOrdinals[$0] : trackData?.index[$0] } ?? 0
    }
    private var expandedIndex: Int? { browser?.location.expanded.flatMap { trackData?.index[$0] } }
    private var field: WallGeometry {
        if let renderedField, renderedField.viewport == bounds.size, renderedField.expanded == expandedIndex, renderedField.count == (browser?.roundWall == true ? tracks.count : max(tracks.count, browser?.sourceTotal ?? 0)), renderedField.search == (browser?.roundWall == true) { return renderedField }
        return browser!.geometry(items: tracks, viewport: bounds.size, expanded: expandedIndex)
    }
    private var carousel: CarouselGeometry {
        if preparedCarousel?.metrics != metrics {
            preparedCarousel = CarouselGeometry.Preparation(metrics: metrics)
        }
        let geometry = CarouselGeometry(count: carouselIDs.count, viewport: bounds.size, position: previewPosition ?? CGFloat(centerIndex), preparation: preparedCarousel)
        return geometry
    }
    private var camera: CGPoint {
        if let previewCamera { return previewCamera }
        let stored = browser?.location.camera ?? .zero
        return expandedIndex == nil ? field.clamp(stored) : stored
    }
    private func render(animated: Bool, membershipOnly: Bool = false, preparationLimit: Int? = nil, motionOnly: Bool = false) {
        guard presented else { return }
        let measurement = BrowseDiagnostics.shared.start(); defer { BrowseDiagnostics.shared.end("scene.render", measurement) }
        guard layer != nil, let browser, bounds.width > 0, bounds.height > 0 else { return }
        if previewPhase == .moving || previewPhase == .waiting {
            updateCarouselRail(); updateCompactPreview(); return
        }
        rendering = true
        defer { rendering = false }
        BrowseDiagnostics.shared.set("viewport", "\(bounds.width)x\(bounds.height)")
        let wall = browser.layout == .wall
        layer?.backgroundColor = browseBackground(wall: wall)
        let metrics = self.metrics
        motion?.configure(count: sceneCount, side: Double(metrics.side), reduced: reduced)
        let field = wall ? self.field : nil, carousel = self.carousel
        let frameOnly = motionOnly && !wall && !entryRequested && !layoutTransitionActive && renderedSize == bounds.size
        let centerChanged = renderedCarouselCenter != carousel.center
        if !wall {
            BrowseDiagnostics.shared.count(frameOnly ? "carousel.motionRender" : "carousel.layoutRender")
        }
        if wall { renderedField = field }
        let camera = wall ? self.camera : .zero
        let selected = wall ? expandedIndex : carouselCenterIndex
        let anchorIndex = centerIndex
        let margin = field.map { max(32, min(bounds.width, bounds.height) * 0.15, $0.metrics.pitch * 2) } ?? 32
        let membershipStart = BrowseDiagnostics.shared.start()
        var indices = wall ? field!.visibleIndices(camera: camera, margin: margin).filter { tracks.indices.contains($0) } : carousel.indices.compactMap { carouselTrackIndices[$0] }
        if let selected, tracks.indices.contains(selected), !indices.contains(selected) { indices.append(selected) }
        // The unexpanded wall's anchor is also critical to entrance. Rank wall
        // neighbors by screen distance, not queue order in the two-dimensional lattice.
        let priority = selected ?? anchorIndex
        if let field, wall {
            let view = CGRect(origin: .zero, size: bounds.size)
            let anchor = entryRequested ? metrics.anchor : CGPoint(x: bounds.midX, y: bounds.midY)
            // Resolve geometry and ObservableObject-backed metrics once per card,
            // rather than repeatedly through the sort comparator.
            indices = indices.map { index in
                let rect = field.rect(index).offsetBy(dx: camera.x, dy: camera.y)
                let distance = hypot(max(rect.minX - anchor.x, 0, anchor.x - rect.maxX), max(rect.minY - anchor.y, 0, anchor.y - rect.maxY))
                return (index: index, visible: rect.intersects(view), distance: distance)
            }.sorted { a, b in
                if a.index == b.index { return false }
                if a.index == priority { return true }; if b.index == priority { return false }
                if a.visible != b.visible { return a.visible }
                return a.distance == b.distance ? a.index < b.index : a.distance < b.distance
            }.map(\.index)
        } else if !frameOnly {
            indices.sort { a, b in
                if a == b { return false }
                if a == priority { return true }; if b == priority { return false }
                return abs(a - priority) < abs(b - priority)
            }
        }
        if diagnosticIndices?.isEmpty == true {
            diagnosticIndices = wall ? field!.visibleIndices(camera: camera, margin: 0) : carousel.indices.filter { carousel.rect($0).intersects(bounds) }
            var usage = rusage(); getrusage(RUSAGE_SELF, &usage)
            let cpu = Double(usage.ru_utime.tv_sec + usage.ru_stime.tv_sec) + Double(usage.ru_utime.tv_usec + usage.ru_stime.tv_usec) / 1_000_000
            BrowseDiagnostics.shared.mark("scene.targetDemand", fields: ["cpuSeconds": String(cpu), "peakRSSMiB": String(Double(usage.ru_maxrss) / 1048576)])
        }
        BrowseDiagnostics.shared.end("scene.membership", membershipStart)
        if !frameOnly { artworkDemandDirty = true }
        let wanted = Set(indices.map { tracks[$0].id })
        let duration: CFTimeInterval = animated && !reduced ? 0.56 : 0
        CATransaction.begin(); CATransaction.setDisableActions(true)
        let oldOffset = presentedContentOffset
        let targetOffset = wall ? camera : .zero
        let coordinateChange = (lastLayout == .wall) != wall
        content.position = targetOffset
        if duration > 0 && wall && !coordinateChange {
            animate(content, key: "position", from: NSValue(point: oldOffset), to: NSValue(point: targetOffset), duration: duration)
        } else { content.removeAnimation(forKey: "position") }
        bufferedViewport = wall ? CGRect(x: -camera.x, y: -camera.y, width: bounds.width, height: bounds.height).insetBy(dx: -(margin - 32), dy: -(margin - 32)) : .null
        var retiring: [(String, Card, UInt64)] = []
        var prepared = 0
        let preparationStarted = CACurrentMediaTime()
        pendingBufferPreparation = false
        let cardsStart = BrowseDiagnostics.shared.start()
        artworkStore.updateRequests {
            let retireStart = BrowseDiagnostics.shared.start()
            for (id, card) in cards where !wanted.contains(id) {
                artworkStore.cancel(card.token); card.token = nil; card.requestedPixels = 0
                if duration == 0 { card.removeFromScene(); cards[id] = nil }
                else {
                    let opacity = card.root.presentation()?.opacity ?? card.root.opacity
                    if wall {
                        // Camera translation belongs to content, including departing cards.
                        card.root.opacity = opacity
                    } else {
                        card.root.opacity = 0
                        animate(card.root, key: "opacity", from: opacity, to: Float(0), duration: 0.16)
                    }
                    card.retiring = true; card.retirementGeneration &+= 1
                    retiring.append((id, card, card.retirementGeneration))
                }
            }
            BrowseDiagnostics.shared.end("scene.retire", retireStart)
            for index in indices {
                let track = tracks[index], id = track.id
                let created = cards[id] == nil
                if created, membershipOnly, let preparationLimit,
                   !field!.rect(index).offsetBy(dx: camera.x, dy: camera.y).intersects(bounds) {
                    if prepared >= preparationLimit || (prepared > 0 && CACurrentMediaTime() - preparationStarted >= 0.0015) {
                        pendingBufferPreparation = true
                        // Preserve prepared coverage. Only the edge beyond this
                        // missing tile is unsafe; invalidating every edge makes
                        // continuous input rebuild membership on every frame.
                        let missing = field!.rect(index)
                        let viewport = CGRect(x: -camera.x, y: -camera.y, width: bounds.width, height: bounds.height)
                        var left = bufferedViewport.minX, right = bufferedViewport.maxX
                        var top = bufferedViewport.minY, bottom = bufferedViewport.maxY
                        if missing.maxX <= viewport.minX { left = max(left, missing.maxX) }
                        if missing.minX >= viewport.maxX { right = min(right, missing.minX) }
                        if missing.maxY <= viewport.minY { top = max(top, missing.maxY) }
                        if missing.minY >= viewport.maxY { bottom = min(bottom, missing.minY) }
                        bufferedViewport = CGRect(x: left, y: top, width: right - left, height: bottom - top)
                        continue
                    }
                    prepared += 1
                }
                let creation = created ? BrowseDiagnostics.shared.start() : nil
                let card = cards[id] ?? Card(track: track, index: index)
                if cards[id] == nil { card.updateIndicatorColor(theme.accent) }
                BrowseDiagnostics.shared.end("card.create", creation)
                if created { BrowseDiagnostics.shared.count("card.created"); cards[id] = card; content.addSublayer(card.root); artworkDemandDirty = true }
                if membershipOnly && !created && !card.retiring {
                    continue
                }
                let center = index == selected
                if !wall && ordinal(index) == carousel.center && card.root.mask?.name != "pagination-reveal" { card.root.mask = nil }
                let updateContents = !frameOnly || created || card.expanded != center
                if updateContents {
                    card.index = index; card.retiring = false; card.retirementGeneration &+= 1
                    if card.title.string as? String != track.title { card.title.string = track.title }
                    if card.artist.string as? String != track.artist { card.artist.string = track.artist }
                    card.hovered = hoverID == id; card.expanded = index == selected
                }
                let rect = wall ? field!.rect(index) : carousel.rect(ordinal(index))
                let old = duration > 0 ? card.root.presentation() : nil
                var oldPosition = old?.position ?? card.root.position
                if coordinateChange {
                    oldPosition.x += oldOffset.x - targetOffset.x
                    oldPosition.y += oldOffset.y - targetOffset.y
                }
                let oldBounds = old?.bounds ?? card.root.bounds
                let oldTransform = old?.transform ?? card.root.transform
                let oldBlack = duration > 0 ? (card.black.presentation()?.opacity ?? card.black.opacity) : card.black.opacity
                let oldBlackBounds = duration > 0 ? (card.black.presentation()?.bounds ?? card.black.bounds) : card.black.bounds
                let oldBlackPosition = duration > 0 ? (card.black.presentation()?.position ?? card.black.position) : card.black.position
                let blackOpacity = wallBlackOpacity(card)
                if card.black.opacity != blackOpacity { card.black.opacity = blackOpacity }
                if !center || card.coverMask.animation(forKey: "layoutMask") == nil { card.coverMask.opacity = wall ? 1 : 0 }
                let position = CGPoint(x: rect.midX, y: rect.midY)
                if card.root.position != position {
                    if duration == 0 {
                        if wall, let existing = card.root.animation(forKey: "position") as? CABasicAnimation,
                           let flight = existing.copy() as? CABasicAnimation,
                           let from = flight.fromValue as? NSValue, let to = flight.toValue as? NSValue {
                            let dx = position.x - card.root.position.x, dy = position.y - card.root.position.y
                            flight.fromValue = NSValue(point: CGPoint(x: from.pointValue.x + dx, y: from.pointValue.y + dy))
                            flight.toValue = NSValue(point: CGPoint(x: to.pointValue.x + dx, y: to.pointValue.y + dy))
                            card.root.add(flight, forKey: "position")
                        } else { card.root.removeAnimation(forKey: "position") }
                    }
                    card.root.position = position
                }
                let resizing = card.root.bounds.size != rect.size
                if resizing {
                    if card.root.mask?.name == "pagination-reveal" {
                        card.root.mask = nil
                    }
                    if duration == 0 { card.root.removeAnimation(forKey: "bounds") }
                    card.root.bounds = CGRect(origin: .zero, size: rect.size)
                }
                let opacity = wall ? Float(1) : carousel.opacity(ordinal(index))
                if !wall { card.carouselShade.opacity = 1 - carousel.brightness(ordinal(index)) }
                if card.root.opacity != opacity { if duration == 0 { card.root.removeAnimation(forKey: "opacity") }; card.root.opacity = opacity }
                card.root.zPosition = wall ? (center ? 100 : 0) : carousel.depth(ordinal(index))
                let transform = wall ? CATransform3DIdentity : carousel.transform(ordinal(index))
                if !CATransform3DEqualToTransform(card.root.transform, transform) {
                    if duration == 0 { card.root.removeAnimation(forKey: "transform") }
                    card.root.transform = transform
                }
                let sublayerSnapshots = (duration > 0 && resizing ? card.root.sublayers ?? [] : []).map { child in
                    (child, child.presentation()?.bounds ?? child.bounds, child.presentation()?.position ?? child.position)
                }
                if updateContents {
                    let cardLayout = BrowseDiagnostics.shared.start()
                    card.sizeContents(rect.size, scale: window?.backingScaleFactor ?? 2, sceneScale: metrics.scale, wall: wall, center: center, playing: isPlaying && id == currentID, indicated: id == currentID, motionReduced: reduced)
                    card.updateStatus(pending: id == pendingID, failed: tracks[card.index].online == nil && failures[id] != nil, wall: wall, center: center, scale: window?.backingScaleFactor ?? 2)
                    BrowseDiagnostics.shared.end("card.layout", cardLayout)
                }
                let shadeOpacity: Float = wallAlwaysShowInfo || center || card.hovered || (keyboardFocusVisible && window?.firstResponder === self && keyboardTarget?.id == id) ? 0.5 : 0
                if wall { applyWallAppearance(card) }
                let oldShade = duration > 0 ? (card.shade.presentation()?.opacity ?? card.shade.opacity) : card.shade.opacity
                if card.shade.opacity != shadeOpacity { card.shade.opacity = shadeOpacity }
                if duration == 0 && resizing {
                    for child in card.root.sublayers ?? [] { child.removeAnimation(forKey: "bounds"); child.removeAnimation(forKey: "position") }
                    card.playback.removeAnimation(forKey: "path")
                    card.black.removeAnimation(forKey: "bounds"); card.black.removeAnimation(forKey: "position")
                }
                if duration > 0 {
                    let resizeStart = CACurrentMediaTime()
                    animate(card.root, key: "position", from: NSValue(point: created ? card.root.position : oldPosition), to: NSValue(point: card.root.position), duration: duration, start: resizeStart)
                    animate(card.root, key: "bounds", from: NSValue(rect: created ? card.root.bounds : oldBounds), to: NSValue(rect: card.root.bounds), duration: duration, start: resizeStart)
                    animate(card.root, key: "transform", from: NSValue(caTransform3D: created ? transform : oldTransform), to: NSValue(caTransform3D: transform), duration: duration)
                    for (child, previousBounds, previousPosition) in sublayerSnapshots {
                        child.removeAnimation(forKey: "bounds"); child.removeAnimation(forKey: "position")
                        let initialBounds = created ? child.bounds : previousBounds
                        animate(child, key: "bounds", from: NSValue(rect: initialBounds), to: NSValue(rect: child.bounds), duration: duration, start: resizeStart)
                        if child === card.playback, let targetPath = card.playback.path {
                            card.playback.removeAnimation(forKey: "path")
                            if initialBounds != child.bounds {
                                animate(child, key: "path", from: CGPath(ellipseIn: initialBounds, transform: nil), to: targetPath, duration: duration, start: resizeStart)
                            }
                        }
                        let position = child === card.titleClip || child === card.artistClip ? CGPoint(x: previousPosition.x, y: child.position.y) : previousPosition
                        animate(child, key: "position", from: NSValue(point: created ? child.position : position), to: NSValue(point: child.position), duration: duration, start: resizeStart)
                    }
                    if resizing {
                        animate(card.black, key: "bounds", from: NSValue(rect: created ? card.black.bounds : oldBlackBounds),
                                to: NSValue(rect: card.black.bounds), duration: duration)
                        animate(card.black, key: "position", from: NSValue(point: created ? card.black.position : oldBlackPosition),
                                to: NSValue(point: card.black.position), duration: duration)
                    }
                    animate(card.shade, key: "opacity", from: oldShade, to: shadeOpacity, duration: duration)
                    animate(card.black, key: "opacity", from: oldBlack, to: card.black.opacity, duration: 0.36)

                }
                if entryRequested && !card.revealed && !reduced { card.root.opacity = 0 }
                if wall { loadArtwork(card, track: track, center: center || index == anchorIndex, visible: screenFrame(card.root, presented: false).intersects(bounds)) }
                if card.image.contents == nil { card.root.isHidden = true }
            }
            if reduced && wall {
                for card in cards.values where card.artworkReady && card.image.contents != nil { card.root.isHidden = false; card.revealed = true }
            }
            updateArtworkPriorities()
            if !wall { reconcileCarouselVisibility() }
            updateCarouselReflections()
        }
        BrowseDiagnostics.shared.end("scene.cardUpdatesAndScheduling", cardsStart)
        let finalizeStart = BrowseDiagnostics.shared.start()
        let captionStart = BrowseDiagnostics.shared.start()
        updateCarouselRail()
        if !wall { updateUnknownCarouselCards() }
        else { for tile in unknownCards.values { tile.removeFromSuperlayer() }; unknownCards = [:] }
        if !frameOnly || centerChanged { updateCaption(carousel: carousel, wall: wall) }
        if !frameOnly {
            for text in transitioningChrome { text.transform = CATransform3DIdentity }
        }
        BrowseDiagnostics.shared.end("scene.finalizeCaption", captionStart)
        let departing = retiring
        if !departing.isEmpty {
            CATransaction.setCompletionBlock { [weak self] in
                guard let self else { return }
                for (id, card, generation) in departing where self.cards[id] === card && card.retiring && card.retirementGeneration == generation {
                    card.removeFromScene(); self.cards[id] = nil
                }
            }
        }
        let commitStart = BrowseDiagnostics.shared.start()
        CATransaction.commit()
        BrowseDiagnostics.shared.end("scene.finalizeCommit", commitStart)
        if !wall && BrowseDiagnostics.shared.enabled { diagnoseCarouselOverlap(carousel) }
        let revealStart = BrowseDiagnostics.shared.start()
        revealBrowsingCards()
        BrowseDiagnostics.shared.end("scene.finalizeReveal", revealStart)
        renderedMetrics = metrics; renderedSize = bounds.size; renderedOwner = browser.sourceOwner; lastLayout = browser.layout
        lastAnchor = browser.location.anchor; lastExpansion = browser.location.expanded
        lastTrackIDs = trackData?.ids ?? []; lastCamera = browser.location.camera
        let accessibilityStart = BrowseDiagnostics.shared.start()
        hitOrder = cards.values.filter { !$0.retiring }.sorted { $0.root.zPosition == $1.root.zPosition ? $0.index < $1.index : $0.root.zPosition > $1.root.zPosition }
        if membershipOnly || frameOnly { updateAccessibilityMembership() } else { rebuildAccessibility() }
        if !wall { renderedCarouselCenter = carousel.center }
        updateFocusRing()
        BrowseDiagnostics.shared.end("scene.finalizeAccessibility", accessibilityStart)
        rendering = false
        let entranceStart = BrowseDiagnostics.shared.start()
        releaseEntrance()
        BrowseDiagnostics.shared.end("scene.finalizeEntrance", entranceStart)
        BrowseDiagnostics.shared.peak("card.peak", cards.count)
        BrowseDiagnostics.shared.end("scene.finalize", finalizeStart)
        if pendingBufferPreparation {
            wakePanLink()
        }
    }
    private func animate(_ target: CALayer, key: String, from: Any, to: Any, duration: CFTimeInterval, delay: CFTimeInterval = 0, timing: CAMediaTimingFunction? = nil, start: CFTimeInterval? = nil) {
        if let existing = target.animation(forKey: key) as? CABasicAnimation,
           let oldTarget = existing.toValue as? NSObject, let newTarget = to as? NSObject, oldTarget.isEqual(newTarget) { return }
        if let initial = from as? NSObject, let final = to as? NSObject, initial.isEqual(final) {
            target.removeAnimation(forKey: key); return
        }
        let animation = CABasicAnimation(keyPath: key)
        animation.fromValue = from; animation.toValue = to; animation.duration = duration
        animation.timingFunction = timing ?? CAMediaTimingFunction(controlPoints: 0.22, 0.8, 0.24, 1)
        animation.beginTime = (start ?? CACurrentMediaTime()) + delay
        animation.fillMode = .backwards
        target.add(animation, forKey: key)
    }
    private func updateArtworkPriorities() {
        let measurement = BrowseDiagnostics.shared.start(); defer { BrowseDiagnostics.shared.end("artwork.priorityUpdate", measurement) }
        guard let browser else { return }
        let wall = browser.layout == .wall
        if !wall { updateCarouselArtworkDemand(); return }
        let viewport = bounds
        let offset = content.position
        var candidates: [(card: Card, rect: CGRect, visible: Bool)] = []
        var visibleIDs: Set<String> = []
        candidates.reserveCapacity(cards.count)
        for (id, card) in cards where !card.retiring {
            let rect = card.root.frame.offsetBy(dx: offset.x, dy: offset.y)
            let visible = rect.intersects(viewport)
            if visible { visibleIDs.insert(id) }
            candidates.append((card, rect, visible))
        }
        guard artworkDemandDirty || visibleIDs != visibleArtworkIDs else { return }
        artworkDemandDirty = false; visibleArtworkIDs = visibleIDs
        let loaded = candidates.filter { $0.visible && $0.card.loadedPixels > 0 && $0.card.artworkReady && !$0.card.root.isHidden && ($0.card.root.presentation()?.opacity ?? ($0.card.revealed ? $0.card.root.opacity : 0)) > 0.05 }.map(\.rect)
        let center = CGPoint(x: bounds.midX, y: bounds.midY)
        let radial = entryRequested && !reduced
        let fallback = radial ? metrics.anchor : center
        let priority = expandedIndex ?? centerIndex
        BrowseDiagnostics.shared.count("artwork.demandRebuild")
        artworkStore.updateRequests {
            for (card, rect, visible) in candidates where card.token != nil {
                artworkStore.setPriority(card.token, center: card.index == priority && visible, visible: visible,
                    distance: WallArtworkLoading.distance(rect, loaded: radial ? [] : loaded, fallback: fallback),
                    centerDistance: hypot(rect.midX - center.x, rect.midY - center.y), hasImage: card.loadedPixels > 0)
            }
        }
    }
    private func cancelCarouselRequests(resetRetry: Bool = false) {
        artworkStore.updateRequests { for request in carouselResourceRequests.values { artworkStore.cancel(request.token) } }
        carouselResourceRequests = [:]; carouselPlanner = CarouselArtworkPlanner(); carouselArtworkDemand = nil
        if ProcessInfo.processInfo.environment["SONO_CAROUSEL_PREFETCH_RANGE"] == "previous" { carouselPlanner.configuration = .previous }
        carouselRefresh?.cancel(); carouselRefresh = nil
        if resetRetry { carouselRetryUsed = []; artworkStore.resetFailures() }
    }
    private func finalCarouselFailure(_ url: URL) -> Bool {
        artworkStore.hasFailure(url, presentation: artworkPresentation) &&
            (!artworkStore.retryableFailure(url, presentation: artworkPresentation) || carouselRetryUsed.contains(ArtworkPresentation.identity(url, artworkPresentation)))
    }
    private func refreshCarouselAfterArrival() {
        artworkDemandDirty = true
        guard carouselRefresh == nil else { return }
        carouselRefresh = Task { @MainActor [weak self] in
            await Task.yield()
            guard let self, !Task.isCancelled, self.browser?.layout == .carousel else { return }
            self.carouselRefresh = nil
            self.updateCarouselArtworkDemand()
            if self.entryRequested { self.releaseEntrance() }
            else { self.reconcileCarouselVisibility(); self.updateAccessibilityMembership() }
        }
    }
    private func updateCarouselArtworkDemand() {
        guard previewPhase != .moving && previewPhase != .waiting else { return }
        guard !carouselIDs.isEmpty else { cancelCarouselRequests(); return }
        let geometry = carousel
        let visible = Set(geometry.indices.filter { geometry.rect($0).intersects(bounds) })
        let settled = motion == nil || motion?.phase == .idle || motion?.phase == .snapping
        let demand = carouselPlanner.demand(position: Double(geometry.position), target: nil, settled: settled,
            visible: visible, count: carouselIDs.count, now: CACurrentMediaTime())
        // Metadata and images are independent: keep the full ordered IDs even
        // when no song details have arrived at this position yet.
        let missing = demand.visible.sorted { abs($0 - demand.center) < abs($1 - demand.center) }.filter { carouselTrackIndices[$0] == nil }.map { carouselIDs[$0] }
        if !scrubbing, missing != demandedDetails { demandedDetails = missing; detailDemand(missing) }
        guard !scrubbing else { return }
        guard artworkDemandDirty || demand != carouselArtworkDemand else { return }
        carouselArtworkDemand = demand; artworkDemandDirty = false
        let resources = demand.resources
        artworkStore.updateRequests {
            for (index, request) in carouselResourceRequests where !resources.contains(index) {
                artworkStore.cancel(request.token); carouselResourceRequests[index] = nil
            }
            if settled {
                for slot in demand.visible {
                    guard let index = carouselTrackIndices[slot], let url = tracks[index].coverURL,
                          artworkStore.retryableFailure(url, presentation: artworkPresentation),
                          carouselRetryUsed.insert(ArtworkPresentation.identity(url, artworkPresentation)).inserted else { continue }
                    artworkStore.clearFailure(url, presentation: artworkPresentation)
                    if let card = cards[tracks[index].id] { card.artworkResult = .pending; card.requestedPixels = card.loadedPixels }
                }
            }
            for card in cards.values where !card.retiring {
                let slot = ordinal(card.index)
                if demand.visible.contains(slot) {
                    let center = slot == demand.center && true
                    loadArtwork(card, track: tracks[card.index], center: center, visible: true, progressive: true)
                    artworkStore.setPriority(card.token, center: center, visible: true,
                        centerDistance: abs(CGFloat(slot) - geometry.position) * geometry.spacing, hasImage: card.loadedPixels > 0)
                } else {
                    artworkStore.cancel(card.token); card.token = nil; card.requestedPixels = card.loadedPixels
                }
            }
            for slot in (previewPhase == .revealing ? Set<Int>() : demand.prefetch).sorted(by: { abs($0 - demand.center) < abs($1 - demand.center) }) {
                guard carouselResourceRequests[slot] == nil, let index = carouselTrackIndices[slot], let url = tracks[index].coverURL,
                      !artworkStore.hasFailure(url, presentation: artworkPresentation), !artworkStore.hasAvailablePreview(url, presentation: artworkPresentation) else { continue }
                let generation = UUID()
                let token = artworkStore.request(url, pixels: 192, center: false, visible: false, prefetch: true,
                    progressive: true, presentation: artworkPresentation, centerDistance: abs(CGFloat(slot - demand.center)) * geometry.spacing) { [weak self] _ in
                        guard let self, self.carouselResourceRequests[slot]?.generation == generation else { return }
                        self.carouselResourceRequests[slot] = nil; self.refreshCarouselAfterArrival()
                    }
                if let token { carouselResourceRequests[slot] = (generation, token) }
            }
        }
    }
    private func cancelDirectionalRequests() {
        directionalFlush?.cancel(); directionalFlush = nil
        artworkStore.updateRequests { for request in directionalRequests.values { artworkStore.cancel(request.token) } }
        directionalRequests = [:]; previousDemandCamera = nil
    }
    private func updateDirectionalRequests(camera: CGPoint) {
        guard presented else { return }
        let measurement = BrowseDiagnostics.shared.start(); defer { BrowseDiagnostics.shared.end("artwork.directionalPlanning", measurement) }
        guard browser?.layout == .wall, let previous = previousDemandCamera else { previousDemandCamera = camera; return }
        previousDemandCamera = camera
        let dx = camera.x - previous.x, dy = camera.y - previous.y
        guard abs(dx) + abs(dy) > 0.5 else { return }
        let predicted = field.clamp(CGPoint(x: camera.x + max(-bounds.width, min(bounds.width, dx * 6)),
                                             y: camera.y + max(-bounds.height, min(bounds.height, dy * 6))))
        let current = CGRect(x: -camera.x, y: -camera.y, width: bounds.width, height: bounds.height)
        let center = CGPoint(x: bounds.midX - predicted.x, y: bounds.midY - predicted.y)
        let candidates = field.visibleIndices(camera: predicted, margin: 32).filter { tracks.indices.contains($0) && !field.rect($0).intersects(current) }
        var ranked: [(index: Int, distance: CGFloat)] = candidates.map { index in
            let rect = field.rect(index)
            return (index, hypot(rect.midX - center.x, rect.midY - center.y))
        }
        ranked.sort { $0.distance == $1.distance ? $0.index < $1.index : $0.distance < $1.distance }
        let indices = ranked.prefix(6).map(\.index)
        let wanted = Set(indices.map { tracks[$0].id })
        artworkStore.updateRequests {
            for (id, request) in directionalRequests where !wanted.contains(id) { artworkStore.cancel(request.token); directionalRequests[id] = nil }
            for index in indices {
                let track = tracks[index]
                guard directionalRequests[track.id] == nil, let url = track.coverURL else { continue }
                let rect = field.rect(index)
                let pixels = ArtworkPixelSize.bucket(Int(ceil(max(rect.width, rect.height) * (window?.backingScaleFactor ?? 2))))
                let token = artworkStore.request(url, pixels: pixels, center: false, visible: false, prefetch: true, presentation: artworkPresentation,
                    distance: hypot(rect.midX - center.x, rect.midY - center.y)) { _ in }
                directionalRequests[track.id] = (token, pixels)
            }
        }
    }
    private func loadArtwork(_ card: Card, track: BrowseItem, center: Bool, visible: Bool, prefetch: Bool = false, progressive: Bool = false) {
        let measurement = BrowseDiagnostics.shared.start(); defer { BrowseDiagnostics.shared.end("artwork.cardUpdate", measurement) }
        if startupEntrance && !reduced && !startupResourcesFinished && !visible { return }
        let sourceSize = track.coverURL.flatMap { artworkStore.sourceSize($0) }
        let pixels = ArtworkPixelSize.demand(width: card.root.bounds.width, height: card.root.bounds.height,
            scale: window?.backingScaleFactor ?? 2, source: sourceSize, remote: track.coverURL?.isFileURL == false)
        guard let url = track.coverURL else {
            if card.url == nil && card.requestedPixels >= pixels { return }
            artworkStore.cancel(card.token)
            card.artworkGeneration &+= 1
            card.token = nil; card.url = nil; card.requestedPixels = pixels; card.loadedPixels = 0; card.hasRealArtwork = false
            card.image.contents = SonoAssets.bitmap("local-default", pixels: pixels)
            card.artworkResult = .complete
            card.artworkReady = true
            return
        }
        if ArtworkResource.matches(card.url, url) && card.presentationKey == artworkPresentation?.key {
            // request() may deliver a cached preview synchronously before its
            // token is assigned. The published pending demand also owns that
            // interval; cancelling a card resets requestedPixels explicitly.
            if card.loadedPixels >= pixels || card.requestedPixels >= pixels || card.artworkResult == .failed { return }
        }
        artworkStore.cancel(card.token)
        card.artworkGeneration &+= 1
        let generation = card.artworkGeneration
        if !ArtworkResource.matches(card.url, url) { card.loadedPixels = 0; card.hasRealArtwork = false; card.artworkReady = false; card.image.contents = nil }
        card.artworkResult = .pending
        card.presentationKey = artworkPresentation?.key
        card.url = url; card.requestedPixels = pixels
        if card.image.contents == nil { card.root.isHidden = true }
        let requestStarted = CACurrentMediaTime()
        let visibleStart = BrowseDiagnostics.shared.start()
        card.token = artworkStore.request(url, pixels: pixels, center: center, visible: visible, prefetch: prefetch,
            progressive: progressive, hasImage: card.loadedPixels > 0, presentation: artworkPresentation, preview: { [weak self, weak card] bitmap in
            guard let self, let card, self.cards[track.id] === card, card.url == url, card.artworkGeneration == generation else { return }
            let availablePixels = max(bitmap.image.width, bitmap.image.height)
            // The layer can retain a sharper bitmap after its cache entry is evicted.
            // Compact revisit previews must never downgrade that displayed cover.
            guard availablePixels > card.loadedPixels else { return }
            if card.loadedPixels == 0 && progressive {
                let elapsed = CACurrentMediaTime() - requestStarted
                self.carouselPlanner.recordReadiness(elapsed)
                BrowseDiagnostics.shared.end("artwork.firstRealCarousel", visibleStart)
            }
            CATransaction.begin(); CATransaction.setDisableActions(true)
            let blank = track.entity?.kind == .playlist && bitmap.isBlankBlack
            self.assignArtwork(blank ? SonoAssets.bitmap("local-default", pixels: pixels) ?? bitmap.image : bitmap.image, pixels: availablePixels, to: card)
            CATransaction.commit()
            BrowseDiagnostics.shared.mark("artwork.cardReal", fields: ["index": String(card.index), "pixels": String(availablePixels)])
            card.hasRealArtwork = !blank
            self.artworkDemandDirty = true
            card.loadedPixels = availablePixels
            card.loadedSize = CGSize(width: bitmap.image.width, height: bitmap.image.height)
            card.artworkReady = true
            self.artworkArrived(card)
        }) { [weak self, weak card] bitmap in
            guard let self, let card, self.cards[track.id] === card, card.url == url, card.artworkGeneration == generation else { return }
            card.token = nil
            card.artworkResult = bitmap == nil ? .failed : .complete
            card.artworkReady = true
            guard let bitmap else {
                BrowseDiagnostics.shared.count("artwork.failed")
                if card.loadedPixels == 0 && (self.browser?.layout != .carousel || self.finalCarouselFailure(url)) {
                    card.image.contents = SonoAssets.bitmap("local-default", pixels: pixels)
                }
                self.artworkDemandDirty = true
                self.artworkArrived(card); return
            }
            let blank = track.entity?.kind == .playlist && bitmap.isBlankBlack
            card.hasRealArtwork = !blank
            let availablePixels = max(bitmap.image.width, bitmap.image.height)
            BrowseDiagnostics.shared.mark("artwork.cardReal", fields: ["index": String(card.index), "pixels": String(availablePixels)])
            let layout = self.browser?.layout == .carousel ? "Carousel" : "Wall"
            if visible {
                BrowseDiagnostics.shared.end("artwork.visibleReady" + layout, visibleStart)
                BrowseDiagnostics.shared.end((center ? "artwork.priorityReady" : "artwork.neighborReady") + layout, visibleStart)
            } else { BrowseDiagnostics.shared.end("artwork.prefetchReady" + layout, visibleStart) }
            guard availablePixels >= card.loadedPixels else { return }
            // A larger shared result remains reusable after its resource-cache entry
            // is evicted; requestedPixels already tracks the fulfilled demand.
            if card.loadedPixels == 0 && progressive {
                self.carouselPlanner.recordReadiness(CACurrentMediaTime() - requestStarted)
                BrowseDiagnostics.shared.end("artwork.firstRealCarousel", visibleStart)
            }
            CATransaction.begin(); CATransaction.setDisableActions(true)
            let assignment = BrowseDiagnostics.shared.start()
            BrowseDiagnostics.shared.count("artwork.layerAssignment")
            BrowseDiagnostics.shared.mark("artwork.assigned")
            self.assignArtwork(blank ? SonoAssets.bitmap("local-default", pixels: pixels) ?? bitmap.image : bitmap.image, pixels: availablePixels, to: card)
            card.loadedPixels = availablePixels
            card.loadedSize = CGSize(width: bitmap.image.width, height: bitmap.image.height)
            self.artworkDemandDirty = true
            BrowseDiagnostics.shared.end("artwork.layerAssignmentCPU", assignment)
            CATransaction.commit()
            self.artworkArrived(card)
            // The decoded image has already applied EXIF orientation. Its ratio
            // gives the aspect-fill demand; retain this bitmap during one upgrade.
            let required = ArtworkPixelSize.demand(width: card.root.bounds.width, height: card.root.bounds.height,
                scale: self.window?.backingScaleFactor ?? 2, source: CGSize(width: bitmap.image.width, height: bitmap.image.height), remote: !url.isFileURL)
            if required > card.requestedPixels {
                if self.browser?.layout == .carousel {
                    self.artworkDemandDirty = true; self.updateArtworkPriorities()
                } else { self.loadArtwork(card, track: track, center: center, visible: visible) }
            } else if !self.targetArtworkReady(card) {
                BrowseDiagnostics.shared.mark("artwork.sourceLimited", fields: ["requested": String(card.requestedPixels), "width": String(bitmap.image.width), "height": String(bitmap.image.height)])
            }
        }
    }
    private func assignArtwork(_ image: CGImage, pixels: Int, to card: Card) {
        if browser?.layout == .carousel, !reduced, card.loadedPixels > 0, pixels > card.loadedPixels {
            let transition = CATransition(); transition.type = .fade; transition.duration = 0.16
            card.image.add(transition, forKey: "quality-upgrade")
        }
        card.image.contents = image
    }
    private func requestCarouselNavigation(_ index: Int) {
        guard carouselIDs.indices.contains(index) else { return }
        diagnosticNavigation = index
        interruptLayoutForInteraction()
        let controller = ensureMotion()
        previewPosition = CGFloat(controller.position)
        controller.navigate(Double(index), now: CACurrentMediaTime(), animated: abs(Double(index) - controller.position) <= 8)
    }
    private func reconcileCarouselVisibility() {
        guard browser?.layout == .carousel else { return }
        CATransaction.begin(); CATransaction.setDisableActions(true)
        defer { if !rendering { updateCarouselReflections() }; CATransaction.commit() }
        guard previewPhase != .moving && previewPhase != .waiting else { return }
        for card in cards.values where !card.retiring {
            guard tracks.indices.contains(card.index) else { continue }
            let track = tracks[card.index]
            if let mask = card.root.mask, mask.name == "pagination-reveal", mask.animation(forKey: "pagination-width") == nil {
                card.root.mask = nil
            }
            if !card.hasRealArtwork, card.loadedPixels == 0, let url = track.coverURL,
               let bitmap = artworkStore.availablePreview(url, presentation: artworkPresentation) {
                let blank = track.entity?.kind == .playlist && bitmap.isBlankBlack
                card.image.contents = blank ? SonoAssets.bitmap("local-default", pixels: max(192, card.requestedPixels)) : bitmap.image
                card.loadedPixels = max(bitmap.image.width, bitmap.image.height)
                card.loadedSize = CGSize(width: bitmap.image.width, height: bitmap.image.height)
                card.hasRealArtwork = !blank; card.artworkReady = true
            }
            let failed = track.coverURL.map(finalCarouselFailure) == true
            if track.entity?.kind == .playlist, !card.hasRealArtwork, card.image.contents == nil {
                // Keep playlist slots and reflections visible while artwork is absent
                // or still arriving. Real images replace this through the normal loader.
                card.image.contents = SonoAssets.bitmap("local-default", pixels: max(192, card.requestedPixels))
                card.artworkReady = true
            }
            if !card.hasRealArtwork, card.image.contents == nil, failed {
                card.image.contents = SonoAssets.bitmap("local-default", pixels: max(192, card.requestedPixels))
                card.artworkReady = true; card.artworkResult = .failed
            }
            let reason: String? = card.hasRealArtwork ? nil : track.coverURL == nil ? "暂无封面" : failed ? "加载失败" : nil
            card.artworkReason.string = reason; card.artworkReason.isHidden = reason == nil
            card.placeholder.isHidden = card.image.contents != nil
            card.root.backgroundColor = card.image.contents == nil ? SonoGeneratedColors.pageBackground.sonoCGColor(in: effectiveAppearance) : SonoGeneratedColors.artworkPlaceholder.sonoCGColor(in: NSApp.effectiveAppearance)
            let hidden = !screenFrame(card.root, presented: false).intersects(bounds) || track.id == retainedCenterID
            if pendingAppendReveals.contains(track.id), !reduced {
                // Keep a newly appended slot out of the scene until its first image is ready.
                // Cached previews and later network arrivals take the same reveal path.
                guard !hidden, card.artworkReady, card.image.contents != nil,
                      !entryRequested, !layoutTransitionActive else { card.root.isHidden = true; continue }
                pendingAppendReveals.remove(track.id)
                unfoldAppendedCard(card)
            } else if reduced { pendingAppendReveals.remove(track.id) }
            card.root.isHidden = hidden
            card.root.opacity = carousel.opacity(ordinal(card.index))
            card.carouselShade.opacity = 1 - carousel.brightness(ordinal(card.index))
            card.revealed = true
        }
    }
    private func unfoldAppendedCard(_ card: Card) {
        let mask = CALayer()
        mask.name = "pagination-reveal"; mask.backgroundColor = NSColor.black.cgColor
        mask.anchorPoint = .zero; mask.position = .zero; mask.bounds = card.root.bounds
        card.root.isHidden = false; card.root.mask = mask
        let animation = CABasicAnimation(keyPath: "bounds.size.width")
        animation.fromValue = CGFloat(0); animation.toValue = mask.bounds.width
        animation.duration = 0.46; animation.beginTime = CACurrentMediaTime()
        animation.timingFunction = CAMediaTimingFunction(controlPoints: 0.16, 1, 0.3, 1)
        animation.fillMode = .backwards
        mask.add(animation, forKey: "pagination-width")
    }
    private func updateUnknownCarouselCards() {
        let geometry = carousel
        let wanted = Set(geometry.indices.filter { carouselTrackIndices[$0] == nil })
        for (index, tile) in unknownCards where !wanted.contains(index) { tile.removeFromSuperlayer(); unknownCards[index] = nil }
        for index in wanted {
            let tile = unknownCards[index] ?? CALayer()
            if tile.superlayer == nil {
                tile.backgroundColor = SonoGeneratedColors.pageBackground.sonoCGColor(in: effectiveAppearance); tile.masksToBounds = true
                tile.contents = SonoAssets.bitmap("local-default", pixels: 720); tile.contentsGravity = .resizeAspectFill
                content.addSublayer(tile); unknownCards[index] = tile
            }
            let rect = geometry.rect(index)
            tile.bounds = CGRect(origin: .zero, size: rect.size); tile.position = CGPoint(x: rect.midX, y: rect.midY)
            tile.cornerRadius = 8 * metrics.scale; tile.transform = geometry.transform(index); tile.zPosition = geometry.depth(index)
            tile.opacity = geometry.opacity(index)
        }
    }
    private func updateCarouselReflections() {
        let carouselActive = browser?.layout == .carousel &&
            (!layoutTransitionActive || retainedCarouselDetails || stagePhase == .sidesIn)
        reflections.bounds = CGRect(origin: .zero, size: bounds.size)
        reflections.isHidden = !carouselActive
        for (id, card) in cards {
            let tile = id == retainedCenterID ? sharedCenter ?? card.root : card.root
            card.updateReflection(in: reflections, visible: carouselActive && card.image.contents != nil && !card.retiring && !tile.isHidden && tile.opacity > 0.001, following: tile, backgroundColor: SonoGeneratedColors.pageBackground.sonoCGColor(in: effectiveAppearance))
            guard let mirror = card.reflection, !mirror.isHidden else { continue }
            synchronizeReflection(mirror, with: tile, targetSize: card.root.bounds.size)
            if let reveal = mirror.sublayers?.first, let mask = reveal.mask {
                if reduced {
                    mask.removeAnimation(forKey: "bounds.size.height")
                    mask.bounds.size.height = reveal.bounds.height * 0.4
                    reveal.removeAnimation(forKey: "opacity"); reveal.opacity = 1
                }
            }
        }
    }
    private func animateReflectionReveal(_ mirror: CALayer, timing: CABasicAnimation) {
        guard let reveal = mirror.sublayers?.first, let mask = reveal.mask else { return }
        let target = reveal.bounds.height * 0.4
        mask.bounds.size.height = target
        let animation = CABasicAnimation(keyPath: "bounds.size.height")
        animation.fromValue = CGFloat(0); animation.toValue = target
        animation.beginTime = timing.beginTime; animation.duration = 0.32
        animation.timingFunction = timing.timingFunction; animation.fillMode = .backwards
        mask.add(animation, forKey: "bounds.size.height")
        // Keep the fade inside the mirror: its outer opacity follows the card.
        let fade = CABasicAnimation(keyPath: "opacity")
        fade.fromValue = Float(0)
        fade.toValue = Float(1)
        fade.beginTime = timing.beginTime; fade.duration = animation.duration
        fade.timingFunction = timing.timingFunction; fade.fillMode = .backwards
        reveal.opacity = 1
        reveal.add(fade, forKey: "opacity")
    }
    private func synchronizeReflection(_ mirror: CALayer, with tile: CALayer, targetSize: CGSize) {
        let sx = tile.bounds.width / targetSize.width, sy = tile.bounds.height / targetSize.height
        func normalized(_ transform: CATransform3D) -> CATransform3D { CATransform3DScale(transform, sx, sy, 1) }
        mirror.position = tile.position; mirror.transform = normalized(tile.transform); mirror.opacity = tile.opacity
        for key in ["position", "transform", "opacity"] {
            if let animation = tile.animation(forKey: key) {
                if mirror.animation(forKey: key)?.beginTime != animation.beginTime {
                    if key == "transform", sx != 1 || sy != 1,
                       let motion = animation.copy() as? CABasicAnimation,
                       let from = motion.fromValue as? NSValue, let to = motion.toValue as? NSValue {
                        motion.fromValue = NSValue(caTransform3D: normalized(from.caTransform3DValue))
                        motion.toValue = NSValue(caTransform3D: normalized(to.caTransform3DValue))
                        mirror.add(motion, forKey: key)
                    } else { mirror.add(animation, forKey: key) }
                }
            } else { mirror.removeAnimation(forKey: key) }
        }
        // Extend the card's horizontal fold through the full mirror height.
        // The independent vertical reveal lives inside this crop.
        if let source = tile.mask, source.name == "pagination-reveal" {
            let mask = mirror.mask ?? CALayer()
            mask.name = "pagination-reveal"; mask.backgroundColor = NSColor.black.cgColor
            mask.anchorPoint = .zero; mask.position = .zero
            mask.bounds = CGRect(x: 0, y: 0, width: mirror.bounds.width, height: mirror.bounds.height)
            mirror.mask = mask
            if let timing = source.animation(forKey: "pagination-width") as? CABasicAnimation,
               mask.animation(forKey: "pagination-width")?.beginTime != timing.beginTime,
               let animation = timing.copy() as? CABasicAnimation {
                animation.fromValue = CGFloat(0); animation.toValue = mirror.bounds.width
                mask.add(animation, forKey: "pagination-width")
            }
            return
        }
        guard let source = tile.mask as? CAShapeLayer else { mirror.mask = nil; return }
        let mask = (mirror.mask as? CAShapeLayer) ?? CAShapeLayer()
        if mirror.mask == nil {
            mask.fillColor = NSColor.black.cgColor; mirror.mask = mask; foldedCards.append(mirror)
        }
        func extended(_ path: CGPath) -> CGPath {
            let rect = path.boundingBoxOfPath
            return CGPath(rect: CGRect(x: rect.minX / sx, y: 0, width: rect.width / sx, height: mirror.bounds.height), transform: nil)
        }
        if let path = source.path { mask.path = extended(path) }
        if let sourceAnimation = source.animation(forKey: "fold-edge") as? CAKeyframeAnimation,
           mask.animation(forKey: "fold-edge")?.beginTime != sourceAnimation.beginTime,
           let paths = sourceAnimation.values as? [CGPath], let animation = sourceAnimation.copy() as? CAKeyframeAnimation {
            animation.values = paths.map(extended)
            mask.add(animation, forKey: "fold-edge")
        }
    }
    private func targetArtworkReady(_ card: Card) -> Bool {
        guard card.hasRealArtwork, card.loadedPixels > 0 else { return false }
        let scale = window?.backingScaleFactor ?? 2
        return card.loadedSize.width + 1 >= card.root.bounds.width * scale && card.loadedSize.height + 1 >= card.root.bounds.height * scale
    }
    private func artworkArrived(_ card: Card) {
        guard !card.retiring else { return }
        artworkDemandDirty = true
        guard !rendering else { return }
        if browser?.layout == .wall {
            arrivedCards.insert(tracks[card.index].id)
            guard artworkFlush == nil else { return }
            // Coalesce arrivals from the same run-loop turn. Use the original
            // entrance clock; never replay a completed reveal on image upgrade.
            artworkFlush = Task { @MainActor [weak self] in
                await Task.yield()
                guard !Task.isCancelled, let self else { return }
                self.artworkFlush = nil
                let ready = self.arrivedCards; self.arrivedCards = []
                if self.entryRequested {
                    for id in ready { if let card = self.cards[id] { self.releaseEntrance(ready: card) } }
                } else { self.revealBrowsingCards(only: ready) }
                if self.startupEntrance && !self.startupResourcesFinished && !self.startupTargets.isEmpty && self.startupTargets.keys.allSatisfy({ self.cards[$0]?.artworkResult != .pending }) {
                    self.startupResourcesFinished = true
                    self.render(animated: false)
                }
                self.artworkDemandDirty = true; self.updateArtworkPriorities(); self.updateAccessibilityMembership()
            }
            return
        }
        refreshCarouselAfterArrival()
        if entryRequested { updateArtworkPriorities(); releaseEntrance(ready: card); return }
        updateArtworkPriorities()
        CATransaction.begin(); CATransaction.setDisableActions(true)
        reconcileCarouselVisibility()
        CATransaction.commit()
        updateAccessibilityMembership()
    }

    // Electron's guardCarouselEdges crops each rear card to the nearer cover's
    // outer edge throughout both fold directions. Sample the same position
    // animations onto mask paths, on the compositor's clock (no UI-frame lag).
    private func guardCarouselEdges(center: CALayer, centerIndex: Int, cards: [(CALayer, Int)]) {
        let moving = cards.compactMap { $0.0.animation(forKey: "position") as? CABasicAnimation } +
            [center.animation(forKey: "transform") as? CABasicAnimation].compactMap { $0 }
        guard !moving.isEmpty else { return }
        let now = CACurrentMediaTime()
        let end = moving.map { $0.beginTime + $0.duration }.max() ?? now
        let duration = max(0, end - now)
        guard duration > 0 else { return }
        let measurement = BrowseDiagnostics.shared.start()
        defer { BrowseDiagnostics.shared.end("carousel.edgeMaskCPU", measurement) }
        // Oversample the projected cuts: clamping a perspective edge at the
        // card boundary creates a corner that frame-rate interpolation can miss.
        // Each animation and Bezier curve is still evaluated only once per tile.
        let fps = Double(window?.screen?.maximumFramesPerSecond ?? 60)
        let samples = max(2, Int(ceil(duration * fps * 4)))
        func progress(_ animation: CABasicAnimation, at time: CFTimeInterval) -> CGFloat {
            var first: [Float] = [0, 0], second: [Float] = [1, 1]
            animation.timingFunction?.getControlPoint(at: 1, values: &first)
            animation.timingFunction?.getControlPoint(at: 2, values: &second)
            func cubic(_ t: Double, _ a: Float, _ b: Float) -> Double { 3 * (1 - t) * (1 - t) * t * Double(a) + 3 * (1 - t) * t * t * Double(b) + t * t * t }
            let fraction = min(1, max(0, (time - animation.beginTime) / animation.duration))
            var low = 0.0, high = 1.0
            for _ in 0..<16 { let middle = (low + high) / 2; if cubic(middle, first[0], second[0]) < fraction { low = middle } else { high = middle } }
            return CGFloat(cubic((low + high) / 2, first[1], second[1]))
        }
        func positions(_ tile: CALayer) -> [CGFloat] {
            guard let animation = tile.animation(forKey: "position") as? CABasicAnimation,
                  let from = animation.fromValue as? NSValue, let to = animation.toValue as? NSValue else { return Array(repeating: tile.position.x, count: samples + 1) }
            return (0...samples).map { sample in
                let t = progress(animation, at: now + duration * Double(sample) / Double(samples))
                return from.pointValue.x + (to.pointValue.x - from.pointValue.x) * t
            }
        }
        func edgeOffsets(_ tile: CALayer, x: CGFloat) -> [CGFloat] {
            guard let animation = tile.animation(forKey: "transform") as? CABasicAnimation,
                  let from = animation.fromValue as? NSValue, let to = animation.toValue as? NSValue else {
                let m = tile.transform
                return Array(repeating: (x * m.m11 + m.m41) / (x * m.m14 + m.m44), count: samples + 1)
            }
            let a = from.caTransform3DValue, b = to.caTransform3DValue
            return (0...samples).map { sample in
                let t = progress(animation, at: now + duration * Double(sample) / Double(samples))
                let m11 = a.m11 + (b.m11 - a.m11) * t, m41 = a.m41 + (b.m41 - a.m41) * t
                let m14 = a.m14 + (b.m14 - a.m14) * t, m44 = a.m44 + (b.m44 - a.m44) * t
                return (x * m11 + m41) / (x * m14 + m44)
            }
        }
        var sampled: [ObjectIdentifier: [CGFloat]] = [:]
        for tile in [center] + cards.map(\.0) where sampled[ObjectIdentifier(tile)] == nil { sampled[ObjectIdentifier(tile)] = positions(tile) }
        CATransaction.begin(); CATransaction.setDisableActions(true)
        CATransaction.setCompletionBlock { [weak self] in
            guard let self, self.foldedCards.allSatisfy({ $0.mask?.animation(forKey: "fold-edge") == nil }) else { return }
            self.releaseCarouselEdges()
        }
        for direction in [-1, 1] {
            var front = center
            for (tile, _) in cards.filter({ ($0.1 - centerIndex) * direction > 0 }).sorted(by: { direction * ($0.1 - $1.1) < 0 }) {
                let mask = (tile.mask as? CAShapeLayer) ?? CAShapeLayer()
                if tile.mask == nil { mask.fillColor = NSColor.black.cgColor; tile.mask = mask; foldedCards.append(tile) }
                var paths: [CGPath] = [], times: [NSNumber] = []
                paths.reserveCapacity(samples + 5); times.reserveCapacity(samples + 5)
                let frontPositions = sampled[ObjectIdentifier(front)]!, tilePositions = sampled[ObjectIdentifier(tile)]!
                let edgeX = front.bounds.width * ((direction > 0 ? 1 : 0) - front.anchorPoint.x)
                let frontEdges = edgeOffsets(front, x: edgeX)
                func path(_ local: CGFloat) -> CGPath {
                    let cut = min(tile.bounds.maxX, max(tile.bounds.minX, local))
                    let rect = CGRect(x: direction > 0 ? cut : tile.bounds.minX, y: tile.bounds.minY,
                                      width: direction > 0 ? tile.bounds.maxX - cut : cut - tile.bounds.minX, height: tile.bounds.height)
                    return CGPath(rect: rect, transform: nil)
                }
                var previousLocal: CGFloat?
                for sample in 0...samples {
                    let x = frontPositions[sample] + frontEdges[sample] - CGFloat(direction) * 0.5 - tilePositions[sample]
                    let m = tile.transform
                    let local = tile.bounds.minX + tile.bounds.width * tile.anchorPoint.x + (m.m41 - x * m.m44) / (x * m.m14 - m.m11)
                    // A clamped cut has a corner at each card edge. Include its
                    // crossing time so linear path interpolation cannot smear
                    // that corner across the surrounding compositor samples.
                    if let previousLocal, local != previousLocal {
                        let crossings = [tile.bounds.minX, tile.bounds.maxX].map { edge in
                            ((edge - previousLocal) / (local - previousLocal), edge)
                        }.filter { $0.0 > 0 && $0.0 < 1 }.sorted { $0.0 < $1.0 }
                        for (fraction, edge) in crossings {
                            paths.append(path(edge))
                            times.append(NSNumber(value: (Double(sample - 1) + Double(fraction)) / Double(samples)))
                        }
                    }
                    paths.append(path(local)); times.append(NSNumber(value: Double(sample) / Double(samples)))
                    previousLocal = local
                }
                mask.path = paths.last
                let animation = CAKeyframeAnimation(keyPath: "path")
                animation.values = paths; animation.keyTimes = times
                animation.duration = duration; animation.beginTime = now
                animation.calculationMode = .linear; animation.fillMode = .backwards
                mask.add(animation, forKey: "fold-edge")
                front = tile
            }
        }
        CATransaction.commit()
    }
    private func releaseCarouselEdges() {
        for tile in foldedCards { tile.mask = nil }
        foldedCards.removeAll()
    }
    // Ordinary browsing has its own per-source reveal history. Cancelling a
    // page transition must not turn late covers into instantaneous layer swaps.
    private func revealBrowsingCards(only arrivals: Set<String>? = nil) {
        guard browser?.layout == .wall, !entryRequested, !layoutTransitionActive else { return }
        let now = CACurrentMediaTime(), center = CGPoint(x: bounds.midX, y: bounds.midY)
        CATransaction.begin(); CATransaction.setDisableActions(true)
        defer { CATransaction.commit() }
        for (id, card) in cards where !card.retiring {
            if let arrivals, !arrivals.contains(id) { continue }
            if card.revealed && !card.root.isHidden && card.root.opacity == 1 { continue }
            let rect = screenFrame(card.root, presented: false)
            guard rect.intersects(bounds) else { continue }
            var record = browseReveals[id] ?? BrowseReveal(started: now, delay: 0.0012 * hypot(max(rect.minX - center.x, 0, center.x - rect.maxX), max(rect.minY - center.y, 0, center.y - rect.maxY)), origin: CGPoint(x: min(rect.width, max(0, center.x - rect.minX)) - rect.width / 2, y: min(rect.height, max(0, center.y - rect.minY)) - rect.height / 2))
            if reduced || card.expanded || card.revealed { record.done = true }
            if !record.ready && card.artworkReady && card.image.contents != nil {
                record.started = max(record.started, now - record.delay)
                record.ready = true
            }
            if record.ready && now >= record.started + record.delay + 0.46 { record.done = true }
            browseReveals[id] = record
            guard record.ready else { card.root.isHidden = true; continue }
            card.root.isHidden = false
            if record.done { card.revealed = true; card.root.opacity = 1; continue }
            let collapsed = CATransform3DScale(CATransform3DMakeTranslation(record.origin.x * 0.8, record.origin.y * 0.8, 0), 0.2, 0.2, 1)
            for (key, from, to) in [("opacity", Float(0) as Any, Float(1) as Any), ("transform", NSValue(caTransform3D: collapsed) as Any, NSValue(caTransform3D: card.root.transform) as Any)] {
                if let animation = card.root.animation(forKey: key), abs(animation.beginTime - (record.started + record.delay)) < 0.000001 { continue }
                let animation = CABasicAnimation(keyPath: key)
                animation.fromValue = from; animation.toValue = to
                animation.beginTime = record.started + record.delay; animation.duration = 0.46
                animation.timingFunction = CAMediaTimingFunction(controlPoints: 0.16, 1, 0.3, 1)
                animation.fillMode = .backwards
                card.root.add(animation, forKey: key)
            }
            card.root.opacity = 1
        }
    }
    private func updateCaption(carousel: CarouselGeometry, wall: Bool) {

        guard let host = layer else { return }
        for clip in [captionClip, captionArtistClip] { clip.masksToBounds = true }
        if caption.superlayer == nil { captionClip.addSublayer(caption) }
        if captionArtist.superlayer == nil { captionArtistClip.addSublayer(captionArtist) }
        for text in [captionClip, captionArtistClip, counter] {
            if text !== counter && text.superlayer == nil { host.addSublayer(text) }
            text.zPosition = 2000; text.isHidden = wall || (carouselIDs.isEmpty && !(text === counter && retainsCarouselCounter))
            if text === counter { counterControl.isHidden = text.isHidden }
            if text === counter { text.opacity = 1; continue }
            // Metadata/artwork refreshes must not reveal the target caption
            // while the outgoing wall still owns the screen.
            if entryRequested && !entryStarted && !retainedCarouselDetails { text.opacity = 0 }
            else if !entryRequested || retainedCarouselDetails { text.opacity = 1 }
        }
        for text in [caption, captionArtist] {
            text.contentsScale = window?.backingScaleFactor ?? 2
            text.alignmentMode = .center; text.truncationMode = .end
        }
        guard !wall, carouselIDs.indices.contains(carousel.center) else { updateCaptionReading(); return }
        let metrics = carousel.metrics
        let track = carouselCenterIndex.map { tracks[$0] }
        // CATextLayer uses its own font when constructing a truncation token,
        // even for attributed strings. Its default 36pt font clips a 14pt line.
        caption.font = SonoTypography.native(size: SonoDesktopTokens.FontSize.itemTitle, weight: SonoDesktopTokens.FontWeight.semibold); caption.fontSize = SonoDesktopTokens.FontSize.itemTitle
        captionArtist.font = SonoTypography.native(size: SonoDesktopTokens.FontSize.body); captionArtist.fontSize = SonoDesktopTokens.FontSize.body
        if captionTrack != track || track == nil {
            captionTrack = track
            caption.string = SonoTypography.line(track?.title ?? "正在读取歌曲信息", size: SonoDesktopTokens.FontSize.itemTitle, weight: SonoDesktopTokens.FontWeight.semibold, height: 24, color: NSColor(cgColor: SonoGeneratedColors.primaryText.sonoCGColor(in: effectiveAppearance))!)
            captionArtist.string = SonoTypography.line(track?.artist ?? "", size: SonoDesktopTokens.FontSize.body, height: 20, color: NSColor(cgColor: SonoGeneratedColors.queueSecondary.sonoCGColor(in: effectiveAppearance))!)
        }
        let width = min(metrics.side, bounds.width - 32)
        captionClip.frame = CGRect(x: metrics.anchor.x - width / 2, y: metrics.centerRect.maxY + 16, width: width, height: 24)
        captionArtistClip.frame = CGRect(x: captionClip.frame.minX, y: captionClip.frame.minY + 28, width: width, height: 19.6)
        // Keep the backing width stable during scrubbing; only the strings
        // change. Hit testing below still uses each line's measured text width.
        caption.frame = captionClip.bounds; captionArtist.frame = captionArtistClip.bounds
        caption.opacity = 1; captionArtist.opacity = 1
        updateCaptionReading()
        let ordinal = browser?.searching == false ? browser?.sourceOrdinals[carouselIDs[carousel.center]] ?? carousel.center : carousel.center
        let total = carouselIDs.count
        let positionText = "\(ordinal + 1)/\(total)" + (hasMore ? "+" : "")
        counterControl.update(positionText, centeredAt: metrics.anchor.x, top: metrics.carouselCounterTop, scale: window?.backingScaleFactor ?? 2)
        counterControl.isHidden = scrubbing || carouselRail.indicatorVisible
    }
    private func captionHitFrame(title: Bool) -> CGRect {
        let clip = title ? captionClip : captionArtistClip
        let text = title ? caption : captionArtist
        let value = text.string as? NSAttributedString ?? NSAttributedString(string: "")
        let width = min(clip.bounds.width, ceil(CTLineGetTypographicBounds(CTLineCreateWithAttributedString(value), nil, nil, nil)))
        return CGRect(x: clip.frame.midX - width / 2, y: clip.frame.minY, width: width, height: clip.frame.height)
    }
    private func updateCaptionReading() {
        let active = captionHovered && !reduced && browser?.layout == .carousel
        for (text, clip) in [(caption, captionClip), (captionArtist, captionArtistClip)] {
            let value = text.string as? NSAttributedString ?? NSAttributedString(string: "")
            let measured = active ? ceil(CTLineGetTypographicBounds(CTLineCreateWithAttributedString(value), nil, nil, nil)) : 0
            SonoTextReading.update(text, width: clip.bounds.width, measured: measured, active: active)
        }
    }
    override func updateTrackingAreas() {
        if let tracking { removeTrackingArea(tracking) }
        let area = NSTrackingArea(rect: .zero, options: [.mouseMoved, .mouseEnteredAndExited, .cursorUpdate, .activeInKeyWindow, .inVisibleRect], owner: self)
        addTrackingArea(area); tracking = area
        super.updateTrackingAreas()
    }
    override func cursorUpdate(with event: NSEvent) { updatePointer(convert(event.locationInWindow, from: nil)) }
    override func mouseEntered(with event: NSEvent) { mouseMoved(with: event) }
    override func mouseMoved(with event: NSEvent) {
        let point = convert(event.locationInWindow, from: nil)
        guard point != lastPointer else { return }
        lastPointer = point; updatePointer(point)
    }
    private func ownsPointer(at point: CGPoint) -> Bool {
        guard interactionEnabled, excludedInteractionRect?.contains(point) != true else { return false }
        guard let root = window?.contentView else { return true }
        // hitTest takes its receiver's superview coordinates. The hosting
        // content view can be flipped relative to the window's content space.
        guard let hit = root.hitTest(convert(point, to: root.superview)) else { return false }
        return hit === self || hit.isDescendant(of: self)
    }
    private func clearPointerFeedback() {
        lastPointer = nil; hoverRegion = nil; artistHovered = false; playHovered = false; captionHovered = false
        updateCaptionReading(); updateHover(nil)
        updateCaptionInk(artistHovered: false)
    }
    private func updatePointer(_ point: CGPoint) {
        guard ownsPointer(at: point) else { counterControl.setHovered(false); clearPointerFeedback(); return }
        if carouselRail.updateCursor(at: convert(point, to: carouselRail)) {
            counterControl.setHovered(false); clearPointerFeedback(); return
        }
        if counterControl.containsPointer(point) {
            clearPointerFeedback(); counterControl.setHovered(true); return
        }
        counterControl.setHovered(false)
        if dragging { NSCursor.openHand.set(); return }
        if target(at: point) != nil { NSCursor.pointingHand.set() }
        else { NSCursor.openHand.set() }
        let hovered = captionHitFrame(title: true).union(captionHitFrame(title: false)).contains(point)
        if captionHovered != hovered { captionHovered = hovered; updateCaptionReading() }
        let card = card(at: point)
        let id = card.flatMap { tracks.indices.contains($0.index) ? tracks[$0.index].id : nil }
        let local = card.flatMap { localPoint(point, in: $0.root) } ?? .zero
        let titleHovered = card?.titleClip.frame.contains(local) == true
        artistHovered = card?.artistClip.frame.contains(local) == true
        playHovered = card?.playback.frame.contains(local) == true && !(artistHovered && card?.expanded == false && (card?.root.bounds.height ?? 0) < 158)
        let region = HoverRegion(id: id, title: titleHovered, artist: artistHovered, play: playHovered, captionTitle: captionHitFrame(title: true).contains(point), captionArtist: captionHitFrame(title: false).contains(point), layout: browser?.layout)
        guard region != hoverRegion else { return }; hoverRegion = region
        updateHover(id)
        updateCaptionInk(artistHovered: region.captionArtist)
        CATransaction.begin(); CATransaction.setDisableActions(true)
        for (key, candidate) in cards {
            candidate.updateReading(key == id && browser?.layout == .wall ? (artistHovered ? 1 : 0) : nil, reduced: reduced)
        }
        CATransaction.commit()
    }
    private func updateCaptionInk(artistHovered: Bool) {
        guard captionTrack?.online != nil, let current = captionArtist.string as? NSAttributedString else { return }
        let value = NSMutableAttributedString(attributedString: current)
        let color = (artistHovered ? SonoGeneratedColors.primaryText : SonoGeneratedColors.queueSecondary).sonoResolved(in: effectiveAppearance)
        value.addAttribute(.foregroundColor, value: color, range: NSRange(location: 0, length: value.length))
        captionArtist.string = value
    }
    override func mouseExited(with event: NSEvent) {
        counterControl.setHovered(false)
        NSCursor.arrow.set()
        clearPointerFeedback()
    }
    private func updateHover(_ id: String?) {
        hoverID = id
        CATransaction.begin(); CATransaction.setDisableActions(true)
        let wall = browser?.layout == .wall
        for (key, card) in cards {
            card.hovered = key == id
            if !card.hovered { card.updateReading(nil, reduced: reduced) }
            let oldPlay = card.playback.presentation()?.opacity ?? card.playback.opacity
            var opacity: Float = card.hovered && (wall || ordinal(card.index) == carousel.center) ? 1 : 0
            if wall && !card.expanded && card.root.bounds.height < 158 && artistHovered && card.hovered { opacity *= 2.0 / 3 }
            let transform = CATransform3DMakeScale(card.hovered && playHovered ? 1.08 : 1, card.hovered && playHovered ? 1.08 : 1, 1)
            CATransaction.begin(); CATransaction.setDisableActions(true)
            for control in [card.playback, card.playbackGlyph] {
                let old = control.presentation()?.transform ?? control.transform
                control.opacity = opacity
                let targetTransform = transform
                control.transform = targetTransform
                if !reduced {
                    animate(control, key: "opacity", from: oldPlay, to: opacity, duration: 0.2, timing: CAMediaTimingFunction(controlPoints: 0.25, 0.1, 0.25, 1))
                    animate(control, key: "transform", from: NSValue(caTransform3D: old), to: NSValue(caTransform3D: targetTransform), duration: 0.2, timing: CAMediaTimingFunction(controlPoints: 0.25, 0.1, 0.25, 1))
                }
            }
            CATransaction.commit()
            if wall {
                let old = card.black.presentation()?.opacity ?? card.black.opacity
                applyWallAppearance(card)
                if !reduced { animate(card.black, key: "opacity", from: old, to: card.black.opacity, duration: 0.36, timing: CAMediaTimingFunction(controlPoints: 0.25, 0.1, 0.25, 1)) }
                card.title.foregroundColor = (card.expanded || card.hovered ? SonoGeneratedColors.primaryText : SonoGeneratedColors.noncenterTitle).sonoCGColor(in: .sonoArtwork)
                card.artist.foregroundColor = (card.expanded || card.hovered ? SonoGeneratedColors.primaryText : SonoGeneratedColors.noncenterArtist).sonoCGColor(in: .sonoArtwork)
            }
        }
        CATransaction.commit()
    }
    private func card(at point: CGPoint) -> Card? {
        return hitOrder.first { card in
            let root = card.root.presentation() ?? card.root
            let local = localPoint(point, in: card.root)
            return !card.retiring && !root.isHidden && root.contains(local) && root.opacity > 0.05
        }
    }
    private func interruptLayoutForInteraction() {
        if previewPhase != .off { stopCompactPreview(); render(animated: false) }
        if browser?.layout == .carousel { releaseCarouselEdges() }
        if startupEntrance {
            startupEntrance = false; entrancePreparation?.cancel(); entrancePreparation = nil
            entryRequested = false; artworkDemandDirty = true
        }
        if content.animation(forKey: "position") != nil {
            let point = presentedWallCamera()
            previewCamera = point
            CATransaction.begin(); CATransaction.setDisableActions(true)
            content.removeAnimation(forKey: "position"); content.position = point
            CATransaction.commit()
        }
        let transitioning = layoutTransitionActive
        // Late covers may retain an entrance descriptor after the transition has
        // finished. User navigation ends that descriptor too: newly culled-in
        // cards must not wait invisibly for the original, now offscreen center.
        guard transitioning || entryRequested else { return }
        let refresh = deferredConfigure
        cancelLayoutTransition()
        render(animated: transitioning)
        refresh?()
    }
    private func target(at point: CGPoint) -> Target? {
        guard previewPhase == .off else { return nil }
        guard ownsPointer(at:point) else { return nil }
        guard let browser else { return nil }
        if browser.layout == .carousel, let center = carouselCenterIndex, tracks[center].online != nil {
            if captionHitFrame(title: true).contains(point) { return Target(id: tracks[center].id, kind: .album) }
            if captionHitFrame(title: false).contains(point) { return Target(id: tracks[center].id, kind: .artist) }
        }
        if browser.layout == .carousel {
            let candidates = unknownCards.sorted { carousel.depth($0.key) > carousel.depth($1.key) }
            if let (index, tile) = candidates.first(where: { !$0.value.isHidden && $0.value.contains(localPoint(point, in: $0.value)) }),
               card(at: point).map({ $0.root.zPosition < tile.zPosition }) ?? true {
                return Target(id: carouselIDs[index], kind: .select)
            }
        }
        guard let card = card(at: point), tracks.indices.contains(card.index) else { return nil }
        let track = tracks[card.index]
        if browser.layout == .wall {
            let local = localPoint(point, in: card.root)
            if track.online != nil && card.titleClip.frame.contains(local) { return Target(id: track.id, kind: .album) }
            if track.online != nil && card.artistClip.frame.contains(local) { return Target(id: track.id, kind: .artist) }
            if card.playback.frame.contains(local) { return Target(id: track.id, kind: .play) }
        }
        return Target(id: track.id, kind: .select)
    }
    private func perform(_ target: Target) {

        guard let browser else { return }
        if browser.layout == .carousel, let slot = carouselOrdinals[target.id] {
            if target.kind == .select, slot != carousel.center { requestCarouselNavigation(slot); return }
            if trackData?.index[target.id] == nil { unresolvedPlay(target.id); return }
        }
        guard let index = trackData?.index[target.id], tracks.indices.contains(index) else { return }
        let track = tracks[index]
        switch target.kind {
        case .album: catalog(track, true)
        case .artist:
            if browser.layout == .wall && browser.location.expanded != track.id { pendingArtist = track; browser.expand(track.id, items: tracks, viewport: bounds.size) }
            else { catalog(track, false) }
        case .play:
            if track.id != currentID { browser.expand(track.id, items: tracks, viewport: bounds.size) }
            play(track)
        case .select:
            if browser.layout == .wall { browser.expand(track.id, items: tracks, viewport: bounds.size) }
            else if ordinal(index) == carousel.center {
                if track.id != pendingID { play(track) }
            }
            else { finishCarousel(projected: CGFloat(ordinal(index))) }
        }
    }
    override func mouseDown(with event: NSEvent) {
        guard !layoutTransitionActive else { return }
        let point = convert(event.locationInWindow, from: nil)
        guard ownsPointer(at:point) else { clearPointerFeedback(); return }
        pressedTarget = target(at: point); keyboardTarget = pressedTarget; keyboardFocusVisible = false; focusRing.path = nil
        window?.makeFirstResponder(self)
        cancelPendingFocus()
        // Wall links retain click behavior until movement crosses the drag threshold.
        let wallLink = browser?.layout == .wall && (pressedTarget?.kind == .album || pressedTarget?.kind == .artist)
        guard pressedTarget == nil || pressedTarget?.kind == .select || wallLink else { return }
        flushWallPan(); interruptLayoutForInteraction(); window?.makeFirstResponder(self)
        pointerOrigin = point; dragStartCamera = presentedWallCamera()
        closeScroll(); if browser?.layout == .carousel { ensureMotion().beginDrag() }; dragging = false
    }
    override func mouseDragged(with event: NSEvent) {
        guard let origin = pointerOrigin, let browser else { return }
        let point = convert(event.locationInWindow, from: nil)
        let dx = point.x - origin.x, dy = point.y - origin.y
        guard dragging || (browser.layout == .wall ? hypot(dx, dy) >= 5 : abs(dx) > 6) else { return }
        let startingDrag = !dragging
        if startingDrag {
            if browser.layout == .wall { BrowseDiagnostics.shared.mark("input.wallDragStarted", fields: ["target": pressedTarget?.kind.rawValue ?? "background"]) }
            dragging = true; pressedTarget = nil; cancelPendingFocus(); browser.onInteraction?(); NSCursor.openHand.set(); hoverRegion = nil; captionHovered = false; artistHovered = false; playHovered = false; updateCaptionReading(); updateHover(nil) }
        lastPointer = point
        if browser.layout == .wall {
            queueWallPan(CGPoint(x: dragStartCamera.x + dx, y: dragStartCamera.y + dy))
            // Reconcile newly visible tiles immediately on the first displacement.
            // Subsequent membership updates are coalesced until the next display tick.
            if startingDrag { flushWallPan(commit: false) }
        }
        else { ensureMotion().drag(Double(dx)) }
    }
    override func mouseUp(with event: NSEvent) {
        let point = convert(event.locationInWindow, from: nil)
        defer { pointerOrigin = nil; pressedTarget = nil; dragging = false; lastPointer = point; updatePointer(point) }
        guard !layoutTransitionActive, let browser else { motion?.blur(); return }
        guard ownsPointer(at: point) else { flushWallPan(); motion?.blur(); clearPointerFeedback(); return }
        if dragging {
            if browser.layout == .wall {
                flushWallPan()
                if BrowseDiagnostics.shared.enabled { BrowseDiagnostics.shared.mark("input.wallDragEnded", fields: diagnosticViewport()) }
            }
            else { if let origin = pointerOrigin { ensureMotion().drag(Double(point.x - origin.x)) }; motion?.endDrag() }
            return
        }
        if pointerOrigin != nil && browser.layout == .carousel { finishCarousel(projected: presentedCarouselPosition()) }
        dismiss()
        if let pressedTarget, pressedTarget == target(at: point) { perform(pressedTarget) }
    }
    private func focusTargets() -> [Target] {
        guard let browser else { return [] }
        if browser.layout == .carousel, carouselCenterIndex == nil, carouselIDs.indices.contains(carousel.center) {
            return [Target(id: carouselIDs[carousel.center], kind: .select)]
        }
        let order = browser.roundWall ? Array(tracks.indices) : trackData?.assignment ?? Array(tracks.indices)
        return order.flatMap { index -> [Target] in
            guard tracks.indices.contains(index), let card = cards[tracks[index].id], !card.root.isHidden, !card.retiring else { return [] }
            let id = tracks[index].id
            if browser.layout == .carousel { return ordinal(index) == carousel.center ? [Target(id: id, kind: .select)] + (tracks[index].online == nil ? [] : [Target(id: id, kind: .album), Target(id: id, kind: .artist)]) : [] }
            return (card.expanded ? [Target(id: id, kind: .select)] : []) + (tracks[index].online == nil ? [] : [Target(id: id, kind: .album), Target(id: id, kind: .artist)]) + (card.expanded ? [Target(id: id, kind: .play)] : [])
        }
    }
    private func updateFocusRing() {
        refreshWallAppearance()
        CATransaction.begin(); CATransaction.setDisableActions(true); defer { CATransaction.commit() }
        guard keyboardFocusVisible, window?.firstResponder === self, let target = keyboardTarget, let card = cards[target.id] else { focusRing.path = nil; return }
        let rect: CGRect
        switch target.kind {
        case .select: rect = screenFrame(card.root).insetBy(dx: 4, dy: 4)
        case .play: rect = card.root.convert(card.playback.frame, to: layer).insetBy(dx: -5, dy: -5)
        case .album: rect = browser?.layout == .carousel ? captionHitFrame(title: true) : card.root.convert(card.titleClip.frame, to: layer)
        case .artist: rect = browser?.layout == .carousel ? captionHitFrame(title: false) : card.root.convert(card.artistClip.frame, to: layer)
        }
        focusRing.path = CGPath(roundedRect: rect, cornerWidth: target.kind == .play ? rect.width / 2 : 4, cornerHeight: target.kind == .play ? rect.height / 2 : 4, transform: nil)
        if target.kind == .play { card.playback.opacity = 1; card.playbackGlyph.opacity = 1 }
    }
    override func resignFirstResponder() -> Bool { focusRing.path = nil; spaceTarget = nil; keyboardFocusVisible = false; refreshWallAppearance(); return super.resignFirstResponder() }
    override func keyUp(with event: NSEvent) {
        if event.keyCode == 49, let target = spaceTarget {
            spaceTarget = nil; if target == keyboardTarget { perform(target) }; return
        }
        super.keyUp(with: event)
    }

    override func scrollWheel(with event: NSEvent) {
        if previewPhase == .waiting || previewPhase == .revealing { stopCompactPreview(); render(animated: false) }
        guard ownsPointer(at:convert(event.locationInWindow,from:nil)) else { clearPointerFeedback(); return }
        guard !scrubbing else { return }
        guard !layoutTransitionActive, !event.modifierFlags.contains(.control), pointerOrigin == nil else { return }
        guard let browser, sceneCount > 0 else { return }
        if browser.layout == .wall {
            if displayProbe.wallFrame != nil, event.hasPreciseScrollingDeltas,
               event.phase.contains(.began) || !event.momentumPhase.isEmpty {
                BrowseDiagnostics.shared.mark("input.wallScroll", fields: ["phase": String(event.phase.rawValue), "momentum": String(event.momentumPhase.rawValue)])
            }
            cancelPendingFocus()
            interruptLayoutForInteraction()
            browser.onInteraction?()
            let current = previewCamera ?? browser.location.camera
            let factor: CGFloat = event.hasPreciseScrollingDeltas ? 1 : 40
            queueWallPan(CGPoint(x: current.x + event.scrollingDeltaX * factor, y: current.y + event.scrollingDeltaY * factor))
            panCommit?.cancel(); panCommit = nil
            if event.phase.contains(.ended) || event.phase.contains(.cancelled) || event.momentumPhase.contains(.ended) || event.momentumPhase.contains(.cancelled) { flushWallPan() }
            else if event.phase.isEmpty && event.momentumPhase.isEmpty {
                panCommit = Task { @MainActor [weak self] in
                    do { try await Task.sleep(for: .milliseconds(120)) } catch { return }
                    self?.flushWallPan(); self?.panCommit = nil
                }
            }
        } else {
            scrollCarousel(dx: event.scrollingDeltaX, dy: event.scrollingDeltaY, precise: event.hasPreciseScrollingDeltas,
                           phase: event.phase, momentum: event.momentumPhase, timestamp: event.timestamp, normalizeUnits: true)
        }
    }
    private func ensureMotion() -> CarouselMotion {
        if let motion { return motion }
        let controller = CarouselMotion(position: Double(previewPosition ?? CGFloat(centerIndex)), count: carouselIDs.count, side: Double(metrics.side))
        controller.configure(count: carouselIDs.count, side: Double(metrics.side), reduced: reduced)
        controller.wake = { [weak self] in self?.startMotionTick() }
        controller.paint = { [weak self] snapshot, settled in
            guard let self, let browser = self.browser, browser.layout == .carousel else { return }
            if abs(snapshot.position - Double(self.previewPosition ?? CGFloat(self.centerIndex))) > 0.000001 {
                self.releaseCarouselEdges()
            }
            self.previewPosition = CGFloat(snapshot.position)
            if settled, self.carouselIDs.indices.contains(Int(snapshot.position)) {
                let id = self.carouselIDs[Int(snapshot.position)]
                // Mark the renderer's own commit before publishing to SwiftUI.
                if browser.location.expanded != id { browser.onInteraction?() }
                self.lastAnchor = id; self.lastExpansion = id
                var next = browser.location; next.anchor = id; next.expanded = id
                browser.location = next
                self.previewPosition = nil
            }
            self.render(animated: false, motionOnly: true)
            if settled { self.finishFocusIfSettled() }
        }
        motion = controller
        return controller
    }
    private func startMotionTick() {
        guard snapLink == nil else { return }
        let link = displayLink(target: self, selector: #selector(motionFrame(_:)))
        snapLink = link; link.add(to: .main, forMode: .common)
    }
    @objc private func motionFrame(_ link: CADisplayLink) {
        guard snapLink === link else { return }
        let measurement = BrowseDiagnostics.shared.start(); defer { BrowseDiagnostics.shared.end("carousel.frameSubmit", measurement) }
        motion?.tick(at: link.targetTimestamp)
        if motion?.needsTick != true { link.invalidate(); snapLink = nil }
    }
    private func cancelPendingFocus() {
        browser?.afterFocus = nil
        pendingArtist = nil

    }
    private func scrollCarousel(dx: CGFloat, dy: CGFloat, precise: Bool, phase: NSEvent.Phase, momentum: NSEvent.Phase, timestamp: Double = CACurrentMediaTime(), normalizeUnits: Bool = false) {
        guard !carouselIDs.isEmpty else { return }
        BrowseDiagnostics.shared.mark("carousel.scrollInput", fields: ["dx": String(Double(dx)), "dy": String(Double(dy)), "finger": String(phase.rawValue), "momentum": String(momentum.rawValue)])
        let phased = !phase.isEmpty || !momentum.isEmpty
        if phased { lastPhasedScroll = timestamp }
        let trackpad = precise && (phased || lastPhasedScroll.map { timestamp >= $0 && timestamp - $0 < 0.25 } == true)
        if phase.contains(.began) { inputGesture += 1 }
        if phase.contains(.ended) || phase.contains(.cancelled) { releasedGesture = inputGesture }
        if momentum.contains(.began) { momentumGesture = releasedGesture }
        func convert(_ value: NSEvent.Phase) -> CarouselMotion.ScrollPhase {
            if value.contains(.cancelled) { return .cancel }; if value.contains(.ended) { return .end }
            if value.contains(.began) { return .begin }; if value.contains(.mayBegin) { return .mayBegin }
            return value.isEmpty ? .none : .update
        }
        inputSequence += 1
        let factor = normalizeUnits && !precise ? -40.0 : -1.0
        if (dx != 0 || dy != 0) && (momentum.isEmpty || phase.contains(.began)) { cancelPendingFocus() }
        let accepted = ensureMotion().native(.init(gesture: momentum.isEmpty ? inputGesture : momentumGesture, sequence: inputSequence,
                                   timestamp: timestamp, trackpad: trackpad, finger: convert(phase), momentum: convert(momentum),
                                   dx: Double(dx) * factor, dy: Double(dy) * factor), hit: true, now: CACurrentMediaTime())
        if accepted {
            if dx != 0 || dy != 0 { carouselRail.scrollActivity() }
            interruptLayoutForInteraction()
            if dx != 0 || dy != 0 { browser?.onInteraction?() }
        }
    }
    private func closeScroll() {
        snapLink?.invalidate(); snapLink = nil; motion?.close()
    }
    private func presentedCarouselPosition() -> CGFloat { motion.map { CGFloat($0.position) } ?? previewPosition ?? CGFloat(centerIndex) }
    private func finishCarousel(projected: CGFloat) { requestCarouselNavigation(Int(projected.rounded())) }
    private func commitPan() {
        guard let browser, let previewCamera else { return }
        BrowseDiagnostics.shared.count("input.panModelCommit")
        browser.pan(to: previewCamera, field: field)
        lastCamera = browser.location.camera
        self.previewCamera = nil
    }
    override func keyDown(with event: NSEvent) {
        flushWallPan()
        interruptLayoutForInteraction()
        guard let browser, sceneCount > 0 else { return }
        if layoutTransitionActive { super.keyDown(with: event); return }
        if event.keyCode == 48 {
            keyboardFocusVisible = true
            let targets = focusTargets(), backwards = event.modifierFlags.contains(.shift)
            let index = keyboardTarget.flatMap { targets.firstIndex(of: $0) } ?? (backwards ? targets.count : -1)
            let next = index + (backwards ? -1 : 1)
            if targets.indices.contains(next) { keyboardTarget = targets[next]; updateFocusRing() }
            else { keyboardTarget = nil; focusRing.path = nil; if backwards { window?.selectPreviousKeyView(self) } else { window?.selectNextKeyView(self) } }
            return
        }
        if [36, 49, 76].contains(event.keyCode), let target = keyboardTarget, event.modifierFlags.intersection([.command, .control, .option]).isEmpty {
            if event.keyCode == 49 { if !event.isARepeat { spaceTarget = target } }
            else { perform(target) }; return
        }
        if browser.layout == .carousel && pointerOrigin != nil { return }
        if browser.layout == .carousel { cancelPendingFocus() }
        let index = browser.layout == .carousel ? Int(motion?.target ?? floor(Double(presentedCarouselPosition()) + 0.5)) : centerIndex
        switch event.keyCode {
        case 123, 124, 125, 126:
            if browser.layout == .carousel && (event.keyCode == 125 || event.keyCode == 126) { super.keyDown(with: event); return }
            let direction = event.keyCode == 124 || event.keyCode == 125 ? 1 : -1
            let next = browser.layout == .wall ? ((expandedIndex ?? -1) + direction + tracks.count) % tracks.count : min(max(0, index + direction), carouselIDs.count - 1)
            if browser.layout == .wall {
                let id = tracks[next].id
                if browser.location.expanded != id { wallKeyboardTarget = id }
                browser.expand(id, items: tracks, viewport: bounds.size)
            }
            else { finishCarousel(projected: CGFloat(next)) }
        case 115 where browser.layout == .carousel, 119 where browser.layout == .carousel:
            finishCarousel(projected: CGFloat(event.keyCode == 115 ? 0 : carouselIDs.count - 1))
        default: super.keyDown(with: event)
        }
    }

    #if DEBUG
    var validationContentLayer: CALayer { content }
    var validationCounterState: (text: String, visible: Bool, animated: Bool, center: CGPoint) {
        (counterControl.text.string as? String ?? "", !counter.isHidden && counter.opacity == 1,
         !(counter.animationKeys() ?? []).isEmpty || !(counterControl.text.animationKeys() ?? []).isEmpty,
         CGPoint(x: counterControl.frame.midX, y: counterControl.frame.midY))
    }
    struct ValidationSnapshot {
        let trackIDs: [String]
        let source: String
        let layout: BrowserLayout?
        let captionText: String
        let artistText: String
        let counterText: String
        let activeAnimations: Int
        let anchor: String?
        let expanded: String?
        let camera: CGPoint?
        let cameraAnimationStart: Double?
        let identities: [String: ObjectIdentifier]
        let frames: [String: CGRect]
        let positionAnimationStarts: [String: CFTimeInterval]
        let images: [String: ObjectIdentifier]
        let transitioning: Bool
        let snapActive: Bool
        let motion: CarouselMotion.Snapshot?
        let phase: String
        let phases: [String]
        let revealed: [String: Bool]
        let opacities: [String: Float]
        let entranceStarts: [String: Double]
        let departingAnimationStarts: [String: Double]
        let sharedCenterID: String?
        let sharedCaptionAnimations: Int
        let hover: String?
        let controlOpacity: [String: Float]
        let controlScale: [String: CGFloat]
        let reading: [String: Int]
        let requestedPixels: [String: Int]
        let loadedPixels: [String: Int]
        let hidden: [String: Bool]
        let keyboardFocus: String?
        let playbackHidden: [String: Bool]
        let failureVisible: [String: Bool]
    }
    func validationOwnsPointer(_ point: CGPoint) -> Bool { ownsPointer(at:point) }
    func validationPointer(_ point: CGPoint) { lastPointer = point; updatePointer(point) }
    func validationRefreshScene() { render(animated: false) }
    var validationCaptionOpacities: [Float] {
        [captionClip, captionArtistClip].map { $0.presentation()?.opacity ?? $0.opacity }
    }
    var validationCaptionEntranceStarts: [CFTimeInterval?] {
        [captionClip, captionArtistClip].map { $0.animation(forKey: "transform")?.beginTime }
    }
    var validationCaptionEntranceCount: Int {
        [captionClip, captionArtistClip].reduce(0) { total, text in
            total + ["opacity", "transform"].filter { text.animation(forKey: $0) != nil }.count
        }
    }
    var validationLiveCaptionOpacity: Float {
        [captionClip, captionArtistClip].filter { !$0.isHidden }.map { $0.presentation()?.opacity ?? $0.opacity }.max() ?? 0
    }
    var validationDepartureOpacity: [String: Float] {
        validationDepartingCardOpacities()
    }
    func validationPresentedFrames() -> [String: CGRect] { cards.mapValues { screenFrame($0.root) } }
    func validationWallPan(dx: CGFloat, dy: CGFloat, ended: Bool = false) {
        guard let browser else { return }
        interruptLayoutForInteraction()
        let current = previewCamera ?? browser.location.camera
        queueWallPan(CGPoint(x: current.x + dx, y: current.y + dy))
        if ended { flushWallPan() }
    }
    func validationScroll(delta: CGFloat, vertical: CGFloat = 0, precise: Bool, phase: NSEvent.Phase = [], momentum: NSEvent.Phase = []) {
        guard !layoutTransitionActive else { return }
        scrollCarousel(dx: delta, dy: vertical, precise: precise, phase: phase, momentum: momentum)
    }
    func validationCarouselJump(to index: Int) {
        let now = CACurrentMediaTime()
        let controller = ensureMotion()
        controller.navigate(Double(index), now: now, animated: false)
        controller.tick(at: now + 1)
    }
    func validationSettleScroll() { motion?.blur() }
    func validationCarouselTick() { motion?.tick(at: CACurrentMediaTime()) }
    func validationNavigateCarousel(to index: Int) { requestCarouselNavigation(index) }
    var validationArtworkReasons: [String: String] { cards.compactMapValues { $0.artworkReason.isHidden ? nil : $0.artworkReason.string as? String } }
    var validationCenterHasFoldMask: Bool { (carouselIDs.indices.contains(carousel.center) ? cards[carouselIDs[carousel.center]] : nil)?.root.mask != nil }
    var validationPreviewPhase: String { String(describing: previewPhase) }
    var validationPreviewContentHidden: Bool { content.isHidden || content.opacity == 0 }
    var validationUnknownCarouselCount: Int { unknownCards.count }
    var validationPaginationRevealIDs: Set<String> {
        Set(cards.filter { $0.value.root.mask?.name == "pagination-reveal" && $0.value.root.mask?.animation(forKey: "pagination-width") != nil }.keys)
    }
    var validationPaginationReflectionIDs: Set<String> {
        Set(cards.filter { _, card in
            guard let timing = card.root.mask?.animation(forKey: "pagination-width") else { return false }
            return card.reflection?.mask?.animation(forKey: "pagination-width")?.beginTime == timing.beginTime
        }.keys)
    }
    var validationCarouselPlaceholderIDs: Set<String> { Set(cards.filter { !$0.value.placeholder.isHidden }.keys) }
    var validationCarouselOrdinal: Int { carousel.center }
    var validationCarouselPrefetch: Set<Int> { carouselArtworkDemand?.prefetch ?? [] }
    var validationArtworkPriorities: [Int: Operation.QueuePriority] {
        Dictionary(uniqueKeysWithValues: cards.values.compactMap { card in artworkStore.validationPriority(card.token).map { (card.index, $0) } })
    }
    func validationCaptionTitleInk() -> (columns: Int, layout: String) {
        let width = Int(ceil(captionClip.bounds.width * 2)), height = Int(ceil(captionClip.bounds.height * 2))
        let layout = "clip=\(captionClip.frame), clipBounds=\(captionClip.bounds), text=\(caption.frame), textBounds=\(caption.bounds), opacity=\(captionClip.opacity), transform=\(captionClip.transform)"
        guard width > 0, height > 0, let context = CGContext(data: nil, width: width, height: height, bitsPerComponent: 8, bytesPerRow: width * 4, space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return (0, layout) }
        context.scaleBy(x: 2, y: 2); captionClip.render(in: context)
        let data = context.data!.assumingMemoryBound(to: UInt8.self)
        return ((0..<width).filter { x in (0..<height).contains { y in data[(y * width + x) * 4 + 3] > 0 } }.count, layout)
    }
    func validationCaptionArtistInkRows() -> Int {
        let scale: CGFloat = 2
        let width = Int(ceil(captionArtistClip.bounds.width * scale)), height = Int(ceil(captionArtistClip.bounds.height * scale))
        guard width > 0, height > 0,
              let context = CGContext(data: nil, width: width, height: height, bitsPerComponent: 8, bytesPerRow: width * 4,
                                      space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return 0 }
        context.scaleBy(x: scale, y: scale)
        // Measure glyph height independently of the caption container's entrance opacity.
        // The bitmap dimensions still enforce the visible clip bounds.
        captionArtist.render(in: context)
        guard let data = context.data?.assumingMemoryBound(to: UInt8.self) else { return 0 }
        return (0..<height).filter { y in (0..<width).contains { x in data[(y * width + x) * 4 + 3] > 0 } }.count
    }
    func validationInterruptLayout() { interruptLayoutForInteraction() }
    func validationArtworkArrival(_ id: String) { if let card = cards[id] { card.artworkReady = true; artworkArrived(card) } }
    func validationHoldArtwork(_ id: String) {
        if let card = cards[id] { card.artworkReady = false; card.revealed = false; card.root.isHidden = true; card.placeholder.isHidden = false }
    }
    struct ReflectionValidation {
        let height: CGFloat
        let fullHeight: CGFloat
        let revealFrom: CGFloat?
        let revealTo: CGFloat?
        let startsWithCaption: Bool
        let startsWithCenter: Bool
        let followsCard: Bool
        let timingDetails: String
    }
    func validationReflections(departing: Bool = false) -> [String: ReflectionValidation] {
        let group = departing ? departure?.sublayers?.first(where: { $0.name == "departure-reflections" }) : reflections
        guard let group, !group.isHidden else { return [:] }
        let captionTiming = departing ? departure?.sublayers?.first(where: { $0.name == "layout-caption-block" })?.animation(forKey: "transform") : captionClip.animation(forKey: "transform")
        var result: [String: ReflectionValidation] = [:]
        for (id, card) in cards {
            let mirror = departing ? group.sublayers?.first(where: { $0.name == id }) : card.reflection
            let tile = departing ? departure?.sublayers?.first(where: { $0.name == id }) : (id == retainedCenterID ? sharedCenter : card.root)
            guard let mirror, !mirror.isHidden, let reveal = mirror.sublayers?.first, let mask = reveal.mask else { continue }
            let animation = mask.animation(forKey: "bounds.size.height") as? CABasicAnimation
            let follows = tile.map { tile in
                ["position", "transform", "opacity"].allSatisfy { key in
                    mirror.animation(forKey: key)?.beginTime == tile.animation(forKey: key)?.beginTime &&
                    mirror.animation(forKey: key)?.duration == tile.animation(forKey: key)?.duration
                } && (mirror.mask?.animation(forKey: "fold-edge")?.beginTime == tile.mask?.animation(forKey: "fold-edge")?.beginTime)
            } ?? true
            result[id] = ReflectionValidation(height: mask.presentation()?.bounds.height ?? mask.bounds.height,
                fullHeight: reveal.bounds.height * 0.4,
                revealFrom: (animation?.fromValue as? NSNumber).map { CGFloat($0.doubleValue) },
                revealTo: (animation?.toValue as? NSNumber).map { CGFloat($0.doubleValue) },
                startsWithCaption: animation != nil && animation?.beginTime == captionTiming?.beginTime,
                startsWithCenter: animation != nil && animation?.beginTime == tile?.animation(forKey: "transform")?.beginTime,
                followsCard: follows, timingDetails: tile.map { tile in
                    (["position", "transform", "opacity"].map { key in
                        "\(key): mirror \(mirror.animation(forKey: key)?.beginTime ?? -1)/\(mirror.animation(forKey: key)?.duration ?? -1), card \(tile.animation(forKey: key)?.beginTime ?? -1)/\(tile.animation(forKey: key)?.duration ?? -1)"
                    } + ["fold: mirror \(mirror.mask?.animation(forKey: "fold-edge")?.beginTime ?? -1), card \(tile.mask?.animation(forKey: "fold-edge")?.beginTime ?? -1)"]).joined(separator: "; ")
                } ?? "retained center")
        }
        return result
    }
    var validationFoldMaskCount: Int { foldedCards.filter { $0.mask != nil }.count }
    var validationSharedCenterFrame: CGRect? { sharedCenter.map { screenFrame($0) } }
    var validationSharedCenterAnimationStarts: [String: Double] {
        Dictionary(uniqueKeysWithValues: ["position", "transform"].compactMap { key in
            sharedCenter?.animation(forKey: key).map { (key, $0.beginTime) }
        })
    }
    var validationDepartureStart: Double? { departure?.animation(forKey: "opacity")?.beginTime }
    func validationFoldEdgeErrors() -> [CGFloat] {
        let center = sharedCenter ?? (carouselIDs.indices.contains(carousel.center) ? cards[carouselIDs[carousel.center]] : nil)?.root
        guard let center else { return [] }
        let centerIndex = carousel.center
        let tiles = cards.values.filter { !$0.root.isHidden && !$0.retiring }.map { ($0.root, $0.index) }
        func x(_ tile: CALayer, _ local: CGFloat) -> CGFloat {
            let shown = tile.presentation() ?? tile, m = shown.transform
            let offset = local - shown.bounds.minX - shown.bounds.width * shown.anchorPoint.x
            return shown.position.x + (offset * m.m11 + m.m41) / (offset * m.m14 + m.m44)
        }
        var errors: [CGFloat] = []
        for direction in [-1, 1] {
            var front = center
            for (tile, _) in tiles.filter({ ($0.1 - centerIndex) * direction > 0 }).sorted(by: { direction * ($0.1 - $1.1) < 0 }) {
                defer { front = tile }
                guard let mask = tile.mask as? CAShapeLayer,
                      // A newly attached mask has no presentation until its first
                      // compositor frame. Mixing its final model path with the
                      // card's previous presentation reports a gap that was never drawn.
                      let clip = mask.presentation()?.path?.boundingBoxOfPath,
                      !clip.isNull, clip.width > 0.5, clip.width < tile.bounds.width - 0.5 else { continue }
                let edge = x(front, direction > 0 ? front.bounds.maxX : front.bounds.minX)
                let cut = x(tile, direction > 0 ? clip.minX : clip.maxX)
                errors.append(cut - (edge - CGFloat(direction) * 0.5))
            }
        }
        return errors
    }
    var validationSharedCaptionLineOpacities: [Float] {
        sharedCenter?.sublayers?.first(where: { $0.name == "layout-caption-block" })?.sublayers?.map(\.opacity) ?? []
    }
    var validationSharedCaptionStart: CFTimeInterval? {
        sharedCenter?.sublayers?.first(where: { $0.name == "layout-caption-block" })?.animation(forKey: "transform")?.beginTime
    }
    var validationSharedCaptionOpacity: Float? {
        guard let block = sharedCenter?.sublayers?.first(where: { $0.name == "layout-caption-block" }) else { return nil }
        return block.presentation()?.opacity ?? block.opacity
    }
    func validationDepartingCardOpacities() -> [String: Float] {
        Dictionary(uniqueKeysWithValues: (departure?.sublayers ?? []).compactMap { tile in
            guard let id = tile.name, tile.sublayers?.contains(where: { $0.name == "artwork" }) == true else { return nil }
            return (id, tile.opacity)
        })
    }
    var validationDirectionalDemand: [String: Int] { directionalRequests.mapValues(\.pixels) }
    func validationFoldClips() -> [String: CGRect] {
        cards.compactMapValues { card in
            guard let mask = card.root.mask as? CAShapeLayer else { return nil }
            return (mask.presentation()?.path ?? mask.path)?.boundingBoxOfPath
        }
    }
    func validationDarkCoverage(_ id: String) -> (cover: CGRect, black: CGRect, target: CGRect)? {
        guard let card = cards[id] else { return nil }
        return (card.coverMask.presentation()?.bounds ?? card.coverMask.bounds,
                card.black.presentation()?.frame ?? card.black.frame,
                card.coverMask.bounds)
    }
    func validationSnapshot() -> ValidationSnapshot {
        func animationCount(_ root: CALayer) -> Int {
            (root.animationKeys() ?? []).filter { $0 != "reading" }.count + (root.sublayers ?? []).reduce(0) { $0 + animationCount($1) }
        }
        return ValidationSnapshot(trackIDs: tracks.map(\.id), source: lastSource, layout: lastLayout,
                           captionText: (caption.string as? NSAttributedString)?.string ?? "", artistText: (captionArtist.string as? NSAttributedString)?.string ?? "", counterText: counterControl.text.string as? String ?? "", activeAnimations: layer.map(animationCount) ?? 0, anchor: lastAnchor, expanded: lastExpansion, camera: lastCamera, cameraAnimationStart: content.animation(forKey: "position")?.beginTime, identities: cards.mapValues { ObjectIdentifier($0.root) },
                           frames: cards.mapValues { screenFrame($0.root, presented: false) },
                           positionAnimationStarts: cards.compactMapValues { $0.root.animation(forKey: "position")?.beginTime },
                           images: cards.compactMapValues { card in
                               guard let image = card.image.contents else { return nil }
                               return ObjectIdentifier(image as AnyObject)
                           }, transitioning: layoutTransitionActive, snapActive: snapLink != nil, motion: motion?.snapshot,
                           phase: stagePhase.rawValue, phases: phaseTrace.map(\.0), revealed: cards.mapValues { $0.revealed }, opacities: cards.mapValues { $0.root.presentation()?.opacity ?? $0.root.opacity }, entranceStarts: cards.compactMapValues { $0.root.animation(forKey: "transform")?.beginTime },
                           departingAnimationStarts: Dictionary(uniqueKeysWithValues: (departure?.sublayers ?? []).compactMap { tile in
                               guard let id = tile.name, let animation = tile.animation(forKey: "position") else { return nil }
                               return (id, animation.beginTime)
                           }), sharedCenterID: retainedCenterID,
                           sharedCaptionAnimations: (sharedCenter?.sublayers ?? []).filter { !["artwork", "cover-mask", "search-gradient"].contains($0.name ?? "") }.reduce(0) { $0 + ($1.animationKeys()?.count ?? 0) }, hover: hoverID,
                           controlOpacity: cards.mapValues { $0.playback.opacity }, controlScale: cards.mapValues { $0.playback.transform.m11 },
                           reading: cards.mapValues { $0.title.animation(forKey: "reading") != nil ? 0 : $0.artist.animation(forKey: "reading") != nil ? 1 : -1 },
                           requestedPixels: cards.mapValues { $0.requestedPixels }, loadedPixels: cards.mapValues { $0.loadedPixels }, hidden: cards.mapValues { $0.root.isHidden }, keyboardFocus: keyboardTarget.map { $0.id + "/" + $0.kind.rawValue }, playbackHidden: cards.mapValues { $0.playback.isHidden }, failureVisible: cards.mapValues { !$0.failureShade.isHidden && $0.failureShade.superlayer != nil })
    }
    #endif
    private func sampleLoadingProgress() {
        guard let indices = diagnosticIndices, !indices.isEmpty, !diagnosticOpaque else { return }
        if !diagnosticFirst && cards.values.contains(where: { $0.loadedPixels > 0 }) {
            diagnosticFirst = true; BrowseDiagnostics.shared.mark("scene.firstRealCover")
        }
        let targets = indices.compactMap { index -> Card? in
            let actual = browser?.layout == .carousel ? carouselTrackIndices[index] : index
            guard let actual, tracks.indices.contains(actual), let card = cards[tracks[actual].id],
                  tracks[actual].coverURL == nil || targetArtworkReady(card) else { return nil }
            return card
        }
        guard targets.count == indices.count else { return }
        if !diagnosticReady { diagnosticReady = true; BrowseDiagnostics.shared.mark("scene.firstViewportDecoded"); BrowseDiagnostics.shared.mark("scene.firstViewportFullQuality") }
        if targets.allSatisfy({ !$0.root.isHidden && ($0.root.presentation()?.opacity ?? $0.root.opacity) >= 0.95 }) {
            diagnosticOpaque = true; BrowseDiagnostics.shared.mark("scene.firstViewportOpaque")
        }
    }
    private func diagnoseCarouselOverlap(_ geometry: CarouselGeometry) {
        let left = Int(floor(geometry.position)), fraction = geometry.position - floor(geometry.position)
        guard fraction > 0, fraction < 1, carouselIDs.indices.contains(left), carouselIDs.indices.contains(left + 1),
              let a = cards[carouselIDs[left]], let b = cards[carouselIDs[left + 1]] else { return }
        var fields = ["position": String(Double(geometry.position)), "fraction": String(Double(fraction)),
                      "phase": motion?.phase.rawValue ?? "none"]
        for (name, card) in [("left", a), ("right", b)] {
            let model = card.root, shown = model.presentation() ?? model
            fields[name + "Z"] = String(Double(model.zPosition))
            fields[name + "Mask"] = String(model.mask != nil)
            fields[name + "PresentedMask"] = String(shown.mask != nil)
            fields[name + "Hidden"] = String(model.isHidden)
            fields[name + "Opacity"] = String(shown.opacity)
            fields[name + "X"] = String(Double(shown.position.x))
            fields[name + "Width"] = String(Double(shown.bounds.width))
            fields[name + "M11"] = String(Double(shown.transform.m11))
            fields[name + "M13"] = String(Double(shown.transform.m13))
            fields[name + "M14"] = String(Double(shown.transform.m14))
            fields[name + "M44"] = String(Double(shown.transform.m44))
            fields[name + "PositionAnimation"] = String(model.animation(forKey: "position") != nil)
        }
        BrowseDiagnostics.shared.mark("carousel.overlapState", fields: fields)
    }
    private func diagnosticViewport() -> [String: String] {
        if browser?.layout == .carousel && !tracks.isEmpty {
            let visible = cards.values.filter { !$0.retiring && screenFrame($0.root, presented: false).intersects(bounds) }.sorted { $0.index < $1.index }
            var states: [String: String] = [:], missingRun = 0, longestGap = 0, real = 0, target = 0, failed = 0, noSource = 0
            var totalArea = 0.0, realArea = 0.0, targetArea = 0.0, shownRealArea = 0.0
            var sourceLimited = 0, defaultShown = 0
            for card in visible {
                let area = screenFrame(card.root, presented: false).intersection(bounds)
                let weight = Double(max(0, area.width) * max(0, area.height))
                let shown = !card.root.isHidden && (card.root.presentation()?.opacity ?? card.root.opacity) >= 0.95
                if shown && !card.hasRealArtwork { defaultShown += 1 }
                let state: String
                if tracks[card.index].coverURL == nil { state = "no-source"; noSource += 1; missingRun = 0 }
                else {
                    totalArea += weight
                    if card.loadedPixels > 0 {
                        real += 1; realArea += weight; missingRun = 0
                        if shown { shownRealArea += weight }
                        if targetArtworkReady(card) { state = "target-ready"; target += 1; targetArea += weight }
                        else if card.artworkResult == .complete { state = "source-limited"; sourceLimited += 1 }
                        else if card.artworkResult == .failed { state = "preview-hd-failed" }
                        else { state = "real-preview" }
                    } else {
                        missingRun += 1; longestGap = max(longestGap, missingRun)
                        if card.artworkResult == .failed { state = "failed"; failed += 1 }
                        else { state = artworkStore.diagnosticPhase(for: card.token) }
                    }
                }
                states[String(card.index)] = state
            }
            var usage = rusage(); getrusage(RUSAGE_SELF, &usage)
            let encoded = (try? JSONSerialization.data(withJSONObject: states, options: [.sortedKeys])).flatMap { String(data: $0, encoding: .utf8) } ?? "{}"
            return ["motionPhase": motion?.phase.rawValue ?? "none", "motionPosition": String(motion?.position ?? Double(carousel.position)),
                    "motionTarget": motion?.target.map(String.init(describing:)) ?? "none", "centerMasked": String((carouselIDs.indices.contains(carousel.center) ? cards[carouselIDs[carousel.center]] : nil)?.root.mask != nil),
                    "navigationIntent": String(diagnosticNavigation ?? -1), "layout": "carousel", "tracks": String(tracks.count), "visible": String(visible.count),
                    "center": String(carousel.center), "heldCards": String(cards.count),
                    "sourceLimited": String(sourceLimited), "defaultShown": String(defaultShown),
                    "centerReal": String((carouselIDs.indices.contains(carousel.center) ? cards[carouselIDs[carousel.center]] : nil)?.hasRealArtwork == true),
                    "shownRealAreaFraction": String(totalArea > 0 ? shownRealArea / totalArea : 1),
                    "decoded": String(real), "targetReady": String(target), "failed": String(failed), "noSource": String(noSource),
                    "longestMissingRun": String(longestGap), "cardStates": encoded,
                    "realAreaFraction": String(totalArea > 0 ? realArea / totalArea : 1),
                    "targetAreaFraction": String(totalArea > 0 ? targetArea / totalArea : 1),
                    "shown": String(visible.filter { !$0.root.isHidden && ($0.root.presentation()?.opacity ?? $0.root.opacity) >= 0.95 }.count),
                    "hiddenDecoded": String(visible.filter { $0.loadedPixels > 0 && $0.root.isHidden }.count),
                    "cpuSeconds": String(Double(usage.ru_utime.tv_sec + usage.ru_stime.tv_sec) + Double(usage.ru_utime.tv_usec + usage.ru_stime.tv_usec) / 1_000_000),
                    "peakRSSMiB": String(Double(usage.ru_maxrss) / 1048576)]
        }
        guard browser?.layout == .wall, renderedField != nil, !tracks.isEmpty else { return ["layout": browser?.layout.rawValue ?? "none"] }
        let camera = presentedWallCamera()
        let lo = field.clamp(CGPoint(x: -1e12, y: -1e12)), hi = field.clamp(CGPoint(x: 1e12, y: 1e12))
        let indices = field.visibleIndices(camera: camera, margin: 0)
        var missingArea: CGFloat = 0, opaqueArea: CGFloat = 0, area: CGFloat = 0
        var missing = 0, complete = 0, preview = 0, failed = 0
        var realTargets = 0, realReady = 0, realShown = 0, limited = 0
        var realArea = 0.0, readyRealArea = 0.0, shownRealArea = 0.0
        for index in indices {
            let rect = field.rect(index).offsetBy(dx: camera.x, dy: camera.y).intersection(bounds)
            let size = max(0, rect.width) * max(0, rect.height)
            area += size
            guard tracks.indices.contains(index), let card = cards[tracks[index].id] else { missing += 1; missingArea += size; continue }
            if tracks[index].coverURL != nil {
                realTargets += 1; realArea += Double(size)
                if targetArtworkReady(card) {
                    realReady += 1; readyRealArea += Double(size)
                    if !card.root.isHidden && (card.root.presentation()?.opacity ?? card.root.opacity) >= 0.95 {
                        realShown += 1; shownRealArea += Double(size)
                    }
                } else if card.artworkResult == .complete && card.loadedPixels > 0 { limited += 1 }
            }
            switch card.artworkResult {
            case .complete: complete += 1
            case .failed: failed += 1
            case .pending: if card.loadedPixels > 0 { preview += 1 }
            }
            guard card.loadedPixels > 0 || tracks[index].coverURL == nil else { missing += 1; missingArea += size; continue }
            if !card.root.isHidden && (card.root.presentation()?.opacity ?? card.root.opacity) >= 0.95 { opaqueArea += size }
        }
        var usage = rusage(); getrusage(RUSAGE_SELF, &usage)
        return ["layout": "wall", "cameraX": String(Double(camera.x)), "cameraY": String(Double(camera.y)),
                "minX": String(Double(lo.x)), "minY": String(Double(lo.y)), "maxX": String(Double(hi.x)), "maxY": String(Double(hi.y)),
                "realTargets": String(realTargets), "realReady": String(realReady), "realShown": String(realShown), "sourceLimited": String(limited),
                "readyRealAreaFraction": String(realArea > 0 ? readyRealArea / realArea : 0), "shownRealAreaFraction": String(realArea > 0 ? shownRealArea / realArea : 0),
                "visible": String(indices.count), "complete": String(complete), "preview": String(preview), "failed": String(failed), "missing": String(missing), "missingAreaFraction": String(Double(area > 0 ? missingArea / area : 0)),
                "opaqueAreaFraction": String(Double(area > 0 ? opaqueArea / area : 1)), "tracks": String(tracks.count),
                "cpuSeconds": String(Double(usage.ru_utime.tv_sec + usage.ru_stime.tv_sec) + Double(usage.ru_utime.tv_usec + usage.ru_stime.tv_usec) / 1_000_000),
                "peakRSSMiB": String(Double(usage.ru_maxrss) / 1048576), "sceneGeneration": String(layoutGeneration)]
    }
    private func diagnosticWallFrame(interval: Double?) {
        guard browser?.layout == .wall, let field = renderedField, !tracks.isEmpty else { return }
        let camera = presentedContentOffset
        let indices = field.visibleIndices(camera: camera, margin: 0).filter { tracks.indices.contains($0) && tracks[$0].coverURL != nil }
        let shown = indices.filter { index in
            guard let card = cards[tracks[index].id], card.hasRealArtwork, !card.retiring else { return false }
            let layer = card.root.presentation() ?? card.root
            return !layer.isHidden && layer.opacity > 0.05 && layer.frame.offsetBy(dx: camera.x, dy: camera.y).intersects(bounds)
        }
        BrowseDiagnostics.shared.mark("wall.frame", fields: [
            "intervalMs": interval.map { String($0) } ?? "",
            "x": String(Double(camera.x)), "y": String(Double(camera.y)),
            "width": String(Double(bounds.width)), "height": String(Double(bounds.height)),
            "tracks": String(tracks.count),
            "visible": indices.map { String($0) }.joined(separator: ","),
            "shown": shown.map { String($0) }.joined(separator: ",")
        ])
    }
    private func updateAccessibilityMembership() {
        let ids = Set(cards.values.filter { !$0.retiring && !$0.root.isHidden && $0.root.opacity > 0.05 && screenFrame($0.root, presented: false).intersects(bounds) }.map { tracks[$0.index].id })
        if ids != accessibleCards || (browser?.layout == .carousel && accessibleCarouselCenter != carousel.center) { rebuildAccessibility() }
    }
    private func rebuildAccessibility() {
        let measurement = BrowseDiagnostics.shared.start(); defer { BrowseDiagnostics.shared.end("scene.accessibility", measurement) }
        let wall = browser?.layout == .wall
        let centered = wall ? expandedIndex : carouselCenterIndex
        accessibleCarouselCenter = wall ? nil : carousel.center
        let visible = cards.values.filter { !$0.root.isHidden && $0.root.opacity > 0.05 && screenFrame($0.root, presented: false).intersects(bounds) && tracks.indices.contains($0.index) }.sorted { $0.index < $1.index }
        accessibleCards = Set(visible.map { tracks[$0.index].id })
        let elements: [NSAccessibilityElement] = visible.flatMap { card -> [NSAccessibilityElement] in
            let track = tracks[card.index]
            let element: BrowseCardAccessibility
            if let existing = card.accessibility { element = existing }
            else {
                element = BrowseCardAccessibility { [weak self, weak card] in
                    guard let self, let card, self.browser != nil, self.tracks.indices.contains(card.index) else { return }
                    let track = self.tracks[card.index]
                    self.perform(Target(id: track.id, kind: .select))
                }
                element.setAccessibilityEnabled(true); element.setAccessibilityRole(.button)
                element.setAccessibilityParent(self); card.accessibility = element
            }
            if card.accessibilitySelected != card.expanded { card.accessibilitySelected = card.expanded; element.setAccessibilityValue(card.expanded) }
            let label = !wall && card.index == centered ? (track.song == nil ? "打开 " : "播放 ") + track.title : "展开 \(track.title)"
            element.setAccessibilityHelp(card.artworkReason.isHidden ? nil : card.artworkReason.string as? String)
            if card.accessibilityLabel != label { card.accessibilityLabel = label; element.setAccessibilityLabel(label) }
            element.frameProvider = { [weak self, weak card] in
                guard let self, let card else { return .zero }
                return self.window?.convertToScreen(self.convert(self.screenFrame(card.root), to: nil)) ?? .zero
            }
            var elements: [NSAccessibilityElement] = [element]
            if track.online != nil && (wall || card.index == centered) {
                for album in [true, false] {
                    let link: BrowseCardAccessibility
                    if let existing = card.links[album] { link = existing }
                    else {
                        link = BrowseCardAccessibility { [weak self, weak card] in
                            guard let self, let card, self.browser != nil, self.tracks.indices.contains(card.index) else { return }
                            let track = self.tracks[card.index]
                            self.perform(Target(id: track.id, kind: album ? .album : .artist))
                        }
                        link.setAccessibilityRole(.button); link.setAccessibilityEnabled(true); link.setAccessibilityParent(self); card.links[album] = link
                    }
                    let label = (album ? "查看专辑：" : "查看歌手：") + (album ? track.title : track.artist)
                    if card.accessibilityLinkLabels[album] != label { card.accessibilityLinkLabels[album] = label; link.setAccessibilityLabel(label) }
                    link.frameProvider = { [weak self, weak card] in
                        guard let self, let card else { return .zero }
                        let local = self.browser?.layout == .carousel ? self.captionHitFrame(title: album) : card.root.convert(album ? card.titleClip.frame : card.artistClip.frame, to: self.layer)
                        return self.window?.convertToScreen(self.convert(local, to: nil)) ?? .zero
                    }
                    elements.append(link)
                }
            }
            if (wall && card.expanded) {
                let control: BrowseCardAccessibility
                if let existing = card.playAccessibility { control = existing }
                else {
                    control = BrowseCardAccessibility { [weak self] in self?.perform(Target(id: track.id, kind: .play)) }
                    control.setAccessibilityRole(.button); control.setAccessibilityParent(self); card.playAccessibility = control
                }
                let label = (isPlaying && currentID == track.id ? "暂停 " : "播放 ") + track.title
                if card.accessibilityPlayLabel != label { card.accessibilityPlayLabel = label; control.setAccessibilityLabel(label) }
                control.frameProvider = { [weak self, weak card] in
                    guard let self, let card else { return .zero }
                    return self.window?.convertToScreen(self.convert(card.root.convert(card.playback.frame, to: self.layer), to: nil)) ?? .zero
                }
                elements.append(control)
            }
            return elements
        }
        let ids = visible.map { tracks[$0.index].id + (wall ? ($0.expanded ? "/wall-expanded" : "/wall") : $0.index == centered ? "/center" : "/side") + (failures[tracks[$0.index].id] == nil ? "/playable" : "/failed") }
        var children: [Any] = elements
        var membership = ids
        if !wall, carouselCenterIndex == nil, carouselIDs.indices.contains(carousel.center) {
            let id = carouselIDs[carousel.center]
            let element = unknownCenterAccessibility ?? BrowseCardAccessibility { [weak self] in
                guard let self, self.carouselIDs.indices.contains(self.carousel.center) else { return }
                self.unresolvedPlay(self.carouselIDs[self.carousel.center])
            }
            unknownCenterAccessibility = element
            element.setAccessibilityRole(.button); element.setAccessibilityParent(self)
            element.setAccessibilityLabel("第\(carousel.center + 1)首，正在读取歌曲信息，播放")
            element.frameProvider = { [weak self] in
                guard let self else { return .zero }
                return self.window?.convertToScreen(self.convert(self.carousel.metrics.centerRect, to: nil)) ?? .zero
            }
            children.append(element); membership.append(id + "/pending-details")
        }
        if !carouselRail.isHidden { children.append(carouselRail); membership.append("carousel-scrollbar") }
        if !wall { children.append(counterControl); membership.append("carousel-quick-list") }
        if membership != accessibilityIDs { accessibilityIDs = membership; setAccessibilityChildren(children) }
    }
}

@MainActor
final class BrowseCardAccessibility: NSAccessibilityElement, @unchecked Sendable {
    private nonisolated let frameLock = NSLock()
    private nonisolated(unsafe) var storedFrameProvider: (@MainActor @Sendable () -> CGRect)?
    nonisolated var frameProvider: (@MainActor @Sendable () -> CGRect)? {
        get { frameLock.withLock { storedFrameProvider } }
        set { frameLock.withLock { storedFrameProvider = newValue } }
    }
    nonisolated override func accessibilityFrame() -> NSRect {
        let provider = frameProvider
        if Thread.isMainThread { return MainActor.assumeIsolated { provider?() ?? .zero } }
        return DispatchQueue.main.sync { MainActor.assumeIsolated { provider?() ?? .zero } }
    }
    nonisolated let action: @MainActor @Sendable () -> Void
    init(action: @escaping @MainActor @Sendable () -> Void) { self.action = action; super.init() }
    nonisolated override func accessibilityPerformPress() -> Bool {
        let callback = action
        Task { @MainActor in callback() }
        return true
    }
}
