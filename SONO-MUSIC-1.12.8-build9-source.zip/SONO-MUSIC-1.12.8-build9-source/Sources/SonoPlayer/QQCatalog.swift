import Foundation

struct QQCatalogSong: Sendable {
    let mid: String
    let numericID: String?
    let mediaMID: String?
    let title: String
    let artists: [OnlineArtist]
    let album: String
    let albumMID: String
    let duration: Double
    let requiresMembershipForFullPlayback: Bool

    init?(_ row: OnlineJSON) {
        let mid = row["mid"].isNull ? row["songmid"].string : row["mid"].string
        let title = row["name"].isNull ? row["songname"].string : row["name"].string
        guard !mid.isEmpty, mid.utf8.allSatisfy({
            (48...57).contains($0) || (65...90).contains($0) || (97...122).contains($0)
        }), !title.isEmpty else { return nil }

        self.mid = mid
        let media = row["file"]["media_mid"].string
        mediaMID = media.isEmpty ? nil : media
        self.title = title
        let id = row["id"].isNull ? row["songid"].string : row["id"].string
        numericID = Int(id).flatMap { $0 > 0 ? id : nil }
        artists = row["singer"].array.map { singer in
            OnlineArtist(id: singer["mid"].string, name: singer["name"].string)
        }
        album = row["album"].isNull ? row["albumname"].string : row["album"]["name"].string
        albumMID = row["album"].isNull ? row["albummid"].string : row["album"]["mid"].string
        duration = Double(row["interval"].int)
        requiresMembershipForFullPlayback = row["pay"]["pay_play"].int == 1 && row["pay"]["pay_month"].int == 1
    }
    var track: LocalTrack {
        let cover = albumMID.isEmpty ? nil : URL(
            string: "https://y.gtimg.cn/music/photo_new/T002R300x300M000" + albumMID + ".jpg"
        )
        return LocalTrack(
            id: "qq/" + mid,
            folderID: UUID(uuidString: "00000000-0000-0000-0000-000000000002")!,
            url: URL(string: "sono-qq://song/" + mid)!,
            title: title, artist: artists.map(\.name).joined(separator: " / "),
            album: album, duration: duration, coverURL: cover, playable: true,
            online: OnlineTrackInfo(
                songID: mid, albumID: albumMID, artistID: artists.first?.id ?? "",
                artists: artists, storedPlatform: .qq, numericSongID: numericID, mediaMID: mediaMID,
                qqRequiresMembershipForFullPlayback: requiresMembershipForFullPlayback
            )
        )
    }
}
