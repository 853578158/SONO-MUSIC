import Foundation

struct QQOnlineCatalog: Sendable {
    let cookie: String

    private func call(_ module: String, _ method: String, _ parameters: [String: Any]) async throws -> OnlineJSON {
        let fields = NeteaseClient.cookies(cookie)
        guard let id = fields["qqmusic_uin"], let loginType = fields["tmeLoginType"].flatMap(Int.init) else {
            throw OnlineError.loginRequired
        }
        return try await QQLoginClient().request(
            module: module, method: method,
            comm: ["ct": 11, "cv": 14090008, "tmeAppID": "qqmusic", "uin": id, "tmeLoginType": loginType],
            parameters: parameters, cookie: cookie
        )
    }

    func playlists(owner: String) async throws -> [OnlinePlaylist] {
        let result = try await call("music.musicasset.PlaylistBaseRead", "GetPlaylistByUin", ["uin": owner])
        guard case .array(let rows) = result["v_playlist"] else { throw URLError(.cannotParseResponse) }
        return rows.compactMap { row in
            let directory = row["dirId"].isNull ? row["dirid"] : row["dirId"]
            guard directory.int > 0 else { return nil }
            let name = ["dirName", "dirname", "title", "name"]
                .map { row[$0].string }.first { !$0.isEmpty } ?? "歌单 " + directory.string
            let count = row["songNum"].isNull ? row["songnum"] : row["songNum"]
            let cover = ["bigpicUrl", "picUrl", "picurl", "coverUrl"].lazy.compactMap { field -> String? in
                let text = row[field].string.trimmingCharacters(in: .whitespacesAndNewlines)
                let address = text.hasPrefix("//") ? "https:" + text : text
                guard var url = URLComponents(string: address), url.host?.isEmpty == false,
                      let scheme = url.scheme, ["https", "http"].contains(scheme.lowercased()) else { return nil }
                url.scheme = "https"
                return url.string
            }.first
            return OnlinePlaylist(.object([
                "id": .string(directory.string),
                "name": .string(directory.int == 201 ? "我喜欢" : name),
                "trackCount": count,
                "coverImgUrl": cover.map(OnlineJSON.string) ?? .null,
                "userId": .string(owner),
                "specialType": .number(directory.int == 201 ? 5 : 0)
            ]))
        }.sorted { ($0.isFavorites == true) && ($1.isFavorites != true) }
    }

    func page(_ original: OnlinePage) async throws -> OnlinePage {
        let rows: OnlineJSON
        switch original.kind {
        case .search(let term), .classifiedSearch(let term, _):
            return try await search(original, term: term)
        case .album(let id):
            let result = try await catalogRequest("music.musichallAlbum.AlbumSongList", "GetAlbumSongList",
                                                  ["albumMid": id, "begin": original.offset, "num": 30])
            return try songPage(original, result["songList"], total: result["totalNum"].int, limit: 30)
        case .artist(let id):
            let result = try await catalogRequest("musichall.song_list_server", "GetSingerSongList",
                                                  ["singerMid": id, "begin": original.offset, "number": 30, "order": 1])
            return try songPage(original, result["songList"], total: result["totalNum"].int, limit: 30)
        case .artistAlbums(let id):
            let result = try await catalogRequest("music.musichallAlbum.AlbumListServer", "GetAlbumList",
                                                  ["singerMid": id, "begin": original.offset, "number": 30, "order": 1])
            let values = try list(result["albumList"])
            return merged(original, items: entities(values, kind: .album), count: values.count,
                          total: result["total"].int, limit: 30)
        case .dailyRecommendations, .dailyStyleRecommendations:
            let result = try await call("music.srfDissInfo.aiDissInfo", "uniform_get_Dissinfo",
                                        ["dirid": 202, "optype": 3, "tag": 1, "userinfo": 0, "pic_dpi": 300])
            rows = result["songlist"]
        case .playlist(let id):
            if id.hasPrefix("qq-public:"), let publicID = Int(id.dropFirst("qq-public:".count)), publicID > 0 {
                rows = .array(try await playlistRows(directory: 0, publicID: publicID))
            } else {
                guard let directory = Int(id), directory > 0 else { throw URLError(.badURL) }
                rows = .array(try await playlistRows(directory: directory))
            }
        default:
            throw OnlineError.protocolFailure("QQ 音乐暂无法打开此详情。")
        }
        let tracks = try decodeTracks(rows)
        var next = OnlinePage(kind: original.kind, title: original.title)
        next.tracks = tracks
        if original.kind.searchQuery != nil { next.items = tracks.map(BrowseItem.song) }
        next.ids = tracks.compactMap { $0.online?.songID }
        next.total = tracks.count
        next.offset = tracks.count
        next.cachedAt = Date()
        return next
    }

    private func catalogRequest(_ module: String, _ method: String, _ parameters: [String: Any]) async throws -> OnlineJSON {
        try await QQLoginClient().request(module: module, method: method,
                                          comm: ["ct": 19, "cv": 1859], parameters: parameters,
                                          cookie: cookie.isEmpty ? nil : cookie)
    }

    private func search(_ original: OnlinePage, term: String) async throws -> OnlinePage {
        let category = original.kind.searchCategory ?? .songs
        if category == .combined {
            async let songs = search(.init(kind: .classifiedSearch(term, .songs), title: original.title), term: term)
            async let artists = search(.init(kind: .classifiedSearch(term, .artists), title: original.title), term: term)
            async let albums = search(.init(kind: .classifiedSearch(term, .albums), title: original.title), term: term)
            async let playlists = search(.init(kind: .classifiedSearch(term, .playlists), title: original.title), term: term)
            let sections = try await [songs, artists, albums, playlists]
            let items = sections.flatMap { $0.browseItems.prefix(5) }
            return merged(original, items: items, count: items.count, total: items.count, limit: 0)
        }
        let type: Int
        let key: String
        let entityKind: BrowseEntity.Kind?
        switch category {
        case .artists: (type, key, entityKind) = (1, "singer", .artist)
        case .albums: (type, key, entityKind) = (2, "album", .album)
        case .playlists: (type, key, entityKind) = (3, "songlist", .playlist)
        case .songs, .combined: (type, key, entityKind) = (0, "song", nil)
        }
        let limit = 20
        let result = try await catalogRequest("music.search.SearchCgiService", "DoSearchForQQMusicDesktop",
                                              ["query": term, "search_type": type, "num_per_page": limit,
                                               "page_num": original.offset / limit + 1])
        let total = result["meta"]["sum"].int
        let value = result["body"][key]["list"]
        if value.isNull && result["meta"]["sum"].string == "0" {
            return merged(original, items: [], count: 0, total: 0, limit: limit)
        }
        if let entityKind {
            let rows = try list(value)
            let items = entities(rows, kind: entityKind)
            guard rows.isEmpty || !items.isEmpty else { throw URLError(.cannotParseResponse) }
            return merged(original, items: items, count: rows.count, total: total, limit: limit)
        }
        return try songPage(original, value, total: total, limit: limit)
    }

    private func entities(_ rows: [OnlineJSON], kind: BrowseEntity.Kind) -> [BrowseItem] {
        rows.compactMap { row in
            func field(_ keys: String...) -> String {
                keys.lazy.map { row[$0].string }.first { !$0.isEmpty } ?? ""
            }
            let id: String
            let title: String
            let artwork: String
            switch kind {
            case .artist:
                id = field("singerMID", "singerMid", "singer_mid", "mid")
                title = field("singerName", "singer_name", "name", "title")
                artwork = field("avatar", "singerPic", "pic")
            case .album:
                id = field("albumMID", "albumMid", "album_mid", "mid")
                title = field("albumName", "album_name", "name", "title")
                artwork = id.isEmpty ? "" : "https://y.gtimg.cn/music/photo_new/T002R300x300M000" + id + ".jpg"
            case .playlist:
                let publicID = field("dissid", "dissId", "tid", "id")
                guard let number = Int(publicID), number > 0 else { return nil }
                id = "qq-public:" + publicID
                title = field("dissname", "dissName", "name", "title")
                artwork = field("imgurl", "picurl", "logo")
            }
            guard !id.isEmpty, !title.isEmpty else { return nil }
            let coverKey = kind == .playlist ? "coverImgUrl" : "picUrl"
            let count = field("song_count", "songnum", "songNum", "songCount")
            return .entity(BrowseEntity(.object([
                "id": .string(id), "name": .string(title), coverKey: .string(artwork),
                "trackCount": count.isEmpty ? .null : .string(count),
                "size": count.isEmpty ? .null : .string(count),
                "artist": .object(["name": .string(field("singerName", "singer_name"))])
            ]), kind: kind))
        }
    }

    private func list(_ value: OnlineJSON) throws -> [OnlineJSON] {
        guard case .array(let rows) = value else { throw URLError(.cannotParseResponse) }
        return rows
    }

    private func songPage(_ original: OnlinePage, _ value: OnlineJSON, total: Int, limit: Int) throws -> OnlinePage {
        let tracks = try decodeTracks(value)
        return merged(original, items: tracks.map(BrowseItem.song), count: value.array.count, total: total, limit: limit)
    }

    private func merged(_ original: OnlinePage, items: [BrowseItem], count: Int, total: Int, limit: Int) -> OnlinePage {
        var next = original
        var known = Set(original.browseItems.map(\.id))
        let additions = items.filter { known.insert($0.id).inserted }
        next.items = original.browseItems + additions
        next.tracks = next.browseItems.compactMap(\.song)
        next.ids = next.tracks.compactMap { $0.online?.songID }
        next.offset += count
        next.total = max(total, next.browseItems.count)
        next.more = limit > 0 && !additions.isEmpty && (total > 0 ? next.offset < total : count >= limit)
        next.cachedAt = Date()
        if next.kind.artistID != nil { next.collectionSubtitle = "" }
        return next
    }

    private func playlistRows(directory: Int, publicID: Int = 0) async throws -> [OnlineJSON] {
        let limit = 100
        var rows: [OnlineJSON] = []
        while true {
            let result = try await call("music.srfDissInfo.DissInfo", "CgiGetDiss", [
                "disstid": publicID, "dirid": directory, "tag": true, "userinfo": true,
                "orderlist": true, "song_begin": rows.count, "song_num": limit
            ])
            guard case .array(let batch) = result["songlist"] else { throw URLError(.cannotParseResponse) }
            if batch.isEmpty { return rows }
            if !rows.isEmpty, let first = batch.first {
                let mid = first["mid"].string
                if !mid.isEmpty, rows.contains(where: { $0["mid"].string == mid }) {
                    throw OnlineError.protocolFailure("QQ 音乐歌单分页未推进，请重试。")
                }
            }
            rows.append(contentsOf: batch)
            let total = result["total_song_num"].int
            if total > 0 ? rows.count >= total : batch.count < limit { return rows }
        }
    }

    func editSong(_ mid: String, directory: Int, add: Bool) async throws {
        let detail = try await call("music.pf_song_detail_svr", "get_song_detail_yqq",
                                    ["song_type": 0, "song_mid": mid])
        let track = detail["track_info"]
        guard track["mid"].string == mid, track["id"].int > 0 else {
            throw OnlineError.protocolFailure("QQ 音乐歌曲详情缺少匹配的数字编号。")
        }
        let result = try await call("music.musicasset.PlaylistDetailWrite", add ? "AddSonglist" : "DelSonglist",
                                    ["dirId": directory, "v_songInfo": [["songId": track["id"].int, "songType": 0]]])
        guard result["retCode"].string == "0", case .object = result["result"] else {
            throw OnlineError.protocolFailure("QQ 音乐未返回有效的歌单写入结果。")
        }
    }

    func fm(page: Int) async throws -> (tracks: [LocalTrack], hasMore: Bool) {
        let result = try await call("music.recommend.TrackRelationServer", "GetRadarSong",
                                    ["Page": page, "ReqType": 0, "FavSongs": [Int](), "EntranceSongs": [Int]()])
        return (try decodeTracks(result["VecSongs"]), result["HasMore"].bool)
    }

    func playURL(mid: String, mediaMID: String?) async throws -> URL {
        let fields = NeteaseClient.cookies(cookie)
        guard let id = fields["qqmusic_uin"], let key = fields["qqmusic_key"],
              let loginType = fields["tmeLoginType"].flatMap(Int.init) else {
            throw OnlineError.loginRequired
        }
        let assetID = mediaMID ?? mid
        let filenames = ["M500" + assetID + ".mp3", "C400" + assetID + ".m4a"]
        let result = try await QQLoginClient().request(
            module: "vkey.GetVkeyServer", method: "CgiGetVkey",
            comm: ["ct": 24, "cv": 0, "format": "json", "uin": id, "authst": key, "tmeLoginType": loginType],
            parameters: [
                "filename": filenames,
                "guid": String(UInt64.random(in: 1_000_000_000...9_999_999_999)),
                "songmid": [mid, mid], "songtype": [0, 0], "uin": id, "loginflag": 1, "platform": "20", "xcdn": 1
            ], cookie: cookie
        )
        if let url = streamURL(result, mid: mid, filenames: filenames) { return url }

        // QQ's authenticated URL endpoint also serves account-authorized previews.
        let alternateNames = ["M500" + mid + assetID + ".mp3", "C400" + mid + assetID + ".m4a"]
        let alternate = try await QQLoginClient().request(
            module: "music.vkey.GetVkey", method: "UrlGetVkey",
            comm: ["ct": 24, "cv": 0, "format": "json", "uin": id, "authst": key, "tmeLoginType": loginType],
            parameters: ["filename": alternateNames, "guid": UUID().uuidString.replacingOccurrences(of: "-", with: ""),
                         "songmid": [mid, mid], "songtype": [0, 0], "uin": id, "ctx": 0],
            cookie: cookie
        )
        if let url = streamURL(alternate, mid: mid, filenames: alternateNames) { return url }

        let codes = (result["midurlinfo"].array + alternate["midurlinfo"].array).map { $0["result"].string }
        NSLog("QQ playback returned no usable stream. Result codes: %@", codes.joined(separator: ","))
        throw OnlineError.unavailable
    }

    private func streamURL(_ result: OnlineJSON, mid: String, filenames: [String]) -> URL? {
        let entries = result["midurlinfo"].array
        let base = result["sip"].array.compactMap { candidate -> URL? in
            guard var components = URLComponents(string: candidate.string),
                  let host = components.host, host.hasSuffix(".qq.com"),
                  components.scheme == "http" || components.scheme == "https" else { return nil }
            components.scheme = "https"
            return components.url
        }.first ?? URL(string: "https://sjy6.stream.qqmusic.qq.com/")!
        let ordered = filenames.flatMap { filename in entries.filter { $0["filename"].string == filename } }
        for entry in ordered + entries.filter({ $0["songmid"].string == mid }) {
            let path = entry["purl"].string
            guard !path.isEmpty, let url = URL(string: path, relativeTo: base)?.absoluteURL,
                  url.scheme == "https", url.host == base.host else { continue }
            return url
        }
        return nil
    }

    private func decodeTracks(_ value: OnlineJSON) throws -> [LocalTrack] {
        guard case .array(let rows) = value else { throw URLError(.cannotParseResponse) }
        let tracks = rows.compactMap { row -> LocalTrack? in
            let track = ["Track", "track", "songInfo"].lazy.map { row[$0] }.first { !$0.isNull } ?? row
            return QQCatalogSong(track)?.track
        }
        guard rows.isEmpty || !tracks.isEmpty else {
            throw OnlineError.protocolFailure("QQ 音乐返回了曲目，但曲目信息格式无法读取。")
        }
        return tracks
    }
}
