import AppKit
import Combine
import MediaPlayer

/// Publishes only committed audio. Remote controls use the same session as the UI.
@MainActor
final class SystemMedia {
    private weak var session: PlayerSession?
    private let center: MPNowPlayingInfoCenter
    private let commands: MPRemoteCommandCenter
    private var targets: [(MPRemoteCommand, Any)] = []
    private var changes: AnyCancellable?
    private var artworkToken: UUID?
    private var artworkURL: URL?
    private var artwork: MPMediaItemArtwork?
    private var stopped = false

    init(session: PlayerSession, center: MPNowPlayingInfoCenter = .default(), commands: MPRemoteCommandCenter = .shared()) {
        self.session = session; self.center = center; self.commands = commands
        bind(commands.playCommand) { $0.setPlayback(true) }
        bind(commands.pauseCommand) { $0.setPlayback(false) }
        bind(commands.togglePlayPauseCommand) { $0.togglePlayback() }
        bind(commands.nextTrackCommand) { $0.step(1) }
        bind(commands.previousTrackCommand) { $0.step(-1) }
        let seek = commands.changePlaybackPositionCommand
        targets.append((seek, seek.addTarget { @Sendable [weak self] event in
            guard let event = event as? MPChangePlaybackPositionCommandEvent, event.positionTime.isFinite else { return .commandFailed }
            let seconds = event.positionTime
            Task { @MainActor [weak self] in
                guard let self, !self.stopped else { return }
                self.session?.audio.seek(seconds)
            }
            return .success
        }))
        // Coalesce @Published's will-change notifications, then read final values.
        changes = session.objectWillChange.merge(with: session.audio.objectWillChange).debounce(for: .milliseconds(40), scheduler: RunLoop.main).sink { [weak self] _ in self?.refresh() }
        refresh()
    }

    private func bind(_ command: MPRemoteCommand, action: @escaping @MainActor @Sendable (PlayerSession) -> Void) {
        targets.append((command, command.addTarget { @Sendable [weak self] _ in
            Task { @MainActor [weak self] in
                guard let self, !self.stopped, let session = self.session else { return }
                action(session)
            }
            return .success
        }))
    }

    func refresh() {
        guard !stopped, let session else { return }
        let audio = session.audio
        let available = audio.current != nil || !session.queue.isEmpty || !session.tracks.isEmpty
        commands.playCommand.isEnabled = available
        commands.pauseCommand.isEnabled = audio.current != nil || audio.isLoading
        commands.togglePlayPauseCommand.isEnabled = available || audio.isLoading
        commands.nextTrackCommand.isEnabled = !session.queue.isEmpty
        commands.previousTrackCommand.isEnabled = !session.history.isEmpty
        commands.changePlaybackPositionCommand.isEnabled = audio.current != nil && audio.duration > 0
        guard let track = audio.current else {
            resetArtwork(); center.nowPlayingInfo = nil; center.playbackState = .stopped
            return
        }
        if artworkURL != track.coverURL {
            resetArtwork(); artworkURL = track.coverURL
            if let url = track.coverURL {
                artworkToken = BrowseArtworkStore.shared.request(url, pixels: 512, center: true) { [weak self] bitmap in
                    guard let self, !self.stopped, self.artworkURL == url, let bitmap else { return }
                    self.artwork = Self.makeArtwork(bitmap)
                    self.refresh()
                }
            }
        }
        var info: [String: Any] = [
            MPMediaItemPropertyTitle: track.title, MPMediaItemPropertyArtist: track.artist,
            MPMediaItemPropertyAlbumTitle: track.album,
            MPMediaItemPropertyPlaybackDuration: audio.duration,
            MPNowPlayingInfoPropertyElapsedPlaybackTime: audio.elapsed,
            MPNowPlayingInfoPropertyPlaybackRate: audio.isPlaying ? 1.0 : 0.0,
            MPNowPlayingInfoPropertyDefaultPlaybackRate: 1.0,
            MPNowPlayingInfoPropertyMediaType: MPNowPlayingInfoMediaType.audio.rawValue
        ]
        if let artwork { info[MPMediaItemPropertyArtwork] = artwork }
        center.nowPlayingInfo = info
        center.playbackState = audio.isPlaying ? .playing : .paused
    }

    // MediaPlayer invokes this callback on its own access queue. Construct it
    // outside MainActor so Swift does not infer a main-isolated callback.
    nonisolated static func makeArtwork(_ bitmap: ArtworkBitmap) -> MPMediaItemArtwork {
        let image = NSImage(cgImage: bitmap.image, size: NSSize(width: bitmap.image.width, height: bitmap.image.height))
        return MPMediaItemArtwork(boundsSize: image.size) { _ in image }
    }

    private func resetArtwork() {
        BrowseArtworkStore.shared.cancel(artworkToken); artworkToken = nil
        artworkURL = nil; artwork = nil
    }

    func shutdown() {
        stopped = true; changes = nil; resetArtwork()
        for (command, target) in targets { command.removeTarget(target); command.isEnabled = false }
        targets = []; center.nowPlayingInfo = nil; center.playbackState = .stopped
    }
}
