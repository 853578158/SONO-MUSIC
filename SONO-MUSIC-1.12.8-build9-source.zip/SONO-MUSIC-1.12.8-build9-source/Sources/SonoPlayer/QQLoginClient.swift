import Foundation

struct QQLoginClient: Sendable {
    static let credentials = OnlineCredentialStore(
        service: (Bundle.main.bundleIdentifier ?? "app.sono.native.preview") + ".qqmusic"
    )

    struct Challenge: Sendable {
        let id: String
        let image: Data
        let expiresIn: Int
    }

    func createChallenge() async throws -> Challenge {
        let challenge = try await request(
            module: "music.login.LoginServer", method: "CreateQRCode",
            comm: ["ct": 23, "cv": 0],
            parameters: ["tmeAppID": "qqmusic", "ct": 11, "cv": 14090008]
        )
        let id = challenge["qrcodeID"].string
        let expiresIn = challenge["expiresIn"].int
        guard !id.isEmpty, expiresIn > 0,
              let encoded = challenge["qrcode"].string.split(separator: ",").last,
              let image = Data(base64Encoded: String(encoded)),
              image.starts(with: [137, 80, 78, 71, 13, 10, 26, 10]) else {
            throw OnlineError.protocolFailure("QQ 音乐返回的登录二维码格式无效。")
        }
        return Challenge(id: id, image: image, expiresIn: expiresIn)
    }
    func confirm(_ event: QQLoginMQTT.Publish, challenge: Challenge) async throws -> OnlineAccount {
        guard event.event == "cookies", event.topic == "management.qrcode_login/" + challenge.id else {
            throw OnlineError.protocolFailure("QQ 音乐返回了无效的扫码确认。")
        }
        let cookies = try OnlineJSON(data: event.payload)["cookies"]
        let id = cookies["qqmusic_uin"]["value"].string
        let token = cookies["qqmusic_key"]["value"].string
        guard let numericID = UInt64(id), numericID > 0, !token.isEmpty else {
            throw OnlineError.protocolFailure("QQ 音乐扫码确认缺少凭据。")
        }

        let login = try await request(
            module: "music.login.LoginServer", method: "Login",
            comm: ["ct": 11, "cv": 14090008, "tmeAppID": "qqmusic", "tmeLoginType": 6],
            parameters: ["musicid": NSNumber(value: numericID), "qrCodeID": challenge.id, "token": token]
        )
        let key = login["musickey"].string
        guard !key.isEmpty, key.utf8.allSatisfy({ $0 > 32 && $0 < 127 && $0 != 59 }) else {
            throw OnlineError.protocolFailure("QQ 音乐返回的会话凭据无效。")
        }
        let returnedID = login["str_musicid"].string
        guard returnedID.isEmpty || returnedID == id else {
            throw OnlineError.protocolFailure("QQ 音乐返回的账号与扫码账号不一致。")
        }
        let responseType = login["loginType"].int
        let reportedType = cookies["tmeLoginType"]["value"].int
        let loginType = [1, 6].contains(responseType) ? responseType : reportedType == 1 ? 1 : 6
        let cookie = "uin=\(id); qqmusic_uin=\(id); qm_keyst=\(key); qqmusic_key=\(key); tmeLoginType=\(loginType)"
        let account = try await verify(id: id, cookie: cookie)
        try Task.checkCancellation()
        try Self.credentials.saveSession(cookie, account: account)
        return account
    }

    func verify(id: String, cookie: String) async throws -> OnlineAccount {
        let fields = NeteaseClient.cookies(cookie)
        guard fields["qqmusic_uin"] == id, let key = fields["qqmusic_key"], !key.isEmpty,
              let type = fields["tmeLoginType"], let loginType = Int(type), [1, 6].contains(loginType) else {
            throw OnlineError.loginRequired
        }
        let profile = try await request(
            module: "music.UserInfo.userInfoServer", method: "GetLoginUserInfo",
            comm: ["ct": 11, "cv": 14090008, "tmeAppID": "qqmusic", "uin": id, "tmeLoginType": loginType],
            parameters: [:], cookie: cookie
        )
        guard case .object = profile["info"] else {
            throw OnlineError.protocolFailure("QQ 音乐未返回当前账号资料。")
        }
        let nickname = profile["info"]["nick"].string
        var avatar = URLComponents(string: profile["info"]["logo"].string)
        if avatar?.scheme == "http" { avatar?.scheme = "https" }
        return OnlineAccount(id: id, name: nickname.isEmpty ? id : nickname,
                             avatar: avatar?.scheme == "https" && avatar?.host != nil ? avatar?.url : nil)
    }

    func request(
        module: String, method: String, comm: [String: Any],
        parameters: [String: Any], cookie: String? = nil,
        operationKey: String = "request", userAgent: String? = nil
    ) async throws -> OnlineJSON {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = 15
        let session = URLSession(configuration: configuration)
        defer { session.finishTasksAndInvalidate() }

        var request = URLRequest(url: URL(string: "https://u.y.qq.com/cgi-bin/musicu.fcg")!)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue(cookie, forHTTPHeaderField: "Cookie")
        request.setValue(userAgent, forHTTPHeaderField: "User-Agent")
        request.httpBody = try JSONSerialization.data(withJSONObject: [
            "comm": comm,
            operationKey: ["module": module, "method": method, "param": parameters]
        ])
        let (data, response) = try await session.data(for: request)
        try Task.checkCancellation()
        guard (response as? HTTPURLResponse)?.statusCode == 200 else {
            throw URLError(.badServerResponse)
        }
        let result = try OnlineJSON(data: data)
        let operation = result[operationKey]
        guard result["code"].string == "0", operation["code"].string == "0" else {
            let code = operation["code"].isNull ? result["code"].int : operation["code"].int
            throw OnlineError.protocolFailure("QQ 音乐请求失败（\(method)，\(code)）。")
        }
        return operation["data"]
    }
}
