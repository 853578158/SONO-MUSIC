import Foundation

/// Classic layouts constrain the minimum content size, not the aspect ratio.
struct BrowseViewport {
    let size: CGSize
    init(_ size: CGSize) { self.size = size }
    var valid: Bool { size.width >= 800 && size.height >= 650 }

    static func constrain(_ requested: CGSize, within limit: CGSize) -> CGSize? {
        let maxW = floor(limit.width), maxH = floor(limit.height)
        guard maxW >= 800, maxH >= 650 else { return nil }
        return CGSize(width: min(maxW, max(800, requested.width)),
                      height: min(maxH, max(650, requested.height)))
    }
}
