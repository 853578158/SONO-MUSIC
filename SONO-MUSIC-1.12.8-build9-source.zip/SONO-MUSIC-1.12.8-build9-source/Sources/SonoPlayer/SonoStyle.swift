import SwiftUI
import AppKit
import CoreText

enum SonoPalette {
    static let accent = SonoGeneratedColors.accent
    static let favorite = SonoGeneratedColors.favorite

    /// Choose between the existing light/dark main-text pair on a coloured surface.
    static func contrastingText(on background: NSColor, appearance: NSAppearance) -> NSColor {
        let surface = background.sonoResolved(in: appearance)
        func luminance(_ color: NSColor) -> Double {
            let a = color.alphaComponent
            let components = [color.redComponent * a + surface.redComponent * (1 - a),
                              color.greenComponent * a + surface.greenComponent * (1 - a),
                              color.blueComponent * a + surface.blueComponent * (1 - a)]
            let linear = components.map { $0 <= 0.04045 ? $0 / 12.92 : pow(($0 + 0.055) / 1.055, 2.4) }
            return Double(linear[0] * 0.2126 + linear[1] * 0.7152 + linear[2] * 0.0722)
        }
        let y = luminance(surface)
        let candidates = [NSAppearance.Name.aqua, .darkAqua].map {
            SonoGeneratedColors.primaryText.sonoResolved(in: NSAppearance(named: $0)!)
        }
        return candidates.max { lhs, rhs in
            let l = luminance(lhs), r = luminance(rhs)
            return (max(l, y) + 0.05) / (min(l, y) + 0.05) < (max(r, y) + 0.05) / (min(r, y) + 0.05)
        }!
    }
}

/// CSS system-ui uses the system outline without AppKit's UI tracking, and
/// PingFang SC rather than PingFang UI for Simplified Chinese fallback.
@MainActor
enum SonoTypography {
    private static let fonts: NSCache<NSString, CTFont> = { let cache = NSCache<NSString, CTFont>(); cache.countLimit = 128; return cache }()
    static func native(size: CGFloat, weight: Font.Weight = SonoDesktopTokens.FontWeight.regular) -> CTFont {
        let numeric: Double
        switch weight {
        case .ultraLight: numeric = 100
        case .thin: numeric = 200
        case .light: numeric = 300
        case .medium: numeric = 500
        case .semibold: numeric = 600
        case .bold: numeric = 700
        case .heavy: numeric = 800
        case .black: numeric = 900
        default: numeric = 400
        }
        let key = "\(size):\(numeric)" as NSString
        if let cached = fonts.object(forKey: key) { return cached }
        let fallback = numeric >= 600 ? "PingFangSC-Semibold" : numeric >= 500 ? "PingFangSC-Medium" : "PingFangSC-Regular"
        let descriptor = CTFontDescriptorCreateWithAttributes([
            kCTFontVariationAttribute: [NSNumber(value: 0x6f70737a): max(17, min(96, size)), NSNumber(value: 0x77676874): numeric],
            kCTFontCascadeListAttribute: [CTFontDescriptorCreateWithAttributes([kCTFontNameAttribute: fallback] as CFDictionary)]
        ] as CFDictionary)
        let outlines = CTFontCopyGraphicsFont(NSFont.systemFont(ofSize: size) as CTFont, nil)
        let font = CTFontCreateWithGraphicsFont(outlines, size, nil, descriptor)
        fonts.setObject(font, forKey: key)
        return font
    }
    static func font(size: CGFloat, weight: Font.Weight = SonoDesktopTokens.FontWeight.regular) -> Font { .system(size: size, weight: weight) }
    static func width(_ text: String, size: CGFloat, weight: Font.Weight = SonoDesktopTokens.FontWeight.regular) -> CGFloat {
        let line = CTLineCreateWithAttributedString(NSAttributedString(string: text, attributes: [NSAttributedString.Key(kCTFontAttributeName as String): native(size: size, weight: weight)]))
        return CGFloat(CTLineGetTypographicBounds(line, nil, nil, nil))
    }
    static func line(_ text: String, size: CGFloat, weight: Font.Weight = SonoDesktopTokens.FontWeight.regular, height: CGFloat, color: NSColor) -> NSAttributedString {
        let paragraph = NSMutableParagraphStyle()
        paragraph.alignment = .center
        paragraph.minimumLineHeight = height; paragraph.maximumLineHeight = height
        return NSAttributedString(string: text, attributes: [.font: native(size: size, weight: weight), .foregroundColor: color, .paragraphStyle: paragraph])
    }
}

@MainActor
enum SonoTextReading {
    static func update(_ layer: CATextLayer, width: CGFloat, measured: CGFloat, active: Bool) {
        let overflow = max(0, measured - width)
        guard active, overflow > 1 else {
            layer.removeAnimation(forKey: "reading")
            layer.bounds.size.width = width; layer.position.x = width / 2
            layer.truncationMode = .end
            return
        }
        layer.truncationMode = .none
        layer.bounds.size.width = measured; layer.position.x = measured / 2
        let travel = Double(overflow) / 40, duration = 2 * (travel + 1.2)
        if let existing = layer.animation(forKey: "reading"), abs(existing.duration - duration) < 0.0001 { return }
        let animation = CAKeyframeAnimation(keyPath: "transform.translation.x")
        animation.values = [0, 0, -overflow, -overflow, 0]
        animation.keyTimes = [0, NSNumber(value: 1.2 / duration), 0.5, NSNumber(value: (2.4 + travel) / duration), 1]
        animation.beginTime = CACurrentMediaTime()
        animation.duration = duration; animation.repeatCount = .infinity; animation.calculationMode = .linear
        layer.add(animation, forKey: "reading")
    }
}

// Name the property wrapper explicitly: this CLT SDK lacks the new State macro plugin.
typealias ViewState<Value> = SwiftUI.State<Value>

@MainActor
enum SonoAssets {
    private static let images = NSCache<NSString, NSImage>()
    private static let bitmaps: NSCache<NSString, ArtworkBitmap> = { let cache = NSCache<NSString, ArtworkBitmap>(); cache.totalCostLimit = 16 * 1024 * 1024; cache.countLimit = 64; return cache }()
    static func image(_ name: String) -> NSImage? {
        if let cached = images.object(forKey: name as NSString) { return cached }
        let resource = Bundle.main.resourceURL?.appendingPathComponent("SonoAssets").appendingPathComponent(name + ".svg")
        #if SONO_RELEASE_CANDIDATE
        let image = resource.flatMap { NSImage(contentsOf: $0) }
        #else
        let source = URL(fileURLWithPath: #filePath).deletingLastPathComponent().appendingPathComponent("Resources").appendingPathComponent(name + ".svg")
        let image = (resource.flatMap { NSImage(contentsOf: $0) }) ?? NSImage(contentsOf: source)
        #endif
        if let image { images.setObject(image, forKey: name as NSString) }
        return image
    }
    static func bitmap(_ name: String, pixels: Int = 720) -> CGImage? {
        let measurement = BrowseDiagnostics.shared.start(); defer { BrowseDiagnostics.shared.end("artwork.defaultLookup", measurement) }
        let side = ArtworkPixelSize.bucket(pixels), key = "\(name):\(side)" as NSString
        if let cached = bitmaps.object(forKey: key) { return cached.image }
        BrowseDiagnostics.shared.count("artwork.defaultRasterized")
        guard let image = image(name), let bitmap = NSBitmapImageRep(bitmapDataPlanes: nil, pixelsWide: side, pixelsHigh: side, bitsPerSample: 8, samplesPerPixel: 4, hasAlpha: true, isPlanar: false, colorSpaceName: .deviceRGB, bytesPerRow: 0, bitsPerPixel: 0), let context = NSGraphicsContext(bitmapImageRep: bitmap) else { return nil }
        NSGraphicsContext.saveGraphicsState(); NSGraphicsContext.current = context
        image.draw(in: CGRect(x: 0, y: 0, width: side, height: side), from: .zero, operation: .copy, fraction: 1)
        NSGraphicsContext.restoreGraphicsState()
        guard let result = bitmap.cgImage else { return nil }
        bitmaps.setObject(ArtworkBitmap(result), forKey: key, cost: side * side * 4)
        return result
    }

}

/// Both states use the same system glyph and image bounds. Fill only its enclosed lens.
struct CapsuleSearchIcon: View {
    let selected: Bool
    private static let images: (outline: NSImage, filled: NSImage) = {
        let symbol = NSImage(systemSymbolName: "magnifyingglass", accessibilityDescription: nil)!
            .withSymbolConfiguration(.init(pointSize: SonoDesktopTokens.SymbolSize.compact, weight: SonoDesktopTokens.NativeFontWeight.regular))!
        let scale: CGFloat = 4
        let width = Int(ceil(symbol.size.width * scale))
        let height = Int(ceil(symbol.size.height * scale))
        let bitmap = NSBitmapImageRep(bitmapDataPlanes: nil, pixelsWide: width, pixelsHigh: height,
                                      bitsPerSample: 8, samplesPerPixel: 4, hasAlpha: true,
                                      isPlanar: false, colorSpaceName: .deviceRGB, bytesPerRow: width * 4, bitsPerPixel: 32)!
        NSGraphicsContext.saveGraphicsState()
        NSGraphicsContext.current = NSGraphicsContext(bitmapImageRep: bitmap)
        symbol.draw(in: CGRect(x: 0, y: 0, width: width, height: height))
        NSGraphicsContext.restoreGraphicsState()
        let pixels = bitmap.bitmapData!
        var exterior = [Bool](repeating: false, count: width * height)
        var frontier: [Int] = []
        func visit(_ x: Int, _ y: Int) {
            let index = y * width + x
            if !exterior[index], pixels[index * 4 + 3] < 128 {
                exterior[index] = true
                frontier.append(index)
            }
        }
        for x in 0..<width { visit(x, 0); visit(x, height - 1) }
        for y in 0..<height { visit(0, y); visit(width - 1, y) }
        var cursor = 0
        while cursor < frontier.count {
            let index = frontier[cursor]
            cursor += 1
            let x = index % width, y = index / width
            if x > 0 { visit(x - 1, y) }
            if x + 1 < width { visit(x + 1, y) }
            if y > 0 { visit(x, y - 1) }
            if y + 1 < height { visit(x, y + 1) }
        }
        for index in 0..<(width * height) where !exterior[index] && pixels[index * 4 + 3] < 128 {
            pixels[index * 4] = 0
            pixels[index * 4 + 1] = 0
            pixels[index * 4 + 2] = 0
            pixels[index * 4 + 3] = 255
        }
        let filled = NSImage(size: symbol.size)
        bitmap.size = symbol.size
        filled.addRepresentation(bitmap)
        filled.isTemplate = true
        symbol.isTemplate = true
        return (symbol, filled)
    }()

    var body: some View {
        Image(nsImage: selected ? Self.images.filled : Self.images.outline)
            .renderingMode(.template)
            .accessibilityHidden(true)
    }
}

struct SonoWordmark: View {
    let height: CGFloat

    var body: some View {
        if let image = SonoAssets.image("sono-wordmark") {
            Image(nsImage: image).resizable().renderingMode(.template)
                .aspectRatio(158.0 / 40.0, contentMode: .fit)
                .frame(height: height)
                .accessibilityLabel("SONO MUSIC")
        }
    }
}

struct SonoIcon: View {
    @Environment(\.colorScheme) private var colorScheme
    @Environment(\.lyricsInk) private var lyricsInk
    let name: String
    var size: CGFloat = SonoDesktopTokens.SvgSize.s32
    var tint: Color? = nil
    var inheritsForeground = false
    var body: some View {
        if let image = SonoAssets.image(name) {
            if name == "sono-logo" {
                if colorScheme == .light {
                    Image(nsImage: image).resizable().scaledToFit().colorInvert().frame(width: size, height: size).accessibilityHidden(true)
                } else {
                    Image(nsImage: image).resizable().scaledToFit().frame(width: size, height: size).accessibilityHidden(true)
                }
            } else if inheritsForeground {
                Image(nsImage: image).resizable().renderingMode(.template).scaledToFit().frame(width: size, height: size).accessibilityHidden(true)
            } else {
                Image(nsImage: image).resizable().renderingMode(tint == nil && lyricsInk.contentAdaptive && !lyricsInk.light ? .original : .template).foregroundStyle(tint ?? Color(nsColor:lyricsInk.primary)).scaledToFit().frame(width: size, height: size).accessibilityHidden(true)
            }
        }
    }
}

enum SonoChromeMetrics {
    static let sourceDrawerMaximumWidth: CGFloat = 352
    static let buttonSize: CGFloat = SonoDesktopTokens.Component.tool
    static let horizontalInset: CGFloat = SonoDesktopTokens.Spacing.s16
    static let topInset: CGFloat = SonoDesktopTokens.Spacing.s36
    static var topCenterY: CGFloat { topInset + buttonSize / 2 }
}

struct SonoChromeButton: View {
    @Environment(\.colorScheme) private var colorScheme
    @Environment(\.isEnabled) private var enabled
    let icon: String
    var iconSize: CGFloat = SonoDesktopTokens.SvgSize.s24
    let label: String
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            SonoIcon(name: icon, size: iconSize, inheritsForeground: true)
                .sonoIconFrame(SonoDesktopTokens.IconFrame.s24)
                .frame(width: SonoChromeMetrics.buttonSize, height: SonoChromeMetrics.buttonSize)
                .chromeSurface()
        }.buttonStyle(SonoQueueButtonStyle(normal: SonoGeneratedColors.toolIcon, light: colorScheme == .light)).help(label).accessibilityLabel(label)
            .onHover { inside in (inside && enabled ? NSCursor.pointingHand : NSCursor.arrow).set() }
    }
}

enum SonoGlassDensity: String, CaseIterable {
    case clear, regular, dense

    var title: String {
        switch self {
        case .clear: "清透"
        case .regular: "标准"
        case .dense: "浓厚"
        }
    }

    var material: Glass { self == .clear ? .clear : .regular }
}

private struct SonoGlassDensityKey: EnvironmentKey {
    static let defaultValue = SonoGlassDensity.regular
}

extension EnvironmentValues {
    var sonoGlassDensity: SonoGlassDensity {
        get { self[SonoGlassDensityKey.self] }
        set { self[SonoGlassDensityKey.self] = newValue }
    }
}

extension View {
    func glass(radius: CGFloat) -> some View {
        modifier(SonoGlassSurface(shape: RoundedRectangle(cornerRadius: radius, style: .continuous)))
            .background { SonoChromeInteractionSurface(radius: radius) }
    }
    func chromeSurface() -> some View {
        modifier(SonoChromeSurface())
    }
}

struct SonoSearchFocusRing: View {
    @Environment(\.sonoTheme) private var theme
    let focused: Bool

    var body: some View {
        if focused {
            Capsule().inset(by: -SonoDesktopTokens.Border.selection)
                .strokeBorder(Color(nsColor: theme.color(pink: SonoGeneratedColors.searchFocusRing)), lineWidth: SonoDesktopTokens.Border.selection)
                .allowsHitTesting(false)
                .accessibilityHidden(true)
        }
    }
}

private struct SonoChromeSurface: ViewModifier {
    @Environment(\.isEnabled) private var enabled
    func body(content: Content) -> some View {
        content.modifier(SonoGlassSurface(shape: Circle(), interactive: enabled))
            .contentShape(Circle())
    }
}

private struct SonoGlassSurface<Outline: Shape>: ViewModifier {
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    @Environment(\.sonoGlassDensity) private var density
    let shape: Outline
    var interactive = false

    func body(content: Content) -> some View {
        content
            .background {
                if reduceTransparency {
                    shape.fill(Color(nsColor: .windowBackgroundColor)).allowsHitTesting(false)
                } else if density == .dense {
                    shape.fill(Color(nsColor: SonoGeneratedColors.glassShade)).allowsHitTesting(false)
                }
            }
            .glassEffect(density.material.interactive(interactive), in: shape)

    }

}

// Glass is visual; its empty areas must also own native pointer events so the
// AppKit cover canvas cannot hover, click or scroll through floating controls.
private struct SonoChromeInteractionSurface: View {
    let radius: CGFloat?
    var body: some View {
        GeometryReader { geometry in
            let corner = radius ?? min(geometry.size.width, geometry.size.height) / 2
            RoundedRectangle(cornerRadius: corner, style: .continuous)
                .fill(Color.clear)
                .contentShape(RoundedRectangle(cornerRadius: corner, style: .continuous))
                .onTapGesture {}
        }
        .accessibilityHidden(true)
    }
}

struct SonoRange: View {
    @Binding var value: Double
    var maximum: Double = 1
    var label: String
    var step: Double = 0.01
    var enabled = true
    var body: some View {
        // A stepped SwiftUI slider creates a mark for every increment. Keep the
        // native continuous track and quantize input, not the rendered tick list.
        Slider(value: Binding(get: { value }, set: { next in
            value = min(max(1, maximum), max(0, (next / step).rounded() * step))
        }), in: 0...max(1, maximum)) { Text(label) }
            .labelsHidden().controlSize(.small).disabled(!enabled)
            .accessibilityLabel(label)
            .accessibilityAdjustableAction { direction in
                switch direction {
                case .increment: adjust(by: step)
                case .decrement: adjust(by: -step)
                @unknown default: break
                }
            }
            .onKeyPress(.leftArrow) { adjust(by: -step); return .handled }
            .onKeyPress(.rightArrow) { adjust(by: step); return .handled }
    }
    private func adjust(by delta: Double) {
        guard enabled else { return }
        value = min(max(1, maximum), max(0, value + delta))
    }
}

struct SonoSwitch: View {
    @Binding var value: Bool
    let label: String
    var body: some View {
        Toggle(label, isOn: $value).toggleStyle(.switch).labelsHidden()
            .accessibilityLabel(label)
    }
}

@MainActor
enum SonoCoverMask {
    static func values(showing: Bool) -> [Float] {
        (0...120).map { index in
            let t = Double(index) / 120
            let sample = showing ? 1 - t : t
            return Float(1 - pow((1 - cos(sample * .pi)) / 2, 1.8))
        }
    }
}

extension View {
    func sonoIconFrame(_ side: CGFloat) -> some View {
        frame(width: side, height: side)
            .clipped()
    }
}

struct SonoThemeSegments<Value: Hashable>: View {
    let label: String
    @Binding var selection: Value
    let options: [Value]
    let title: (Value) -> String
    let disabledReason: (Value) -> String?
    var showsLabel: Bool
    @Environment(\.sonoTheme) private var theme
    @Environment(\.isEnabled) private var enabled

    init(_ label: String, selection: Binding<Value>, options: [Value], showsLabel: Bool = true, disabledReason: @escaping (Value) -> String? = { _ in nil }, title: @escaping (Value) -> String) {
        self.label = label
        self._selection = selection
        self.options = options
        self.showsLabel = showsLabel
        self.title = title
        self.disabledReason = disabledReason
    }

    var body: some View {
        HStack(spacing: SonoDesktopTokens.Spacing.s8) {
            if showsLabel { Text(label) }
            HStack(spacing: 0) {
                ForEach(options, id: \.self) { option in
                    let selected = selection == option
                    let reason = disabledReason(option)
                    let button = Button { selection = option } label: {
                        Text(title(option))
                            .foregroundStyle(Color(nsColor: selected ? theme.foreground() : SonoGeneratedColors.primaryText))
                            .padding(.horizontal, SonoDesktopTokens.Spacing.s12)
                            .frame(minHeight: SonoDesktopTokens.Component.inlineAction)
                            .background(selected ? Color(nsColor: theme.accent) : .clear, in: RoundedRectangle(cornerRadius: 6))
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .accessibilityAddTraits(selected ? [.isSelected] : [])
                    if let reason {
                        button
                            .disabled(true)
                            .opacity(0.4)
                            .accessibilityHint(reason)
                            .sonoTooltip(reason)
                    } else {
                        button
                    }
                }
            }
            .background(Color(nsColor: SonoGeneratedColors.recommendationControlFill), in: RoundedRectangle(cornerRadius: 6))
            .opacity(enabled ? 1 : 0.4)
            .accessibilityElement(children: .contain)
            .accessibilityLabel(label)
        }
    }
}

struct BrowseCategoryTitle: View {
    let title: String
    let selected: Bool
    let scale: CGFloat
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        let largeSize = SonoDesktopTokens.FontSize.pageTitle * scale
        let size = selected ? largeSize : SonoDesktopTokens.FontSize.sectionTitle * scale
        let ratio = size / largeSize
        let width = ceil(SonoTypography.width(title, size: largeSize, weight: .semibold))
        Text(title)
            .font(SonoTypography.font(size: largeSize, weight: .semibold))
            .fixedSize()
            .scaleEffect(ratio, anchor: .bottom)
            .frame(width: width * ratio + 2 * SonoDesktopTokens.Spacing.s12 * scale,
                   height: 36 * scale, alignment: .bottom)
            .contentShape(Rectangle())
            .animation(reduceMotion ? nil : .easeInOut(duration: 0.2), value: selected)
    }
}
