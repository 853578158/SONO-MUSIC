import Foundation

struct SearchResultBatch: Sendable {
    var items: [BrowseItem]
    var received: Int
    var total: Int
    var more: Bool
}

extension NeteaseClient {
    func searchBatch(query: String, category: SearchCategory, offset: Int, cookie: String, previous: [BrowseItem] = []) async throws -> SearchResultBatch {
        let started = BrowseDiagnostics.shared.start()
        let result = try await request(category == .combined ? "/api/search/get" : "/api/cloudsearch/pc",
            ["s": query, "type": category.serviceType, "offset": String(offset), "limit": "60", "total": "true"],
            cookie: cookie, weapi: category == .combined)
        BrowseDiagnostics.shared.end("search.request", started)
        try Task.checkCancellation()
        let decoding = BrowseDiagnostics.shared.start()
        defer { BrowseDiagnostics.shared.end("search.decodeAndMerge", decoding) }
        var batch = try SearchResultDecoder.decode(result["result"], category: category)
        var known = Set(previous.map(\.id))
        batch.items = previous + batch.items.filter { known.insert($0.id).inserted }
        return batch
    }
    func searchPage(_ original: OnlinePage, cookie: String) async throws -> OnlinePage {
        let category = original.kind.searchCategory ?? .songs
        let batch = try await searchBatch(query: original.kind.searchQuery!, category: category,
            offset: original.offset, cookie: cookie, previous: original.offset == 0 ? [] : original.browseItems)
        var next = original
        var items = batch.items
        if original.offset == 0 {
            items = items.map { item in
                guard var song = item.song else { return item }
                song.searchCoverFallback = song.coverURL == nil
                return .song(song)
            }
        }
        next.items = original.kind.classifiedSearch ? items : nil
        next.tracks = items.compactMap(\.song)
        next.offset += batch.received; next.total = max(items.count, batch.total)
        next.more = batch.more && batch.received > 0 && next.offset < next.total
        return next
    }
}
enum SearchResultDecoder {
    static func decode(_ result: OnlineJSON, category: SearchCategory) throws -> SearchResultBatch {
        if category == .combined {
            let order = result["order"].array.map(\.string)
            var items: [BrowseItem] = []
            for group in order {
                switch group {
                case "song": items += result["song"]["songs"].array.map { .song(OnlineSong($0).track) }
                case "artist": break // Artist results have their own independent search group.
                case "album": items += result["album"]["albums"].array.map { .entity(BrowseEntity($0, kind: .album)) }
                case "playList", "playlist":
                    let section = result[group]
                    items += section["playLists"].array.map { .entity(BrowseEntity($0, kind: .playlist)) }
                default: break
                }
            }
            // The composite endpoint is a ranked snapshot; individual categories own full pagination.
            if order.isEmpty && !result["song"].isNull { throw OnlineError.protocolFailure("综合搜索未返回结果顺序，请重试") }
            return SearchResultBatch(items: unique(items), received: items.count, total: items.count, more: false)
        }
        let field: String, count: String
        switch category { case .artists: field = "artists"; count = "artistCount"; case .songs: field = "songs"; count = "songCount"; case .albums: field = "albums"; count = "albumCount"; case .playlists: field = "playlists"; count = "playlistCount"; case .combined: preconditionFailure() }
        let values = result[field].array
        let items: [BrowseItem] = values.map { value in
            category == .songs ? .song(OnlineSong(value).track) : .entity(BrowseEntity(value, kind: category == .artists ? .artist : category == .albums ? .album : .playlist))
        }
        let total = result[count].int
        return SearchResultBatch(items: unique(items), received: values.count, total: total, more: !values.isEmpty)
    }
    private static func unique(_ items: [BrowseItem]) -> [BrowseItem] {
        var seen = Set<String>()
        return items.filter { !$0.id.isEmpty && seen.insert($0.id).inserted }
    }
}
