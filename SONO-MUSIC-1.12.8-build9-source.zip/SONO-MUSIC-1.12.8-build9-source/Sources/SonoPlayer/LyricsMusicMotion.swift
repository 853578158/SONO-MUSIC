import Foundation
import simd

enum LyricsMusicMotionStyle:String, CaseIterable {
    case gentle, balanced, rhythm
    var title:String { switch self { case .balanced: "均衡"; case .rhythm: "节奏"; case .gentle: "柔和" } }
    var weights:SIMD4<Float> {
        switch self {
        case .balanced: SIMD4(1,0.9,0.2,1)
        case .rhythm: SIMD4(1.3,0.28,0.1,1)
        case .gentle: SIMD4(0.22,1.2,0.15,0.8)
        }
    }
    var attack:SIMD4<Float> {
        switch self {
        case .balanced: SIMD4(0.035,0.18,0.25,0.3)
        case .rhythm: SIMD4(0.02,0.18,0.25,0.3)
        case .gentle: SIMD4(0.22,0.3,0.3,0.4)
        }
    }
    var release:SIMD4<Float> {
        switch self {
        case .balanced: SIMD4(0.12,0.45,0.6,0.8)
        case .rhythm: SIMD4(0.075,0.45,0.6,0.8)
        case .gentle: SIMD4(0.65,0.8,0.7,1)
        }
    }
}

struct LyricsMusicMotionSettings:Equatable {
    let enabled:Bool
    let style:LyricsMusicMotionStyle
    let strength:Float
    init(enabled:Bool,style:LyricsMusicMotionStyle = .balanced,strength:Double = 0.5) {
        self.enabled = enabled; self.style = style
        self.strength = strength.isFinite ? Float(min(1,max(0,strength))) : 0.5
    }
    var active:Bool { enabled && strength > 0 }
}
