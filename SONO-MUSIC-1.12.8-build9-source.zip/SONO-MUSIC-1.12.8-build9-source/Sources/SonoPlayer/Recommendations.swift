import Foundation

struct DailyStyleTag: Identifiable, Equatable, Sendable {
    let id: String
    let name: String
}
struct DailyStyleGroup: Identifiable, Equatable, Sendable {
    let id: String
    let name: String
    let tags: [DailyStyleTag]
}
struct DailyStyleSelection: Codable, Equatable, Sendable {
    var categoryID: String
    var tagIDs: [String]
    mutating func toggle(_ tag: String, in category: String) -> Bool {
        if categoryID != category { categoryID = category; tagIDs = [tag]; return true }
        if let index = tagIDs.firstIndex(of: tag) { tagIDs.remove(at: index); return true }
        guard tagIDs.count < 5 else { return false }
        tagIDs.append(tag); return true
    }
}
struct DailyStyleResponse: Sendable {
    let songs: [OnlineSong]
    let selection: DailyStyleSelection?
}

// Native recommendation models. Mode identifiers follow api-enhanced 4.40.1.
struct PersonalFMSelection: Codable, Equatable, Sendable {
    enum Mode: String, Codable, CaseIterable, Sendable {
        case `default` = "DEFAULT", familiar = "FAMILIAR", explore = "EXPLORE", puzzle = "PUZZLE_MODE_RCMD", scene = "SCENE_RCMD"
        var title: String { switch self { case .default: "默认"; case .familiar: "熟悉"; case .explore: "探索"; case .puzzle: "拼图"; case .scene: "场景" } }
    }
    var mode: Mode = .default
    var scene: String? = nil
    var valid: Bool { mode != .scene || Self.scenes.contains { $0.id == scene } }
    var title: String { mode == .scene ? "场景 · " + (Self.scenes.first { $0.id == scene }?.title ?? "请选择") : mode.title }
    struct Scene: Identifiable, Sendable { let id: String; let category: String; let title: String }
    static let categories = ["情绪", "活动", "曲风", "语言"]
    static let scenes: [Scene] = [
        .init(id: "NIGHT_EMO", category: "情绪", title: "伤感"),
        .init(id: "CURE", category: "情绪", title: "治愈"),
        .init(id: "CHEERFUL", category: "情绪", title: "欢快"),
        .init(id: "LYRICAL", category: "情绪", title: "抒情"),
        .init(id: "INSPIRATIONAL", category: "情绪", title: "励志"),
        .init(id: "RELAX", category: "情绪", title: "放松"),
        .init(id: "SWEET", category: "情绪", title: "情歌"),
        .init(id: "EXERCISE", category: "活动", title: "运动"),
        .init(id: "FOCUS", category: "活动", title: "专注"),
        .init(id: "SLEEP_HELP", category: "活动", title: "助眠"),
        .init(id: "TAKE_SHOWER", category: "活动", title: "洗澡"),
        .init(id: "COMMUTE", category: "活动", title: "出行"),
        .init(id: "COFFEE_SHOP", category: "活动", title: "咖啡馆"),
        .init(id: "GAMES", category: "活动", title: "游戏"),
        .init(id: "DANCE", category: "活动", title: "舞蹈"),
        .init(id: "RAINY", category: "活动", title: "雨天"),
        .init(id: "RHYTHM_BLUES", category: "曲风", title: "R&B"),
        .init(id: "RAP", category: "曲风", title: "说唱"),
        .init(id: "K_POP", category: "曲风", title: "K-Pop"),
        .init(id: "ELECTRONIC", category: "曲风", title: "电音"),
        .init(id: "ROCK", category: "曲风", title: "摇滚"),
        .init(id: "FOLK", category: "曲风", title: "民谣"),
        .init(id: "GUDIAN", category: "曲风", title: "古典"),
        .init(id: "JAZZ", category: "曲风", title: "爵士"),
        .init(id: "BLUE", category: "曲风", title: "蓝调"),
        .init(id: "PUNK", category: "曲风", title: "放克"),
        .init(id: "COUNTRY", category: "曲风", title: "乡村乐"),
        .init(id: "LIGHT", category: "曲风", title: "轻音乐"),
        .init(id: "GUOFENG", category: "曲风", title: "国风"),
        .init(id: "MANYAO", category: "曲风", title: "慢摇DJ"),
        .init(id: "MUSICAL", category: "曲风", title: "音乐剧"),
        .init(id: "ACG", category: "曲风", title: "二次元"),
        .init(id: "JINGDIAN", category: "曲风", title: "经典"),
        .init(id: "ORIGINAL_MUSICIAL", category: "曲风", title: "宝藏原创"),
        .init(id: "YINGSHI", category: "曲风", title: "影视"),
        .init(id: "CHINESE", category: "语言", title: "华语"),
        .init(id: "ENGLISH", category: "语言", title: "欧美"),
        .init(id: "YUEYU", category: "语言", title: "粤语"),
        .init(id: "JAPANESE", category: "语言", title: "日语"),
        .init(id: "FRANCH", category: "语言", title: "法语"),
        .init(id: "LATIN", category: "语言", title: "拉丁"),
        .init(id: "GLOBAL", category: "语言", title: "全球"),
    ]
}
enum DailyRecommendationFeedback: Sendable {
    case replacement(OnlineSong), limitReached
}
enum RecommendationDate {
    static func refreshDay(_ date: Date = Date()) -> String { day(date.addingTimeInterval(-6 * 3600)) }
    static func nextRefresh(_ date: Date = Date()) -> Date {
        var calendar = Calendar(identifier: .gregorian); calendar.timeZone = TimeZone(identifier: "Asia/Shanghai")!
        return calendar.nextDate(after: date, matching: DateComponents(hour: 6), matchingPolicy: .nextTime)!
    }
    static func day(_ date: Date = Date()) -> String {
        let format = DateFormatter(); format.timeZone = TimeZone(identifier: "Asia/Shanghai")
        format.calendar = Calendar(identifier: .gregorian); format.locale = Locale(identifier: "en_US_POSIX")
        format.dateFormat = "yyyy-MM-dd"; return format.string(from: date)
    }
}

extension NeteaseClient {
    func dailyStyleGroups(cookie: String) async throws -> [DailyStyleGroup] {
        let result = try await request("/api/homepage/daily/song/config/get", cookie: cookie, xeapi: true)
        guard case .array(let rows) = result["data"]["categorys"] else {
            throw OnlineError.protocolFailure("风格分类格式无效")
        }
        return try rows.map { row in
            let id = row["categoryId"].string
            guard !id.isEmpty, case .array(let tags) = row["tagVOList"] else {
                throw OnlineError.protocolFailure("风格标签格式无效")
            }
            return DailyStyleGroup(id: id, name: row["categoryName"].string, tags: try tags.map { tag in
                guard !tag["tagId"].string.isEmpty else { throw OnlineError.protocolFailure("风格标签缺少标识") }
                return DailyStyleTag(id: tag["tagId"].string, name: tag["tagName"].string)
            })
        }
    }
    func dailyStyleSongs(cookie: String) async throws -> DailyStyleResponse {
        let result = try await request("/api/homepage/category/daily/song/list", cookie: cookie, xeapi: true)
        let tags = result["data"]["tags"]
        let category = tags["categoryId"].string
        let ids = tags["tagVOList"].array.map { $0["tagId"].string }.filter { !$0.isEmpty }
        return DailyStyleResponse(songs: try Self.dailySongs(result), selection: category.isEmpty || ids.isEmpty ? nil : .init(categoryID: category, tagIDs: ids))
    }
    func saveDailyStyle(_ selection: DailyStyleSelection, cookie: String) async throws {
        guard let category = Int(selection.categoryID), (1...5).contains(selection.tagIDs.count),
              Set(selection.tagIDs).count == selection.tagIDs.count else {
            throw OnlineError.protocolFailure("请选择同一分类的 1 至 5 种风格")
        }
        let ids = try selection.tagIDs.map { id -> Int in
            guard let value = Int(id) else { throw OnlineError.protocolFailure("风格标签标识无效") }
            return value
        }
        let payload = try NeteaseCrypto.json(["categoryId": category, "tagIds": ids])
        let result = try await request("/api/homepage/daily/song/tag/save", ["tags": String(decoding: payload, as: UTF8.self)], cookie: cookie, xeapi: true)
        guard result["data"]["saveSuccess"].bool else { throw OnlineError.protocolFailure("网易云未确认风格保存成功") }
    }
    func personalFM(selection: PersonalFMSelection, cookie: String) async throws -> [OnlineSong] {
        guard selection.valid else { throw OnlineError.protocolFailure("请选择具体的 FM 场景") }
        var parameters = [String: String]()
        if selection.mode != .default {
            parameters["mode"] = selection.mode.rawValue
            if selection.mode == .scene { parameters["subMode"] = selection.scene }
        }
        let result = try await request("/api/v1/radio/get", parameters, cookie: cookie, weapi: selection.mode == .default, numbers: selection.mode == .default ? [:] : ["limit": 3])
        return try Self.recommendationSongs(result["data"])
    }
    func dailyRecommendations(afresh: Bool = false, cookie: String) async throws -> [OnlineSong] {
        let result = try await request("/api/v3/discovery/recommend/songs", cookie: cookie, weapi: true, flags: ["afresh": afresh])
        return try Self.dailySongs(result)
    }
    func trashFM(_ song: String, playedSeconds: Int, cookie: String) async throws {
        let result = try await request("/api/radio/trash/add", ["songId": song, "alg": "RT"], cookie: cookie, weapi: true, numbers: ["time": max(0, playedSeconds)])
        guard result["code"].int == 200 else { throw OnlineError.protocolFailure("不喜欢反馈未确认") }
    }
    func dislikeRecommendation(_ song: String, cookie: String) async throws -> DailyRecommendationFeedback {
        do {
            let result = try await request("/api/v2/discovery/recommend/dislike", ["resId": song], cookie: cookie, weapi: true, numbers: ["resType": 4, "sceneType": 1])
            let songs = try Self.recommendationSongs(.array([result["data"]]))
            return .replacement(songs[0])
        } catch OnlineError.service(432, _) { return .limitReached }
    }
    private static func dailySongs(_ result: OnlineJSON) throws -> [OnlineSong] {
        for value in [result["data"]["dailySongs"], result["data"]["songs"], result["recommendData"]["dailySongs"], result["songs"]] {
            if !value.isNull { return try recommendationSongs(value) }
        }
        throw OnlineError.protocolFailure("每日推荐响应缺少歌曲列表")
    }
    private static func recommendationSongs(_ value: OnlineJSON) throws -> [OnlineSong] {
        guard case .array(let rows) = value, rows.allSatisfy({ !$0["id"].string.isEmpty && !$0["name"].string.isEmpty }) else { throw OnlineError.protocolFailure("推荐歌曲响应格式无效") }
        var seen = Set<String>()
        return rows.filter { seen.insert($0["id"].string).inserted }.map(OnlineSong.init)
    }
}

// Old historical pages are discarded; old playing queues retain their tracks as a playback snapshot.
enum RecommendationPersistenceMigration {
    static func data(_ data: Data, cache: Bool) throws -> Data {
        guard var object = try JSONSerialization.jsonObject(with: data) as? [String: Any] else { return data }
        if cache, let pages = object["pages"] as? [[String: Any]] {
            object["pages"] = pages.filter { (($0["kind"] as? [String: Any])?["recommendationHistory"]) == nil }
        } else if let kind = object["queueSourceKind"] as? [String: Any], kind["recommendationHistory"] != nil {
            object["queueSourceKind"] = ["playback": [String: String]()]; object["queueTitle"] = "播放队列"
        }
        return try JSONSerialization.data(withJSONObject: object)
    }
}
