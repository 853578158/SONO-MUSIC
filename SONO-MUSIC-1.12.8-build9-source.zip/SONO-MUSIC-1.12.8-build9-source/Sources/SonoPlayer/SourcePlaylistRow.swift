import SwiftUI
import AppKit

enum SourcePlaylistSection: CaseIterable {
    case owned, subscribed

    var title: String { self == .owned ? "我的歌单" : "收藏歌单" }
}

struct SourceDrawerSection<Rows: View>: View {
    let title: String
    let expanded: Bool
    let toggle: () -> Void
    @ViewBuilder let rows: () -> Rows

    var body: some View {
        LazyVStack(spacing: SonoDesktopTokens.Spacing.s4) {
            header
            if expanded { rows() }
        }
    }

    private var header: some View {
        Button(action: toggle) {
            HStack {
                Text(title).font(SonoTypography.font(size: SonoDesktopTokens.FontSize.caption, weight: SonoDesktopTokens.FontWeight.medium))
                    .lineLimit(1)
                Spacer()
                Image(systemName: "chevron.backward")
                    .font(.system(size: SonoDesktopTokens.SymbolSize.small))
                    .rotationEffect(.degrees(expanded ? -90 : 0))
                    .sonoIconFrame(SonoDesktopTokens.IconFrame.s16)
                    .frame(width: SonoDesktopTokens.Component.control)
                    .modifier(SonoHoverForeground(normal: SonoGeneratedColors.sourceSectionArrow))
            }
            .foregroundStyle(Color(nsColor: SonoGeneratedColors.sourceText))
            .frame(height: SonoDesktopTokens.Spacing.s28)
            .contentShape(Rectangle())
        }
        .accessibilityLabel(title)
        .accessibilityValue(expanded ? "已展开" : "已折叠")
        .padding(.horizontal, -SonoDesktopTokens.Spacing.s8)
    }
}

/// Changes only the label foreground; selected and disabled controls keep their normal colour.
struct SonoHoverForeground: ViewModifier {
    let normal: NSColor
    var hover: NSColor? = nil
    var active = true
    @Environment(\.colorScheme) private var colorScheme
    @Environment(\.isEnabled) private var enabled
    @State private var hovered = false

    func body(content: Content) -> some View {
        content
            .foregroundStyle(Color(nsColor: enabled && active && hovered ? (hover ?? (colorScheme == .light ? SonoGeneratedColors.interfaceHoverForeground : SonoGeneratedColors.interfaceHoverForegroundDark)) : normal))
            .onHover { hovered = $0 }
            .onDisappear { hovered = false }
    }
}

struct SourceDrawerResizeHandle: NSViewRepresentable {
    let width: CGFloat
    let resize: (CGFloat) -> Void

    func makeNSView(context: Context) -> Handle { Handle() }

    func updateNSView(_ view: Handle, context: Context) {
        view.drawerWidth = width
        view.resize = resize
    }

    final class Handle: NSView {
        var drawerWidth: CGFloat = 0
        var resize: (CGFloat) -> Void = { _ in }
        private var startX: CGFloat = 0
        private var startWidth: CGFloat = 0

        override var mouseDownCanMoveWindow: Bool { false }

        override func resetCursorRects() {
            addCursorRect(bounds, cursor: .resizeLeftRight)
        }

        override func mouseDown(with event: NSEvent) {
            startX = event.locationInWindow.x
            startWidth = drawerWidth
        }

        override func mouseDragged(with event: NSEvent) {
            resize(startWidth + event.locationInWindow.x - startX)
        }
    }
}

/// Queue controls resolve disabled, pressed, hover and normal foregrounds in one place.
struct SonoQueueButtonStyle: ButtonStyle {
    let normal: NSColor
    let light: Bool
    var hover: NSColor? = nil
    var active = true
    @Environment(\.isEnabled) private var enabled
    @State private var hovered = false

    func makeBody(configuration: Configuration) -> some View {
        let foreground = !enabled
            ? (light ? SonoGeneratedColors.queueDisabledLight : SonoGeneratedColors.queueDisabledDark)
            : configuration.isPressed
                ? (light ? SonoGeneratedColors.queuePressedLight : SonoGeneratedColors.queuePressedDark)
                : hovered && active
                    ? (hover ?? (light ? SonoGeneratedColors.interfaceHoverForeground : SonoGeneratedColors.interfaceHoverForegroundDark))
                    : normal
        configuration.label
            .foregroundStyle(Color(nsColor: foreground))
            .onHover { inside in
                hovered = inside
                (inside && enabled ? NSCursor.pointingHand : .arrow).set()
            }
            .onDisappear { hovered = false }
    }
}

struct SonoPanelCloseStyle: ButtonStyle {
    var usesIconOpacity = false
    @Environment(\.colorScheme) private var colorScheme
    @Environment(\.isEnabled) private var enabled
    @State private var hovered = false

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .contentShape(Circle())
            .foregroundStyle(Color(nsColor: !enabled ? SonoGeneratedColors.interfaceDisabled : configuration.isPressed ? SonoGeneratedColors.sourceIconPressed : hovered ? (colorScheme == .light ? SonoGeneratedColors.interfaceHoverForeground : SonoGeneratedColors.interfaceHoverForegroundDark) : usesIconOpacity ? SonoGeneratedColors.sourceIcon : SonoGeneratedColors.sourceOrdinaryIcon))
            .onHover { inside in
                hovered = inside
                (inside && enabled ? NSCursor.pointingHand : .arrow).set()
            }
    }
}

struct SourcePlaylistArtwork: View {
    let url: URL?
    var size: CGFloat = SonoDesktopTokens.Cover.navigation

    var body: some View {
        AsyncImage(url: url.map { url in
            var parts = URLComponents(url: url, resolvingAgainstBaseURL: false)
            let items = (parts?.queryItems ?? []).filter { $0.name != "param" }
            parts?.queryItems = items + [URLQueryItem(name: "param", value: "80y80")]
            return parts?.url ?? url
        }) { image in
            image.resizable().scaledToFill()
        } placeholder: {
            if let fallback = SonoAssets.image("local-default") {
                Image(nsImage: fallback).resizable().scaledToFill()
            }
        }
        .frame(width: size, height: size)
    }
}

struct SourcePlaylistRow<Artwork: View>: View {
    @Environment(\.sonoTheme) private var theme
    let title: String
    var count: Int? = nil
    var isPlaylistCover = false
    let selected: Bool
    var iconColor: NSColor? = nil
    var playbackActive: Bool? = nil
    var warm: () -> Void = {}
    let action: () -> Void
    @ViewBuilder let artwork: () -> Artwork
    @ViewState private var hovered = false
    @Environment(\.accessibilityReduceMotion) private var reduced
    @Environment(\.colorScheme) private var colorScheme

    var body: some View {
        let inset: CGFloat = 8
        let radius: CGFloat = 12
        let showsWave = playbackActive != nil && !hovered
        let selectedForeground = theme.foreground(onAccent: colorScheme == .light ? SonoGeneratedColors.sourceSelectedLight : SonoGeneratedColors.sourceSelected)
        let iconForeground = selected && (colorScheme == .light || theme == .monochrome) ? selectedForeground : iconColor ?? (selected ? SonoGeneratedColors.sourceSelected : SonoGeneratedColors.sourceText)
        Button(action: action) {
            HStack(spacing: SonoDesktopTokens.Spacing.s12) {
                Group {
                    if isPlaylistCover {
                        artwork().sonoIconFrame(SonoDesktopTokens.Cover.navigation)
                    } else {
                        artwork().frame(width: SonoDesktopTokens.IconFrame.s20, height: SonoDesktopTokens.IconFrame.s20)
                    }
                }
                .frame(width: SonoDesktopTokens.Component.inlineAction, height: SonoDesktopTokens.Component.inlineAction)
                    .foregroundStyle(Color(nsColor: iconForeground))
                Text(title)
                    .font(SonoTypography.font(size: SonoDesktopTokens.FontSize.body, weight: SonoDesktopTokens.FontWeight.regular))
                    .lineLimit(1)
                    .frame(maxWidth: .infinity, alignment: .leading)
                if let count {
                    Text("\(count) 首")
                        .font(SonoTypography.font(size: SonoDesktopTokens.FontSize.caption))
                        .monospacedDigit()
                        .fixedSize()
                        .foregroundStyle(Color(nsColor: selected ? selectedForeground : SonoGeneratedColors.sourceText))
                        .opacity(hovered ? 1 : 0)
                        .accessibilityHidden(!hovered)
                        .overlay(alignment: .trailing) {
                            if showsWave, let playbackActive {
                                CapsulePlaybackIndicator(playing: playbackActive,
                                                         foreground: selected ? selectedForeground : nil)
                                    .sonoIconFrame(SonoDesktopTokens.IconFrame.s16)
                            }
                        }
                }
            }
            .padding(inset)
            .background {
                RoundedRectangle(cornerRadius: radius)
                    .fill(Color(nsColor: selected ? theme.color(pink: SonoGeneratedColors.sourceSelection) : hovered ? (colorScheme == .light ? SonoGeneratedColors.sourceHover : SonoGeneratedColors.sourceHoverDark) : .clear))
                    .padding(.horizontal, -8)
            }
            .contentShape(RoundedRectangle(cornerRadius: radius))
        }
        .foregroundStyle(Color(nsColor: selected ? selectedForeground : SonoGeneratedColors.sourceText))
        .onHover { inside in
            hovered = inside
            if inside && !selected { warm() }
        }
        .animation(reduced ? nil : .easeInOut(duration: 0.2), value: selected)
        .accessibilityLabel(title)
        .accessibilityValue(selected ? "当前来源" : "")
        .accessibilityAddTraits(selected ? [.isSelected] : [])
    }
}
