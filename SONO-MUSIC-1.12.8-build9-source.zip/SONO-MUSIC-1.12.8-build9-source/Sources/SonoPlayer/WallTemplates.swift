import Foundation

// v1.8.1 12×8 templates and compact tails.
struct WallSlot: Sendable {
    var x: Int; var y: Int; var cols: Int; var rows: Int
}

enum WallTemplates {
    static let columns = 12
    static let rows = 8
    static let capacity = 12
    // Partial blocks have their own connected mosaics; missing songs never
    // reserve the unused seats of a reflected 12×8 template. All dimensions
    // come from the existing card vocabulary (6×6 is reserved for selection).
    private static let compact: [[WallSlot]] = [
        [(0,0,4,4)],
        [(0,0,4,4),(4,0,2,4)],
        [(0,0,4,4),(4,0,2,2),(4,2,2,2)],
        [(0,0,4,4),(4,0,2,4),(0,4,3,2),(3,4,3,2)],
        [(0,0,4,4),(4,0,2,4),(0,4,2,2),(2,4,2,2),(4,4,2,2)],
        [(0,0,4,4),(4,0,4,2),(4,2,4,2),(0,4,2,2),(2,4,2,2),(4,4,4,2)],
        [(0,0,4,4),(4,0,4,2),(4,2,4,2),(0,4,2,2),(2,4,2,2),(4,4,2,2),(6,4,2,2)],
        [(0,0,4,4),(4,0,4,4),(0,4,2,2),(2,4,2,2),(4,4,2,2),(6,4,2,2),(0,6,4,2),(4,6,4,2)],
        [(0,0,4,4),(4,0,2,4),(6,0,2,4),(0,4,2,2),(2,4,2,2),(4,4,2,2),(6,4,2,2),(0,6,4,2),(4,6,4,2)],
        [(0,0,4,4),(4,0,4,4),(8,0,2,4),(0,4,2,2),(2,4,2,2),(4,4,2,2),(6,4,4,2),(0,6,4,2),(4,6,4,2),(8,6,2,2)],
        [(0,0,4,4),(4,0,4,4),(8,0,2,4),(0,4,2,2),(2,4,2,2),(4,4,2,2),(6,4,4,2),(0,6,2,2),(2,6,2,2),(4,6,2,2),(6,6,4,2)]
    ].map { $0.map { WallSlot(x: $0.0, y: $0.1, cols: $0.2, rows: $0.3) } }
    private static let compactExpanded: [[WallSlot]] = [
        [(0,0,6,6)],
        [(0,0,6,6),(6,0,4,4)],
        [(0,0,6,6),(6,0,2,3),(6,3,2,3)],
        [(0,0,6,6),(6,0,2,2),(6,2,2,2),(6,4,2,2)],
        [(0,0,6,6),(6,0,2,3),(6,3,2,3),(8,0,2,3),(8,3,2,3)],
        [(0,0,6,6),(6,0,2,2),(6,2,2,2),(6,4,2,2),(0,6,4,2),(4,6,4,2)],
        [(0,0,6,6),(6,0,2,2),(6,2,2,2),(6,4,2,2),(0,6,2,2),(2,6,2,2),(4,6,4,2)],
        [(0,0,6,6),(6,0,2,2),(6,2,2,2),(6,4,2,2),(0,6,2,2),(2,6,2,2),(4,6,2,2),(6,6,2,2)],
        [(0,0,6,6),(6,0,4,2),(6,2,4,2),(6,4,4,2),(0,6,2,2),(2,6,2,2),(4,6,2,2),(6,6,2,2),(8,6,2,2)],
        [(0,0,6,6),(6,0,2,2),(8,0,2,2),(6,2,2,2),(8,2,2,2),(6,4,4,2),(0,6,4,2),(4,6,2,2),(6,6,2,2),(8,6,2,2)],
        [(0,0,6,6),(6,0,2,2),(8,0,2,2),(6,2,2,2),(8,2,2,2),(6,4,4,2),(0,6,2,2),(2,6,2,2),(4,6,2,2),(6,6,2,2),(8,6,2,2)]
    ].map { $0.map { WallSlot(x: $0.0, y: $0.1, cols: $0.2, rows: $0.3) } }
    static func partialSlots(occupied: Int, expanded: Int?) -> [WallSlot] {
        guard let expanded else { return compact[occupied - 1] }
        var result = compactExpanded[occupied - 1]
        result.swapAt(0, expanded)
        return result
    }

    // Partition six 4×4 panels into twelve seats. Rotate the panel roles
    // between blocks to vary the composition while preserving its density.
    private static let resting = (0..<6).map { phase in
        (0..<6).flatMap { panel -> [WallSlot] in
            let x = panel % 3 * 4
            let y = panel / 3 * 4
            switch (panel + phase) % 6 {
            case 0, 1:
                return [WallSlot(x: x, y: y, cols: 4, rows: 4)]
            case 2:
                return [WallSlot(x: x, y: y, cols: 4, rows: 2),
                        WallSlot(x: x, y: y + 2, cols: 4, rows: 2)]
            case 3:
                return [WallSlot(x: x, y: y, cols: 2, rows: 4),
                        WallSlot(x: x + 2, y: y, cols: 2, rows: 4)]
            default:
                return [WallSlot(x: x, y: y, cols: 4, rows: 2),
                        WallSlot(x: x, y: y + 2, cols: 2, rows: 2),
                        WallSlot(x: x + 2, y: y + 2, cols: 2, rows: 2)]
            }
        }.sorted { ($0.y, $0.x) < ($1.y, $1.x) }
    }

    private static func displacement(_ a: WallSlot, _ b: WallSlot) -> Int {
        let dx = 2 * (a.x - b.x) + a.cols - b.cols
        let dy = 2 * (a.y - b.y) + a.rows - b.rows
        return dx * dx + dy * dy
    }

    #if SONO_GENERATE_WALL
    // Each step joins two free 2×2 squares.
    static let expansions = resting.map { base in
        base.indices.map { selected in
            (0..<8).map { origin in
                let focus = WallSlot(x: origin % 4 * 2, y: origin / 4 * 2, cols: 6, rows: 6)
                var remaining = (0..<24).compactMap { cell -> WallSlot? in
                    let x = cell % 6 * 2
                    let y = cell / 6 * 2
                    guard !(focus.x..<(focus.x + 6)).contains(x)
                            || !(focus.y..<(focus.y + 6)).contains(y) else { return nil }
                    return WallSlot(x: x, y: y, cols: 2, rows: 2)
                }
                var seats: [WallSlot] = []
                for _ in 0..<4 {
                    let first = remaining.firstIndex { tile in
                        remaining.contains { adjacent(tile, $0) }
                    }!
                    var tile = remaining.remove(at: first)
                    let neighbor = remaining.remove(at: remaining.firstIndex { adjacent(tile, $0) }!)
                    tile.cols += neighbor.x == tile.x ? 0 : 2
                    tile.rows += neighbor.y == tile.y ? 0 : 2
                    seats.append(tile)
                }
                seats += remaining

                var result = base
                result[selected] = focus
                var unassigned = base.indices.filter { $0 != selected }
                while !unassigned.isEmpty {
                    var best = (distance: Int.max, track: 0, seat: 0)
                    for track in unassigned.indices {
                        for seat in seats.indices {
                            let distance = displacement(base[unassigned[track]], seats[seat])
                            if distance < best.distance { best = (distance, track, seat) }
                        }
                    }
                    result[unassigned.remove(at: best.track)] = seats.remove(at: best.seat)
                }
                return result
            }
        }
    }

    private static func adjacent(_ a: WallSlot, _ b: WallSlot) -> Bool {
        (a.x == b.x && b.y == a.y + 2) || (a.y == b.y && b.x == a.x + 2)
    }

    #else
    private static func expansion(phase: Int, selected: Int, origin: Int) -> [WallSlot] {
        let offset = ((phase * capacity + selected) * 8 + origin) * capacity * 4
        return (0..<capacity).map { index in
            let start = offset + index * 4
            return WallSlot(x: Int(WallExpansionData.bytes[start]),
                            y: Int(WallExpansionData.bytes[start + 1]),
                            cols: Int(WallExpansionData.bytes[start + 2]),
                            rows: Int(WallExpansionData.bytes[start + 3]))
        }
    }

    private static func phase(column: Int, row: Int) -> Int {
        let offset = (column % 6 + 5 * (row % 6)) % 6
        return (offset + 6) % 6
    }

    static func slots(column: Int, row: Int, expanded: Int?) -> [WallSlot] {
        let phase = phase(column: column, row: row)
        guard let expanded else { return resting[phase] }
        let base = resting[phase][expanded]
        let nearest = (0..<8).min { lhs, rhs in
            func focus(_ origin: Int) -> WallSlot {
                WallSlot(x: origin % 4 * 2, y: origin / 4 * 2, cols: 6, rows: 6)
            }
            return displacement(base, focus(lhs)) < displacement(base, focus(rhs))
        }!
        return expansion(phase: phase, selected: expanded, origin: nearest)
    }

    static func slots(column: Int, row: Int, expanded: Int, targetOrigin: CGPoint) -> [WallSlot] {
        let x = min(3, max(0, Int((targetOrigin.x / 2).rounded())))
        let y = min(1, max(0, Int((targetOrigin.y / 2).rounded())))
        return expansion(phase: phase(column: column, row: row), selected: expanded, origin: y * 4 + x)
    }
    #endif
}
