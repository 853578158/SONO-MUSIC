import Foundation
import Combine

enum LyricTimeSource: String, Codable, Sendable { case explicit, inferred }
struct LyricWord: Codable, Sendable {
    var text: String; var start: Double; var end: Double; var timed: Bool = false
    var emphasis: Bool?; var endSource: LyricTimeSource?
}
struct LyricLine: Codable, Sendable, Identifiable {
    var id: Int = 0; var start: Double; var end: Double; var words: [LyricWord]
    var translation = ""; var romanization = ""; var voice = ""; var background = false
    var endSource: LyricTimeSource?
    var text: String { words.map(\.text).joined() }
}
struct LyricDocument: Codable, Sendable {
    var lines: [LyricLine] = []; var plain = ""; var instrumental = false
    var wordTimed: Bool { lines.contains { $0.words.contains { $0.timed && $0.end > $0.start } } }
}
enum LyricsParser {
    static let cacheVersion = 2
    // Netease v1 mixes JSON credit records into LRC. They are metadata even
    // when the response contains no timestamped lyrics at all.
    private struct Credit: Decodable {
        let t: Double?; let c: [Part]
        struct Part: Decodable { let tx: String }
    }
    static let formats = ["ttml", "krc", "lys", "yrc", "qrc", "eslrc", "lrc"]
    static func matches(_ pattern: String, _ text: String) -> [[String]] {
        guard let re = try? NSRegularExpression(pattern: pattern) else { return [] }
        let ns = text as NSString
        return re.matches(in: text, range: NSRange(location: 0, length: ns.length)).map { m in (0..<m.numberOfRanges).map { m.range(at: $0).location == NSNotFound ? "" : ns.substring(with: m.range(at: $0)) } }
    }
    static func time(_ text: String) -> Double {
        if text.hasSuffix("ms") { return (Double(text.dropLast(2)) ?? 0) / 1000 }
        if text.hasSuffix("s") { return Double(text.dropLast()) ?? 0 }
        return text.split(separator: ":").reduce(0) { $0 * 60 + (Double($1) ?? 0) }
    }
    static func parse(_ text: String, format: String) throws -> LyricDocument {
        guard formats.contains(format) else { throw CocoaError(.fileReadUnknown) }
        if format == "ttml" {
            let delegate = TTMLReader(); let parser = XMLParser(data: Data(text.utf8)); parser.shouldProcessNamespaces = true; parser.delegate = delegate
            guard parser.parse() else { throw parser.parserError ?? CocoaError(.fileReadCorruptFile) }
            return finish(delegate.lines, plain: delegate.plain)
        }
        let rows = text.components(separatedBy: .newlines).filter {
            let row = $0.trimmingCharacters(in: .whitespacesAndNewlines)
            return !row.hasPrefix("{") || (try? JSONDecoder().decode(Credit.self, from: Data(row.utf8))) == nil
        }
        let content = rows.joined(separator: "\n")
        var lines: [LyricLine] = []
        let offset = (matches("\\[offset:([+-]?\\d+)\\]", content).first.flatMap { Double($0[1]) } ?? 0) / 1000
        for row in rows {
            if format == "krc" {
                guard let h = matches("^\\[(\\d+),(\\d+)\\]", row).first else { continue }
                let start = Double(h[1])! / 1000, end = start + Double(h[2])! / 1000
                let words = matches("<(\\d+),(\\d+)(?:,\\d+)?>([^<]*)",row).map { p in LyricWord(text:p[3],start:start+Double(p[1])!/1000,end:start+(Double(p[1])!+Double(p[2])!)/1000,timed:true) }
                if !words.isEmpty { lines.append(.init(start:start,end:end,words:words)) }
            } else if format == "yrc" || format == "qrc" {
                guard let h = matches("^\\[(\\d+),(\\d+)\\]", row).first else { continue }
                let start = Double(h[1])! / 1000, end = start + Double(h[2])! / 1000
                let body = String(row.dropFirst(h[0].count))
                let parts = format == "yrc" ? matches("\\((\\d+),(\\d+),[^)]*\\)([^()]*)", body) : matches("([^()]+)\\((\\d+),(\\d+)\\)", body)
                let words = parts.map { p -> LyricWord in
                    let t = Double(p[format == "yrc" ? 1 : 2])! / 1000
                    return LyricWord(text: p[format == "yrc" ? 3 : 1], start: t, end: t + Double(p[format == "yrc" ? 2 : 3])! / 1000, timed:true)
                }
                // YRC/QRC punctuation can have an explicit zero duration. Keep
                // its text without rejecting the surrounding timed lyric line.
                if end > start && !words.isEmpty && words.allSatisfy({ $0.start >= start && $0.end >= $0.start && $0.end <= end + 0.05 }) { lines.append(.init(start: start, end: end, words: words)) }
            } else if format == "lys" {
                let words = matches("([^()]+)\\((\\d+),(\\d+)\\)", row.replacingOccurrences(of: "^\\[\\d+\\]", with: "", options: .regularExpression)).map { p in LyricWord(text: p[1], start: Double(p[2])! / 1000, end: (Double(p[2])! + Double(p[3])!) / 1000, timed:true) }
                if let first = words.first, let last = words.last { lines.append(.init(start: first.start, end: last.end, words: words)) }
            } else {
                let tags = matches("\\[(\\d+:\\d+(?:[.:]\\d+)?)\\]", row)
                let body = row.replacingOccurrences(of: "\\[[^]]*\\]", with: "", options: .regularExpression)
                let syllables = matches("<(\\d+:\\d+(?:\\.\\d+)?)>([^<]*)", body)
                for tag in tags {
                    let start = time(tag[1]) + offset
                    var words = syllables.map { LyricWord(text: $0[2], start: time($0[1]) + offset, end: 0, timed:true, endSource:.inferred) }
                    for i in words.indices { words[i].end = i + 1 < words.count ? words[i+1].start : words[i].start + 1 }
                    if words.isEmpty { words = [.init(text: body, start: start, end: start)] }
                    if !body.isEmpty { lines.append(.init(start: start, end: 0, words: words)) }
                }
            }
        }
        let plain = content.replacingOccurrences(of: "(?m)^\\s*\\[[A-Za-z]+:[^\\]\\r\\n]*\\]\\s*$", with: "", options: .regularExpression).trimmingCharacters(in: .whitespacesAndNewlines)
        if format == "krc", let encoded=matches("\\[language:([^\\]]+)\\]",text).first?[1], let data=Data(base64Encoded:encoded),let obj=try? OnlineJSON(data:data) {
            for track in obj["content"].array {
                let values=track["lyricContent"].array
                for i in lines.indices where i < values.count { let value=values[i].array.map(\.string).joined(); if track["type"].int == 0 { lines[i].romanization=value } else if track["type"].int == 1 { lines[i].translation=value } }
            }
        }
        return finish(lines, plain: lines.isEmpty && format == "lrc" && matches("\\[\\d+:",content).isEmpty ? plain : "")
    }
    static func finish(_ input: [LyricLine], plain: String) -> LyricDocument {
        var lines = input.filter { $0.start.isFinite && $0.start >= 0 && !$0.text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }.sorted { $0.start < $1.start }
        for i in lines.indices {
            lines[i].id = i
            if lines[i].end <= lines[i].start {
                lines[i].end = i+1 < lines.count ? lines[i+1].start : lines[i].start + 10
                lines[i].endSource = .inferred
            } else if lines[i].endSource == nil { lines[i].endSource = .explicit }
            for j in lines[i].words.indices where lines[i].words[j].timed && lines[i].words[j].endSource == nil {
                lines[i].words[j].endSource = .explicit
            }
            if lines[i].words.count == 1 && !lines[i].words[0].timed { lines[i].words[0].end = lines[i].end }
        }
        return .init(lines: lines, plain: plain, instrumental: !lines.isEmpty && lines.allSatisfy { $0.text.contains("纯音乐") })
    }
}
struct CommunityLyric: Decodable, Identifiable, Sendable {
    let id: Int64; let filename: String; let musicNames: [String]; let artistNames: [String]; let lyrics: String?
}
actor CommunityLyrics {
    enum Failure: LocalizedError {
        case notFound
        var errorDescription: String? { "社区词库尚未收录这份歌词" }
    }
    static let shared = CommunityLyrics()
    private let storage: LyricsCacheStorage
    init(cacheURL: URL? = nil) {
        storage = cacheURL.map { LyricsCacheStorage(directory:$0.deletingLastPathComponent(), communityFilename:$0.lastPathComponent) } ?? .shared
    }
    struct Response<T: Decodable>: Decodable { let data: T }
    struct Search: Decodable { let items: [CommunityLyric]; let pagination: Pagination }
    struct Pagination: Decodable { let hasMore: Bool }
    func get(_ query: [String:String]) async throws -> CommunityLyric { try await request("get", query: query) }
    func search(_ query: String, page: Int) async throws -> Search { try await request("search", query: ["q":query,"page":String(page),"pageSize":"20"]) }
    func netease(_ id: String) async throws -> LyricDocument? { try await platform("ncm",id:id) }
    func platform(_ platform:String,id:String) async throws -> LyricDocument? {
        guard !id.isEmpty, id.allSatisfy({ $0.isASCII && $0.isNumber }) else { throw URLError(.badURL) }
        // The repository's platform index is authoritative for this exact audio
        // version. Use its documented author mirror if GitHub is unavailable.
        let urls = ["https://raw.githubusercontent.com/amll-dev/amll-ttml-db/refs/heads/main/\(platform == "qq" ? "qq-lyrics" : "ncm-lyrics")/\(id).ttml",
                    "https://amll-ttml-db.stevexmh.net/\(platform)/\(id)"]
        for (index, url) in urls.enumerated() {
            if let cached = await storage.communityRecord(url), Date().timeIntervalSince(cached.date) < 3600 {
                return try LyricsParser.parse(String(decoding: cached.data, as: UTF8.self), format: "ttml")
            }
            do {
                var request = URLRequest(url: URL(string: url)!); request.timeoutInterval = 10
                let (data, response) = try await PerformanceEnvironment.networkSession.data(for: request)
                try Task.checkCancellation()
                if (response as? HTTPURLResponse)?.statusCode == 404 { return nil }
                guard (response as? HTTPURLResponse)?.statusCode == 200,
                      let text = String(data: data, encoding: .utf8) else { throw URLError(.badServerResponse) }
                let document = try LyricsParser.parse(text, format: "ttml")
                guard !document.lines.isEmpty else { throw CocoaError(.fileReadCorruptFile) }
                try await storage.setCommunity(.init(date:Date(),data:data),for:url)
                return document
            } catch {
                guard !Task.isCancelled else { throw CancellationError() }
                if index == urls.count - 1 {
                    if let cached = await staleRecord(urls) {
                        return try LyricsParser.parse(String(decoding: cached.data, as: UTF8.self), format: "ttml")
                    }
                    throw error
                }
            }
        }
        return nil
    }
    private func staleRecord(_ urls:[String]) async -> LyricsCacheStorage.CommunityRecord? {
        for url in urls { if let record = await storage.communityRecord(url) { return record } }
        return nil
    }
    private func request<T: Decodable>(_ path: String, query: [String:String]) async throws -> T {
        var url = URLComponents(string: "https://api.amll.dev/v1/lyrics/" + path)!
        url.queryItems = query.map { URLQueryItem(name: $0.key, value: $0.value) }
        let key = url.url!.absoluteString
        if let cached = await storage.communityRecord(key), query["id"] != nil || Date().timeIntervalSince(cached.date) < 3600 {
            return try JSONDecoder().decode(Response<T>.self,from:cached.data).data
        }
        do {
            let (data, response) = try await PerformanceEnvironment.networkSession.data(from: url.url!)
            try Task.checkCancellation()
            if (response as? HTTPURLResponse)?.statusCode == 404 { throw Failure.notFound }
            guard (response as? HTTPURLResponse)?.statusCode == 200 else { throw URLError(.badServerResponse) }
            let result = try JSONDecoder().decode(Response<T>.self, from: data).data
            try await storage.setCommunity(.init(date:Date(),data:data),for:key)
            return result
        } catch {
            guard !Task.isCancelled else { throw CancellationError() }
            if let cached = await storage.communityRecord(key) { return try JSONDecoder().decode(Response<T>.self,from:cached.data).data }
            throw error
        }
    }
}
@MainActor final class LyricsState: ObservableObject {
    @Published var document = LyricDocument() { didSet { documentRevision &+= 1 } }
    private(set) var documentRevision: UInt64 = 0; @Published var status = ""; @Published var source = ""; @Published var error: String?
    let community = CommunityLyrics.shared
    let providers = LyricProviders()
    @Published var automatic = PerformanceEnvironment.defaults.object(forKey:"lyrics.auto") as? Bool ?? true { didSet { PerformanceEnvironment.defaults.set(automatic,forKey:"lyrics.auto") } }
    @Published var preferred = LyricSource(rawValue:PerformanceEnvironment.defaults.string(forKey:"lyrics.preferred") ?? "qq") ?? .qq { didSet { PerformanceEnvironment.defaults.set(preferred.rawValue,forKey:"lyrics.preferred") } }
    private var task: Task<Void,Never>?; private var trackID: String?
    private var generation = UUID()
    private struct Saved: Codable, Sendable { var text: String; var format: String; var source: String; var translation: String?; var romanization: String?; var snapshot: LyricDocument? }
    private var saved: [String:Saved] = [:]
    private let storage = LyricsCacheStorage.shared
    private var preparation: LyricsState?
    private var preparationID: String?
    private var requestAccountRevision: UUID?
    private var preparationTask: Task<Void,Never>?

    /// Prepares one target through the same resolver, without publishing into the visible state.
    func prepare(_ track:LocalTrack, online:OnlineSession) {
        guard track.id != trackID, !(preparationID == track.id && preparation?.automatic == automatic && preparation?.preferred == preferred && preparation?.requestAccountRevision == online.lyricsPreparationRevision) else { return }
        cancelPreparation()
        let staged = LyricsState(); staged.automatic = automatic; staged.preferred = preferred
        preparation = staged; preparationID = track.id
        staged.load(track,online:online)
        preparationTask = Task { [weak self, weak staged] in
            await staged?.task?.value
            guard let self, self.preparation === staged, !Task.isCancelled else { return }
            self.preparationTask = nil
        }
    }
    func cancelPreparation() {
        preparationTask?.cancel(); preparationTask = nil
        preparation?.stop(); preparation = nil; preparationID = nil
    }

    #if DEBUG
    var validationPreparationID: String? { preparationID }
    #endif
    private var localVersion: String?
    private let url: URL
    init() {
        url = FolderStore().url.deletingLastPathComponent().appendingPathComponent("lyrics-state-v1.json")

    }
    func load(_ track: LocalTrack?, online: OnlineSession) {
        if trackID == track?.id { return }; generation = UUID(); task?.cancel(); error = nil; trackID = track?.id; document = .init(); source = ""; status = ""
        guard let track else { cancelPreparation(); status = "选择一首音乐"; return }
        let token = generation
        let accountRevision = online.lyricsPreparationRevision; requestAccountRevision = accountRevision
        let preparedState = preparationID == track.id && preparation?.automatic == automatic && preparation?.preferred == preferred && preparation?.requestAccountRevision == accountRevision ? preparation : nil
        if preparedState != nil {
            // Transfer ownership synchronously. Queue commit may immediately warm
            // another target; that new slot must not own this foreground resolver.
            preparationTask?.cancel(); preparationTask = nil
            preparation = nil; preparationID = nil
        } else { cancelPreparation() }
        task = Task {
            @MainActor func checkRequest() throws {
                try Task.checkCancellation()
                guard generation == token, online.lyricsPreparationRevision == accountRevision else { throw CancellationError() }
            }
            defer {
                if Task.isCancelled { preparedState?.stop() }
            }
            do {
                let version = track.online == nil ? await LyricsParsingWorker.shared.version(track) : nil
                try checkRequest()
                localVersion = version
                let staged = preparedState.flatMap { track.online != nil || $0.localVersion == version ? $0 : nil }
                if preparedState != nil && staged == nil { preparedState?.stop() }
                if let staged {
                    @MainActor func publish() {
                        guard generation == token, online.lyricsPreparationRevision == accountRevision else { return }
                        saved.merge(staged.saved) { current,_ in current }
                        document = staged.document; source = staged.source; status = staged.status; error = staged.error
                    }
                    publish()
                    let delivery = staged.objectWillChange.sink { [weak self, weak staged] _ in
                        Task { @MainActor in
                            guard let self, let staged, self.generation == token, online.lyricsPreparationRevision == accountRevision else { return }
                            self.document = staged.document; self.source = staged.source; self.status = staged.status; self.error = staged.error
                        }
                    }
                    defer { delivery.cancel() }
                    await withTaskCancellationHandler { await staged.task?.value } onCancel: {
                        Task { @MainActor in staged.stop() }
                    }
                    try checkRequest()
                    guard trackID == track.id else { return }
                    saved.merge(staged.saved) { current,_ in current }
                    document = staged.document; source = staged.source; status = staged.status; error = staged.error
                    return
                }
                if let stored = try await storage.read([String:Saved].self,at:url) { saved.merge(stored) { current,_ in current } }
                try checkRequest()
                let cached = await storage.automaticRecord(track.id)
                try checkRequest()
                let cacheValid = cached.map { $0.parserVersion == LyricsParser.cacheVersion && $0.preference == preferred && (track.online != nil || $0.localVersion == version) && Date().timeIntervalSince($0.date) < ($0.document?.wordTimed == true ? 604800 : 900) } ?? false
                if let record = saved[track.id], record.snapshot != nil || !record.text.isEmpty { let selectedDocument:LyricDocument
                    if let snapshot = record.snapshot { selectedDocument = snapshot } else { selectedDocument = try await LyricsParsingWorker.shared.parse(record.text,format:record.format) }
                    try checkRequest(); document = selectedDocument; applyAuxiliary(record.translation, romanization:record.romanization); source = record.source; status = document.instrumental ? "纯音乐，请欣赏" : ""; return }
                if automatic, track.online != nil, cacheValid, let cached, let doc = cached.document {
                    document = doc; source = cached.source
                    if let record = saved[track.id] { applyAuxiliary(record.translation,romanization:record.romanization) }
                    status = document.instrumental ? "纯音乐，请欣赏" : document.lines.isEmpty && document.plain.isEmpty ? "暂无歌词" : ""
                    return
                }
                status = "正在加载歌词…"
                var hadProviderFailure=false
                if let info = track.online, info.platform == .qq {
                    if let id = info.numericSongID {
                        do {
                            let candidate = LyricCandidate(
                                source: .qq, key: id, title: track.title, artist: track.artist,
                                album: track.album, duration: track.duration
                            )
                            let lyrics = try await providers.fetch(candidate, online: online)
                            try checkRequest()
                            document = lyrics
                            source = LyricSource.qq.title
                        } catch {
                            guard !Task.isCancelled, generation == token,
                                  online.lyricsPreparationRevision == accountRevision else { return }
                            hadProviderFailure = true
                            self.error = "QQ 音乐歌词加载失败：" + error.localizedDescription
                        }
                    }
                } else if let info = track.online {
                    do {
                        let payload = try await online.lyrics(info.songID)
                        try checkRequest()
                        let yrc = payload["yrc"]["lyric"].string, lrc = payload["lrc"]["lyric"].string
                        let parsedYRC = try await LyricsParsingWorker.shared.parse(yrc,format:"yrc")
                        let nativeDocument = parsedYRC.wordTimed ? parsedYRC : try await LyricsParsingWorker.shared.parse(lrc,format:"lrc")
                        try checkRequest(); document = nativeDocument
                        if payload["nolyric"].bool || payload["pureMusic"].bool { document = .init(instrumental:true) }
                        applyAuxiliary(payload[document.wordTimed ? "ytlrc" : "tlyric"]["lyric"].string,
                                       romanization:payload[document.wordTimed ? "yromalrc" : "romalrc"]["lyric"].string)
                        source = "网易云"; status = ""
                    } catch {
                        guard !Task.isCancelled, generation == token, online.lyricsPreparationRevision == accountRevision else { return }
                        hadProviderFailure = true
                        self.error = "网易云歌词加载失败：" + error.localizedDescription
                    }
                } else {
                    let local = try await LyricsParsingWorker.shared.local(track)
                    try checkRequest()
                    document = local.document; source = "本地歌词"; error = local.error

                }
                status = document.instrumental ? "纯音乐，请欣赏" : document.lines.isEmpty && document.plain.isEmpty ? "正在寻找逐字歌词…" : ""
                if automatic, cacheValid, let cached, let doc=cached.document { document=doc; source=cached.source }
                var qqCandidates:[LyricCandidate]=[]
                var neteaseCandidates:[LyricCandidate]=[]
                if automatic && !document.instrumental && !cacheValid {
                    let order = [preferred] + [LyricSource.netease,.amll,.qq,.kugou].filter { $0 != preferred }
                    for provider in order {
                        try checkRequest()
                        if document.wordTimed && source == provider.title { break }
                        if provider == .amll {
                            do {
                                if let info = track.online, info.platform == .netease, let doc=try await community.netease(info.songID), doc.wordTimed { try checkRequest(); document=doc; source=provider.title; break }
                                for candidate in neteaseCandidates { if let doc=try await community.netease(candidate.key),doc.wordTimed { try checkRequest(); document=doc; source=provider.title; break } }
                                for candidate in qqCandidates { if let doc=try await providers.amllQQ(candidate),doc.wordTimed { try checkRequest(); document=doc; source=provider.title; break } }
                            } catch { if Task.isCancelled || generation != token || online.lyricsPreparationRevision != accountRevision { return }; hadProviderFailure=true }
                            try checkRequest()
                            if document.wordTimed { break }
                            continue
                        }
                        do {
                            let candidates = try await providers.search(provider,query:track.title+" "+track.artist,page:1,track:track,online:online)
                            if provider == .netease { neteaseCandidates=Array(candidates.filter { $0.reliable(for:track) }.prefix(3)) }
                            if provider == .qq { qqCandidates=Array(candidates.filter { $0.reliable(for:track) }.prefix(3)) }
                            for candidate in candidates.filter({ $0.reliable(for:track) }).prefix(3) {
                                let result = try await providers.fetch(candidate,online:online)
                                try checkRequest()
                                if result.wordTimed { document=result; source=provider.title; error=nil; break }
                            }
                            if document.wordTimed { break }
                        } catch { if Task.isCancelled || generation != token || online.lyricsPreparationRevision != accountRevision { return }; hadProviderFailure=true }
                    }
                }
                if automatic && !cacheValid && (!hadProviderFailure || document.wordTimed) {
                    try checkRequest()
                    do { try await storage.setAutomatic(.init(date:Date(),document:document,source:source,preference:preferred,parserVersion:LyricsParser.cacheVersion,localVersion:version),for:track.id) }
                    catch { if Task.isCancelled || generation != token || online.lyricsPreparationRevision != accountRevision { return }; self.error="歌词缓存保存失败："+error.localizedDescription }

                }
                try checkRequest()
                if let record=saved[track.id] { applyAuxiliary(record.translation,romanization:record.romanization) }
                status = document.instrumental ? "纯音乐，请欣赏" : document.lines.isEmpty && document.plain.isEmpty ? "暂无歌词" : ""
            } catch is CancellationError { } catch { guard !Task.isCancelled, generation == token, online.lyricsPreparationRevision == accountRevision else { return }; status = "歌词加载失败"; self.error = error.localizedDescription }
        }
    }
    func select(text: String, format: String, source: String, track: LocalTrack) throws {
        let parsed = try LyricsParser.parse(text,format:format)
        guard !parsed.lines.isEmpty || !parsed.plain.isEmpty else { throw CocoaError(.fileReadCorruptFile) }
        generation = UUID(); cancelPreparation(); task?.cancel(); saved[track.id] = .init(text:text,format:format,source:source)
        try persist(for:track.id); document = parsed; self.source = source; status = ""
    }
    func reset(_ track: LocalTrack, online: OnlineSession) throws {
        generation = UUID(); saved[track.id] = nil; cancelPreparation(); task?.cancel(); trackID = nil
        let resetGeneration = generation
        Task {
            do {
                try await storage.updateManual(Optional<Saved>.none,for:track.id,at:url)
                try await storage.setAutomatic(nil,for:track.id)
                guard generation == resetGeneration else { return }
                load(track,online:online)
            } catch { self.error=error.localizedDescription }
        }
    }

    private func persist(for trackID:String) throws {
        let record = saved[trackID]
        Task {
            do { try await storage.updateManual(record,for:trackID,at:url) }
            catch { self.error = "歌词记录保存失败：" + error.localizedDescription }
        }
    }
    func auxiliary(text:String, romanization:Bool, track:LocalTrack) throws {
        let token = generation
        Task {
            do {
                let stored = try await storage.read([String:Saved].self,at:url)
                guard generation == token, trackID == track.id else { return }
                var record = saved[track.id] ?? stored?[track.id] ?? Saved(text:"",format:"lrc",source:source)
                if romanization { record.romanization = text } else { record.translation = text }
                saved[track.id] = record
                applyAuxiliary(record.translation,romanization:record.romanization)
                try await storage.updateManual(record,for:track.id,at:url)
            } catch { self.error = "歌词记录保存失败：" + error.localizedDescription }
        }
    }
    private func applyAuxiliary(_ translation:String?, romanization:String?) {
        var updated = document
        for (text,roman) in [(translation,false),(romanization,true)] {
            guard let text, let parsed = try? LyricsParser.parse(text,format:"lrc") else { continue }
            for i in updated.lines.indices {
                let match = parsed.lines.first { abs($0.start-updated.lines[i].start) < 0.2 }?.text ?? ""
                if roman { updated.lines[i].romanization = match } else { updated.lines[i].translation = match }
            }
        }
        document = updated
    }
    func select(document:LyricDocument, source:String, track:LocalTrack) throws {
        generation = UUID(); cancelPreparation(); task?.cancel(); saved[track.id] = .init(text:"",format:"lrc",source:source,snapshot:document)
        try persist(for:track.id); self.document=document; self.source=source; status=""; error=nil
    }
    func stop() { generation = UUID(); task?.cancel(); trackID=nil; cancelPreparation() }
}
