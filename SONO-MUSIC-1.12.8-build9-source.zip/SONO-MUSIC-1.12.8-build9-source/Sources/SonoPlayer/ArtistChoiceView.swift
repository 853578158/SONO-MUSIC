import AppKit
import SwiftUI

struct ArtistChoiceView: NSViewRepresentable {
    let track: LocalTrack
    let online: OnlineSession
    let scale: CGFloat
    let showTitle: Bool
    let reduced: Bool
    let closing: Bool
    let close: () -> Void
    let select: (OnlineArtist) -> Void

    func makeNSView(context: Context) -> ArtistChoicePanel { ArtistChoicePanel() }
    func updateNSView(_ view: ArtistChoicePanel, context: Context) {
        view.reduced = reduced; view.onClose = close; view.radius = 8 * scale
        view.host.rootView = AnyView(ArtistChoiceContent(track: track, online: online, scale: scale, showTitle: showTitle, close: { [weak view] in view?.dismiss() }, select: select))
        if closing { view.dismiss() }
    }
}

@MainActor
final class ArtistChoicePanel: NSView {
    let host = NSHostingView(rootView: AnyView(EmptyView()))
    var reduced = false
    var radius: CGFloat = 8
    var onClose: () -> Void = {}
    private var opened = false, closing = false
    override var acceptsFirstResponder: Bool { true }
    override var isFlipped: Bool { true }
    override init(frame frameRect: NSRect) {
        super.init(frame: frameRect)
        wantsLayer = true; host.wantsLayer = true; addSubview(host)
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    override func layout() {
        super.layout(); host.frame = bounds
        CATransaction.begin(); CATransaction.setDisableActions(true)
        layer?.anchorPoint = CGPoint(x: 0.5, y: 0.5); layer?.position = CGPoint(x: frame.midX, y: frame.midY)
        layer?.cornerRadius = radius; layer?.masksToBounds = true
        CATransaction.commit()
    }
    override func viewDidMoveToWindow() {
        super.viewDidMoveToWindow()
        guard window != nil, !opened else { return }; opened = true
        window?.makeFirstResponder(self)
        animate(leaving: false)
    }
    override func keyDown(with event: NSEvent) {
        if event.keyCode == 53 { dismiss() } else { super.keyDown(with: event) }
    }
    func dismiss() {
        guard !closing else { return }; closing = true
        animate(leaving: true)
    }
    private func animate(leaving: Bool) {
        guard !reduced, let layer, let surface = host.layer else { if leaving { onClose() }; return }
        CATransaction.begin(); CATransaction.setDisableActions(true)
        if leaving { CATransaction.setCompletionBlock { [weak self] in self?.onClose() } }
        let transform = CABasicAnimation(keyPath: "transform.scale")
        transform.fromValue = leaving ? (layer.presentation()?.transform.m11 ?? 1) : 0.2
        transform.toValue = leaving ? 0.2 : 1
        transform.duration = 0.46
        transform.timingFunction = leaving ? CAMediaTimingFunction(controlPoints: 0.7, 0, 0.84, 0) : CAMediaTimingFunction(controlPoints: 0.16, 1, 0.3, 1)
        transform.fillMode = .both; transform.isRemovedOnCompletion = !leaving
        layer.add(transform, forKey: "choice.scale")
        let opacity = CABasicAnimation(keyPath: "opacity")
        opacity.fromValue = leaving ? (layer.presentation()?.opacity ?? 1) : 0
        opacity.toValue = leaving ? 0 : 1; opacity.duration = 0.46; opacity.timingFunction = transform.timingFunction
        opacity.fillMode = .both; opacity.isRemovedOnCompletion = !leaving
        layer.add(opacity, forKey: "choice.opacity")
        let mask = CAKeyframeAnimation(keyPath: "opacity")
        mask.values = SonoCoverMask.values(showing: !leaving); mask.duration = 1
        mask.calculationMode = .linear; mask.fillMode = .both; mask.isRemovedOnCompletion = !leaving
        surface.add(mask, forKey: "choice.mask")
        CATransaction.commit()
    }
}

private struct ArtistChoiceContent: View {
    let track: LocalTrack
    let online: OnlineSession
    let scale: CGFloat
    let showTitle: Bool
    let close: () -> Void
    let select: (OnlineArtist) -> Void
    var body: some View {
        GeometryReader { proxy in
            ZStack(alignment: .topLeading) {
                Color(nsColor: SonoGeneratedColors.artistPanel)
                if showTitle {
                    Text(track.title).font(SonoTypography.font(size: SonoDesktopTokens.FontSize.itemTitle, weight: SonoDesktopTokens.FontWeight.semibold)).lineLimit(1)
                        .padding(.horizontal, SonoDesktopTokens.Spacing.s28 * scale).padding(.top, SonoDesktopTokens.Spacing.s28 * scale)
                }
                ScrollView {
                    VStack(spacing: SonoDesktopTokens.Spacing.s12) {
                        ForEach(track.online?.artists ?? []) { artist in
                            ArtistChoiceRow(artist: artist, online: online) { select(artist) }
                        }
                    }.padding(.top, SonoDesktopTokens.Spacing.s12).padding(.horizontal, SonoDesktopTokens.Spacing.s4).padding(.bottom, SonoDesktopTokens.Spacing.s4)
                }.padding(.horizontal, SonoDesktopTokens.Spacing.s28).padding(.bottom, SonoDesktopTokens.Spacing.s28).padding(.top, showTitle ? 28 * scale + 22.4 + 16 : 28)
                Button(action: close) { Image(systemName: "xmark").font(.system(size: SonoDesktopTokens.SymbolSize.control)).sonoIconFrame(SonoDesktopTokens.IconFrame.s24).frame(width: 32, height: 32).background(Color(nsColor: SonoGeneratedColors.artistClose), in: Circle()) }
                    .position(x: proxy.size.width - 28, y: 28).accessibilityLabel("关闭歌手选择")
            }.foregroundStyle(Color(nsColor: SonoGeneratedColors.primaryText)).buttonStyle(.plain).accessibilityElement(children: .contain).accessibilityLabel("选择歌手")
        }
    }
}

private struct ArtistChoiceRow: View {
    let artist: OnlineArtist
    let online: OnlineSession
    let select: () -> Void
    @ViewState private var avatar: URL?
    @ViewState private var hovered = false
    var body: some View {
        Button(action: select) {
            HStack(spacing: SonoDesktopTokens.Spacing.s16) {
                AsyncImage(url: avatar) { image in image.resizable().scaledToFill() } placeholder: {
                    Text(String(artist.name.prefix(1))).frame(maxWidth: .infinity, maxHeight: .infinity).background(Color(nsColor: SonoGeneratedColors.artistPlaceholder))
                }.frame(width: SonoDesktopTokens.Cover.portrait, height: SonoDesktopTokens.Cover.portrait).clipShape(Circle())
                Text(artist.name).font(SonoTypography.font(size: SonoDesktopTokens.FontSize.itemTitle)); Spacer(minLength: 0)
            }.padding(SonoDesktopTokens.Spacing.s8).frame(minHeight: 64).background(hovered ? Color(nsColor: SonoGeneratedColors.artistHover) : Color.clear, in: RoundedRectangle(cornerRadius: 12))
        }.onHover { hovered = $0; ($0 ? NSCursor.pointingHand : .arrow).set() }.accessibilityLabel("查看歌手：" + artist.name)
            .task(id: artist.id) { avatar = await online.artistAvatar(artist.id) }
    }
}
