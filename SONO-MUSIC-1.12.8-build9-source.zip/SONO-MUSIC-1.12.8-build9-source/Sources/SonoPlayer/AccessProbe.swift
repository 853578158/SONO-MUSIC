#if !SONO_RELEASE_CANDIDATE
import Foundation

// A non-UI, read-only diagnostic used to prove sandbox isolation in a fresh
// process. Opening a write handle tests the grant without changing file bytes.
enum AccessProbe {
    static func run(arguments: [String]) {
        guard arguments.count >= 3 else { print("Usage: --verify-access FILE [--restore-bookmarks]"); return }
        let url = URL(fileURLWithPath: arguments[2])
        var leases: [FolderAccess] = []
        var errors: [String] = []
        if arguments.contains("--restore-bookmarks") {
            do {
                for record in try FolderStore().load() {
                    do { leases.append(try FolderStore.resolve(record)) }
                    catch { errors.append(error.localizedDescription) }
                }
            } catch { errors.append(error.localizedDescription) }
        }
        withExtendedLifetime(leases) {
            var read = false, write = false
            var readError: Int?
            do { _ = try Data(contentsOf: url); read = true }
            catch { readError = (error as NSError).code }
            do { let handle = try FileHandle(forWritingTo: url); try handle.close(); write = true }
            catch { }
            let result: [String: Any] = ["file": url.lastPathComponent, "read": read, "writeHandle": write,
                                        "restoredLeases": leases.count, "readErrorCode": readError as Any? ?? NSNull(),
                                        "bookmarkErrors": errors, "home": NSHomeDirectory()]
            if let data = try? JSONSerialization.data(withJSONObject: result, options: [.sortedKeys]), let string = String(data: data, encoding: .utf8) { print(string) }
        }
    }
}
#endif
