import AppKit
import QuartzCore

/// Correlation only: one current switch, no retained song metadata or per-frame history.
/// Samples and events use the existing opt-in, bounded BrowseDiagnostics collector.
final class LyricsPerformanceDiagnostics: @unchecked Sendable {
    static let shared = LyricsPerformanceDiagnostics()
    struct Switch: Sendable {
        let track: String
        let generation: UInt64
        let started: CFTimeInterval
        var fields: [String: String] { ["track": track, "switchGeneration": String(generation)] }
    }
    private let lock = NSLock()
    private var revision: UInt64 = 0
    private var current: Switch?
    private var trackID: String?
    private var coverID: String?
    private var preparedImages = Set<ObjectIdentifier>()
    private var reached = Set<String>()

    @discardableResult func begin(_ track: LocalTrack, source: String) -> Switch? {
        guard BrowseDiagnostics.shared.enabled else { return nil }
        let anonymous = BrowseDiagnostics.shared.resourceID(track.id)
        let nextCoverID = track.coverURL.map(ArtworkResource.identity)
        let token = lock.withLock { () -> Switch in
            revision &+= 1
            let token = Switch(track: anonymous, generation: revision, started: CACurrentMediaTime())
            if coverID != nextCoverID { preparedImages = [] }
            current = token; trackID = track.id; coverID = nextCoverID; reached = []
            return token
        }
        BrowseDiagnostics.shared.mark("playback.switchIntent", fields: token.fields.merging(["source": source]) { _, new in new })
        if lock.withLock({ !preparedImages.isEmpty }) {
            milestone("coverPreparedCPU", token:token, fields:["availability":"already prepared at intent"], at:token.started)
        }
        return token
    }
    func attempt(_ track: LocalTrack) -> Switch? {
        guard BrowseDiagnostics.shared.enabled else { return nil }
        if let token = lock.withLock({ trackID == track.id && !reached.contains("audioCommitted") ? current : nil }) { return token }
        return begin(track, source: "playback.directOrRecoveryCandidate")
    }
    func token(for trackID: String?) -> Switch? {
        guard BrowseDiagnostics.shared.enabled else { return nil }
        return lock.withLock { self.trackID == trackID ? current : nil }
    }
    func token(for analysis: LyricsArtworkAnalysis?) -> Switch? {
        guard BrowseDiagnostics.shared.enabled, let analysis else { return nil }
        return lock.withLock { preparedImages.contains(ObjectIdentifier(analysis.thumbnail)) ? current : nil }
    }
    func prepared(_ url: URL?, analysis: LyricsArtworkAnalysis?) {
        guard BrowseDiagnostics.shared.enabled, let analysis else { return }
        let identity = url.map(ArtworkResource.identity)
        let token = lock.withLock { () -> Switch? in
            guard current != nil, coverID == identity else { return nil }
            preparedImages = [ObjectIdentifier(analysis.thumbnail)]
            return current
        }
        milestone("coverPreparedCPU", token: token)
    }
    /// Submission and readiness labels deliberately do not imply visible screen pixels.
    func milestone(_ name: String, token: Switch?, fields: [String: String] = [:], at time: CFTimeInterval = CACurrentMediaTime()) {
        guard BrowseDiagnostics.shared.enabled, let token else { return }
        let accepted = lock.withLock { () -> Bool in
            guard current?.generation == token.generation else { return false }
            return reached.insert(name).inserted
        }
        guard accepted else { return }
        BrowseDiagnostics.shared.record("switch.intentTo.\(name)", max(0, time - token.started) * 1000)
        BrowseDiagnostics.shared.mark("switch.\(name)", fields: token.fields.merging(fields) { _, new in new })
    }
    func outcome(_ name: String, token: Switch?) {
        guard BrowseDiagnostics.shared.enabled, let token else { return }
        BrowseDiagnostics.shared.mark("playback.\(name)", fields: token.fields)
    }
    func handleCreated() {
        guard BrowseDiagnostics.shared.enabled else { return }
        BrowseDiagnostics.shared.count("audio.handlesCreatedDuringCapture")
    }
    func handleDestroyed() {
        guard BrowseDiagnostics.shared.enabled else { return }
        BrowseDiagnostics.shared.count("audio.handlesDestroyedDuringCapture")
    }
}
