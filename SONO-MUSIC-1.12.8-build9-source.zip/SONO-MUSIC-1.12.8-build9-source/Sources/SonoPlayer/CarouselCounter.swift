import AppKit

@MainActor
final class CarouselCounter: NSButton {
    static let rowHeight = SonoDesktopTokens.Spacing.s16
    let text = CATextLayer()
    private let symbol = CALayer()
    private let symbolSize: CGSize
    private var hovered = false
    private var pointerTracking: NSTrackingArea?
    private var lastUpdate: (value: String, x: CGFloat, top: CGFloat, scale: CGFloat)?
    var openList: () -> Void = {}
    private var visible: Bool {
        guard let layer else { return false }
        return !isHidden && !layer.isHidden && (layer.presentation() ?? layer).opacity > 0.05
    }
    override var isFlipped: Bool { true }
    override init(frame: NSRect) {
        let image = NSImage(systemSymbolName: "line.3.horizontal.decrease", accessibilityDescription: nil)!
            .withSymbolConfiguration(NSImage.SymbolConfiguration(pointSize: SonoDesktopTokens.SymbolSize.micro, weight: SonoDesktopTokens.NativeFontWeight.regular))!
        symbolSize = image.size
        super.init(frame: frame)
        wantsLayer = true; isBordered = false; title = ""
        target = self; action = #selector(activate)
        setAccessibilityRole(.button); setAccessibilityLabel("快速列表"); toolTip = "快速列表"
        let mask = CALayer()
        mask.contents = image.cgImage(forProposedRect: nil, context: nil, hints: nil)
        mask.frame = CGRect(origin: .zero, size: symbolSize)
        symbol.mask = mask
        // CATextLayer can redraw its backing contents after the update transaction.
        text.actions = ["contents": NSNull()]
        layer?.addSublayer(symbol); layer?.addSublayer(text)
        updateInk()
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    func update(_ value: String, centeredAt x: CGFloat, top: CGFloat, scale: CGFloat) {
        if let previous = lastUpdate, previous.value == value, previous.x == x,
           previous.top == top, previous.scale == scale { return }
        lastUpdate = (value, x, top, scale)
        CATransaction.begin(); CATransaction.setDisableActions(true)
        defer { CATransaction.commit() }
        let width = ceil(SonoTypography.width(value, size: SonoDesktopTokens.FontSize.caption))
        let total = symbolSize.width + 8 + width
        frame = CGRect(x: x - total / 2, y: top, width: total, height: Self.rowHeight)
        symbol.frame = CGRect(x: 0, y: (Self.rowHeight - symbolSize.height) / 2, width: symbolSize.width, height: symbolSize.height)
        symbol.contentsScale = scale
        text.contentsScale = scale; text.alignmentMode = .center; text.truncationMode = .end
        let font = SonoTypography.native(size: SonoDesktopTokens.FontSize.caption)
        text.font = font; text.fontSize = SonoDesktopTokens.FontSize.caption
        text.string = value
        // Center the digits' cap height on the symbol, rather than aligning
        // their unequal font and image canvases.
        let textY = (Self.rowHeight + CTFontGetCapHeight(font)) / 2 - CTFontGetAscent(font)
        text.frame = CGRect(x: symbolSize.width + 8, y: textY, width: width, height: Self.rowHeight)
    }
    override func viewDidChangeEffectiveAppearance() { super.viewDidChangeEffectiveAppearance(); updateInk() }
    private func updateInk() {
        CATransaction.begin(); CATransaction.setDisableActions(true)
        let color = (hovered ? SonoGeneratedColors.primaryText : SonoGeneratedColors.queueSecondary).sonoCGColor(in: effectiveAppearance)
        symbol.backgroundColor = color; text.foregroundColor = color
        CATransaction.commit()
    }
    func containsPointer(_ point: CGPoint) -> Bool { visible && frame.contains(point) }
    func setHovered(_ value: Bool) {
        if hovered != value { hovered = value; updateInk() }
        if value { NSCursor.pointingHand.set() }
    }
    override func hitTest(_ point: NSPoint) -> NSView? { visible ? super.hitTest(point) : nil }
    override func isAccessibilityElement() -> Bool { visible }
    override func resetCursorRects() { if visible { addCursorRect(bounds, cursor: .pointingHand) } }
    override func updateTrackingAreas() {
        super.updateTrackingAreas()
        if let pointerTracking { removeTrackingArea(pointerTracking) }
        let tracking = NSTrackingArea(rect: bounds, options: [.activeInKeyWindow, .mouseEnteredAndExited, .mouseMoved, .cursorUpdate], owner: self)
        addTrackingArea(tracking); pointerTracking = tracking
    }
    override func mouseEntered(with event: NSEvent) { if visible { setHovered(true) } }
    override func mouseMoved(with event: NSEvent) { if visible { setHovered(true) } }
    override func cursorUpdate(with event: NSEvent) { if visible { NSCursor.pointingHand.set() } }
    override func mouseExited(with event: NSEvent) { setHovered(false) }
    @objc private func activate() { if visible { openList() } }
}
