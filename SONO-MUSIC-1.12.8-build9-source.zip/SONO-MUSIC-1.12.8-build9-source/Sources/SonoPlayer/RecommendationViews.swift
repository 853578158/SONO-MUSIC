import SwiftUI

struct PersonalFMModePicker: View {
    @Environment(\.sonoTheme) private var theme
    @ObservedObject var session: PlayerSession
    var body: some View {
        VStack(spacing: SonoDesktopTokens.Spacing.s12) {
            HStack { Text("私人FM · 漫游模式").font(.headline); Spacer(); Button("完成") { session.fmModePickerOpen = false } }
                .padding(.horizontal, SonoDesktopTokens.Spacing.s20).padding(.top, SonoDesktopTokens.Spacing.s20)
            List {
                Section("模式") {
                    ForEach(PersonalFMSelection.Mode.allCases.filter { $0 != .scene }, id: \.self) { mode in
                        choice(mode.title, selection: .init(mode: mode))
                    }
                }
                ForEach(PersonalFMSelection.categories, id: \.self) { category in
                    Section("场景 · " + category) {
                        ForEach(PersonalFMSelection.scenes.filter { $0.category == category }) { scene in
                            choice(scene.title, selection: .init(mode: .scene, scene: scene.id))
                        }
                    }
                }
            }.listStyle(.inset)
        }.frame(width: 380, height: 540)
    }
    private func choice(_ title: String, selection: PersonalFMSelection) -> some View {
        Button { session.startPersonalFM(selection: selection) } label: {
            HStack { Text(title); Spacer(); if session.fm.selection == selection { Image(systemName: "checkmark").foregroundStyle(Color(nsColor: theme.accent)) } }
                .contentShape(Rectangle())
        }.buttonStyle(.plain).padding(.vertical, SonoDesktopTokens.Spacing.s4)
    }
}

private struct RecommendationTitleButtonStyle: ButtonStyle {
    @Environment(\.colorScheme) private var colorScheme
    var selected = false
    var icon = false
    @Environment(\.isEnabled) private var enabled
    @ViewState private var hovered = false
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .foregroundStyle(Color(nsColor: !enabled ? SonoGeneratedColors.interfaceDisabled : icon || selected || hovered ? SonoGeneratedColors.primaryText : SonoGeneratedColors.queueTab))
            .background(icon && enabled ? Color(nsColor: configuration.isPressed ? SonoGeneratedColors.recommendationPressedFill : hovered ? (colorScheme == .light ? SonoGeneratedColors.modeHover : SonoGeneratedColors.modeHoverDark) : SonoGeneratedColors.recommendationControlFill) : Color.clear, in: RoundedRectangle(cornerRadius: 6))
            .contentShape(Rectangle())
            .pointerStyle(enabled && !selected ? .link : .default)
            .onHover { hovered = $0 }
    }
}

struct DailyRecommendationToolbar: View {
    @ObservedObject var online: OnlineSession
    var scale: CGFloat = 1
    var viewport: CGSize = CGSize(width: 1440, height: 900)
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.scenePhase) private var scenePhase
    @ViewState private var clock = Date()
    private var styleSelected: Bool { online.page?.kind == .dailyStyleRecommendations }
    var body: some View {
        let used = online.dailyRefreshUsed(at: clock)
        HStack(alignment: .bottom, spacing: SonoDesktopTokens.Spacing.s0) {
            Button { online.openRecommendations(style: false) } label: { title("默认推荐", selected: !styleSelected) }
            .buttonStyle(RecommendationTitleButtonStyle(selected: !styleSelected))
            .disabled(online.loading || online.dailyRefreshing || online.dailyStyleSaving)
            .accessibilityAddTraits(!styleSelected ? [.isSelected] : [])
            .overlay(alignment: .leading) {
                if !styleSelected {
                    HStack(spacing: SonoDesktopTokens.Spacing.s0) {
                        Button { online.refreshRecommendations() } label: {
                            Image(systemName: used ? "checkmark.arrow.trianglehead.clockwise" : "arrow.trianglehead.clockwise")
                            .font(.system(size: SonoDesktopTokens.SymbolSize.compact * scale, weight: SonoDesktopTokens.FontWeight.medium))
                            .symbolEffect(.rotate, options: .repeating, isActive: online.dailyRefreshing && !reduceMotion)
                            .contentTransition(.symbolEffect(.replace))
                            .sonoIconFrame(SonoDesktopTokens.IconFrame.s20 * scale).frame(width: 24 * scale, height: 24 * scale)
                        }.buttonStyle(RecommendationTitleButtonStyle(icon: true))
                        .disabled(used || online.dailyRefreshing || online.loading || online.authentication != .verified)
                        .accessibilityLabel(used ? "今日已刷新" : "刷新默认推荐")
                    }
                    .sonoTooltip(used ? "已刷新" : "每日可刷新一次")
                    .offset(x: -24 * scale, y: SonoDesktopTokens.Spacing.s4 * scale)
                }
            }
            Button { online.openRecommendations(style: true) } label: { title("风格推荐", selected: styleSelected) }
            .buttonStyle(RecommendationTitleButtonStyle(selected: styleSelected))
            .disabled(online.loading || online.dailyRefreshing || online.dailyStyleSaving || online.authentication != .verified)
            .accessibilityAddTraits(styleSelected ? [.isSelected] : [])
            .overlay(alignment: .trailing) {
                if styleSelected {
                    Button {
                        if online.dailyStylePickerOpen { online.closeDailyStylePicker() }
                        else { online.dailyStylePickerOpen = true }
                    } label: {
                        Image(systemName: online.dailyStylePickerOpen ? "chevron.up" : "chevron.down").font(.system(size: SonoDesktopTokens.SymbolSize.compact * scale, weight: SonoDesktopTokens.FontWeight.medium))
                        .sonoIconFrame(SonoDesktopTokens.IconFrame.s20 * scale).frame(width: 24 * scale, height: 24 * scale)
                    }.buttonStyle(RecommendationTitleButtonStyle(icon: true))
                    .disabled(online.loading || online.dailyStyleSaving || online.authentication != .verified)
                    .accessibilityLabel(online.dailyStylePickerOpen ? "收起推荐风格" : "选择推荐风格")
                    .help(online.dailyStylePickerOpen ? "收起推荐风格" : "选择推荐风格")
                    .offset(x: 24 * scale, y: SonoDesktopTokens.Spacing.s4 * scale)
                }
            }
        }.buttonStyle(RecommendationTitleButtonStyle()).foregroundStyle(Color(nsColor: SonoGeneratedColors.primaryText)).fixedSize()
            .overlay(alignment: .top) {
                if online.dailyStylePickerOpen {
                    DailyStylePicker(online: online)
                        .frame(width: min(544, max(260, viewport.width - 32)), height: min(448, max(260, viewport.height - 180 * scale - 24)))
                        .clipShape(RoundedRectangle(cornerRadius: SonoDesktopTokens.Component.recommendationButton * SonoDesktopTokens.Radius.circle + SonoDesktopTokens.Spacing.s8))
                        .shadow(color: Color(nsColor: SonoGeneratedColors.interfaceBackdrop), radius: 20, y: 8)

                        .offset(y: 44 * scale)
                }
            }
            .animation(reduceMotion ? nil : .easeInOut(duration: 0.2), value: used)
            .accessibilityElement(children: .contain).accessibilityLabel("每日推荐分类")
            .task {
                clock = Date()
                while !Task.isCancelled {
                    let wait = max(1, RecommendationDate.nextRefresh().timeIntervalSinceNow)
                    do { try await Task.sleep(for: .seconds(wait)) } catch { return }
                    clock = Date()
                }
            }
            .onChange(of: scenePhase) { _, phase in if phase == .active { clock = Date() } }
            .onDisappear { online.closeDailyStylePicker() }
    }
    private func title(_ value: String, selected: Bool) -> some View {
        BrowseCategoryTitle(title: value, selected: selected, scale: scale)
    }
}

struct RecommendationChoiceStyle: ButtonStyle {
    @Environment(\.sonoTheme) private var theme
    enum Kind { case category, tag, cancel, confirm }
    let kind: Kind
    var selected = false
    var shape = AnyShape(Capsule())
    @Environment(\.isEnabled) private var enabled
    @Environment(\.colorScheme) private var colorScheme
    @State private var hovered = false

    func makeBody(configuration: Configuration) -> some View {
        let pressed = enabled && configuration.isPressed
        let over = enabled && !selected && hovered
        let accent = kind == .confirm || (kind == .tag && selected)
        let fill: NSColor
        if accent {
            fill = theme.color(pink: pressed ? SonoGeneratedColors.recommendationAccentPressed
                : over ? SonoGeneratedColors.recommendationAccentHover : SonoPalette.accent)
        } else if kind == .category {
            fill = .clear
        } else if pressed {
            fill = SonoGeneratedColors.recommendationPressedFill
        } else if over {
            fill = colorScheme == .light ? SonoGeneratedColors.modeHover : SonoGeneratedColors.modeHoverDark
        } else {
            fill = kind == .tag ? SonoGeneratedColors.recommendationControlFill : .clear
        }

        let foreground: NSColor
        if accent {
            foreground = theme.foreground()
        } else if !enabled {
            foreground = SonoGeneratedColors.interfaceDisabled
        } else if pressed {
            foreground = colorScheme == .light ? SonoGeneratedColors.queuePressedLight : SonoGeneratedColors.queuePressedDark
        } else if selected || over {
            foreground = SonoGeneratedColors.primaryText
        } else {
            foreground = kind == .cancel ? SonoGeneratedColors.queueSecondary : SonoGeneratedColors.queueTab
        }

        return configuration.label
            .foregroundStyle(Color(nsColor: foreground))
            .opacity(accent && !enabled ? 0.65 : 1)
            .background(Color(nsColor: fill), in: shape)
            .pointerStyle(enabled && (!selected || kind == .tag) ? .link : .default)
            .onHover { hovered = $0 }
    }
}

struct DailyStylePicker: View {
    @ObservedObject var online: OnlineSession
    @ViewState private var draft: DailyStyleSelection?
    @ViewState private var activeCategory: String?
    @ViewState private var toast: String?
    private var group: DailyStyleGroup? { online.dailyStyleGroups.first { $0.id == activeCategory } ?? online.dailyStyleGroups.first }
    private var busy: Bool { online.dailyStyleLoading || online.dailyStyleSaving }
    var body: some View {
        VStack(spacing: SonoDesktopTokens.Spacing.s24) {
            Group {
                if online.dailyStyleLoading {
                    Spacer(); ProgressView().accessibilityLabel("正在读取推荐风格"); Spacer()
                } else if online.dailyStyleGroups.isEmpty {
                    Spacer()
                    Text(online.dailyStyleError ?? "暂无可用推荐风格").font(.system(size: SonoDesktopTokens.FontSize.label)).foregroundStyle(Color(nsColor: SonoGeneratedColors.queueSecondary))
                    Button("重试") { Task { await load() } }.buttonStyle(.bordered)
                    Spacer()
                } else {
                    ScrollView(.horizontal) {
                        HStack(spacing: SonoDesktopTokens.Spacing.s24) {
                            ForEach(online.dailyStyleGroups) { category in
                                Button { activeCategory = category.id } label: {
                                    Text(category.name).font(.system(size: SonoDesktopTokens.FontSize.sectionTitle, weight: group?.id == category.id ? SonoDesktopTokens.FontWeight.semibold : SonoDesktopTokens.FontWeight.regular))
                                }.buttonStyle(RecommendationChoiceStyle(kind: .category, selected: group?.id == category.id))
                                .accessibilityAddTraits(group?.id == category.id ? [.isSelected] : [])
                            }
                        }
                    }.scrollIndicators(.never).defaultScrollAnchor(.center, for: .alignment)
                        .fixedSize(horizontal: false, vertical: true)
                    GeometryReader { geometry in
                      ScrollView {
                        LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: SonoDesktopTokens.Spacing.s24), count: geometry.size.width >= 480 ? 5 : 3), spacing: SonoDesktopTokens.Spacing.s24) {
                            ForEach(group?.tags ?? []) { tag in
                                let selected = draft?.categoryID == group?.id && draft?.tagIDs.contains(tag.id) == true
                                Button {
                                    guard let group else { return }
                                    var selection = draft ?? DailyStyleSelection(categoryID: group.id, tagIDs: [])
                                    if selection.toggle(tag.id, in: group.id) { draft = selection }
                                    else { toast = "最多选择 5 种风格" }
                                } label: {
                                    Text(tag.name).font(.system(size: SonoDesktopTokens.FontSize.body)).lineLimit(1).truncationMode(.tail)
                                        .padding(.horizontal, SonoDesktopTokens.Spacing.s8).padding(.vertical, SonoDesktopTokens.Spacing.s8)
                                        .frame(maxWidth: .infinity, minHeight: SonoDesktopTokens.Component.recommendationTag)
                                        .contentShape(Capsule())
                                }.buttonStyle(RecommendationChoiceStyle(kind: .tag, selected: selected))
                                .help(tag.name).accessibilityAddTraits(selected ? [.isSelected] : [])
                            }
                        }.padding(.vertical, SonoDesktopTokens.Spacing.s2)
                      }.scrollIndicators(.never)
                    }
                    if let error = online.dailyStyleError {
                        Text(error).font(.system(size: SonoDesktopTokens.FontSize.caption)).foregroundStyle(Color(nsColor: SonoGeneratedColors.queueSecondary)).lineLimit(3)
                        if online.dailyStyleResponse == nil { Button("重试读取风格") { Task { await load() } }.buttonStyle(.bordered) }
                    }
                }
            }.padding(.horizontal, SonoDesktopTokens.Spacing.s24)
            HStack(spacing: SonoDesktopTokens.Spacing.s24) {
                Button { online.closeDailyStylePicker() } label: {
                    Text("取消")
                        .frame(minWidth: 80, maxWidth: 184, minHeight: SonoDesktopTokens.Component.recommendationButton, maxHeight: SonoDesktopTokens.Component.recommendationButton)
                        .overlay(Capsule().strokeBorder(Color(nsColor: SonoGeneratedColors.interfaceBorder), lineWidth: SonoDesktopTokens.Border.standard))
                        .contentShape(Capsule())
                }.buttonStyle(RecommendationChoiceStyle(kind: .cancel)).keyboardShortcut(.cancelAction)
                Button {
                    if let draft { Task { await online.confirmDailyStyle(draft) } }
                } label: {
                    HStack { if online.dailyStyleSaving { ProgressView().controlSize(.small) }; Text(online.dailyStyleSaving ? "正在确认…" : "确认") }
                        .frame(maxWidth: .infinity, minHeight: SonoDesktopTokens.Component.recommendationButton)
                        .contentShape(Capsule())
                }.buttonStyle(RecommendationChoiceStyle(kind: .confirm))
                    .disabled(busy || online.dailyStyleResponse == nil || !(1...5).contains(draft?.tagIDs.count ?? 0))
            }.font(.system(size: SonoDesktopTokens.FontSize.body)).padding(.horizontal, SonoDesktopTokens.Spacing.s8)
        }.padding(.bottom, SonoDesktopTokens.Spacing.s8).padding(.top, SonoDesktopTokens.Spacing.s36).background(Color(nsColor: SonoGeneratedColors.recommendationPanel)).contentShape(Rectangle())
            .overlay(alignment: .center) {
                if let toast { Text(toast).font(.system(size: SonoDesktopTokens.FontSize.label)).foregroundStyle(Color(nsColor: SonoGeneratedColors.notificationText)).padding(SonoDesktopTokens.Spacing.s12).background(Color(nsColor: SonoGeneratedColors.localSource), in: RoundedRectangle(cornerRadius: 12)).allowsHitTesting(false) }
            }
            .task(id: toast) {
                guard toast != nil else { return }
                do { try await Task.sleep(for: .seconds(2.5)); toast = nil } catch { }
            }
            .task { await load() }
            .onDisappear { online.closeDailyStylePicker() }
    }
    private func load() async {
        await online.prepareDailyStylePicker()
        guard !Task.isCancelled else { return }
        draft = online.dailyStyleResponse?.selection
        activeCategory = draft?.categoryID ?? online.dailyStyleGroups.first?.id
    }
}

struct DailyRecommendationEmptyState: View {
    @ObservedObject var online: OnlineSession
    var body: some View {
        VStack(spacing: SonoDesktopTokens.Spacing.s12) {
            if online.loading { ProgressView(); Text("正在读取推荐…") }
            else {
                Text(online.notice ?? "暂无推荐歌曲")
                Button("重新读取") { online.retryCurrentPage() }.buttonStyle(.bordered)
            }
        }.font(SonoTypography.font(size: SonoDesktopTokens.FontSize.body)).foregroundStyle(Color(nsColor: SonoGeneratedColors.queueSecondary))
            .frame(maxWidth: 420).padding(SonoDesktopTokens.Spacing.s20)
    }
}
