import Foundation

/// One bounded preparation clock. Layout changes update coverage, never deadlines.
struct ColdEntranceGate {
    enum Decision: Equatable { case waiting, release(String), emptyFailure, noResources }
    private(set) var started: TimeInterval?
    private(set) var firstReady: TimeInterval?
    var deadline: TimeInterval? {
        started.map { min($0 + 3, firstReady.map { $0 + 1.5 } ?? .infinity) }
    }
    mutating func evaluate(now: TimeInterval, total: Int, ready: Int, available: Int,
                           failed: Int, readyArea: Double, totalArea: Double, innerReady: Bool) -> Decision {
        if started == nil { started = now }
        if ready > 0 && firstReady == nil { firstReady = now }
        guard total > 0 else { return .noResources }
        if failed == total && available == 0 { return .emptyFailure }
        if innerReady && Double(ready) / Double(total) >= 0.9 && totalArea > 0 && readyArea / totalArea >= 0.95 { return .release("coverage") }
        if now >= deadline! && available > 0 { return .release("deadline") }
        return .waiting
    }
}
