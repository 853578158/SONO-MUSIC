import AppKit
import SwiftUI

enum SongActionKind { case favorite, addToPlaylist }

struct SongAction {
    var kind: SongActionKind? = nil
    let title: String
    let enabled: Bool
    let perform: @MainActor () -> Void
}

struct SongActions {
    var items: @MainActor (LocalTrack) -> [SongAction] = { _ in [] }

    var browseItems: @MainActor (LocalTrack) -> [SongAction] = { _ in [] }

    var removal: @MainActor (LocalTrack) -> SongAction? = { _ in nil }

    @MainActor func menu(for track: LocalTrack) -> NSMenu? {
        let actions = browseItems(track) + items(track)
        guard !actions.isEmpty else { return nil }
        let menu = NSMenu()
        menu.autoenablesItems = false
        for action in actions {
            let item = SongMenuItem(action)
            menu.addItem(item)
        }
        if let action = removal(track) {
            menu.addItem(.separator())
            menu.addItem(SongMenuItem(action))
        }
        return menu
    }
}

@MainActor final class SongMenuItem: NSMenuItem {
    private let perform: @MainActor () -> Void

    init(_ action: SongAction) {
        perform = action.perform
        super.init(title: action.title, action: nil, keyEquivalent: "")
        target = self
        self.action = #selector(invoke)
        isEnabled = action.enabled
    }
    required init(coder: NSCoder) { fatalError("Song menus are created in code") }
    @objc private func invoke() { perform() }
}

private enum SongActionsKey: EnvironmentKey {
    static var defaultValue: SongActions { SongActions() }
}

extension EnvironmentValues {
    var songActions: SongActions {
        get { self[SongActionsKey.self] }
        set { self[SongActionsKey.self] = newValue }
    }
}

struct SongPlaylistPicker: View {
    @ObservedObject var online: OnlineSession
    let select: (String) -> Void
    let cancel: () -> Void

    @Environment(\.sonoTheme) private var theme
    @State private var selected: String?
    @State private var hovered: String?

    private let footerInset = SonoDesktopTokens.Spacing.s8
    private let buttonHeight = SonoDesktopTokens.Component.recommendationButton
    private var panelRadius: CGFloat { buttonHeight * SonoDesktopTokens.Radius.circle + footerInset }

    private var canConfirm: Bool {
        guard let selected, !online.playlistsLoading, !online.playlistsMore else { return false }
        return online.editablePlaylists.contains { $0.id == selected }
            && !online.songOperations.contains("playlist/" + selected)
    }

    var body: some View {
        VStack(spacing: SonoDesktopTokens.Spacing.s12) {
            Text("添加到歌单")
                .font(SonoTypography.font(size: SonoDesktopTokens.FontSize.sectionTitle, weight: .bold))
                .frame(maxWidth: .infinity, minHeight: SonoDesktopTokens.Component.control)
                .padding(.top, SonoDesktopTokens.Spacing.s36)
            if online.playlistsLoading {
                ProgressView("正在加载歌单…").frame(maxWidth: .infinity, minHeight: 100)
            } else if online.playlistsMore {
                Button("歌单未加载完整，重试") { online.loadPlaylists(more: true) }
                    .frame(maxWidth: .infinity, minHeight: 100)
            } else if online.editablePlaylists.isEmpty {
                Text("没有可添加的自建歌单").foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, minHeight: 100)
            } else {
                ScrollView {
                    LazyVStack(spacing: 0) {
                        ForEach(online.editablePlaylists) { playlist in
                            let isSelected = selected == playlist.id
                            let isHovered = hovered == playlist.id && !isSelected
                            Button { selected = playlist.id } label: {
                                HStack(spacing: 12) {
                                    SourcePlaylistArtwork(url: playlist.cover, size: SonoDesktopTokens.Cover.compactTitle)
                                        .clipShape(RoundedRectangle(cornerRadius: 8))
                                    Text(playlist.name)
                                        .font(SonoTypography.font(size: SonoDesktopTokens.FontSize.label, weight: isSelected ? .bold : .regular))
                                        .lineLimit(1)
                                    Spacer(minLength: 0)
                                }
                                .padding(.horizontal, SonoDesktopTokens.Spacing.s8)
                                .frame(height: 48)
                                .foregroundStyle(isSelected ? Color(nsColor: theme.foreground()) : .primary)
                                .background(isSelected ? Color(nsColor: theme.accent) : .primary.opacity(isHovered ? 0.07 : 0),
                                            in: RoundedRectangle(cornerRadius: isHovered ? SonoDesktopTokens.Radius.large : SonoDesktopTokens.Radius.small))
                                .contentShape(Rectangle())
                            }
                            .buttonStyle(.plain)
                            .onHover { if $0 { hovered = playlist.id } else if hovered == playlist.id { hovered = nil } }
                            .accessibilityAddTraits(selected == playlist.id ? .isSelected : [])
                            .disabled(online.songOperations.contains("playlist/" + playlist.id))
                        }
                    }
                    .padding(.leading, SonoDesktopTokens.Spacing.s24)
                    .padding(.trailing, SonoScrollbarStyle.thumbWidth + 11)
                    .background(PanelScrollConfiguration(usesCustomIndicator: true))
                }
                .panelOverlayScrollbar()
                .padding(.trailing, footerInset - PanelScrollConfiguration.overlayThumbTrailingInset)
                .frame(idealHeight: CGFloat(min(online.editablePlaylists.count, 7)) * 48,
                       maxHeight: CGFloat(min(online.editablePlaylists.count, 7)) * 48)
            }
            HStack(spacing: 8) {
                Button(action: cancel) {
                    Text("取消").frame(maxWidth: .infinity).frame(height: buttonHeight)
                        .background(Color(nsColor: SonoGeneratedColors.quickPlaceholder), in: Capsule())
                        .contentShape(Capsule())
                }.buttonStyle(.plain).keyboardShortcut(.cancelAction)
                Button {
                    if canConfirm, let selected { select(selected) }
                } label: {
                    Text("确认").fontWeight(.bold)
                        .frame(maxWidth: .infinity).frame(height: buttonHeight)
                        .foregroundStyle(canConfirm ? Color(nsColor: theme.foreground()) : Color(nsColor: SonoGeneratedColors.interfaceDisabled))
                        .background(canConfirm ? Color(nsColor: theme.accent) : .primary.opacity(0.05), in: Capsule())
                        .contentShape(Capsule())
                }.buttonStyle(.plain).keyboardShortcut(.defaultAction)
                    .disabled(!canConfirm)
            }
            .font(SonoTypography.font(size: SonoDesktopTokens.FontSize.label))
            .padding(.top, SonoDesktopTokens.Spacing.s4)
            .padding(.horizontal, footerInset)
        }
        .padding(.bottom, footerInset)
        .frame(width: 380)
        .overlay(alignment: .topTrailing) {
            Button(action: cancel) {
                Image(systemName: "xmark")
                    .font(.system(size: SonoDesktopTokens.SymbolSize.control))
                    .frame(width: SonoDesktopTokens.Component.control, height: SonoDesktopTokens.Component.control)
            }.buttonStyle(SonoPanelCloseStyle())
                .accessibilityLabel("关闭")
                .padding(SonoDesktopTokens.Spacing.s16)
        }
        .presentationCornerRadius(panelRadius)
        .presentationBackground(Color(nsColor: SonoGeneratedColors.recommendationPanel))
    }
}

struct SonoConfirmationDialog: View {
    let title: String
    let cancel: () -> Void
    let confirm: () -> Void

    @Environment(\.sonoTheme) private var theme
    private let inset = SonoDesktopTokens.Spacing.s8
    private let buttonHeight = SonoDesktopTokens.Component.recommendationButton

    var body: some View {
        VStack(spacing: 0) {
            Text(title)
                .font(SonoTypography.font(size: SonoDesktopTokens.FontSize.sectionTitle, weight: .bold))
                .multilineTextAlignment(.center)
                .padding(.horizontal, SonoDesktopTokens.Spacing.s24)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .padding(.top, SonoDesktopTokens.Spacing.s40)
                .padding(.bottom, 10)
            HStack(spacing: inset) {
                Button(action: cancel) {
                    Text("取消")
                        .frame(maxWidth: .infinity).frame(height: buttonHeight)
                        // The existing placeholder role resolves to color-fill-2 in both appearances.
                        .background(Color(nsColor: SonoGeneratedColors.quickPlaceholder), in: Capsule())
                        .contentShape(Capsule())
                }.buttonStyle(.plain).keyboardShortcut(.cancelAction)
                Button(action: confirm) {
                    Text("确认").fontWeight(.bold)
                        .frame(maxWidth: .infinity).frame(height: buttonHeight)
                        .foregroundStyle(Color(nsColor: theme.foreground()))
                        .background(Color(nsColor: theme.accent), in: Capsule())
                        .contentShape(Capsule())
                }.buttonStyle(.plain).keyboardShortcut(.defaultAction)
            }
            .font(SonoTypography.font(size: SonoDesktopTokens.FontSize.label))
            .padding(inset)
        }
        .frame(width: 380, height: 246)
        .overlay(alignment: .topTrailing) {
            Button(action: cancel) {
                Image(systemName: "xmark")
                    .font(.system(size: SonoDesktopTokens.SymbolSize.control))
                    .frame(width: SonoDesktopTokens.Component.control, height: SonoDesktopTokens.Component.control)
            }.buttonStyle(SonoPanelCloseStyle())
                .accessibilityLabel("关闭")
                .padding(SonoDesktopTokens.Spacing.s16)
        }
        .presentationCornerRadius(SonoDesktopTokens.Radius.window)
        .presentationBackground(Color(nsColor: SonoGeneratedColors.recommendationPanel))
    }
}

struct SongInfoMenu: View {
    let track: LocalTrack
    let feedback: SongAction?
    let openAlbum: () -> Void
    let openArtist: (OnlineArtist) -> Void

    private var artists: [OnlineArtist] {
        guard let info = track.online else { return [] }
        if let names = info.artists, !names.isEmpty { return names }
        return info.artistID.isEmpty ? [] : [OnlineArtist(id: info.artistID, name: track.artist)]
    }

    var body: some View {
        Text(track.title)
        Divider()
        if artists.isEmpty {
            Text("歌手：" + (track.artist.isEmpty ? "未知歌手" : track.artist))
        } else {
            ForEach(artists) { artist in
                Button("查看歌手：" + artist.name) { openArtist(artist) }
            }
        }
        if let info = track.online, !info.albumID.isEmpty {
            Button("查看专辑：" + (track.album.isEmpty ? "未知专辑" : track.album), action: openAlbum)
        } else {
            Text("专辑：" + (track.album.isEmpty ? "未知专辑" : track.album))
        }
        if let feedback {
            Divider()
            Button(action: feedback.perform) {
                Label(feedback.title, systemImage: "heart.slash")
            }.disabled(!feedback.enabled)
        }
    }
}
