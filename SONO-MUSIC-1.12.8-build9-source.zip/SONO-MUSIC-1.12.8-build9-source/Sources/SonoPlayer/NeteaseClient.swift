import Foundation
import Security

indirect enum OnlineJSON: Sendable {
    case object([String: OnlineJSON]), array([OnlineJSON]), string(String), number(Double), bool(Bool), null
    init(data: Data) throws { self = Self.wrap(try JSONSerialization.jsonObject(with: data)) }
    private static func wrap(_ value: Any) -> Self {
        switch value {
        case let value as [String: Any]: .object(value.mapValues(wrap))
        case let value as [Any]: .array(value.map(wrap))
        case let value as String: .string(value)
        case let value as NSNumber: CFGetTypeID(value) == CFBooleanGetTypeID() ? .bool(value.boolValue) : .number(value.doubleValue)
        default: .null
        }
    }
    subscript(_ key: String) -> Self { if case .object(let value) = self { value[key] ?? .null } else { .null } }
    var array: [Self] { if case .array(let value) = self { value } else { [] } }
    var string: String { switch self { case .string(let value): value; case .number(let value): String(format: "%.0f", value); default: "" } }
    var int: Int { Int(string) ?? 0 }
    var bool: Bool { if case .bool(let value) = self { value } else { int != 0 } }
    var isNull: Bool { if case .null = self { true } else { false } }
}

struct OnlineAudioSource {
    let url: URL
    let expires: Date
    var trial: Range<Double>? = nil
}

enum OnlineError: LocalizedError {
    case protocolFailure(String), service(Int, String), loginRequired, unavailable, membershipRequired, qqFullTrackUnavailable, credential(Int32), performanceIsolation
    static let membershipMessage = "请开通会员后再尝试"
    static let qqFullTrackUnavailableMessage = "这首歌暂时无法在 SONO MUSIC 完整播放"
    static func isNonRetryablePlaybackMessage(_ message: String?) -> Bool {
        message == membershipMessage || message == qqFullTrackUnavailableMessage
    }
    var errorDescription: String? {
        switch self {
        case .protocolFailure(let text): text
        case .service(let code, let message): "网易云请求失败（\(code)）：\(message)"
        case .loginRequired: "登录已失效，请重新扫码登录。"
        case .membershipRequired: Self.membershipMessage
        case .qqFullTrackUnavailable: Self.qqFullTrackUnavailableMessage
        case .unavailable: Self.qqFullTrackUnavailableMessage
        case .credential(let code): "无法访问登录凭据（Keychain \(code)）"
        case .performanceIsolation: "性能验收使用独立访客环境，无法保存或使用账号登录凭据。"
        }
    }
}

struct OnlineAccount: Codable, Sendable, Equatable {
    let id: String
    let name: String
    var avatar: URL? = nil
}
struct OnlinePlaylist: Identifiable, Codable, Sendable {
    let id: String; let name: String; var count: Int; var cover: URL?
    var ownerID: String? = nil
    var tracksUpdatedAt: Double? = nil
    var isFavorites: Bool? = nil
    var subscribed: Bool? = nil
    init(_ json: OnlineJSON) {
        id = json["id"].string
        name = json["name"].string
        count = json["trackCount"].int
        let updated = json["trackUpdateTime"].string
        tracksUpdatedAt = Double(updated).flatMap { $0 > 0 ? $0 / 1000 : nil }
        isFavorites = json["specialType"].int == 5
        subscribed = json["subscribed"].bool
        let creator = json["creator"]["userId"].string
        let userID = json["userId"].string
        ownerID = creator.isEmpty ? (userID.isEmpty ? nil : userID) : creator
        cover = URL(string: json["coverImgUrl"].string.replacingOccurrences(of: "http://", with: "https://"))
    }
}
struct OnlineSong: Identifiable, Sendable {
    let id: String; let title: String; let artist: String; let album: String; let duration: Double
    let albumID: String; let artistID: String; let cover: URL?
    let artists: [OnlineArtist]
    let privilege: OnlineJSON
    init(_ json: OnlineJSON) {
        privilege = json["privilege"]
        id = json["id"].string; title = json["name"].string
        let artists = json["ar"].isNull ? json["artists"] : json["ar"]
        let record = json["al"].isNull ? json["album"] : json["al"]
        artist = artists.array.map { $0["name"].string }.joined(separator: " / ")
        artistID = artists.array.first?["id"].string ?? ""
        self.artists = artists.array.map { OnlineArtist(id: $0["id"].string, name: $0["name"].string) }
        album = record["name"].string; albumID = record["id"].string
        duration = Double(json["dt"].isNull ? json["duration"].int : json["dt"].int) / 1000
        cover = URL(string: record["picUrl"].string.replacingOccurrences(of: "http://", with: "https://"))
    }
}

struct OnlineCredentialStore: Sendable {
    struct Session: Codable, Sendable {
        var version = 1
        let cookie: String
        let account: OnlineAccount
        let verifiedAt: Date
    }
    private struct AccountVault: Codable {
        var version = 2
        var activeID: String?
        var sessions: [Session]
    }
    struct Saved: Sendable {
        let cookie: String
        let session: Session?
        var accounts: [OnlineAccount] = []
    }
    private static func vault(_ text: String) throws -> AccountVault {
        if text.first == "{", (try JSONDecoder().decode(Version.self, from: Data(text.utf8))).version == 2 {
            return try JSONDecoder().decode(AccountVault.self, from: Data(text.utf8))
        }
        let session = try decode(text).session
        return AccountVault(activeID: session?.account.id, sessions: session.map { [$0] } ?? [])
    }
    private struct Version: Decodable { let version: Int }
    static func decode(_ text: String) throws -> Saved {
        // Legacy entries are cookie headers. A malformed versioned record must
        // never be interpreted as a credential or trusted account binding.
        if text.first == "{" {
            let data = Data(text.utf8)
            if try JSONDecoder().decode(Version.self, from: data).version == 2 {
                let vault = try JSONDecoder().decode(AccountVault.self, from: data)
                let current = vault.sessions.first { $0.account.id == vault.activeID }
                return Saved(cookie: current?.cookie ?? "", session: current, accounts: vault.sessions.map(\.account))
            }
            let record = try JSONDecoder().decode(Session.self, from: data)
            guard record.version == 1, !record.account.id.isEmpty else { throw OnlineError.protocolFailure("登录记录格式无效") }
            return Saved(cookie: record.cookie, session: record, accounts: [record.account])
        }
        return Saved(cookie: text, session: nil)
    }
    private var invalidationKey: String { service + ".snapshot-invalidated.v1" }
    func loadSaved() throws -> Saved {
        guard PerformanceEnvironment.root == nil else { return Saved(cookie: "", session: nil) }
        let saved = try Self.decode(read())
        return PerformanceEnvironment.defaults.bool(forKey: invalidationKey) ? Saved(cookie: saved.cookie, session: nil, accounts: saved.accounts) : saved
    }
    func saveSession(_ cookie: String, account: OnlineAccount) throws {
        guard PerformanceEnvironment.root == nil else { throw OnlineError.performanceIsolation }
        // Persist invalidation before attempting the atomic Keychain replacement.
        // A denied write (or interruption) must not make the old owner snapshot
        // eligible for speculative publication on the next launch.
        invalidateSnapshot()
        var vault = try Self.vault(read())
        vault.sessions.removeAll { $0.account.id == account.id }
        vault.sessions.append(Session(cookie: cookie, account: account, verifiedAt: Date()))
        vault.activeID = account.id
        try saveVault(vault)
        PerformanceEnvironment.defaults.removeObject(forKey: invalidationKey)
    }
    func savedSession(for id: String) throws -> Session? {
        guard PerformanceEnvironment.root == nil else { return nil }
        return try Self.vault(read()).sessions.first { $0.account.id == id }
    }

    func removeSession(id: String? = nil) throws {
        guard PerformanceEnvironment.root == nil else { return }
        var vault = try Self.vault(read())
        let target = id ?? vault.activeID
        vault.sessions.removeAll { $0.account.id == target }
        if vault.activeID == target { vault.activeID = nil }
        if vault.sessions.isEmpty { try save("") }
        else { try saveVault(vault) }
    }

    private func saveVault(_ vault: AccountVault) throws {
        let data = try JSONEncoder().encode(vault)
        try save(String(decoding: data, as: UTF8.self))
    }

    func invalidateSnapshot() {
        guard PerformanceEnvironment.root == nil else { return }
        PerformanceEnvironment.defaults.set(true, forKey: invalidationKey)
        PerformanceEnvironment.defaults.synchronize()
    }
    #if DEBUG
    var validationWriteFailure: OSStatus?
    #endif
    let service: String
    init(service: String = (Bundle.main.bundleIdentifier ?? "app.sono.native.preview") + ".netease") { self.service = service }
    private var query: [String: Any] { [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: service, kSecAttrAccount as String: "session"] }
    func load() throws -> String { try loadSaved().cookie }
    private func read() throws -> String {
        var query = query; query[kSecReturnData as String] = true; query[kSecMatchLimit as String] = kSecMatchLimitOne
        var value: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &value)
        if status == errSecItemNotFound { return "" }
        guard status == errSecSuccess, let data = value as? Data, let text = String(data: data, encoding: .utf8) else { throw OnlineError.credential(status) }
        return text
    }
    func save(_ cookie: String) throws {
        if PerformanceEnvironment.root != nil {
            guard cookie.isEmpty else { throw OnlineError.performanceIsolation }
            return
        }
        #if DEBUG
        if let validationWriteFailure { throw OnlineError.credential(validationWriteFailure) }
        #endif
        if cookie.isEmpty {
            let status = SecItemDelete(query as CFDictionary)
            guard status == errSecSuccess || status == errSecItemNotFound else { throw OnlineError.credential(status) }
            PerformanceEnvironment.defaults.removeObject(forKey: invalidationKey); return
        }
        let data = Data(cookie.utf8)
        let status = SecItemUpdate(query as CFDictionary, [kSecValueData as String: data] as CFDictionary)
        if status == errSecItemNotFound {
            var item = query; item[kSecValueData as String] = data; item[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
            let added = SecItemAdd(item as CFDictionary, nil)
            guard added == errSecSuccess else { throw OnlineError.credential(added) }
        } else if status != errSecSuccess { throw OnlineError.credential(status) }
    }
}

private final class NeteaseSessionDelegate: NSObject, URLSessionTaskDelegate, @unchecked Sendable {
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest, completionHandler: @escaping @Sendable (URLRequest?) -> Void) {
        // API endpoints are fixed HTTPS origins; never forward account cookies
        // to a redirect destination or downgrade transport security.
        completionHandler(nil)
    }
}

actor NeteaseClient {
    func chorus(_ songID: String, cookie: String = "") async throws -> [ChorusRange] {
        let json = try await request("/api/song/chorus", ["ids": "[\(songID)]"], cookie: cookie)
        return ChorusRange.parse(json, songID: songID)
    }

    private let session: URLSession
    private let deviceID: String
    // Upstream util/request.js's osx and weapi compatibility profiles.
    private static let desktopUA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    private static let webUA = desktopUA + " Edg/124.0.0.0"
    static func installationDeviceID(defaults: UserDefaults = PerformanceEnvironment.defaults) -> String {
        let key = "netease.installation-device-id.v1"
        if let saved = defaults.string(forKey: key), UUID(uuidString: saved) != nil { return saved }
        let generated = UUID().uuidString
        defaults.set(generated, forKey: key)
        return generated
    }
    private var publicKey: OnlineJSON?
    init(configuration: URLSessionConfiguration = .ephemeral, deviceID: String? = nil) {
        self.deviceID = deviceID ?? Self.installationDeviceID()
        configuration.httpShouldSetCookies = false
        configuration.httpCookieStorage = nil; configuration.urlCache = nil
        configuration.timeoutIntervalForRequest = 20; configuration.timeoutIntervalForResource = 30
        session = URLSession(configuration: configuration, delegate: NeteaseSessionDelegate(), delegateQueue: nil)
    }
    func request(_ path: String, _ parameters: [String: String] = [:], cookie: String = "", weapi: Bool = false, xeapi: Bool = false, flags: [String: Bool] = [:], numbers: [String: Int] = [:]) async throws -> OnlineJSON {
        var headers = ["Content-Type": "application/x-www-form-urlencoded;charset=utf-8", "Referer": "https://music.163.com/", "User-Agent": Self.desktopUA]
        var data: [String: Any] = parameters
        for (key, value) in flags { data[key] = value }
        for (key, value) in numbers { data[key] = value }
        let cookies = Self.cookies(cookie)
        let csrf = cookies["__csrf"] ?? ""
        let device = xeapi ? deviceID : (cookies["deviceId"] ?? deviceID)
        var clientHeaders = ["os": xeapi ? "android" : "osx", "osver": xeapi ? "12" : "15.5", "appver": xeapi ? "9.5.61" : "3.1.10.5100", "deviceId": device,
                             "requestId": "\(Int64(Date().timeIntervalSince1970 * 1000))_\(Int.random(in: 1000...9999))", "__csrf": csrf,
                             "channel": "netease", "versioncode": "140", "mobilename": "", "buildver": String(Int(Date().timeIntervalSince1970)), "resolution": "1920x1080"]
        for name in ["MUSIC_U", "MUSIC_A", "NMTID"] { if let value = cookies[name], !value.isEmpty { clientHeaders[name] = value } }
        let context = cookies.merging(clientHeaders) { _, new in new }
        headers["Cookie"] = Self.cookieHeader(context)
        let body: [String: String]
        let domain: String
        let prefix: String
        if xeapi {
            headers["User-Agent"] = "NeteaseMusic/9.5.61.260802021928(9005061);Dalvik/2.1.0 (Linux; U; Android 12; HBN-AL00 Build/cd737a2.0)"
            if publicKey == nil { publicKey = try await registerKey() }
            guard let publicKey else { throw OnlineError.protocolFailure("音源公钥未初始化") }
            headers["X-Client-Enc-State"] = "ENCRYPTED"; headers["x-aeapi"] = "true"
            for (key, value) in clientHeaders { headers["x-" + key.lowercased()] = value }
            headers["x-sdeviceid"] = device
            body = try NeteaseCrypto.xeapi(path: path, data: parameters, publicKey: publicKey, deviceID: deviceID)
            domain = "https://interface3.music.163.com"; prefix = "/xeapi/"
        } else if weapi {
            headers["User-Agent"] = Self.webUA
            data["csrf_token"] = csrf; data["e_r"] = false
            body = try NeteaseCrypto.weapi(data); domain = "https://music.163.com"; prefix = "/weapi/"
        } else {
            data["header"] = clientHeaders; data["e_r"] = false
            body = try NeteaseCrypto.eapi(path: path, data: data); domain = "https://interfacepc.music.163.com"; prefix = "/eapi/"
        }
        let (bytes, response) = try await send(domain + prefix + path.dropFirst(5), body: body, headers: headers)
        let json = try NeteaseCrypto.decodeResponse(bytes)
        let code = json["code"].int
        if code == 301 || code == 302 { throw OnlineError.loginRequired }
        guard code == 0 || code == 200 || (800...803).contains(code) else { throw OnlineError.service(code, json["message"].string.isEmpty ? json["msg"].string : json["message"].string) }
        // QR cookies are returned to this login task, never installed in a shared jar.
        // This preserves the key request's server context without allowing a late
        // cancelled request to mutate the active account.
        if path == "/api/login/qrcode/unikey" || path == "/api/login/qrcode/client/login" {
            guard case .object(var result) = json else { throw OnlineError.protocolFailure("扫码响应格式无效") }
            let merged = Self.responseCookies(response, existing: context)
            result["cookie"] = .string(Self.cookieHeader(merged))
            return .object(result)
        }
        return json
    }
    private func registerKey() async throws -> OnlineJSON {
        let nonce = (0..<16).map { _ in String(Int.random(in: 0...9)) }.joined()
        let timestamp = String(Int64(Date().timeIntervalSince1970 * 1000))
        let (data, _) = try await send("https://interface.music.163.com/api/gorilla/anti/crawler/security/key/get", body: ["appVersion": "9.5.61", "currentKeyVersion": "", "deviceId": deviceID, "nonce": nonce, "os": "android", "requestType": "active", "signature": NeteaseCrypto.signature(timestamp, nonce: nonce), "t1": "", "t2": "", "timestamp": timestamp, "uid": ""], headers: ["Content-Type": "application/x-www-form-urlencoded", "User-Agent": "NeteaseMusic/9.5.61.260802021928(9005061);Dalvik/2.1.0 (Linux; U; Android 12; HBN-AL00 Build/cd737a2.0)"])
        let response = try OnlineJSON(data: data)
        guard response["code"].int == 200, response["data"]["signature"].string == NeteaseCrypto.signature(response["data"]["timestamp"].string, nonce: nonce),
              let encrypted = Data(base64Encoded: response["data"]["encryptedData"].string) else { throw OnlineError.protocolFailure("音源公钥签名验证失败") }
        let key = try OnlineJSON(data: NeteaseCrypto.aes(encrypted, key: NeteaseCrypto.staticKey, decrypt: true))
        guard !key["sk"].string.isEmpty else { throw OnlineError.protocolFailure("音源公钥缺少会话参数") }
        return key
    }
    private func send(_ url: String, body: [String: String], headers: [String: String]) async throws -> (Data, HTTPURLResponse) {
        try Task.checkCancellation()
        var request = URLRequest(url: URL(string: url)!)
        request.httpMethod = "POST"; request.httpBody = Data(NeteaseCrypto.form(body).utf8); request.allHTTPHeaderFields = headers
        let diagnosticID = BrowseDiagnostics.shared.enabled && request.url?.path.hasSuffix("/nuser/account/get") == true ? UUID().uuidString : nil
        let delegate = diagnosticID.map { ArtworkTransferMetrics($0, category: "account") }
        if let diagnosticID { BrowseDiagnostics.shared.mark("account.requestStarted", fields: ["request": diagnosticID]) }
        let result: (Data, URLResponse)
        do { result = try await session.data(for: request, delegate: delegate) }
        catch {
            if let diagnosticID { BrowseDiagnostics.shared.mark("account.requestFailed", fields: ["request": diagnosticID, "code": String((error as? URLError)?.code.rawValue ?? -1)]) }
            throw error
        }
        let (data, response) = result
        if let diagnosticID { BrowseDiagnostics.shared.mark("account.response", fields: ["request": diagnosticID, "bytes": String(data.count), "status": String((response as? HTTPURLResponse)?.statusCode ?? 0)]) }
        try Task.checkCancellation()
        guard let response = response as? HTTPURLResponse, (200..<300).contains(response.statusCode) else { throw OnlineError.protocolFailure("网易云服务暂不可用，请稍后重试") }
        guard data.count <= 32 * 1024 * 1024 else { throw OnlineError.protocolFailure("响应过大") }
        return (data, response)
    }
    static func cookieHeader(_ cookies: [String: String]) -> String {
        let allowed = CharacterSet(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_.!~*'()")
        return cookies.keys.sorted().map { key in
            (key.addingPercentEncoding(withAllowedCharacters: allowed) ?? "") + "=" + (cookies[key]!.addingPercentEncoding(withAllowedCharacters: allowed) ?? "")
        }.joined(separator: "; ")
    }
    static func responseCookies(_ response: HTTPURLResponse, existing: [String: String]) -> [String: String] {
        guard let url = response.url, url.scheme == "https", let host = url.host,
              host == "music.163.com" || host.hasSuffix(".music.163.com") else { return existing }
        var result = existing
        // Foundation combines duplicate Set-Cookie fields. Split only at a new
        // cookie name, retaining the comma inside Expires=Wed, ... dates.
        let boundary = try! NSRegularExpression(pattern: ",(?=\\s*[!#$%&'*+.^_`|~a-zA-Z0-9-]+=)")
        for (name, value) in response.allHeaderFields where String(describing: name).lowercased() == "set-cookie" {
            let raw = String(describing: value)
            let separated = boundary.stringByReplacingMatches(in: raw, range: NSRange(raw.startIndex..., in: raw), withTemplate: "\n")
            for line in separated.split(separator: "\n") {
                for cookie in HTTPCookie.cookies(withResponseHeaderFields: ["Set-Cookie": String(line)], for: url) {
                    let domain = cookie.domain.trimmingCharacters(in: CharacterSet(charactersIn: "."))
                    guard domain == "music.163.com" || domain.hasSuffix(".music.163.com"), host == domain || host.hasSuffix("." + domain) else { continue }
                    if cookie.value.isEmpty || cookie.expiresDate.map({ $0 <= Date() }) == true { result[cookie.name] = nil }
                    else { result[cookie.name] = cookie.value.removingPercentEncoding ?? cookie.value }
                }
            }
        }
        return result
    }
    static func cookies(_ cookie: String) -> [String: String] {
        cookie.split(separator: ";").reduce(into: [:]) { result, item in
            let parts = item.split(separator: "=", maxSplits: 1).map { $0.trimmingCharacters(in: .whitespaces) }
            if parts.count == 2, !["path", "domain", "expires", "max-age", "samesite", "secure", "httponly", "priority"].contains(parts[0].lowercased()) {
                result[parts[0]] = parts[1].removingPercentEncoding ?? parts[1]
            }
        }
    }
    func favoriteIDs(owner: String, cookie: String) async throws -> Set<String> {
        let result = try await request("/api/song/like/get", ["uid": owner], cookie: cookie)
        guard case .array(let ids) = result["ids"], ids.allSatisfy({ !$0.string.isEmpty }) else {
            throw OnlineError.protocolFailure("网易云未返回有效的收藏列表")
        }
        return Set(ids.map(\.string))
    }
    func setFavorite(_ song: String, liked: Bool, cookie: String) async throws {
        let result = try await request("/api/radio/like", ["trackId": song, "alg": "itembased", "time": "3"],
                                       cookie: cookie, weapi: true, flags: ["like": liked])
        try Self.checkMutation(result)
    }
    func addSong(_ song: String, to playlist: String, cookie: String) async throws {
        try await editPlaylist(song, playlist: playlist, removing: false, cookie: cookie)
    }
    func editPlaylist(_ song: String, playlist: String, removing: Bool, cookie: String) async throws {
        let ids = String(decoding: try JSONEncoder().encode([song]), as: UTF8.self)
        let result = try await request("/api/playlist/manipulate/tracks",
                                       ["op": removing ? "del" : "add", "pid": playlist, "trackIds": ids, "imme": "true"], cookie: cookie)
        try Self.checkMutation(result)
    }
    private static func checkMutation(_ result: OnlineJSON) throws {
        // Require a positive write acknowledgement; the general reader also accepts
        // code-less payloads and QR login statuses.
        let code = result["code"].int
        guard code == 200 else { throw OnlineError.protocolFailure("网易云未确认保存结果") }
    }
    func audioURL(_ id: String, cookie: String) async throws -> URL {
        try await audioSource(id,cookie:cookie).url
    }
    func audioSource(_ id:String,cookie:String) async throws -> OnlineAudioSource {
        let json = try await request("/api/song/enhance/player/url/v1", ["ids": "[\(id)]", "level": "exhigh", "encodeType": "flac"], cookie: cookie, xeapi: true)
        guard let song = json["data"].array.first else { throw OnlineError.unavailable }
        guard song["code"].int == 200,
              let url = URL(string: song["url"].string.replacingOccurrences(of: "http://", with: "https://")), url.scheme == "https" else { throw OnlineError.unavailable }
        let lifetime = song["expi"].int
        let start = Double(song["freeTrialInfo"]["start"].string)
        let end = Double(song["freeTrialInfo"]["end"].string)
        let trial: Range<Double>?
        if let start, let end, start.isFinite, end.isFinite, start >= 0, end > start {
            trial = start..<end
        } else {
            trial = nil
        }
        return OnlineAudioSource(url: url, expires: Date().addingTimeInterval(TimeInterval(lifetime > 0 ? lifetime : 60)), trial: trial)
    }
}
