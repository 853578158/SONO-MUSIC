import SwiftUI
import AppKit
import CoreText

/// The console uses the same Core Animation reading motion as artwork captions.
struct ConsoleReadingText: View {
    let text: String
    let size: CGFloat
    let weight: Font.Weight
    let color: NSColor
    var action: (() -> Void)? = nil
    var highlightsOnHover = false
    var hoverColor: NSColor? = nil
    var scrollsOnHover = true
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.colorScheme) private var colorScheme
    @Environment(\.colorSchemeContrast) private var colorSchemeContrast
    @Environment(\.sonoAppearance) private var appearance

    var body: some View {
        let measuredWidth = ceil(SonoTypography.width(text, size: size, weight: weight))
        ZStack {
            Color.clear
            ConsoleTextSurface(text: text, size: size, weight: weight, color: color, colorScheme: appearance.colorScheme ?? colorScheme, colorSchemeContrast: colorSchemeContrast, measuredWidth: measuredWidth, reduceMotion: reduceMotion || !scrollsOnHover, action: action, highlightsOnHover: highlightsOnHover, hoverColor: hoverColor)
        }
        .frame(maxWidth: measuredWidth, alignment: .leading)
        .contentShape(Rectangle())
        .accessibilityRepresentation {
            if let action { Button(text, action: action) }
            else { Text(text) }
        }
    }
}

private struct ConsoleTextSurface: NSViewRepresentable {
    let text: String
    let size: CGFloat
    let weight: Font.Weight
    let color: NSColor
    let colorScheme: ColorScheme
    let colorSchemeContrast: ColorSchemeContrast
    let measuredWidth: CGFloat
    let reduceMotion: Bool
    let action: (() -> Void)?
    let highlightsOnHover: Bool
    let hoverColor: NSColor?

    func makeNSView(context: Context) -> ReadingView { ReadingView() }
    func updateNSView(_ view: ReadingView, context: Context) {
        // The Core Animation text must follow SwiftUI's theme, including inside glass.
        let name: NSAppearance.Name = colorScheme == .dark
            ? (colorSchemeContrast == .increased ? .accessibilityHighContrastDarkAqua : .darkAqua)
            : (colorSchemeContrast == .increased ? .accessibilityHighContrastAqua : .aqua)
        view.action = action
        view.window?.invalidateCursorRects(for: view)
        view.configure(text: text, size: size, weight: weight, color: color, appearance: NSAppearance(named: name)!, measuredWidth: measuredWidth, reduceMotion: reduceMotion, highlightsOnHover: highlightsOnHover, hoverColor: hoverColor)
    }

    static func dismantleNSView(_ view: ReadingView, coordinator: ()) { view.stopObservingPointer() }

    final class ReadingView: NSView {
        var action: (() -> Void)?
        private let textLayer = CATextLayer()
        private var measured: CGFloat = 0
        private var lineHeight: CGFloat = 0
        private var reduceMotion = false
        private var hovered = false
        private var textColor = NSColor.white
        private var colorAppearance = NSAppearance(named: .aqua)!
        private var highlightsOnHover = false
        private var hoverColor = NSColor.white
        private var hoverTracking: NSTrackingArea?
        private var pressOrigin: CGPoint?
        private var pressCancelled = false
        private var resignObserver: NSObjectProtocol?
        private var content: String?
        override var isFlipped: Bool { true }

        override init(frame: NSRect) {
            super.init(frame: frame)
            wantsLayer = true
            layer?.masksToBounds = true
            textLayer.alignmentMode = .left
            textLayer.isWrapped = false
            layer?.addSublayer(textLayer)
        }
        required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

        func configure(text: String, size: CGFloat, weight: Font.Weight, color: NSColor, appearance: NSAppearance, measuredWidth: CGFloat, reduceMotion: Bool, highlightsOnHover: Bool, hoverColor: NSColor?) {
            CATransaction.begin(); CATransaction.setDisableActions(true)
            if content != text { textLayer.removeAnimation(forKey: "reading"); content = text }
            textLayer.string = text
            let font = SonoTypography.native(size: size, weight: weight)
            textLayer.font = font
            lineHeight = ceil(CTFontGetAscent(font) + CTFontGetDescent(font))
            textLayer.fontSize = size
            textColor = color
            colorAppearance = appearance
            self.highlightsOnHover = highlightsOnHover
            self.hoverColor = hoverColor ?? SonoGeneratedColors.primaryText
            measured = measuredWidth
            self.reduceMotion = reduceMotion
            updateTextLayout()
            CATransaction.commit()
        }

        override func viewDidChangeEffectiveAppearance() {
            super.viewDidChangeEffectiveAppearance(); updateTextLayout()
        }

        override func resetCursorRects() {
            super.resetCursorRects()
            addCursorRect(visibleRect, cursor: action == nil ? .arrow : .pointingHand)
        }

        private func ownsPointer(_ point: CGPoint) -> Bool {
            guard let root = window?.contentView, !isHiddenOrHasHiddenAncestor else { return false }
            let hit = root.hitTest(convert(point, to: root.superview))
            return hit === self || hit?.isDescendant(of: self) == true
        }
        override func mouseDown(with event: NSEvent) {
            let point = convert(event.locationInWindow, from: nil)
            pressOrigin = ownsPointer(point) && visibleRect.contains(point) ? point : nil
            pressCancelled = false
            updatePointer(event)
        }
        override func mouseDragged(with event: NSEvent) {
            guard let origin = pressOrigin else { return }
            let point = convert(event.locationInWindow, from: nil)
            if hypot(point.x - origin.x, point.y - origin.y) >= 5 { pressCancelled = true }
        }
        override func mouseUp(with event: NSEvent) {
            let point = convert(event.locationInWindow, from: nil)
            let clicked = pressOrigin != nil && !pressCancelled && visibleRect.contains(point) && ownsPointer(point)
            pressOrigin = nil
            updatePointer(event)
            if clicked { action?() }
        }
        override func scrollWheel(with event: NSEvent) { }
        override func updateTrackingAreas() {
            super.updateTrackingAreas()
            if let hoverTracking { removeTrackingArea(hoverTracking) }
            let area = NSTrackingArea(rect: .zero, options: [.inVisibleRect, .activeAlways, .mouseEnteredAndExited, .mouseMoved, .cursorUpdate], owner: self)
            addTrackingArea(area); hoverTracking = area
        }
        override func cursorUpdate(with event: NSEvent) { updatePointer(event) }
        override func mouseEntered(with event: NSEvent) { updatePointer(event) }
        override func mouseMoved(with event: NSEvent) { updatePointer(event) }
        override func mouseExited(with event: NSEvent) { setHovered(false) }

        override func viewDidMoveToWindow() {
            super.viewDidMoveToWindow()
            stopObservingPointer()
            guard let window else { return }
            window.acceptsMouseMovedEvents = true
            resignObserver = NotificationCenter.default.addObserver(forName: NSWindow.didResignKeyNotification, object: window, queue: .main) { [weak self] _ in
                MainActor.assumeIsolated { self?.pressOrigin = nil; self?.setHovered(false) }
            }
        }
        func stopObservingPointer() {
            if let resignObserver { NotificationCenter.default.removeObserver(resignObserver) }
            pressOrigin = nil; resignObserver = nil
            setHovered(false)
        }
        private func updatePointer(_ event: NSEvent) {
            guard let window, event.window === window, !isHiddenOrHasHiddenAncestor else {
                setHovered(false); return
            }
            // Responder-chain mouse events can arrive from outside this view.
            // Use the visible text viewport, never the animated text layer's bounds.
            let point = convert(event.locationInWindow, from: nil)
            let inside = visibleRect.contains(point) && ownsPointer(point)
            if inside { (action == nil ? NSCursor.arrow : NSCursor.pointingHand).set() }
            setHovered(inside)
        }
        private func setHovered(_ value: Bool) {
            guard hovered != value else { return }
            hovered = value
            CATransaction.begin(); CATransaction.setDisableActions(true)
            updateTextLayout()
            CATransaction.commit()
        }

        override func layout() {
            super.layout()
            CATransaction.begin(); CATransaction.setDisableActions(true)
            updateTextLayout()
            CATransaction.commit()
        }
        override func viewDidChangeBackingProperties() {
            super.viewDidChangeBackingProperties()
            textLayer.contentsScale = window?.backingScaleFactor ?? 2
        }
        private func updateTextLayout() {
            textLayer.foregroundColor = (hovered && highlightsOnHover ? hoverColor : textColor).sonoCGColor(in: colorAppearance)
            textLayer.contentsScale = window?.backingScaleFactor ?? 2
            textLayer.bounds.size.height = max(bounds.height, lineHeight)
            textLayer.position.y = bounds.height / 2
            SonoTextReading.update(textLayer, width: bounds.width, measured: measured, active: hovered && !reduceMotion)
        }
    }
}
