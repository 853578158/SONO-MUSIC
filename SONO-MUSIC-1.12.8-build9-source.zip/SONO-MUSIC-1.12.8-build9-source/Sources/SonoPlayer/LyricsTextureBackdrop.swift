import MetalKit

/// One point-resolution filter chain for both texture appearances.
@MainActor final class LyricsTextureBackdrop {
    struct Pipelines {
        let layers, twist, blur, display: MTLRenderPipelineState
    }

    struct Artwork {
        let texture: MTLTexture
    }

    private struct Parameters {
        var size: SIMD2<Float>
        var fade: Float
        var blur: Float = 0
        var angles: SIMD4<Float>
        var oldAngles: SIMD4<Float>
        // x: prior layers, y: interrupted fade snapshot, z: light appearance
        var options: SIMD3<Float>
    }

    private let pipelines: Pipelines
    private var current: MTLTexture?
    private var previous: MTLTexture?
    private var angles = SIMD4<Float>.zero
    private var oldAngles = SIMD4<Float>.zero
    private var fade: Float = 0
    private var tick: Float = 0
    private var layers: MTLTexture?
    private var ping: MTLTexture?
    private var pong: MTLTexture?
    private var interruption: MTLTexture?
    private var filtersReady = false

    init(pipelines: Pipelines) { self.pipelines = pipelines }

    func encode(_ command: MTLCommandBuffer, artwork: Artwork, style: LyricsTextureStyle,
                size: SIMD2<Int>, elapsed: Float, reduced: Bool, dynamic: Bool = true, canFade: Bool = true,
                uniforms: inout LyricsMetalBackground.Renderer.Uniforms,
                output: MTLRenderPassDescriptor) -> Bool {
        let input = artwork.texture
        let device = input.device
        func target() -> MTLTexture? {
            let descriptor = MTLTextureDescriptor.texture2DDescriptor(
                pixelFormat:.rgba8Unorm,width:size.x,height:size.y,mipmapped:false)
            descriptor.storageMode = .private
            descriptor.usage = [.renderTarget,.shaderRead]
            return device.makeTexture(descriptor:descriptor)
        }
        if layers?.width != size.x || layers?.height != size.y || ping == nil || pong == nil {
            layers = target(); ping = target(); pong = target(); interruption = nil
            filtersReady = false
        }
        guard let layers, let ping, let pong else { return false }

        if current !== input {
            if filtersReady, current != nil, fade < 1, let snapshot = target(), let copy = command.makeBlitCommandEncoder() {
                copy.copy(from:layers,to:snapshot)
                copy.endEncoding()
                interruption = snapshot
            } else {
                interruption = nil
            }
            previous = current
            current = input
            oldAngles = angles
            angles *= SIMD4(1,1,-1,-1)
            fade = 0
            filtersReady = false
        }

        // Pixi advances at up to 15 Hz, capping each elapsed step at 100 ms.
        if !dynamic || reduced {
            tick = 0
            if fade < 1 {
                fade = 1
                previous = nil; interruption = nil
                filtersReady = false
            }
        } else if canFade || previous != nil || fade > 0 {
            tick += elapsed
        }
        if tick >= 1/15 {
            filtersReady = false
            let dt = min(0.1,tick)
            tick = 0
            let rates: SIMD4<Float> = reduced ? SIMD4(repeating:0.03) : SIMD4(0.09,-0.24,-0.18,0.12)
            angles += rates * dt
            fade = min(1,fade+0.6*dt)
            if fade == 1 { previous = nil; interruption = nil }
        }

        var parameters = Parameters(size:SIMD2(Float(size.x),Float(size.y)),fade:fade,
            angles:angles,oldAngles:oldAngles,
            options:SIMD3(previous == nil ? 0 : 1,interruption == nil ? 0 : 1,style == .clear ? 1 : 0))
        func pass(_ pipeline: MTLRenderPipelineState, into target: MTLTexture, inputs: [MTLTexture]) -> Bool {
            let descriptor = MTLRenderPassDescriptor()
            descriptor.colorAttachments[0].texture = target
            descriptor.colorAttachments[0].loadAction = .dontCare
            descriptor.colorAttachments[0].storeAction = .store
            guard let encoder = command.makeRenderCommandEncoder(descriptor:descriptor) else { return false }
            encoder.setRenderPipelineState(pipeline)
            for (index, texture) in inputs.enumerated() { encoder.setFragmentTexture(texture,index:index) }
            encoder.setFragmentBytes(&parameters,length:MemoryLayout<Parameters>.stride,index:0)
            encoder.drawPrimitives(type:.triangle,vertexStart:0,vertexCount:3)
            encoder.endEncoding()
            return true
        }
        if !filtersReady {
            guard pass(pipelines.layers,into:layers,inputs:[input,previous ?? input,interruption ?? input]),
                  pass(pipelines.twist,into:ping,inputs:[layers]) else { return false }
            var from = ping, to = pong
            for offset: Float in [5.5,10.5,20.5,10.5,40.5,20.5,80.5,40.5] {
                parameters.blur = offset
                guard pass(pipelines.blur,into:to,inputs:[from]) else { return false }
                swap(&from,&to)
            }
        }

        guard let encoder = command.makeRenderCommandEncoder(descriptor:output) else { return false }
        encoder.setRenderPipelineState(pipelines.display)
        // Eight blur passes leave the filtered frame in ping.
        encoder.setFragmentTexture(ping,index:0)
        encoder.setFragmentBytes(&parameters,length:MemoryLayout<Parameters>.stride,index:0)
        encoder.setFragmentBytes(&uniforms,length:MemoryLayout<LyricsMetalBackground.Renderer.Uniforms>.stride,index:1)
        encoder.drawPrimitives(type:.triangle,vertexStart:0,vertexCount:3)
        encoder.endEncoding()
        return true
    }

    func didSubmit() { filtersReady = true }
}
