import Foundation

// Rendering metadata belongs to a browse item; only the song case can enter playback.
enum BrowseItem: Codable, Equatable, Sendable, Identifiable {
    case song(LocalTrack)
    case entity(BrowseEntity)
    var song: LocalTrack? { if case .song(let song) = self { return song }; return nil }
    var entity: BrowseEntity? { if case .entity(let entity) = self { return entity }; return nil }
    var id: String { song?.id ?? entity!.id }
    var title: String { song?.title ?? entity!.title }
    var artist: String { song?.artist ?? entity!.displaySubtitle }
    var coverURL: URL? { song?.coverURL ?? entity?.artwork }
    var online: OnlineTrackInfo? { song?.online }
}
struct BrowseEntity: Codable, Equatable, Sendable, Identifiable {
    enum Kind: String, Codable, Sendable { case artist, album, playlist }
    var kind: Kind
    var serviceID: String
    var title: String
    var subtitle: String
    var artwork: URL?
    var trackCount: Int?
    var displaySubtitle: String {
        let prefix = kind == .album ? "专辑 · " : kind == .playlist ? "歌单 · " : ""
        let name = !prefix.isEmpty && subtitle.hasPrefix(prefix) ? String(subtitle.dropFirst(prefix.count)) : subtitle
        guard kind != .artist, let trackCount else { return name }
        return [name, "\(trackCount)首"].filter { !$0.isEmpty }.joined(separator: " · ")
    }
    var published: Double = 0
    var id: String { "entity/" + kind.rawValue + "/" + serviceID }
    var destination: OnlinePageKind {
        switch kind { case .artist: .artist(serviceID); case .album: .album(serviceID); case .playlist: .playlist(serviceID) }
    }
    init(_ json: OnlineJSON, kind: Kind) {
        self.kind = kind; serviceID = json["id"].string; title = json["name"].string
        published = Double(json["publishTime"].string) ?? 0
        let authors = json["artists"].array.map { $0["name"].string }.filter { !$0.isEmpty }.joined(separator: " / ")
        switch kind {
        case .artist: subtitle = "歌手"
        case .album: subtitle = authors.isEmpty ? json["artist"]["name"].string : authors
        case .playlist: subtitle = json["creator"]["nickname"].string
        }
        let count = kind == .album ? (json["size"].isNull ? json["songCount"] : json["size"]) : json["trackCount"]
        trackCount = kind != .artist && !count.isNull && count.int >= 0 ? count.int : nil
        let image = kind == .playlist ? json["coverImgUrl"].string : json["picUrl"].string
        artwork = image.isEmpty ? nil : URL(string: image.replacingOccurrences(of: "http://", with: "https://"))
    }
}
enum SearchCategory: String, Codable, CaseIterable, Sendable {
    case combined, songs, albums, playlists, artists
    var title: String { switch self { case .artists: "歌手"; case .combined: "综合"; case .songs: "单曲"; case .albums: "专辑"; case .playlists: "歌单" } }
    var serviceType: String { switch self { case .artists: "100"; case .combined: "1018"; case .songs: "1"; case .albums: "10"; case .playlists: "1000" } }
}

@MainActor
final class BrowseItemData {
    let tracks: [BrowseItem]
    let ids: [String]
    let index: [String: Int]
    let assignment: [Int]
    init(_ items: [BrowseItem], assignment: [Int]) {
        tracks = items; ids = items.map(\.id); self.assignment = assignment
        index = Dictionary(ids.enumerated().map { ($0.element, $0.offset) }, uniquingKeysWith: { first, _ in first })
    }
}
