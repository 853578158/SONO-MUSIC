import Foundation

/// Resource demand is independent of card/layer membership. Only the small
/// visible set creates views; this bounded window prepares upcoming images.
struct CarouselArtworkPlanner {
    struct Configuration {
        let minimumAhead: Int, maximumAhead: Int, reserve: Int
        static let expanded = Configuration(minimumAhead: 6, maximumAhead: 24, reserve: 8)
        static let previous = Configuration(minimumAhead: 2, maximumAhead: 12, reserve: 4)
    }
    var configuration = Configuration.expanded
    struct Demand: Equatable {
        let center: Int
        let visible: Set<Int>
        let prefetch: Set<Int>
        let settled: Bool
        var resources: Set<Int> { visible.union(prefetch) }
    }
    private var previous: (position: Double, time: Double)?
    private var velocity = 0.0
    private var latency = 0.6
    mutating func recordReadiness(_ seconds: Double) {
        guard seconds.isFinite, seconds > 0 else { return }
        latency = latency * 0.75 + min(3, max(0.05, seconds)) * 0.25
    }
    mutating func demand(position: Double, target: Double?, settled: Bool, visible: Set<Int>, count: Int, now: Double, intentVelocity: Double? = nil) -> Demand {
        guard count > 0 else { previous = nil; velocity = 0; return Demand(center: 0, visible: [], prefetch: [], settled: settled) }
        let center = min(count - 1, max(0, Int(position.rounded())))
        let radius = max(2, visible.map { abs($0 - center) }.max() ?? 4)
        let jumping = target.map { abs($0 - position) > Double(max(8, radius * 2)) } ?? false
        if let previous, now > previous.time, now - previous.time < 1, !jumping {
            let instantaneous = (position - previous.position) / max(0.001, now - previous.time)
            velocity = instantaneous * velocity < 0 ? instantaneous : velocity * 0.75 + instantaneous * 0.25
        }
        previous = (position, now)
        if let intentVelocity, intentVelocity != 0 { velocity = intentVelocity }
        if settled || jumping { velocity = 0 }
        let focus = jumping ? min(count - 1, max(0, Int(target!.rounded()))) : center
        let active = jumping ? Set(max(0, focus - radius)...min(count - 1, focus + radius)) : visible
        let minimum = jumping ? max(0, focus - radius) : active.min() ?? focus
        let maximum = jumping ? min(count - 1, focus + radius) : active.max() ?? focus
        let ahead = settled || jumping ? configuration.reserve : min(configuration.maximumAhead, max(configuration.minimumAhead, Int(ceil(abs(velocity) * min(1.2, max(0.3, latency)))) + configuration.minimumAhead))
        let before = settled || velocity >= 0 ? configuration.reserve : ahead
        let after = settled || velocity <= 0 ? configuration.reserve : ahead
        let resources = Set(max(0, minimum - before)...min(count - 1, maximum + after))
        return Demand(center: focus, visible: active, prefetch: resources.subtracting(active), settled: settled)
    }
}
