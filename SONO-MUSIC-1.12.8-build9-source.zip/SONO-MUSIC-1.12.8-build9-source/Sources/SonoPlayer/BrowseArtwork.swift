import AppKit
import ImageIO
import CryptoKit

/// These two artwork CDN shards serve the same content-addressed paths. Keep
/// demand/cache identity when metadata swaps shards. Transport URLs stay intact;
/// other origins and every path/query remain distinct.
enum ArtworkResource {
    static func identity(_ url: URL) -> String {
        let value = url.absoluteString
        let prefix = "https://p4.music.126.net/"
        guard value.hasPrefix(prefix) else { return value }
        return "https://p3.music.126.net/" + value.dropFirst(prefix.count)
    }
    static func matches(_ old: URL?, _ new: URL) -> Bool {
        guard let old else { return false }
        return old == new || identity(old) == identity(new)
    }
    static func alternateCacheRequest(_ request: URLRequest) -> URLRequest? {
        guard let url = request.url, url.scheme == "https",
              let host = url.host, host == "p3.music.126.net" || host == "p4.music.126.net",
              var parts = URLComponents(url: url, resolvingAgainstBaseURL: false) else { return nil }
        parts.host = host == "p3.music.126.net" ? "p4.music.126.net" : "p3.music.126.net"
        var alternate = request; alternate.url = parts.url
        return alternate
    }
}

/// A decoded presentation is reusable only for the same window backing profile.
struct ArtworkPresentation: @unchecked Sendable {
    let colorSpace: CGColorSpace
    let key: String
    init?(_ space: NSColorSpace) {
        guard let colorSpace = space.cgColorSpace, colorSpace.model == .rgb, let data = space.iccProfileData else { return nil }
        self.colorSpace = colorSpace
        key = SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
    }
    static func identity(_ url: URL, _ presentation: ArtworkPresentation?) -> String {
        let version: String
        if url.isFileURL, let values = try? FileManager.default.attributesOfItem(atPath:url.path) {
            version = "@file:\((values[.modificationDate] as? Date)?.timeIntervalSince1970 ?? 0):\((values[.size] as? NSNumber)?.intValue ?? 0)"
        } else { version = "" }
        return ArtworkResource.identity(url) + version + (presentation.map { "@profile:" + $0.key } ?? "")
    }
}

final class ArtworkTransferMetrics: NSObject, URLSessionTaskDelegate, @unchecked Sendable {
    let requestID: String
    let category: String
    init(_ requestID: String, category: String = "artwork") { self.requestID = requestID; self.category = category }
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest, completionHandler: @escaping @Sendable (URLRequest?) -> Void) {
        completionHandler(category == "account" ? nil : request)
    }
    func urlSession(_ session: URLSession, task: URLSessionTask, didFinishCollecting metrics: URLSessionTaskMetrics) {
        for (index, transaction) in metrics.transactionMetrics.enumerated() {
            func interval(_ start: Date?, _ end: Date?) -> String {
                guard let start, let end else { return "unavailable" }
                return String(max(0, end.timeIntervalSince(start)) * 1000)
            }
            BrowseDiagnostics.shared.mark(category + ".transaction", fields: [
                "request": requestID, "transaction": String(index), "redirects": String(metrics.redirectCount),
                "dnsMs": interval(transaction.domainLookupStartDate, transaction.domainLookupEndDate),
                "connectMs": interval(transaction.connectStartDate, transaction.connectEndDate),
                "tlsMs": interval(transaction.secureConnectionStartDate, transaction.secureConnectionEndDate),
                "firstByteMs": interval(transaction.requestStartDate, transaction.responseStartDate),
                "bodyMs": interval(transaction.responseStartDate, transaction.responseEndDate),
                "protocol": transaction.networkProtocolName ?? "unavailable", "reused": String(transaction.isReusedConnection),
                "fetchType": String(transaction.resourceFetchType.rawValue), "bytes": String(transaction.countOfResponseBodyBytesReceived)])
            if transaction.resourceFetchType == .localCache { BrowseDiagnostics.shared.count("http.cacheHit"); continue }
            guard transaction.resourceFetchType == .networkLoad else { continue }
            BrowseDiagnostics.shared.count("http.networkLoad")
            if let name = transaction.networkProtocolName { BrowseDiagnostics.shared.count("http.protocol." + name) }
            func span(_ key: String, _ from: Date?, _ to: Date?) {
                if let from, let to { BrowseDiagnostics.shared.record(key, max(0, to.timeIntervalSince(from)) * 1000) }
            }
            span("http.dns", transaction.domainLookupStartDate, transaction.domainLookupEndDate)
            span("http.connect", transaction.connectStartDate, transaction.connectEndDate)
            span("http.responseWait", transaction.requestEndDate, transaction.responseStartDate)
            span("http.bodyTransfer", transaction.responseStartDate, transaction.responseEndDate)
            BrowseDiagnostics.shared.count("http.responseBytes", by: Int(max(0, transaction.countOfResponseBodyBytesReceived)))
        }
    }
}

// Six ordinary resources plus one center slot hide network latency. ImageIO
// has its own two-worker budget, independent of network admission.
final class ArtworkLoadOperation: Operation, @unchecked Sendable {
    private let lock = NSRecursiveLock()
    private var runningState = false
    private var finishedState = false
    private var download: URLSessionDataTask?
    private var decoder: BlockOperation?
    private let url: URL
    var resourceURL: URL { url }
    var cacheIdentity: String { ArtworkPresentation.identity(url, presentation) }
    private var targetPixels: Int
    private var stagePixels: Int
    private let progressive: Bool
    private let partial: @Sendable (ArtworkBitmap?) -> Void
    private var transientFailure = false
    var requestedPixels: Int { lock.withLock { targetPixels } }
    var decodedStagePixels: Int { lock.withLock { stagePixels } }
    var retryableFailure: Bool { lock.withLock { transientFailure } }
    func promote(to pixels: Int) { lock.withLock { targetPixels = max(targetPixels, pixels) } }
    private let presentation: ArtworkPresentation?
    let originalOnly: Bool
    private var cachedPreview: ArtworkBitmap?
    private let session: URLSession
    private let completion: @Sendable (ArtworkBitmap?) -> Void
    private let networkNeeded: @Sendable () -> Void
    private let transferFinished: @Sendable (Int, Int) -> Void
    private var preparedRequest: URLRequest?
    private var phaseName = "queued"
    var diagnosticPhase: String { lock.withLock { phaseName } }
    fileprivate let diagnosticID: String? = BrowseDiagnostics.shared.enabled ? UUID().uuidString : nil
    init(url: URL, pixels: Int, session: URLSession = .shared, presentation: ArtworkPresentation? = nil, cachedPreview: ArtworkBitmap? = nil, progressive: Bool = false, originalOnly: Bool = false, partial: @escaping @Sendable (ArtworkBitmap?) -> Void = { _ in }, networkNeeded: @escaping @Sendable () -> Void,
         transferFinished: @escaping @Sendable (Int, Int) -> Void, completion: @escaping @Sendable (ArtworkBitmap?) -> Void) {
        self.url = url; targetPixels = pixels; stagePixels = pixels; self.session = session; self.cachedPreview = cachedPreview; self.presentation = presentation
        self.originalOnly = originalOnly
        self.progressive = progressive; self.partial = partial
        self.networkNeeded = networkNeeded; self.transferFinished = transferFinished; self.completion = completion
        super.init()
        var group = URLComponents(string: ArtworkResource.identity(url))
        group?.query = nil; group?.fragment = nil
        trace("demand", fields: ["variantGroup": BrowseDiagnostics.shared.enabled ? BrowseDiagnostics.shared.resourceID("path:" + (group?.string ?? "")) : "disabled"])
    }
    override var isAsynchronous: Bool { true }
    override var isExecuting: Bool { lock.withLock { runningState } }
    override var isFinished: Bool { lock.withLock { finishedState } }
    private static let decoders: OperationQueue = {
        let queue = OperationQueue(); queue.name = "Sono.ArtworkDecode"
        queue.maxConcurrentOperationCount = 2; queue.qualityOfService = .userInitiated
        return queue
    }()
    func prioritize(center: Bool, visible: Bool = true, prefetch: Bool = false) {
        let priority: Operation.QueuePriority = center && visible ? .veryHigh : visible ? .normal : prefetch ? .low : .veryLow
        // Camera distance changes reorder waiting demand without changing the
        // resource's priority class. Avoid redundant Foundation/KVO/task writes.
        guard queuePriority != priority else { return }
        queuePriority = priority
        lock.withLock {
            download?.priority = center ? URLSessionTask.highPriority : visible ? URLSessionTask.defaultPriority : URLSessionTask.lowPriority
            decoder?.queuePriority = queuePriority
        }
    }
    private let queuedAt = BrowseDiagnostics.shared.start()
    override func start() {
        trace("cacheReadStarted")
        BrowseDiagnostics.shared.end("artwork.queueWait", queuedAt)
        BrowseDiagnostics.shared.end("artwork.queueWait." + diagnosticTier, queuedAt)
        let shouldStart = lock.withLock {
            guard !isCancelled, !finishedState else { return false }
            willChangeValue(forKey: "isExecuting"); runningState = true; didChangeValue(forKey: "isExecuting")
            return true
        }
        guard shouldStart else { finish(nil); return }
        // Never hold the state lock during IO/decoding: cancel() runs on the UI thread.
        prepareStage(first: true)
    }
    private func remoteRequest(pixels: Int) -> URLRequest? {
        guard url.scheme == "https", var components = URLComponents(url: url, resolvingAgainstBaseURL: false) else { return nil }
        if let host = components.host, host == "music.126.net" || host.hasSuffix(".music.126.net") {
            components.queryItems = (components.queryItems ?? []).filter { $0.name != "param" } + [URLQueryItem(name: "param", value: "\(min(1200, pixels))y\(min(1200, pixels))")]
        }
        guard let requestURL = components.url else { return nil }
        // Cover URLs identify the artwork; revisiting a region must not revalidate
        // an already downloaded size just because its decoded bitmap was evicted.
        var request = URLRequest(url: requestURL, cachePolicy: .returnCacheDataElseLoad); request.timeoutInterval = 15
        return request
    }
    private func cachedResponse(_ request: URLRequest) -> CachedURLResponse? {
        let cacheRead = BrowseDiagnostics.shared.start()
        let cache = session.configuration.urlCache
        let cached = cache?.cachedResponse(for: request) ?? ArtworkResource.alternateCacheRequest(request).flatMap { cache?.cachedResponse(for: $0) }
        BrowseDiagnostics.shared.end("artwork.encodedCacheRead", cacheRead)
        guard let cached, let response = cached.response as? HTTPURLResponse,
              (200..<300).contains(response.statusCode), cached.data.count <= 12 * 1024 * 1024 else { return nil }
        return cached
    }
    private func cachedLargerRendition(pixels: Int) -> CachedURLResponse? {
        // Only the CDN's existing resize parameter varies here. Keep the path,
        // all other query variants and shard matching used by exact cache reads.
        guard pixels < 1200, let host = url.host,
              host == "music.126.net" || host.hasSuffix(".music.126.net") else { return nil }
        for size in ArtworkPixelSize.steps where size > pixels && size <= 1200 {
            if let request = remoteRequest(pixels:size), let cached = cachedResponse(request) {
                BrowseDiagnostics.shared.count("artwork.largerEncodedCacheHit")
                return cached
            }
        }
        return nil
    }
    private func prepareStage(first: Bool) {
        guard !isCancelled else { finish(nil); return }
        let target = requestedPixels
        lock.withLock { stagePixels = target; transientFailure = false }
        if url.isFileURL { transferFinished(0, decodedStagePixels); enqueueDecode(data: nil); return }
        guard let targetRequest = remoteRequest(pixels: target) else { finish(nil); return }
        if let cached = cachedResponse(targetRequest) ?? cachedLargerRendition(pixels:target) {
            trace("cacheHit", fields: ["bytes": String(cached.data.count)])
            BrowseDiagnostics.shared.count("artwork.diskOrEncodedCacheHit")
            transferFinished(cached.data.count, decodedStagePixels)
            enqueueDecode(data: cached.data)
            return
        }
        let host = url.host ?? ""
        let staged = first && progressive && cachedPreview == nil && target > 192 && (host == "music.126.net" || host.hasSuffix(".music.126.net"))
        let pixels = staged ? 192 : target
        lock.withLock { stagePixels = pixels }
        guard let request = remoteRequest(pixels: pixels) else { finish(nil); return }
        if staged, let cached = cachedResponse(request) {
            trace("cacheHit", fields: ["bytes": String(cached.data.count)])
            BrowseDiagnostics.shared.count("artwork.diskOrEncodedCacheHit")
            transferFinished(cached.data.count, decodedStagePixels); enqueueDecode(data: cached.data); return
        }
        lock.withLock { preparedRequest = request }
        trace("networkAdmissionQueued")
        networkNeeded()
    }
    // The same operation owns both qualities, including a prefetched 192px task
    // promoted by a newly visible consumer. The store releases the decode budget
    // before scheduling this continuation; no UI-thread cache IO is introduced.
    func continueAfterPreview(_ bitmap: ArtworkBitmap?, requiredPixels: Int) {
        if requiredPixels <= decodedStagePixels { finish(bitmap); return }
        lock.withLock { targetPixels = requiredPixels; if cachedPreview == nil { cachedPreview = bitmap?.preview } }
        let operation = BlockOperation { [self] in prepareStage(first: false) }
        lock.withLock { decoder = operation; operation.queuePriority = queuePriority }
        if isCancelled { operation.cancel(); finish(nil) } else { Self.decoders.addOperation(operation) }
    }
    private func trace(_ stage: String, fields: [String: String] = [:]) {
        switch stage {
        case "cacheReadStarted": lock.withLock { phaseName = "cache-read" }
        case "networkAdmissionQueued": lock.withLock { phaseName = "network-queued" }
        case "transferStarted": lock.withLock { phaseName = "downloading" }
        case "decodeQueued": lock.withLock { phaseName = "decode-queued" }
        case "decodeStarted": lock.withLock { phaseName = "decoding" }
        case "decodeFinished": lock.withLock { phaseName = "delivering" }
        case "cancelled": lock.withLock { phaseName = "cancelled" }
        default: break
        }
        if let diagnosticID { BrowseDiagnostics.shared.mark("artwork." + stage, fields: fields.merging(["request": diagnosticID, "resource": BrowseDiagnostics.shared.resourceID(ArtworkResource.identity(url)), "requestedPixels": String(requestedPixels), "stagePixels": String(decodedStagePixels)]) { _, new in new }) }
    }
    func startNetwork() {
        guard !isCancelled, let request = lock.withLock({ preparedRequest }) else { finish(nil); return }
        let cacheRequest = request
        let networkStart = BrowseDiagnostics.shared.start()
        trace("transferStarted", fields: ["tier": diagnosticTier])
        let task = session.dataTask(with: request) { [weak self] data, response, error in
            guard let self else { return }
            BrowseDiagnostics.shared.end("artwork.network", networkStart)
            BrowseDiagnostics.shared.end("artwork.network." + diagnosticTier, networkStart)
            if let diagnosticID { BrowseDiagnostics.shared.mark("artwork.transferFinished", fields: ["request": diagnosticID, "tier": diagnosticTier, "bytes": String(data?.count ?? 0), "status": String((response as? HTTPURLResponse)?.statusCode ?? 0), "success": String(error == nil && (response as? HTTPURLResponse).map { (200..<300).contains($0.statusCode) } == true)]) }
            guard !isCancelled, let response = response as? HTTPURLResponse, (200..<300).contains(response.statusCode), let data, data.count <= 12 * 1024 * 1024 else {
                let status = (response as? HTTPURLResponse)?.statusCode ?? 0
                let code = (error as? URLError)?.code
                lock.withLock { transientFailure = (500..<600).contains(status) || code.map { [.timedOut, .networkConnectionLost, .notConnectedToInternet, .cannotConnectToHost, .cannotFindHost, .dnsLookupFailed].contains($0) } == true }
                if let error = error as? URLError { BrowseDiagnostics.shared.count("artwork.networkError.\(error.code.rawValue)") }
                completeStage(nil); return
            }
            // URLSession's delegate queue must not be occupied by image decoding.
            transferFinished(data.count, decodedStagePixels)
            enqueueDecode(data: data, cacheRequest: cacheRequest, cacheResponse: response)
        }
        if BrowseDiagnostics.shared.enabled { task.delegate = ArtworkTransferMetrics(diagnosticID ?? "unavailable") }
        lock.withLock {
            download = task
            task.priority = queuePriority == .veryHigh ? URLSessionTask.highPriority : queuePriority.rawValue < Operation.QueuePriority.normal.rawValue ? URLSessionTask.lowPriority : URLSessionTask.defaultPriority
        }
        if isCancelled { task.cancel(); finish(nil) } else { task.resume() }
    }
    override func cancel() {
        if let diagnosticID { BrowseDiagnostics.shared.mark("artwork.cancelled", fields: ["request": diagnosticID]) }
        super.cancel()
        let task = lock.withLock { download }
        task?.cancel()
        lock.withLock { decoder?.cancel() }
        // Unprepared requests have no queue owner to call start() after removal.
        // Complete their lifecycle too, so cancellation releases every stage.
        finish(nil)
    }
    private func enqueueDecode(data: Data?, cacheRequest: URLRequest? = nil, cacheResponse: HTTPURLResponse? = nil) {
        let queued = BrowseDiagnostics.shared.start()
        trace("decodeQueued")
        let operation = BlockOperation { [self] in
            BrowseDiagnostics.shared.end("artwork.decodeQueueWait", queued)
            BrowseDiagnostics.shared.end("artwork.decodeQueueWait." + diagnosticTier, queued)
            decode(data: data, cacheRequest: cacheRequest, cacheResponse: cacheResponse)
        }
        lock.withLock { decoder = operation; operation.queuePriority = queuePriority }
        if isCancelled { operation.cancel(); finish(nil) }
        else { Self.decoders.addOperation(operation) }
    }
    private var diagnosticTier: String { queuePriority == .veryHigh ? "center" : queuePriority == .low ? "prefetch" : queuePriority == .veryLow ? "background" : "visible" }
    #if DEBUG
    static var validationDecodeWorkers: OperationQueue { decoders }
    #endif
    private func decode(data: Data?, cacheRequest: URLRequest? = nil, cacheResponse: HTTPURLResponse? = nil) {
        trace("decodeStarted")
        let measurement = BrowseDiagnostics.shared.start(); defer { trace("decodeFinished"); BrowseDiagnostics.shared.end(url.isFileURL ? "artwork.localReadAndDecode" : "artwork.remoteDecode", measurement) }
        guard !isCancelled else { finish(nil); return }
        let bitmap: ArtworkBitmap? = autoreleasepool {
            let options = [kCGImageSourceShouldCache: false] as CFDictionary
            let readStart = BrowseDiagnostics.shared.start()
            // Invalid downloaded data must never fall back to ImageIO opening an HTTPS URL.
            let source: CGImageSource?
            if let data { source = CGImageSourceCreateWithData(data as CFData, options) }
            else if url.isFileURL { source = CGImageSourceCreateWithURL(url as CFURL, options) }
            else { source = nil }
            BrowseDiagnostics.shared.end("artwork.sourceOpen", readStart)
            guard !isCancelled else { return nil }
            guard let source else { BrowseDiagnostics.shared.count("artwork.invalidImageSource"); return nil }
            let properties = CGImageSourceCopyPropertiesAtIndex(source, 0, nil) as? [CFString: Any]
            trace("responseImage", fields: ["width": String(properties?[kCGImagePropertyPixelWidth] as? Int ?? 0),
                "height": String(properties?[kCGImagePropertyPixelHeight] as? Int ?? 0),
                "format": CGImageSourceGetType(source).map { $0 as String } ?? "unavailable", "orientation": String(properties?[kCGImagePropertyOrientation] as? Int ?? 1), "bytes": data.map { String($0.count) } ?? "unavailable"])
            let decodeStart = BrowseDiagnostics.shared.start()
            defer { BrowseDiagnostics.shared.end("artwork.thumbnailDecode", decodeStart) }
            guard let image = CGImageSourceCreateThumbnailAtIndex(source, 0, [kCGImageSourceCreateThumbnailFromImageAlways: true, kCGImageSourceCreateThumbnailWithTransform: true, kCGImageSourceThumbnailMaxPixelSize: decodedStagePixels, kCGImageSourceShouldCacheImmediately: true] as CFDictionary) else { BrowseDiagnostics.shared.count("artwork.thumbnailFailure"); return nil }
            if originalOnly { return ArtworkBitmap(image, original: image) }
            // Keep a small decoded rendition for revisiting culled wall regions.
            // Generate it here, alongside the full decode, never on the UI thread.
            let preview: ArtworkBitmap?
            if let cachedPreview = lock.withLock({ self.cachedPreview }) {
                // Upgrades and revisits share the existing compact bitmap. The
                // full-size decode above is unchanged; do not decode 96px again.
                BrowseDiagnostics.shared.count("artwork.previewDecodeAvoided")
                preview = cachedPreview
            } else {
                let previewStart = BrowseDiagnostics.shared.start()
                if let compact = ArtworkBitmap.compactPreview(image, presentation: presentation) {
                    preview = ArtworkBitmap(compact)
                    BrowseDiagnostics.shared.count("artwork.previewFromDecodedImage")
                } else {
                    preview = CGImageSourceCreateThumbnailAtIndex(source, 0, [kCGImageSourceCreateThumbnailFromImageAlways: true,
                    kCGImageSourceCreateThumbnailWithTransform: true, kCGImageSourceThumbnailMaxPixelSize: 96,
                    kCGImageSourceShouldCacheImmediately: true] as CFDictionary).map { ArtworkBitmap(ArtworkBitmap.preparedForLayer($0, presentation: presentation)) }
                }
                BrowseDiagnostics.shared.end("artwork.previewDecode", previewStart)
            }
            return ArtworkBitmap(ArtworkBitmap.preparedForLayer(image, presentation: presentation), preview: preview, original: image)
        }
        // Only successful image data enters our reusable encoded cache; malformed
        // responses never become a successful cover or trigger another download.
        if bitmap != nil, !isCancelled, let data, let cacheRequest, let cacheResponse {
            session.configuration.urlCache?.storeCachedResponse(CachedURLResponse(response: cacheResponse, data: data, storagePolicy: .allowed), for: cacheRequest)
        }
        completeStage(isCancelled ? nil : bitmap)
    }
    private func completeStage(_ bitmap: ArtworkBitmap?) {
        guard !isCancelled else { finish(nil); return }
        if decodedStagePixels < requestedPixels { partial(bitmap) }
        else { finish(bitmap) }
    }
    private func finish(_ bitmap: ArtworkBitmap?) {
        let deliver = lock.withLock {
            guard !finishedState else { return false }
            if runningState { willChangeValue(forKey: "isExecuting") }
            willChangeValue(forKey: "isFinished")
            let wasExecuting = runningState; runningState = false; finishedState = true; download = nil; decoder = nil
            didChangeValue(forKey: "isFinished"); if wasExecuting { didChangeValue(forKey: "isExecuting") }
            return true
        }
        if deliver { completion(bitmap) }
    }
}

final class ArtworkBitmap: @unchecked Sendable {
    let image: CGImage
    let preview: ArtworkBitmap?
    let original: CGImage?
    let isBlankBlack: Bool
    init(_ image: CGImage, preview: ArtworkBitmap? = nil, original: CGImage? = nil) {
        self.image = image; self.preview = preview; self.original = original
        self.isBlankBlack = Self.blankBlack(image)
    }
    private static func blankBlack(_ image: CGImage) -> Bool {
        // Classify once per decoded bitmap, never during scrolling. Only a uniformly
        // near-zero image qualifies; dark artwork with visible details stays intact.
        guard let context = CGContext(data: nil, width: 64, height: 64, bitsPerComponent: 8, bytesPerRow: 256,
            space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue),
              let data = context.data else { return false }
        context.interpolationQuality = .high
        context.draw(image, in: CGRect(x: 0, y: 0, width: 64, height: 64))
        let pixels = data.assumingMemoryBound(to: UInt8.self)
        return (0..<4096).allSatisfy { index in
            let offset = index * 4
            return pixels[offset] <= 2 && pixels[offset + 1] <= 2 && pixels[offset + 2] <= 2
        }
    }
    // The full thumbnail is already decoded and EXIF-oriented. Downsample it
    // once for the revisit cache instead of decompressing the source a second
    // time before delivering the full cover. Keep unusual formats on ImageIO's
    // original path rather than reducing their bit depth or changing color models.
    static func compactPreview(_ image: CGImage, presentation: ArtworkPresentation? = nil) -> CGImage? {
        guard image.bitsPerComponent == 8, let space = image.colorSpace, space.model == .rgb else { return nil }
        let scale = min(1, 96.0 / Double(max(image.width, image.height)))
        let width = max(1, Int((Double(image.width) * scale).rounded()))
        let height = max(1, Int((Double(image.height) * scale).rounded()))
        let format = CGBitmapInfo.byteOrder32Little.rawValue | CGImageAlphaInfo.premultipliedFirst.rawValue
        guard let context = CGContext(data: nil, width: width, height: height, bitsPerComponent: 8, bytesPerRow: 0,
                                      space: presentation?.colorSpace ?? space, bitmapInfo: format) else { return nil }
        context.interpolationQuality = .high
        context.setBlendMode(.copy)
        context.draw(image, in: CGRect(x: 0, y: 0, width: width, height: height))
        return context.makeImage()
    }
    // Materialize common 8-bit RGB images on the decode worker in native BGRA
    // storage. Use the actual backing profile when supplied; retain dimensions. Higher bit-depth and
    // non-RGB images retain their original representation.
    static func preparedForLayer(_ image: CGImage, presentation: ArtworkPresentation? = nil) -> CGImage {
        guard image.bitsPerComponent == 8, let colorSpace = image.colorSpace, colorSpace.model == .rgb else { return image }
        let format = CGBitmapInfo.byteOrder32Little.rawValue | CGImageAlphaInfo.premultipliedFirst.rawValue
        let targetSpace = presentation?.colorSpace ?? colorSpace
        if image.bitmapInfo.rawValue == format && CFEqual(colorSpace, targetSpace) { return image }
        let measurement = BrowseDiagnostics.shared.start()
        defer { BrowseDiagnostics.shared.end("artwork.layerBitmapPreparation", measurement) }
        guard let context = CGContext(data: nil, width: image.width, height: image.height, bitsPerComponent: 8, bytesPerRow: 0,
                                      space: targetSpace, bitmapInfo: format) else {
            BrowseDiagnostics.shared.count("artwork.layerBitmapPreparationUnavailable")
            return image
        }
        context.setBlendMode(.copy)
        context.draw(image, in: CGRect(x: 0, y: 0, width: image.width, height: image.height))
        guard let prepared = context.makeImage() else { return image }
        return prepared
    }
    var cost: Int { image.bytesPerRow * image.height + (preview?.cost ?? 0) }
}

enum ArtworkPixelSize {
    // Share renditions across resting/reflowed/expanded cards instead of requesting
    // a new size at each geometry change. Keep the existing upper decode limits.
    static let steps = [128, 192, 256, 320, 448, 512, 640, 768, 896, 1024, 1200, 1440]
    static func bucket(_ pixels: Int) -> Int { steps.first { $0 >= pixels } ?? 1440 }
    static func demand(width: CGFloat, height: CGFloat, scale: CGFloat, source: CGSize? = nil, remote: Bool = false) -> Int {
        let source = source ?? CGSize(width: 1, height: 1)
        let fill = max(width * scale / max(1, source.width), height * scale / max(1, source.height))
        return min(remote ? 1200 : 1440, bucket(max(1, Int(ceil(fill * max(source.width, source.height))))))
    }
}

/// Independent bounded cache-read, network and decode lanes; one reserved visible-center slot.
@MainActor
final class BrowseArtworkStore {
    static let shared = BrowseArtworkStore(backgroundLimit: ProcessInfo.processInfo.environment["SONO_CAROUSEL_BACKGROUND_LIMIT"] == "2" ? 2 : 1)
    private static func makeSession() -> URLSession {
        let fallback = ProcessInfo.processInfo.environment["SONO_ARTWORK_CACHE_ROOT"].map { URL(fileURLWithPath: $0, isDirectory: true) } ?? FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
            .appendingPathComponent((Bundle.main.bundleIdentifier ?? "app.sono.native.preview") + "/Artwork", isDirectory: true)
        let root = PerformanceEnvironment.cacheDirectory(default:fallback,subdirectory:"Artwork")
        let configuration = URLSessionConfiguration.default
        configuration.urlCache = URLCache(memoryCapacity: 16 * 1024 * 1024, diskCapacity: 256 * 1024 * 1024, directory: root)
        configuration.requestCachePolicy = .returnCacheDataElseLoad
        configuration.httpMaximumConnectionsPerHost = 7
        return URLSession(configuration: configuration)
    }
    private let session: URLSession
    // NSCache's cost limit is advisory. Keep bitmap ownership within a hard byte
    // budget; images retained by visible layers are measured separately.
    private struct Cached {
        let bitmap: ArtworkBitmap
        var access: UInt64
    }
    private struct BitmapCache {
        var entries: [String: Cached] = [:]
        var bytes = 0
        var clock: UInt64 = 0
        var byteLimit: Int
        let countLimit: Int
        mutating func resize(to limit: Int) {
            byteLimit = max(0, limit)
            while bytes > byteLimit {
                guard let oldest = entries.min(by: { $0.value.access < $1.value.access }) else { break }
                bytes -= oldest.value.bitmap.cost; entries[oldest.key] = nil
            }
        }
        mutating func read(_ key: String) -> ArtworkBitmap? {
            guard var entry = entries[key] else { return nil }
            clock &+= 1; entry.access = clock; entries[key] = entry
            return entry.bitmap
        }
        mutating func insert(_ bitmap: ArtworkBitmap, for key: String) {
            guard bitmap.cost <= byteLimit else { return }
            if let previous = entries.removeValue(forKey: key) { bytes -= previous.bitmap.cost }
            while entries.count >= countLimit || bytes + bitmap.cost > byteLimit {
                guard let oldest = entries.min(by: { $0.value.access < $1.value.access }) else { break }
                bytes -= oldest.value.bitmap.cost; entries[oldest.key] = nil
            }
            clock &+= 1; entries[key] = Cached(bitmap: bitmap, access: clock); bytes += bitmap.cost
        }
    }
    private var sourceSizes: [String: CGSize] = [:]
    func sourceSize(_ url: URL) -> CGSize? { sourceSizes[ArtworkResource.identity(url)] }
    // Retain roughly forty 896px Retina covers; pressure events shrink ownership.
    static let defaultBitmapBudget = 128 * 1024 * 1024
    private let bitmapBudget: Int
    private var cache: BitmapCache
    private var pressureSource: DispatchSourceMemoryPressure?
    // Full Retina images churn after only a few viewports. A separate bounded
    // rendition cache keeps visited covers immediately displayable after culling.
    private var previews = BitmapCache(byteLimit: 64 * 1024 * 1024, countLimit: 2048)
    private let workers: OperationQueue = {
        let queue = OperationQueue(); queue.name = "Sono.ArtworkCacheRead"; queue.maxConcurrentOperationCount = 2
        queue.qualityOfService = .userInitiated
        return queue
    }()
    private struct Subscriber {
        var center: Bool
        var prefetch: Bool
        var visible: Bool
        var distance: CGFloat
        var centerDistance: CGFloat
        let pixels: Int
        var hasImage: Bool
        var nearby: Bool = false
        var original: Bool = false
        let preview: ((ArtworkBitmap) -> Void)?
        let completion: (ArtworkBitmap?) -> Void
    }
    private struct Request {
        let generation: UUID
        let operation: ArtworkLoadOperation
        var subscribers: [UUID: Subscriber]
        let order: UInt64
        let resource: String
        let progressive: Bool
        var submitted = false
        var networkReady = false
        var networkSubmitted = false
        var networkQueuedAt: CFTimeInterval?
        var completedPixels = 0
    }
    private struct DerivedDisplay {
        var subscribers: [UUID: Subscriber]
        var request: UUID?
        var task: Task<Void, Never>?
    }
    private var derivedDisplays: [String: DerivedDisplay] = [:]
    private var derivedKeys: [UUID: String] = [:]
    private var pending: [String: Request] = [:]
    private var keys: [UUID: String] = [:]
    private var running: Set<UUID> = []
    private var preparing: Set<UUID> = []
    private var operations: [UUID: ArtworkLoadOperation] = [:]
    private var decodingBytes: [UUID: Int] = [:]
    private var requestOrder: UInt64 = 0
    private let backgroundLimit: Int
    private var failures: [String: Bool] = [:]
    private var updateDepth = 0
    private var schedulingPending = false
    // Publish a complete scene demand before filling vacant resource slots.
    func updateRequests(_ update: () -> Void) {
        updateDepth += 1
        defer {
            updateDepth -= 1
            if updateDepth == 0 && schedulingPending { schedule() }
        }
        update()
    }
    init(session: URLSession? = nil, bitmapBudget: Int = BrowseArtworkStore.defaultBitmapBudget, backgroundLimit: Int = 1) {
        self.session = session ?? Self.makeSession()
        self.bitmapBudget = max(0, bitmapBudget)
        self.backgroundLimit = min(2, max(1, backgroundLimit))
        cache = BitmapCache(byteLimit: max(0, bitmapBudget), countLimit: 160)
        let source = DispatchSource.makeMemoryPressureSource(eventMask: [.normal, .warning, .critical], queue: .main)
        pressureSource = source
        source.setEventHandler { [weak self] in
            MainActor.assumeIsolated {
                guard let self, let pressure = self.pressureSource?.data else { return }
                self.applyMemoryPressure(pressure)
            }
        }
        source.resume()
    }
    isolated deinit { pressureSource?.cancel() }

    private func applyMemoryPressure(_ pressure: DispatchSource.MemoryPressureEvent) {
        let critical = pressure.contains(.critical), warning = pressure.contains(.warning)
        cache.resize(to: critical ? 0 : warning ? min(bitmapBudget, 24 * 1024 * 1024) : bitmapBudget)
        previews.resize(to: critical ? 0 : warning ? 16 * 1024 * 1024 : 64 * 1024 * 1024)
        // Visible layers retain their images; only reusable cache ownership shrinks.
        BrowseDiagnostics.shared.count("artwork.memoryPressureTrim")
    }
    @discardableResult
    func request(_ url: URL, pixels: Int, center: Bool, visible: Bool = true, prefetch: Bool = false, progressive: Bool = false, hasImage: Bool = false, nearby: Bool = false, presentation: ArtworkPresentation? = nil, originalOnly: Bool = false, distance: CGFloat = .greatestFiniteMagnitude, centerDistance: CGFloat = .greatestFiniteMagnitude, preview: ((ArtworkBitmap) -> Void)? = nil, completion: @escaping (ArtworkBitmap?) -> Void) -> UUID? {
        BrowseDiagnostics.shared.count("artwork.request")
        let pixels = ArtworkPixelSize.bucket(pixels)
        let resource = ArtworkPresentation.identity(url, presentation)
        var hasImage = hasImage
        // A larger decoded image can satisfy a smaller consumer without another decode.
        let sizes = originalOnly ? [] : ArtworkPixelSize.steps.filter { $0 >= pixels }
        for size in sizes {
            if let bitmap = cache.read(resource + "#\(size)") {
                BrowseDiagnostics.shared.count("artwork.cacheHit"); completion(bitmap); return nil
            }
        }
        if let preview {
            var available: ArtworkBitmap?
            for size in ArtworkPixelSize.steps.reversed() where size < pixels {
                if let bitmap = cache.read(resource + "#\(size)") { available = bitmap; break }
            }
            if let bitmap = available ?? previews.read(resource) {
                hasImage = true
                BrowseDiagnostics.shared.count("artwork.previewCacheHit"); preview(bitmap)
            }
        }
        // Terminal page failures survive card recycling. Only the scene's
        // explicit, once-per-page transient recovery removes this record.
        if progressive, failures[resource] != nil {
            Task { @MainActor in completion(nil) }
            return nil
        }
        let displayKey = resource + "#\(pixels)"
        if !originalOnly, derivedDisplays[displayKey] != nil || (!originalOnly && pending.values.contains(where: {
            $0.operation.originalOnly && $0.resource == ArtworkPresentation.identity(url,nil) && $0.operation.requestedPixels == pixels
        })) {
            return displayFromOriginal(url, pixels:pixels, presentation:presentation, key:displayKey, subscriber:Subscriber(center:center,prefetch:prefetch,visible:visible,distance:distance,centerDistance:centerDistance,pixels:pixels,hasImage:hasImage,nearby:nearby,preview:preview,completion:completion))
        }
        let reusable: (Request) -> Bool = { $0.operation.originalOnly == originalOnly && (!$0.operation.isFinished || $0.operation.decodedStagePixels >= pixels) }
        let shared = sizes.map { resource + "#\($0)" }.first { pending[$0].map(reusable) == true }
            ?? (progressive ? pending.first { $0.value.resource == resource && reusable($0.value) }?.key : nil)
        let key = shared ?? resource + "#\(pixels)" + (originalOnly ? "@original" : "")
        let token = UUID(); keys[token] = key
        if pending[key] != nil {
            pending[key]?.subscribers[token] = Subscriber(center: center, prefetch: prefetch, visible: visible, distance: distance, centerDistance: centerDistance, pixels: pixels, hasImage: hasImage, nearby: nearby, original: originalOnly, preview: preview, completion: completion)
            if progressive { pending[key]?.operation.promote(to: pixels) }
            reprioritize(key); schedule()
            return token
        }
        let generation = UUID()
        let operation = ArtworkLoadOperation(url: url, pixels: pixels, session: session, presentation: presentation, cachedPreview: previews.read(resource), progressive: progressive && !hasImage, originalOnly: originalOnly, partial: { [weak self] bitmap in
            Task { @MainActor [weak self] in self?.partial(key, generation: generation, bitmap: bitmap) }
        }, networkNeeded: { [weak self] in
            Task { @MainActor [weak self] in
                guard let self, self.pending[key]?.generation == generation else { return }
                self.preparing.remove(generation)
                self.decodingBytes[generation] = nil
                self.pending[key]?.networkReady = true
                self.pending[key]?.networkSubmitted = false
                self.pending[key]?.networkQueuedAt = BrowseDiagnostics.shared.start()
                self.schedule()
            }
        }, transferFinished: { [weak self] bytes, stagePixels in
            Task { @MainActor [weak self] in
                guard let self, self.operations[generation] != nil,
                      let request = self.pending[key], request.generation == generation,
                      stagePixels > request.completedPixels else { return }
                self.preparing.remove(generation); self.running.remove(generation)
                self.decodingBytes[generation] = bytes
                BrowseDiagnostics.shared.peak("artwork.decodeBacklogPeak", self.decodingBytes.count)
                BrowseDiagnostics.shared.peak("artwork.encodedBacklogBytesPeak", self.decodingBytes.values.reduce(0, +))
                self.schedule()
            }
        }) { [weak self] bitmap in
            let readyAt = BrowseDiagnostics.shared.start()
            Task { @MainActor [weak self] in
                BrowseDiagnostics.shared.end("artwork.mainDeliveryWait", readyAt)
                self?.finish(key, generation: generation, bitmap: bitmap)
            }
        }
        operation.prioritize(center: center, visible: visible, prefetch: prefetch)
        operations[generation] = operation
        requestOrder &+= 1
        pending[key] = Request(generation: generation, operation: operation, subscribers: [token: Subscriber(center: center, prefetch: prefetch, visible: visible, distance: distance, centerDistance: centerDistance, pixels: pixels, hasImage: hasImage, nearby: nearby, original: originalOnly, preview: preview, completion: completion)], order: requestOrder, resource: resource, progressive: progressive)
        BrowseDiagnostics.shared.peak("artwork.pendingPeak", pending.count)
        schedule()
        return token
    }
    /// A display demand arriving during an original-only decode shares that input.
    /// Conversion remains off the UI thread and has independent subscriber ownership.
    private func displayFromOriginal(_ url:URL, pixels:Int, presentation:ArtworkPresentation?, key:String, subscriber:Subscriber) -> UUID {
        let token = UUID(); derivedKeys[token] = key
        if derivedDisplays[key] != nil { derivedDisplays[key]?.subscribers[token] = subscriber; updateDerivedPriority(key); return token }
        derivedDisplays[key] = DerivedDisplay(subscribers:[token:subscriber])
        let resource = ArtworkPresentation.identity(url,presentation)
        let request = requestOriginal(url,pixels:pixels,foreground:subscriber.visible && !subscriber.prefetch) { [weak self] original in
            guard let self, self.derivedDisplays[key] != nil else { return }
            self.derivedDisplays[key]?.request = nil
            let failure = original == nil ? self.failures[ArtworkPresentation.identity(url,nil)] : nil
            let conversion = Task.detached(priority:.userInitiated) { () -> ArtworkBitmap? in
                guard !Task.isCancelled, let original else { return nil }
                return autoreleasepool {
                    let image = ArtworkBitmap.preparedForLayer(original.image,presentation:presentation)
                    let preview = ArtworkBitmap.compactPreview(original.image,presentation:presentation).map { ArtworkBitmap($0) }
                    return ArtworkBitmap(image,preview:preview)
                }
            }
            self.derivedDisplays[key]?.task = Task { [weak self] in
                let result = await withTaskCancellationHandler { await conversion.value } onCancel: { conversion.cancel() }
                guard !Task.isCancelled, let self, let demand = self.derivedDisplays.removeValue(forKey:key) else { return }
                if let result {
                    self.failures[resource] = nil
                    self.cache.insert(result,for:key)
                    BrowseDiagnostics.shared.peak("artwork.cacheBytesPeak",self.cache.bytes)
                    BrowseDiagnostics.shared.peak("artwork.cacheEntriesPeak",self.cache.entries.count)
                    if let preview = result.preview { self.previews.insert(preview,for:resource) }
                    if self.sourceSizes.count >= 4096, let first = self.sourceSizes.keys.first { self.sourceSizes[first] = nil }
                    self.sourceSizes[ArtworkResource.identity(url)] = CGSize(width:result.image.width,height:result.image.height)
                } else if let failure {
                    if self.failures.count >= 4096, let first = self.failures.keys.first { self.failures[first] = nil }
                    self.failures[resource] = failure
                }
                for (subscriber,callback) in demand.subscribers { self.derivedKeys[subscriber] = nil; callback.completion(result) }
                self.deliverForegroundIdleActions()
            }
        }
        derivedDisplays[key]?.request = request
        updateDerivedPriority(key)
        return token
    }
    /// Subscribe before display-profile conversion without retaining originals in the display cache.
    @discardableResult
    func requestOriginal(_ url: URL, pixels: Int, foreground: Bool, completion: @escaping (ArtworkBitmap?) -> Void) -> UUID? {
        let pixels = ArtworkPixelSize.bucket(pixels)
        let resource = ArtworkPresentation.identity(url,nil)
        if let entry = pending.first(where: {
            let published = $0.value.resource.components(separatedBy:"@profile:")[0]
            return published == resource && $0.value.operation.requestedPixels == pixels
        }) {
            let token = UUID(), key = entry.key
            keys[token] = key
            pending[key]?.subscribers[token] = Subscriber(center:foreground,prefetch:!foreground,visible:foreground,distance:0,centerDistance:0,pixels:pixels,hasImage:false,original:true,preview:nil,completion: { bitmap in
                if let original = bitmap?.original { completion(ArtworkBitmap(original)) }
                else { completion(nil) }
            })
            reprioritize(key); schedule(); return token
        }
        return request(url,pixels:pixels,center:foreground,visible:foreground,prefetch:!foreground,originalOnly:true,completion:completion)
    }
    private var foregroundIdleActions:[UUID:() -> Void] = [:]
    @discardableResult func whenForegroundIdle(_ action:@escaping () -> Void) -> UUID? {
        if hasForegroundArtworkWork { let token = UUID(); foregroundIdleActions[token] = action; return token }
        action(); return nil
    }
    func cancelForegroundIdle(_ token:UUID?) { if let token { foregroundIdleActions[token] = nil } }
    private func deliverForegroundIdleActions() {
        guard !hasForegroundArtworkWork, !foregroundIdleActions.isEmpty else { return }
        let tokens = Array(foregroundIdleActions.keys)
        Task { @MainActor in
            for token in tokens {
                guard !self.hasForegroundArtworkWork else { return }
                if let action = self.foregroundIdleActions.removeValue(forKey:token) { action() }
            }
        }
    }
    var hasForegroundArtworkWork: Bool {
        derivedDisplays.values.contains { $0.subscribers.values.contains { $0.visible && !$0.prefetch } } || pending.values.contains { $0.subscribers.values.contains { $0.visible && !$0.prefetch } }
    }
    func availablePreview(_ url: URL, presentation: ArtworkPresentation?) -> ArtworkBitmap? {
        let resource = ArtworkPresentation.identity(url, presentation)
        for size in ArtworkPixelSize.steps.reversed() {
            if let bitmap = cache.read(resource + "#\(size)") { return bitmap }
        }
        return previews.read(resource)
    }
    // Availability probes do not consume a bitmap. Only actual presentation
    // should refresh recency, otherwise scanning a long ready range evicts the
    // covers the user is viewing in favor of distant cached covers.
    func hasAvailablePreview(_ url: URL, presentation: ArtworkPresentation?) -> Bool {
        let resource = ArtworkPresentation.identity(url, presentation)
        if previews.entries[resource] != nil { return true }
        return ArtworkPixelSize.steps.contains { cache.entries[resource + "#\($0)"] != nil }
    }
    private func updateDerivedPriority(_ key:String) {
        guard let demand = derivedDisplays[key] else { return }
        let visible = demand.subscribers.values.filter(\.visible)
        let owners = visible.isEmpty ? Array(demand.subscribers.values) : visible
        setPriority(demand.request,center:visible.contains(where: \.center),visible:!visible.isEmpty,
                    prefetch:owners.allSatisfy(\.prefetch),distance:owners.map(\.distance).min() ?? .greatestFiniteMagnitude,
                    centerDistance:owners.map(\.centerDistance).min() ?? .greatestFiniteMagnitude,
                    hasImage:owners.allSatisfy(\.hasImage),nearby:owners.contains(where: \.nearby))
    }
    func setPriority(_ token: UUID?, center: Bool, visible: Bool = true, prefetch: Bool = false, distance: CGFloat = .greatestFiniteMagnitude, centerDistance: CGFloat = .greatestFiniteMagnitude, hasImage: Bool? = nil, nearby: Bool = false) {
        if let token, let key = derivedKeys[token], var owner = derivedDisplays[key]?.subscribers[token] {
            owner.center = center; owner.visible = visible; owner.prefetch = prefetch
            owner.distance = distance; owner.centerDistance = centerDistance; owner.nearby = nearby
            if let hasImage { owner.hasImage = hasImage }
            derivedDisplays[key]?.subscribers[token] = owner; updateDerivedPriority(key); return
        }
        guard let token, let key = keys[token], var request = pending[key], request.subscribers[token]?.nearby != nearby || request.subscribers[token]?.center != center || request.subscribers[token]?.prefetch != prefetch || request.subscribers[token]?.visible != visible || request.subscribers[token]?.distance != distance || request.subscribers[token]?.centerDistance != centerDistance || hasImage.map({ request.subscribers[token]?.hasImage != $0 }) == true else { return }
        request.subscribers[token]?.nearby = nearby
        request.subscribers[token]?.prefetch = prefetch
        request.subscribers[token]?.center = center
        request.subscribers[token]?.visible = visible
        request.subscribers[token]?.distance = distance
        request.subscribers[token]?.centerDistance = centerDistance
        if let hasImage { request.subscribers[token]?.hasImage = hasImage }
        pending[key] = request
        reprioritize(key); schedule()
    }
    func cancel(_ token: UUID?) {
        if let token, let key = derivedKeys.removeValue(forKey:token) {
            derivedDisplays[key]?.subscribers[token] = nil
            if derivedDisplays[key]?.subscribers.isEmpty == true {
                let demand = derivedDisplays.removeValue(forKey:key)
                cancel(demand?.request); demand?.task?.cancel(); deliverForegroundIdleActions()
            } else { updateDerivedPriority(key) }
            return
        }
        guard let token, let key = keys.removeValue(forKey: token), var request = pending[key] else { return }
        BrowseDiagnostics.shared.count("artwork.cancelSubscriber")
        request.subscribers[token] = nil
        if request.subscribers.isEmpty { request.operation.cancel(); pending[key] = nil }
        else {
            pending[key] = request
            reprioritize(key)
        }
        schedule()
    }
    // A resource-window subscriber keeps an in-flight operation alive when its
    // card leaves the much smaller layer window. It creates no second transfer.
    func retain(_ token: UUID?, completion: @escaping (ArtworkBitmap?) -> Void) -> UUID? {
        if let token, let key = derivedKeys[token], var owner = derivedDisplays[key]?.subscribers[token] {
            owner.center = false; owner.visible = false; owner.prefetch = true
            let retained = UUID(); derivedKeys[retained] = key
            derivedDisplays[key]?.subscribers[retained] = Subscriber(center:false,prefetch:true,visible:false,distance:owner.distance,centerDistance:owner.centerDistance,pixels:owner.pixels,hasImage:owner.hasImage,preview:nil,completion:completion)
            updateDerivedPriority(key); return retained
        }
        guard let token, let key = keys[token], let request = pending[key], let subscriber = request.subscribers[token] else { return nil }
        let retained = UUID(); keys[retained] = key
        pending[key]?.subscribers[retained] = Subscriber(center: false, prefetch: true, visible: false,
            distance: subscriber.distance, centerDistance: subscriber.centerDistance, pixels: 192,
            hasImage: subscriber.hasImage, preview: nil, completion: completion)
        return retained
    }
    private func reprioritize(_ key: String) {
        guard let request = pending[key] else { return }
        request.operation.prioritize(center: request.subscribers.values.contains(where: { $0.center && $0.visible }), visible: request.subscribers.values.contains(where: \.visible), prefetch: request.subscribers.values.contains(where: \.prefetch))
    }
    private func schedule() {
        defer { deliverForegroundIdleActions() }
        guard updateDepth == 0 else { schedulingPending = true; return }
        schedulingPending = false
        let measurement = BrowseDiagnostics.shared.start()
        defer { BrowseDiagnostics.shared.end("artwork.schedule", measurement) }
        // Bound retained encoded data. In-flight responses can still finish, but
        // neither new cache reads nor downloads enter while this backlog drains.
        guard decodingBytes.count < 4, decodingBytes.values.reduce(0, +) < 24 * 1024 * 1024 else { return }
        guard pending.values.contains(where: { (!$0.submitted && preparing.count < 2) || ($0.networkReady && !$0.networkSubmitted && running.count < ($0.subscribers.values.contains(where: { $0.center && $0.visible }) ? 7 : 6)) }) else { return }
        let waiting = pending.map { key, request in
            let visible = request.subscribers.values.filter(\.visible)
            let demand = visible.isEmpty ? Array(request.subscribers.values) : visible
            let center = visible.contains(where: \.center)
            let needsImage = visible.contains { !$0.hasImage }
            let nearby = request.subscribers.values.contains { $0.nearby && !$0.hasImage }
            let rank = center && needsImage ? 0 : needsImage ? 1 : nearby ? 2 : visible.isEmpty ? 4 : 3
            return (key: key, value: request, rank: rank, priority: request.operation.queuePriority.rawValue,
                    distance: demand.map(\.distance).min() ?? .greatestFiniteMagnitude,
                    centerDistance: visible.map(\.centerDistance).min() ?? .greatestFiniteMagnitude)
        }.sorted {
            if $0.rank != $1.rank { return $0.rank < $1.rank }
            if $0.priority != $1.priority { return $0.priority > $1.priority }
            if $0.distance != $1.distance { return $0.distance < $1.distance }
            if $0.centerDistance != $1.centerDistance { return $0.centerDistance < $1.centerDistance }
            return $0.value.order < $1.value.order
        }
        // Cache lookup has its own two-worker lane, independent of network slots.
        for entry in waiting where !entry.value.submitted && preparing.count < 2 {
            let (key, request) = (entry.key, entry.value)
            pending[key]?.submitted = true; preparing.insert(request.generation)
            let operation = request.operation
            workers.addOperation { operation.start() }
        }
        let hasVisibleWaiting = waiting.contains { !$0.value.networkSubmitted && decodingBytes[$0.value.generation] == nil && $0.rank < 2 }
        var backgroundRunning = pending.values.filter { running.contains($0.generation) && !$0.subscribers.values.contains(where: \.visible) }.count
        var reservedVisibleSlots = 0
        for entry in waiting where !entry.value.networkSubmitted {
            let (key, request) = (entry.key, entry.value)
            guard request.networkReady else {
                // A closer visible cover may still be checking its encoded cache.
                // Reserve its ordinary slot without blocking the rest of the lane.
                if entry.rank == 1 && decodingBytes[request.generation] == nil { reservedVisibleSlots += 1 }
                continue
            }
            let visible = request.subscribers.values.contains(where: \.visible)
            if !visible && (backgroundRunning >= backgroundLimit || (hasVisibleWaiting && entry.rank >= 2) || (entry.rank == 4 && waiting.contains { $0.rank < 4 && !$0.value.networkSubmitted && decodingBytes[$0.value.generation] == nil })) { continue }
            let center = request.subscribers.values.contains { $0.center && $0.visible }
            guard center ? running.count < 7 : running.count + reservedVisibleSlots < 6 else { continue }
            pending[key]?.networkSubmitted = true; running.insert(request.generation)
            BrowseDiagnostics.shared.peak("artwork.networkConcurrentPeak", running.count)
            if !visible { backgroundRunning += 1 }
            let tier = center ? "center" : visible ? "visible" : request.subscribers.values.contains(where: \.prefetch) ? "prefetch" : "background"
            BrowseDiagnostics.shared.end("artwork.networkAdmissionWait." + tier, request.networkQueuedAt)
            request.operation.startNetwork()
        }
    }
    func diagnosticPhase(for token: UUID?) -> String {
        guard let token, let key = keys[token], let operation = pending[key]?.operation else { return "not-requested" }
        return operation.diagnosticPhase
    }
    #if DEBUG
    var validationPendingRequests: Int { pending.count }
    var validationWorkerLimit: Int { 7 }
    var validationOperationCount: Int { operations.count }
    var validationNetworkCount: Int { running.count }
    var validationDecodeBacklog: Int { decodingBytes.count }
    var validationCacheLimit: Int { cache.byteLimit }
    func validationMemoryPressure(_ pressure: DispatchSource.MemoryPressureEvent) { applyMemoryPressure(pressure) }
    var validationCacheBytes: Int { cache.bytes }
    var validationCacheEntries: Int { cache.entries.count }
    var validationPreviewBytes: Int { previews.bytes }
    var validationPreviewEntries: Int { previews.entries.count }
    func validationPriority(_ token: UUID?) -> Operation.QueuePriority? { token.flatMap { keys[$0] }.flatMap { pending[$0]?.operation.queuePriority } }
    #endif
    func retryableFailure(_ url: URL, presentation: ArtworkPresentation?) -> Bool {
        failures[ArtworkPresentation.identity(url, presentation)] == true
    }
    func hasFailure(_ url: URL, presentation: ArtworkPresentation?) -> Bool {
        failures[ArtworkPresentation.identity(url, presentation)] != nil
    }
    func clearFailure(_ url: URL, presentation: ArtworkPresentation?) {
        failures[ArtworkPresentation.identity(url, presentation)] = nil
    }
    func resetFailures() { failures = [:] }
    private func retain(_ bitmap: ArtworkBitmap, request: Request) -> ArtworkBitmap {
        guard !request.operation.originalOnly else { return bitmap }
        let display = bitmap.original == nil ? bitmap : ArtworkBitmap(bitmap.image, preview:bitmap.preview)
        if sourceSizes.count >= 4096, let first = sourceSizes.keys.first { sourceSizes[first] = nil }
        sourceSizes[ArtworkResource.identity(request.operation.resourceURL)] = CGSize(width: bitmap.image.width, height: bitmap.image.height)
        cache.insert(display, for: request.resource + "#\(request.operation.decodedStagePixels)")
        if let preview = bitmap.preview { previews.insert(preview, for: request.resource) }
        BrowseDiagnostics.shared.peak("artwork.cacheBytesPeak", cache.bytes)
        BrowseDiagnostics.shared.peak("artwork.cacheEntriesPeak", cache.entries.count)
        BrowseDiagnostics.shared.peak("artwork.previewBytesPeak", previews.bytes)
        return display
    }
    private func partial(_ key: String, generation: UUID, bitmap: ArtworkBitmap?) {
        guard let request = pending[key], request.generation == generation, !request.operation.isCancelled else { return }
        defer { schedule() }
        running.remove(generation); preparing.remove(generation); decodingBytes[generation] = nil
        pending[key]?.networkReady = false; pending[key]?.networkSubmitted = false
        pending[key]?.completedPixels = request.operation.decodedStagePixels
        updateRequests {
            if let bitmap {
                let display = retain(bitmap, request: request)
                BrowseDiagnostics.shared.count("artwork.progressivePreview")
                for (token, subscriber) in request.subscribers {
                    guard pending[key]?.subscribers[token] != nil else { continue }
                    pending[key]?.subscribers[token]?.hasImage = true
                    subscriber.preview?(display)
                }
            } else { BrowseDiagnostics.shared.count("artwork.previewFallbackToTarget") }
            guard let next = pending[key], next.generation == generation else { return }
            let required = next.subscribers.values.map(\.pixels).max() ?? request.operation.decodedStagePixels
            request.operation.continueAfterPreview(bitmap, requiredPixels: required)
        }
    }
    private func finish(_ key: String, generation: UUID, bitmap: ArtworkBitmap?) {
        running.remove(generation); preparing.remove(generation); decodingBytes[generation] = nil; operations[generation] = nil
        defer { schedule() }
        guard let request = pending[key], request.generation == generation, !request.operation.isCancelled else { return }
        pending[key] = nil
        let display = bitmap.map { retain($0, request:request) }
        if let bitmap {
            failures[request.resource] = nil
            if let diagnosticID = request.operation.diagnosticID { BrowseDiagnostics.shared.mark("artwork.delivered", fields: ["request": diagnosticID, "pixels": String(bitmap.image.width)]) }
        } else {
            if failures.count >= 4096, let first = failures.keys.first { failures[first] = nil }
            failures[request.resource] = request.operation.retryableFailure
        }
        updateRequests {
            for (token, subscriber) in request.subscribers { keys[token] = nil; subscriber.completion(subscriber.original ? bitmap : display) }
        }
    }
}
