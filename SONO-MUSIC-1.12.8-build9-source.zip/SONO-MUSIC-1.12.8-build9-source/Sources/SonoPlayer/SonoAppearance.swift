import AppKit
import SwiftUI

enum SonoTheme: String, CaseIterable {
    #if SONO_RELEASE_CANDIDATE
    static let initialValue: Self = .monochrome
    #else
    static let initialValue: Self = .pink
    #endif

    case pink, blue, monochrome

    var title: String {
        switch self {
        case .pink: "粉"
        case .blue: "蓝"
        case .monochrome: "黑白"
        }
    }

    func foreground(onAccent defaultColor: NSColor = .white) -> NSColor {
        self == .monochrome ? SonoGeneratedColors.monochromeOnAccent : defaultColor
    }
    var accent: NSColor { color(pink: SonoPalette.accent) }

    func color(pink: NSColor) -> NSColor {
        switch self {
        case .pink: pink
        case .blue: .systemBlue
        case .monochrome: SonoGeneratedColors.monochromeAccent
        }
    }

}

private struct SonoThemeKey: EnvironmentKey {
    static let defaultValue = SonoTheme.initialValue
}

extension EnvironmentValues {
    var sonoTheme: SonoTheme {
        get { self[SonoThemeKey.self] }
        set { self[SonoThemeKey.self] = newValue }
    }
}

enum SonoAppearance: String, CaseIterable {
    #if SONO_RELEASE_CANDIDATE
    static let initialValue: Self = .light
    #else
    static let initialValue: Self = .system
    #endif

    case system, light, dark
    var title: String {
        switch self { case .system: "跟随系统"; case .light: "浅色"; case .dark: "深色" }
    }
    var colorScheme: ColorScheme? {
        switch self { case .system: nil; case .light: .light; case .dark: .dark }
    }
    @MainActor func apply() {
        switch self {
        case .system: NSApp.appearance = nil
        case .light: NSApp.appearance = NSAppearance(named: .aqua)
        case .dark: NSApp.appearance = NSAppearance(named: .darkAqua)
        }
    }
}

private struct SonoAppearancePreferenceKey: EnvironmentKey {
    static let defaultValue = SonoAppearance.initialValue
}

extension EnvironmentValues {
    var sonoAppearance: SonoAppearance {
        get { self[SonoAppearancePreferenceKey.self] }
        set { self[SonoAppearancePreferenceKey.self] = newValue }
    }
}

extension NSColor {
    func sonoResolved(in appearance: NSAppearance) -> NSColor {
        var result: NSColor!
        appearance.performAsCurrentDrawingAppearance { result = self.usingColorSpace(.sRGB)! }
        return result
    }

    /// Resolve inside the owning AppKit view's appearance before storing a CGColor.
    func sonoCGColor(in appearance: NSAppearance) -> CGColor {
        sonoResolved(in: appearance).cgColor
    }
}

@MainActor
extension NSAppearance {
    /// Cover labels sit above the existing dark artwork scrim, in either app theme.
    static var sonoArtwork: NSAppearance {
        NSAppearance(named: NSWorkspace.shared.accessibilityDisplayShouldIncreaseContrast ? .accessibilityHighContrastDarkAqua : .darkAqua)!
    }
}

struct SonoProgressBubbleColors {
    let fill: NSColor
    let text: NSColor

    init(dark: Bool, fillColor: NSColor = SonoGeneratedColors.railLabel) {
        let appearance = NSAppearance(named: dark ? .darkAqua : .aqua)!
        fill = fillColor.sonoResolved(in: appearance)
        text = SonoGeneratedColors.monochromeOnAccent.sonoResolved(in: appearance)
    }

    init(appearance: NSAppearance, fillColor: NSColor = SonoGeneratedColors.railLabel) {
        self.init(dark: appearance.bestMatch(from: [.darkAqua, .aqua]) == .darkAqua, fillColor: fillColor)
    }
}
