import AppKit
import QuartzCore

@MainActor
final class CarouselPreview: CALayer {
    @MainActor
    private final class Tile {
        let root = CALayer(), cover = CALayer()
        let title = CATextLayer(), artist = CATextLayer()
        init() {
            cover.contentsGravity = .resizeAspectFill; cover.masksToBounds = true; cover.cornerRadius = 4
            cover.backgroundColor = SonoGeneratedColors.previewPlaceholder.sonoCGColor(in: NSApp.effectiveAppearance)
            root.addSublayer(cover)
            for text in [title, artist] {
                text.alignmentMode = .center; text.truncationMode = .end; text.needsDisplayOnBoundsChange = true
                root.addSublayer(text)
            }
            title.font = SonoTypography.native(size: SonoDesktopTokens.FontSize.sectionTitle, weight: SonoDesktopTokens.FontWeight.semibold); title.fontSize = SonoDesktopTokens.FontSize.sectionTitle; title.foregroundColor = SonoGeneratedColors.primaryText.sonoCGColor(in: NSApp.effectiveAppearance)
            title.anchorPoint = CGPoint(x: 0.5, y: 1)
            artist.font = SonoTypography.native(size: SonoDesktopTokens.FontSize.body); artist.fontSize = SonoDesktopTokens.FontSize.body; artist.foregroundColor = SonoGeneratedColors.queueSecondary.sonoCGColor(in: NSApp.effectiveAppearance)
        }
    }
    private var tiles: [Int: Tile] = [:]
    private var departing: [Tile] = []
    private var cleanup: Task<Void, Never>?
    private var previousPosition: CGFloat?
    private var viewport = CGSize.zero
    private let timing = CAMediaTimingFunction(controlPoints: 0.22, 0.8, 0.25, 1)
    override init() { super.init(); zPosition = 3000; isHidden = true; masksToBounds = true }
    override init(layer: Any) { super.init(layer: layer) }
    required init?(coder: NSCoder) { fatalError() }

    func showImage(_ image: CGImage, at index: Int) {
        guard let tile = tiles[index] else { return }
        CATransaction.begin(); CATransaction.setDisableActions(true)
        tile.cover.contents = image
        CATransaction.commit()
    }
    func reset() {
        cleanup?.cancel(); cleanup = nil
        for tile in Array(tiles.values) + departing { tile.root.removeFromSuperlayer() }
        tiles = [:]; departing = []; previousPosition = nil
    }
    private func dimensions(_ geometry: CarouselGeometry) -> (width: CGFloat, stride: CGFloat, side: CGFloat) {
        // Keep the five-column spacing of the standard 1440-point layout as
        // the largest stride. Extra horizontal space then reveals more songs.
        let standardStride: CGFloat = (1440 - 32) / 5
        let stride = max(1, min((geometry.viewport.width - 32) / 5, standardStride * geometry.metrics.scale))
        let width = max(1, stride - 16)
        return (width, stride, max(1, min(geometry.metrics.side * 0.31, width - 16)))
    }
    func tileIndices(_ geometry: CarouselGeometry) -> Range<Int> {
        let halfSpan = geometry.viewport.width / (2 * dimensions(geometry).stride)
        let first = max(0, Int(floor(geometry.position - halfSpan)))
        let end = min(geometry.count, Int(ceil(geometry.position + halfSpan)) + 1)
        return first..<max(first, end)
    }
    func visibleIndices(_ geometry: CarouselGeometry) -> [Int] {
        let viewport = CGRect(origin: .zero, size: geometry.viewport)
        return tileIndices(geometry).filter { coverRect($0, geometry: geometry).intersects(viewport) }
            .sorted { abs(CGFloat($0) - geometry.position) < abs(CGFloat($1) - geometry.position) }
    }
    func coverRect(_ index: Int, geometry: CarouselGeometry) -> CGRect {
        let d = dimensions(geometry)
        let x = geometry.viewport.width / 2 + (CGFloat(index) - geometry.position) * d.stride
        return CGRect(x: x - d.side/2, y: geometry.metrics.centerRect.midY - d.side/2, width: d.side, height: d.side)
    }
    func coverState(_ index: Int, geometry: CarouselGeometry, size: CGSize) -> (position: CGPoint, transform: CATransform3D) {
        let rect = coverRect(index, geometry: geometry)
        let tile = tiles[index]
        let transform = tile?.cover.presentation()?.transform ?? CATransform3DIdentity
        return (tile?.root.presentation()?.position ?? CGPoint(x: rect.midX, y: rect.midY),
                CATransform3DScale(transform, rect.width / size.width, rect.height / size.height, 1))
    }
    private func animate(_ layer: CALayer, key: String, from: Any, to: Any, duration: Double) {
        let animation = CABasicAnimation(keyPath: key)
        animation.fromValue = from; animation.toValue = to; animation.duration = duration; animation.timingFunction = timing
        layer.add(animation, forKey: "preview-" + key)
    }
    func enter(_ geometry: CarouselGeometry, reduced: Bool) {
        guard !reduced else { return }
        for (index, tile) in tiles {
            let source = geometry.rect(index), destination = coverRect(index, geometry: geometry)
            tile.root.zPosition = geometry.depth(index)
            animate(tile.root, key: "position", from: NSValue(point: CGPoint(x: source.midX, y: source.midY)), to: NSValue(point: tile.root.position), duration: 0.42)
            let transform = CATransform3DScale(geometry.transform(index), source.width / destination.width, source.height / destination.height, 1)
            animate(tile.cover, key: "transform", from: NSValue(caTransform3D: transform), to: NSValue(caTransform3D: CATransform3DIdentity), duration: 0.42)
            animate(tile.title, key: "transform", from: NSValue(caTransform3D: CATransform3DMakeScale(16.0 / 20, 16.0 / 20, 1)), to: NSValue(caTransform3D: CATransform3DIdentity), duration: 0.42)
            for text in [tile.title, tile.artist] { animate(text, key: "opacity", from: Float(0), to: Float(1), duration: 0.3) }
        }
    }
    func update(_ geometry: CarouselGeometry, ids: [String], track: (Int) -> LocalTrack?, image: (Int) -> Any?, scale: CGFloat, reduced: Bool, settling: Bool) {
        updateItems(geometry, ids: ids, track: { track($0).map(BrowseItem.song) }, image: image, scale: scale, reduced: reduced, settling: settling)
    }
    func updateItems(_ geometry: CarouselGeometry, ids: [String], track: (Int) -> BrowseItem?, image: (Int) -> Any?, scale: CGFloat, reduced: Bool, settling: Bool) {
        frame = CGRect(origin: .zero, size: geometry.viewport)
        let d = dimensions(geometry), old = previousPosition
        let resized = viewport != geometry.viewport
        let jumped = old.map { abs($0 - geometry.position) > 1 } == true && !resized && !reduced
        let direction: CGFloat = (old ?? geometry.position) < geometry.position ? 1 : -1
        let wanted = tileIndices(geometry)
        if jumped {
            cleanup?.cancel()
            for tile in departing { tile.root.removeFromSuperlayer() }
            departing = []
        }
        for (index, tile) in tiles where !wanted.contains(index) {
            tiles[index] = nil
            if jumped {
                departing.append(tile)
                let start = tile.root.presentation()?.position ?? tile.root.position
                let opacity = tile.root.presentation()?.opacity ?? tile.root.opacity
                tile.title.isHidden = true; tile.artist.isHidden = true
                let end = CGPoint(x: start.x - direction * d.stride, y: start.y)
                tile.root.position = end; tile.root.opacity = 0
                animate(tile.root, key: "position", from: NSValue(point: start), to: NSValue(point: end), duration: 0.18)
                animate(tile.root, key: "opacity", from: opacity, to: Float(0), duration: 0.18)
            } else { tile.root.removeFromSuperlayer() }
        }
        for index in wanted where ids.indices.contains(index) {
            let fresh = tiles[index] == nil
            let tile = tiles[index] ?? Tile()
            if fresh { tiles[index] = tile; addSublayer(tile.root) }
            let rect = coverRect(index, geometry: geometry)
            let oldPoint = tile.root.presentation()?.position ?? tile.root.position
            tile.root.position = CGPoint(x: rect.midX, y: rect.midY)
            tile.cover.bounds = CGRect(origin: .zero, size: rect.size); tile.cover.position = .zero
            tile.cover.contents = image(index) ?? SonoAssets.bitmap("local-default", pixels: 320)
            tile.cover.contentsScale = scale
            let value = track(index)
            tile.title.string = SonoTypography.line(value?.title ?? "第\(index + 1)首", size: SonoDesktopTokens.FontSize.sectionTitle, weight: SonoDesktopTokens.FontWeight.semibold, height: 28, color: SonoGeneratedColors.primaryText.sonoResolved(in: NSApp.effectiveAppearance))
            tile.artist.string = SonoTypography.line(value?.artist ?? "歌曲信息未就绪", size: SonoDesktopTokens.FontSize.body, height: 20, color: SonoGeneratedColors.queueSecondary.sonoResolved(in: NSApp.effectiveAppearance))
            for text in [tile.title, tile.artist] { text.contentsScale = scale }
            // Match the normal caption's bottom edge and four-point artist gap.
            // The title grows upward around its bottom-center anchor.
            tile.title.frame = CGRect(x: -d.width/2, y: geometry.metrics.centerRect.maxY + 12 - rect.midY, width: d.width, height: 28)
            tile.artist.frame = CGRect(x: -d.width/2, y: geometry.metrics.centerRect.maxY + 44 - rect.midY, width: d.width, height: 19.6)
            if jumped || ((settling || tile.root.animation(forKey: "preview-position") != nil) && old != nil && old != geometry.position && !resized && !reduced) {
                let start = fresh ? CGPoint(x: rect.midX + direction * d.stride, y: rect.midY) : oldPoint
                animate(tile.root, key: "position", from: NSValue(point: start), to: NSValue(point: tile.root.position), duration: 0.18)
                if fresh { animate(tile.root, key: "opacity", from: Float(0), to: Float(1), duration: 0.18) }
            }
        }
        if jumped && !departing.isEmpty {
            cleanup = Task { @MainActor [weak self] in
                do { try await Task.sleep(for: .milliseconds(180)) } catch { return }
                guard let self else { return }
                for tile in self.departing { tile.root.removeFromSuperlayer() }
                self.departing = []; self.cleanup = nil
            }
        }
        previousPosition = geometry.position; viewport = geometry.viewport
    }
}
