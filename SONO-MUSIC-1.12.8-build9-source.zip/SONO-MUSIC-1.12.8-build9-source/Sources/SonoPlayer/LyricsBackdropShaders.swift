import Foundation

/// Original Metal source implementing the recovered stage interfaces. Sono's
/// tone curve and mesh interpolation are intentionally documented separately.
enum LyricsBackdropShaders {
    static let source = """
    #include <metal_stdlib>
    using namespace metal;
    struct Uniforms { float4 control; float4 spectrum; float4 geometry; float4 edge; float4 tint; float4 artwork; float4 appearance; float4 flow; float4 scene; float4 feather; };
    struct Vertex { float2 uv; float2 from; float2 to; };
    struct Varying { float4 position [[position]]; float2 uv; uint instance [[flat]]; half bridgeWeight; float2 screenUV; };
    constexpr sampler artworkSampler(coord::normalized,min_filter::linear,mag_filter::linear,mip_filter::none,address::clamp_to_edge);
    vertex Varying fullscreen(uint id [[vertex_id]]) {
        float2 p = float2((id<<1)&2,id&2);
        return {float4(p*2-1,0,1),float2(p.x,1-p.y),0,0,float2(p.x,1-p.y)};
    }
    fragment half4 blendArtwork(Varying in [[stage_in]],texture2d<half> from [[texture(0)]],texture2d<half> to [[texture(1)]],constant Uniforms &u [[buffer(0)]]) {
        return mix(from.sample(artworkSampler,in.uv),to.sample(artworkSampler,in.uv),half(u.control.y));
    }
    float2 rotate(float2 p,float a) { return float2(cos(a)*p.x-sin(a)*p.y,sin(a)*p.x+cos(a)*p.y); }
    vertex Varying rotateArtwork(uint id [[vertex_id]],uint instance [[instance_id]],constant Uniforms &u [[buffer(0)]]) {
        constexpr float2 corners[6] = {float2(-1,-1),float2(1,-1),float2(-1,1),float2(1,-1),float2(1,1),float2(-1,1)};
        float2 local = corners[id];
        float periods[3] = {120,70,90};
        float rate = cos(u.flow.z+float(instance)*.9);
        float angle = (u.control.x*rate+u.flow.x*13.+u.flow.y*7.)*6.28318530718/periods[instance] + u.flow.z*(.25+.2*float(instance));
        float2 p = rotate(local,angle)*(instance==0 ? 1.4 : .7);
        if (instance==1) p += float2(-.25,.15);
        if (instance==2) p = rotate(p+float2(.7,.7),(u.control.x*rate+u.flow.y*7.)*6.28318530718/120);
        p = p*(1.+u.flow.w*.5)+u.flow.xy*.035;
        p.y *= u.geometry.x;
        return {float4(p,0,1),float2(local.x*.5+.5,.5-local.y*.5),instance,0,float2(0)};
    }
    fragment half4 colorArtwork(Varying in [[stage_in]],texture2d<half> image [[texture(0)]],constant Uniforms &u [[buffer(0)]]) {
        half3 c = image.sample(artworkSampler,in.uv).rgb;
        c = mix(c,half3(0),half((u.geometry.w+float(in.instance)*.0075)*(1-u.appearance.a)));
        half saturation = mix(half(u.control.w),half(1),half(u.appearance.a));
        half luminance = dot(c,half3(.2126,.7152,.0722));
        return half4(mix(half3(luminance),c,saturation),1);
    }
    vertex Varying warpArtwork(uint id [[vertex_id]],constant Vertex *vertices [[buffer(0)]],constant Uniforms &u [[buffer(1)]]) {
        Vertex v = vertices[id];
        float2 warped = mix(v.from,v.to,u.control.z)*2-1;
        float2 expanded = (v.uv-.5)*(2+(1-u.geometry.y)*.5);
        float2 p = mix(expanded,warped,u.geometry.y);
        // A smooth, screen-anchored bridge is evaluated on the existing mesh.
        // Interpolation avoids repeating its smoothsteps at drawable resolution.
        float2 uv = p*.5+.5;
        float x = (uv.x-u.artwork.w)/max(.001,u.artwork.x);
        float y = (uv.y-u.artwork.z)/max(.001,u.artwork.y);
        float left = mix(1.,smoothstep(-.35,.45,x),u.feather.z);
        float right = 1.-u.feather.w*smoothstep(.55,1.35,x);
        float top = mix(1.,smoothstep(-.20,.20,y),u.feather.x);
        float bottom = 1.-u.feather.y*smoothstep(.80,1.20,y);
        float strength = max(max(u.feather.x,u.feather.y),max(u.feather.z,u.feather.w));
        half weight = half(u.artwork.x > 0. ? left*right*top*bottom*strength : 0.);
        return {float4(p.x,-p.y,0,1),v.uv,0,weight,uv};
    }
    // Local, non-rigid displacement: bass bends broad regions, mids shear
    // their boundaries, treble adds a small counterflow. No global spin/zoom.
    float2 flowDomain(float2 p,float time,float3 audio) {
        float t = time*.12;
        float2 q = float2(sin(p.y*2.3+t*.83)+cos(p.x*1.7-t*.61),
                          cos(p.x*2.1-t*.71)+sin(p.y*1.9+t*.53));
        p += q*(.28+.34*audio.x);
        p += float2(sin(p.y*3.1-p.x*.7-t*1.17),cos(p.x*2.7+p.y*.8+t*.93))*(.14+.30*audio.y);
        return p+float2(sin(p.y*5.3+t*1.37),cos(p.x*4.7-t*1.11))*(.035+.045*audio.z);
    }
    float3 musicFieldDrive(float3 spectrum) {
        // Keep the original midpoint response and give strong signals room above it.
        return 1.-exp(-3.4*spectrum)+.2*max(spectrum-.5,0.);
    }
    float2 musicArtworkUV(float2 uv,constant Uniforms &u,float3 drive) {
        if (all(drive == float3(0.))) return uv;
        float2 aspect = float2(u.geometry.x,1);
        float2 p = (uv-.5)*aspect;
        float envelope = .48*sin(3.14159265*uv.x)*sin(3.14159265*uv.y);
        return uv+envelope*(flowDomain(p,u.control.x,drive)-flowDomain(p,u.control.x,float3(0)))/aspect;
    }
    float3 decodeSRGB(float3 c) {
        return select(c/12.92,pow((c+.055)/1.055,float3(2.4)),c>.04045);
    }
    float3 encodeSRGB(float3 c) {
        return select(c*12.92,1.055*pow(c,float3(1./2.4))-.055,c>.0031308);
    }
    half3 lightBackdrop(half3 sample) {
        float3 linear = decodeSRGB(float3(sample));
        float y = dot(linear,float3(.2126,.7152,.0722));
        // A continuous luminance floor follows the sampled color across the
        // whole backdrop, independent of the cover and text rectangles.
        float3 ink = decodeSRGB(float3(28.,33.,40.)/255.*.9+float3(sample)*.1);
        float inkY = max(dot(ink,float3(.2126,.7152,.0722)),
                         dot(decodeSRGB(float3(37.,43.,52.)/255.),float3(.2126,.7152,.0722)));
        float floorY = 4.65*(inkY+.05)-.05;
        constexpr float width = .035;
        float delta = y-floorY;
        float shoulder = max(width-abs(delta),0.);
        float lift = max(-delta,0.) + shoulder*shoulder/(4.*width);
        if (lift <= 0) return sample;
        float peak = max(max(linear.r,linear.g),linear.b);
        float scale = min((y+lift)/max(y,.0001),1./max(peak,.0001));
        linear *= scale;
        float remaining = max(0.,y+lift-y*scale);
        linear = mix(linear,float3(1),remaining/max(.0001,1.-y*scale));
        return half3(encodeSRGB(clamp(linear,0.,1.)));
    }
    float fieldValue(float2 cell) {
        float3 h = fract(float3(cell.xyx)*float3(.1031,.11369,.13787));
        h += dot(h,h.yzx+19.19);
        return fract((h.x+h.y)*h.z);
    }
    float fieldNoise(float2 p) {
        float2 cell = floor(p);
        float2 f = fract(p);
        float2 w = f*f*f*(f*(f*6.-15.)+10.);
        float upper = mix(fieldValue(cell),fieldValue(cell+float2(1,0)),w.x);
        float lower = mix(fieldValue(cell+float2(0,1)),fieldValue(cell+float2(1,1)),w.x);
        return mix(upper,lower,w.y);
    }
    fragment half4 flowArtwork(Varying in [[stage_in]],texture2d<half> palette [[texture(0)]],constant Uniforms &u [[buffer(0)]]) {
        float2 uv = in.uv;
        float3 drive = musicFieldDrive(u.spectrum.xyz);
        float time = u.control.x+u.flow.x*13.+u.flow.y*7.;
        float2 domain = rotate((uv-.5)*float2(u.geometry.x,1)*2.,u.flow.z)*(1.+u.flow.w)+u.flow.xy;
        float2 p = flowDomain(domain,time,drive);
        float t = time*.12;
        // Two broad fields drift independently in both axes. Their peaks stay
        // local instead of lining up into a stripe across the opening frame.
        float a = fieldNoise(p*.98+float2(3.84,7.63)+t*rotate(float2(.26,-.15),u.flow.z));
        float b = fieldNoise(rotate(p,.71)*1.22+float2(11.45,2.27)+t*rotate(float2(-.18,.27),u.flow.z));
        half3 c0 = palette.sample(artworkSampler,float2(1./12.,.5)).rgb;
        half3 c1 = palette.sample(artworkSampler,float2(3./12.,.5)).rgb;
        half3 c2 = palette.sample(artworkSampler,float2(5./12.,.5)).rgb;
        half3 c3 = palette.sample(artworkSampler,float2(7./12.,.5)).rgb;
        half3 c4 = palette.sample(artworkSampler,float2(9./12.,.5)).rgb;
        half3 c5 = palette.sample(artworkSampler,float2(11./12.,.5)).rgb;
        float tone = smoothstep(.08,.92,a);
        half3 low = mix(c0,c1,half(b));
        half3 high = mix(c2,c3,half(.25+.55*b));
        half3 color = mix(low,high,half(tone));
        // Local colored regions move with the field, rather than tinting its base.
        float accent = .40*smoothstep(.38,.85,b)*(1.-smoothstep(.10,.75,a));
        half3 pigment = mix(c4,c5,half(b));
        // Protect only the visible feather, not a whole rectangular half-screen.
        // Away from the cover, the same flowing field runs across both sides.
        float2 local = float2((uv.x-u.artwork.w)/max(.001,u.artwork.x),(uv.y-u.artwork.z)/max(.001,u.artwork.y));
        float3 offset = (local.xyy-float3(.90,.10,.90))/float3(.15,.14,.14);
        float3 feather = exp(-offset*offset);
        float right = u.feather.w*feather.x*smoothstep(-.10,.12,local.y)*(1.-smoothstep(.88,1.10,local.y));
        float vertical = (u.feather.x*feather.y + u.feather.y*feather.z)*(1.-smoothstep(.85,1.12,local.x));
        float left = u.feather.z*exp(-pow(abs((local.x-.10)/.15),2.))*smoothstep(-.10,.12,local.y)*(1.-smoothstep(.88,1.10,local.y));
        vertical *= mix(1.,smoothstep(-.12,.15,local.x),u.feather.z);
        float protection = u.artwork.x > 0. ? clamp(max(max(left,right),vertical),0.,1.) : 0.;
        color = mix(color,pigment,half(accent*(1.-protection)));
        float anchor = protection*.56;
        color = mix(color,half3(u.appearance.rgb),half(anchor));
        return half4(lightBackdrop(color),1);
    }
    float4 presentColor(float3 color,float2 pixel) {
        // A stable screen-space hash breaks up adjacent 8-bit levels without
        // introducing moving grain or a repeating pattern along the gradient.
        uint2 xy = uint2(pixel);
        uint hash = xy.x*0x9E3779B9u ^ xy.y*0x85EBCA6Bu;
        hash ^= hash >> 16;
        hash *= 0x7FEB352Du;
        hash ^= hash >> 15;
        float noise = float(hash & 0xFFFFu)/65535. - .5;
        return float4(clamp(color+noise/255.,0.,1.),1);
    }
    float4 presentScene(float3 color,float2 pixel,float2 uv,texture2d<float> snapshot,float4 scene) {
        float4 current = presentColor(color,pixel);
        if (scene.y <= .5) return current;
        float weight = smoothstep(0.,1.,scene.x);
        return mix(snapshot.sample(artworkSampler,uv),current,weight);
    }
    fragment float4 displayArtwork(Varying in [[stage_in]],texture2d<float> image [[texture(0)]],texture3d<float> lut [[texture(1)]],texture2d<float> field [[texture(2)]],texture2d<float> snapshot [[texture(3)]],constant Uniforms &u [[buffer(0)]]) {
        if (u.appearance.a >= 1) {
            return presentScene(field.sample(artworkSampler,in.screenUV).rgb,in.position.xy,in.screenUV,snapshot,u.scene);
        }
        float2 uv = musicArtworkUV(in.uv,u,u.spectrum.xyz);
        float4 c = image.sample(artworkSampler,uv);
        float3 unpremultiplied = c.rgb/max(c.a,.0001);
        float3 mapped = mix(unpremultiplied,float3(1),u.geometry.z);
        float3 color = lut.sample(artworkSampler,mapped).rgb;
        color = mix(color,u.edge.rgb,float(in.bridgeWeight)*u.edge.a);
        color = mix(color,u.tint.rgb,u.tint.a);
        if (u.appearance.a <= 0) return presentScene(color,in.position.xy,in.screenUV,snapshot,u.scene);
        float3 light = field.sample(artworkSampler,in.screenUV).rgb;
        return presentScene(mix(color,light,u.appearance.a),in.position.xy,in.screenUV,snapshot,u.scene);
    }
    struct TextureParameters {
        float2 size; float fade; float blur; float4 angles; float4 oldAngles; float3 options;
    };
    float4 textureLayers(float2 pixel,float2 size,texture2d<float> cover,float4 q,float opacity,float4 below) {
        float w = size.x;
        float2 middle = size*.5;
        float2 centers[4] = {middle,size*.4,
            middle+w*.25*float2(cos(q.z*.75),sin(q.z*.75)),
            middle+w*.05+w*.25*float2(cos(q.w*.75),sin(q.w*.75))};
        constexpr float widths[4] = {1.25,.8,.5,.25};
        float4 rotations = q*float4(1,1,-1,-1);
        for (int i=0; i<4; ++i) {
            float2 uv = rotate(pixel-centers[i],-rotations[i])/(w*widths[i])+.5;
            if (all(uv >= 0.) && all(uv <= 1.)) {
                float4 color = cover.sample(artworkSampler,uv)*opacity;
                below = color+below*(1.-color.a);
            }
        }
        return below;
    }
    fragment float4 layerTextureArtwork(Varying in [[stage_in]],texture2d<float> cover [[texture(0)]],
        texture2d<float> old [[texture(1)]],texture2d<float> snapshot [[texture(2)]],
        constant TextureParameters &p [[buffer(0)]]) {
        float4 below(0.);
        if (p.options.y > .5) below = snapshot.sample(artworkSampler,in.uv)*(1.-p.fade);
        else if (p.options.x > .5) below = textureLayers(in.position.xy,p.size,old,p.oldAngles,1.-p.fade,below);
        return textureLayers(in.position.xy,p.size,cover,p.angles,p.fade,below);
    }
    fragment float4 twistTextureArtwork(Varying in [[stage_in]],texture2d<float> image [[texture(0)]],
        constant TextureParameters &p [[buffer(0)]]) {
        float2 delta = in.position.xy-p.size*.5;
        float weight = max(0.,1.-length(delta)/900.);
        float2 uv = rotate(delta,-3.25*weight*weight)/p.size+.5;
        return image.sample(artworkSampler,uv);
    }
    fragment float4 blurTextureArtwork(Varying in [[stage_in]],texture2d<float> image [[texture(0)]],
        constant TextureParameters &p [[buffer(0)]]) {
        float2 d = p.blur/p.size, uv = in.uv;
        return .25*(image.sample(artworkSampler,uv+d)+image.sample(artworkSampler,uv-d)
            +image.sample(artworkSampler,uv+float2(d.x,-d.y))+image.sample(artworkSampler,uv+float2(-d.x,d.y)));
    }
    float3 clearTextureColor(float3 rgb) {
        // Grade the un-clipped cover mixture. OKLab keeps the lightness of
        // color boundaries independent of their changing hue and chroma.
        float3 linear = decodeSRGB(rgb);
        float3 lms = pow(max(float3(
            dot(linear,float3(.4122214708,.5363325363,.0514459929)),
            dot(linear,float3(.2119034982,.6806995451,.1073969566)),
            dot(linear,float3(.0883024619,.2817188376,.6299787005))),float3(0.)),float3(1./3.));
        float3 lab = float3(
            dot(lms,float3(.2104542553,.7936177850,-.0040720468)),
            dot(lms,float3(1.9779984951,-2.4285922050,.4505937099)),
            dot(lms,float3(.0259040371,.7827717662,-.8086757660)));
        float chroma = length(lab.yz);
        // Keep neutral boundaries clean while giving vivid colors a little
        // more depth. Both adjustments vary smoothly with the source color.
        lab.x = .84+.02*tanh((lab.x-.7)*3.)-.055*smoothstep(.015,.12,chroma);
        float softened = .16*(1.-exp(-chroma*2.4/.16));
        lab.yz *= softened/max(chroma,.00001);
        lms = float3(
            lab.x+.3963377774*lab.y+.2158037573*lab.z,
            lab.x-.1055613458*lab.y-.0638541728*lab.z,
            lab.x-.0894841775*lab.y-1.2914855480*lab.z);
        lms = lms*lms*lms;
        linear = float3(
            dot(lms,float3(4.0767416621,-3.3077115913,.2309699292)),
            dot(lms,float3(-1.2684380046,2.6097574011,-.3413193965)),
            dot(lms,float3(-.0041960863,-.7034186147,1.7076147010)));
        // Compress toward the same-lightness neutral before a channel clips.
        // A soft shoulder avoids a visible contour at the gamut boundary.
        float neutral = lab.x*lab.x*lab.x;
        float3 delta = linear-neutral;
        float3 room = select(float3(neutral),float3(1.-neutral),delta >= 0.);
        float pressure = max(max(abs(delta.r)/room.r,abs(delta.g)/room.g),abs(delta.b)/room.b);
        float compression = pow(1.+pow(pressure,4.),-.25);
        return encodeSRGB(float3(neutral)+delta*compression);
    }
    fragment float4 displayTextureArtwork(Varying in [[stage_in]],texture2d<float> background [[texture(0)]],
        constant TextureParameters &p [[buffer(0)]],constant Uniforms &u [[buffer(1)]]) {
        // The heavily blurred texture needs more displacement for the same visible response.
        // Warp only the displayed frame so the cached flow and crossfade keep their own timing.
        float3 drive = 1.35*musicFieldDrive(u.spectrum.xyz);
        float4 source = background.sample(artworkSampler,musicArtworkUV(in.uv,u,drive));
        float3 rgb = source.rgb/max(source.a,.00001);
        if (p.options.z > .5) {
            return presentColor(clearTextureColor(rgb*source.a+(1.-source.a)),in.position.xy);
        }
        float luma = dot(rgb,float3(.2125,.7154,.0721));
        float3 adjusted = .7*mix(float3(.5),mix(float3(luma),rgb,2.75),1.9);
        float3 color = clamp(adjusted*source.a+(1.-source.a),0.,1.);
        return float4(.05+.475*color,1.);
    }
    """
}
