import AVFoundation
import Combine
import Foundation

// The generation is invalidated on cancellation, including pause and source edits.
// No candidate may publish a track/queue until AVPlayer reports actual playback.
struct PlaybackGate {
    private(set) var revision: UInt64 = 0
    private(set) var pending: UInt64?
    mutating func begin() -> UInt64 { revision &+= 1; pending = revision; return revision }
    mutating func cancel() { revision &+= 1; pending = nil }
    mutating func commit(_ token: UInt64) -> Bool {
        guard pending == token && revision == token else { return false }
        pending = nil
        return true
    }
    func accepts(_ token: UInt64) -> Bool { pending == token && revision == token }
}

@MainActor
final class AudioHandle {
    let player: AVPlayer
    let track: LocalTrack
    let analysis = PlaybackAnalysis()
    func playableDuration(_ duration: Double) -> Double {
        guard let trial else { return duration }
        let limit = trial.upperBound - trial.lowerBound
        return duration.isFinite && duration > 0 ? min(duration, limit) : limit
    }
    var analysisPreparation: Task<Void,Never>?
    let trial: Range<Double>?
    let access: FolderAccess?
    var observations: [NSKeyValueObservation] = []
    var notifications: [NSObjectProtocol] = []
    var timeout: Task<Void, Never>?
    init(track: LocalTrack, access: FolderAccess?, sourceURL: URL, trial: Range<Double>? = nil) {
        self.trial = trial
        self.track = track; self.access = access
        player = AVPlayer(playerItem: AVPlayerItem(url: sourceURL))
        if let trial { player.currentItem?.forwardPlaybackEndTime = CMTime(seconds: trial.upperBound - trial.lowerBound, preferredTimescale: 600) }
        player.volume = 0
        LyricsPerformanceDiagnostics.shared.handleCreated()
        analysisPreparation = Task { [weak self] in
            guard let self, let item = player.currentItem else { return }
            do {
                let tracks = try await item.asset.loadTracks(withMediaType:.audio)
                try Task.checkCancellation()
                guard let track = tracks.first else { return }
                let parameters = AVMutableAudioMixInputParameters(track:track)
                parameters.audioTapProcessor = try analysis.makeTap()
                let mix = AVMutableAudioMix(); mix.inputParameters = [parameters]; item.audioMix = mix
            } catch { if !Task.isCancelled { NSLog("Audio analysis unavailable: %@",error.localizedDescription) } }
        }
    }
    isolated deinit { LyricsPerformanceDiagnostics.shared.handleDestroyed() }
    func stop() {
        analysisPreparation?.cancel(); analysisPreparation = nil
        analysis.setEnabled(false)
        timeout?.cancel(); timeout = nil
        observations.removeAll()
        for token in notifications { NotificationCenter.default.removeObserver(token) }
        notifications.removeAll()
        player.pause()
        player.replaceCurrentItem(with: nil)
    }
}

/// A completion can only commit the latest position request. Pausing revokes
/// automatic playback without discarding the user's requested destination.
struct PlaybackPosition {
    struct Request { let revision: UInt64; let target: Double; var play: Bool }
    private(set) var revision: UInt64 = 0
    private(set) var pending: Request?
    mutating func begin(_ target: Double, play: Bool) -> UInt64 {
        revision &+= 1; pending = Request(revision:revision,target:target,play:play); return revision
    }
    mutating func pause() { pending?.play = false }
    mutating func cancel() { revision &+= 1; pending = nil }
    mutating func finish(_ token: UInt64) -> Request? {
        guard token == revision, pending?.revision == token else { return nil }
        defer { pending = nil }; return pending
    }
}

enum PlaybackAttemptOutcome { case committed, failed(String), cancelled }

@MainActor
final class PlaybackController: ObservableObject {
    @Published private(set) var current: LocalTrack?
    @Published private(set) var isPlaying = false
    @Published private(set) var isLoading = false
    @Published private(set) var pendingID: String?
    @Published private(set) var failures: [String: String] = [:]
    @Published private(set) var elapsed = 0.0
    @Published private(set) var duration = 0.0
    @Published var volume: Double = 0.65 { didSet { active?.player.volume = Float(volume) } }
    @Published var notice: String?
    private var gate = PlaybackGate()
    private var position = PlaybackPosition()
    var positionRevision: UInt64 { position.revision }
    var pendingSeekTarget: Double? { position.pending?.target }
    private var candidate: AudioHandle?
    private var active: AudioHandle?
    private var warmed: AudioHandle?
    private var warming: Task<Void, Never>?
    private var warmID: String?
    private var warmExpires: Date?
    private var warmRevision: UInt64 = 0
    #if DEBUG
    var validationWarmID: String? { warmID }
    var validationWarmReady: Bool { warmed?.player.status == .readyToPlay }
    #endif
    func cancelPrewarm() {
        warmRevision &+= 1; warmID = nil; warmExpires = nil
        warming?.cancel(); warming = nil
        warmed?.player.cancelPendingPrerolls(); warmed?.stop(); warmed = nil
        diagnosticHandles()
    }
    func prewarm(_ track: LocalTrack, access: FolderAccess? = nil, resolve: (@MainActor () async throws -> OnlineAudioSource)? = nil) {
        guard warmID != track.id else { return }
        cancelPrewarm(); warmID = track.id
        let revision = warmRevision
        warming = Task { [weak self] in
            do {
                let resolved = try await resolve?()
                let url = resolved?.url ?? track.url
                try Task.checkCancellation()
                guard let self, self.warmRevision == revision else { return }
                guard !url.isFileURL || FileManager.default.isReadableFile(atPath:url.path) else { self.cancelPrewarm(); return }
                let handle = AudioHandle(track:track,access:access,sourceURL:url,trial:resolved?.trial)
                self.warmed = handle; self.warmExpires = resolved?.expires
                self.diagnosticHandles()
                handle.player.currentItem?.preferredForwardBufferDuration = 3
                handle.observations.append(handle.player.observe(\.status,options:[.initial,.new]) { [weak self, weak handle] player,_ in
                    let ready = player.status == .readyToPlay, failed = player.status == .failed
                    Task { @MainActor in
                        guard let self, let handle, self.warmed === handle else { return }
                        if failed { self.cancelPrewarm() }
                        else if ready { handle.player.preroll(atRate:1) { _ in } }
                    }
                })
            } catch { if let self, self.warmRevision == revision { self.cancelPrewarm() } }
        }
    }
    private var periodicObserver: Any?
    private var resolution: Task<Void, Never>?
    private var attemptCompletion: ((PlaybackAttemptOutcome) -> Void)?
    private var diagnosticSwitch: LyricsPerformanceDiagnostics.Switch?
    var onCommit: ((LocalTrack) -> Void)?
    var onCandidateCancelled: (() -> Void)?
    var onEnded: (() -> Void)?
    var onSeekRequested: (() -> Void)?
    var onUserPause: (() -> Void)?

    private var interruptedPosition: [String: Double] = [:]
    func play(_ track: LocalTrack, access: FolderAccess? = nil, resolve: (@MainActor () async throws -> URL)? = nil, resolveSource: (@MainActor () async throws -> OnlineAudioSource)? = nil, fresh: Bool = false, completion: ((PlaybackAttemptOutcome) -> Void)? = nil) {
        cancelCandidate()
        attemptCompletion = completion
        let token = gate.begin()
        diagnosticSwitch = LyricsPerformanceDiagnostics.shared.attempt(track)
        if let diagnosticSwitch { BrowseDiagnostics.shared.mark("playback.candidate", fields: diagnosticSwitch.fields.merging(["playbackGeneration": String(token)]) { _, new in new }) }
        isLoading = true; pendingID = track.id; failures[track.id] = nil
        notice = nil
        if resolve == nil, resolveSource == nil,
           !track.url.isFileURL || !FileManager.default.isReadableFile(atPath: track.url.path) {
            cancelPrewarm()
            fail(token, message: "文件不存在或无读取权限：\(track.title)")
            return
        }
        if !fresh, let handle = warmed, warmID == track.id, handle.track.url == track.url, warmExpires.map({ $0.timeIntervalSinceNow > 5 }) ?? true {
            BrowseDiagnostics.shared.count("audio.prewarmTakeovers")
            warmed = nil; warmID = nil; warming?.cancel(); warming = nil; warmRevision &+= 1
            handle.observations.removeAll(); handle.player.cancelPendingPrerolls()
            handle.player.currentItem?.preferredForwardBufferDuration = 0
            observeCandidate(handle,track:track,token:token)
            return
        }
        BrowseDiagnostics.shared.count("audio.prewarmMisses")
        cancelPrewarm()
        if resolve != nil || resolveSource != nil {
            resolution = Task { [weak self] in
                do {
                    let source = try await resolveSource?()
                    let url: URL
                    if let source { url = source.url }
                    else if let resolve { url = try await resolve() }
                    else { return }
                    try Task.checkCancellation()
                    guard let self, self.gate.accepts(token) else { return }
                    self.resolution = nil
                    self.prepare(track, access: nil, sourceURL: url, trial: source?.trial, token: token)
                } catch {
                    guard !Task.isCancelled else { return }
                    let message: String
                    switch error {
                    case OnlineError.unavailable, OnlineError.membershipRequired, OnlineError.qqFullTrackUnavailable:
                        message = OnlineError.qqFullTrackUnavailableMessage
                    case OnlineError.loginRequired:
                        message = error.localizedDescription
                    case is URLError:
                        message = "网络连接不可用，暂时无法播放"
                    default:
                        message = "这首歌暂时无法播放"
                    }
                    NSLog("Playback source failed: %@", String(reflecting: type(of: error)))
                    self?.fail(token, message: message)
                }
            }
            return
        }
        prepare(track, access: access, sourceURL: track.url, token: token)
    }
    private func prepare(_ track: LocalTrack, access: FolderAccess?, sourceURL: URL, trial: Range<Double>? = nil, token: UInt64) {
        let handle = AudioHandle(track: track, access: access, sourceURL: sourceURL, trial: trial)
        observeCandidate(handle,track:track,token:token)
    }
    private func observeCandidate(_ handle: AudioHandle, track: LocalTrack, token: UInt64) {
        candidate = handle
        diagnosticHandles()
        guard let item = handle.player.currentItem else { fail(token, message: "无法创建音频项目"); return }
        handle.observations.append(item.observe(\.status, options: [.initial, .new]) { [weak self, weak handle] item, _ in
            let status = item.status
            let message = item.error?.localizedDescription
            Task { @MainActor in
                guard let self, let handle, self.gate.accepts(token), self.candidate === handle else { return }
                if status == .readyToPlay {
                    if handle.trial == nil, let seconds = self.interruptedPosition[track.id], seconds > 0 {
                        handle.player.seek(to: CMTime(seconds: seconds, preferredTimescale: 600)) { [weak self, weak handle] _ in
                            Task { @MainActor in
                                guard let self, let handle, self.gate.accepts(token), self.candidate === handle else { return }
                                handle.player.play()
                            }
                        }
                    } else {
                        handle.player.play()
                    }
                }
                if status == .failed {
                    if let message { NSLog("AVPlayer could not start: %@", message) }
                    self.fail(token, message: "这首歌暂时无法播放")
                }
            }
        })
        handle.observations.append(handle.player.observe(\.timeControlStatus, options: [.new]) { [weak self, weak handle] player, _ in
            let playing = player.timeControlStatus == .playing
            Task { @MainActor in
                guard playing, let self, let handle else { return }
                self.commit(handle, token: token)
            }
        })
        handle.timeout = Task { [weak self] in
            do { try await Task.sleep(for: .seconds(15)) } catch { return }
            self?.fail(token, message: track.online == nil ? "音频未能在 15 秒内起播，请检查文件或重新授权目录" : "在线音频暂时无法播放")
        }
    }
    private func commit(_ handle: AudioHandle, token: UInt64) {
        guard candidate === handle, gate.commit(token) else { return }
        handle.timeout?.cancel(); handle.timeout = nil
        handle.observations.removeAll()
        detachActive()
        active = handle
        handle.analysis.setEnabled(analysisEnabled)
        candidate = nil
        diagnosticHandles()
        current = handle.track
        elapsed = max(0, handle.player.currentTime().seconds.isFinite ? handle.player.currentTime().seconds : 0)
        interruptedPosition[handle.track.id] = nil
        let value = handle.player.currentItem?.duration.seconds ?? 0
        duration = handle.playableDuration(value.isFinite && value > 0 ? value : handle.track.duration)
        handle.player.volume = Float(volume)
        isPlaying = true
        isLoading = false; pendingID = nil
        LyricsPerformanceDiagnostics.shared.milestone("audioCommitted", token: diagnosticSwitch, fields: ["playbackGeneration": String(token), "boundary": "AVPlayer playing observed; configured volume restored; not acoustic output"])
        diagnosticSwitch = nil
        attachActive(handle)
        let completion = attemptCompletion; attemptCompletion = nil
        onCommit?(handle.track); completion?(.committed)
    }
    private func diagnosticHandles() {
        guard BrowseDiagnostics.shared.enabled else { return }
        let handles = [active, candidate, warmed].compactMap { $0 }
        let count = Set(handles.map(ObjectIdentifier.init)).count
        BrowseDiagnostics.shared.peak("audio.ownedHandlesPeak", count)
        BrowseDiagnostics.shared.set("audio.ownedHandlesLast", String(count))
        BrowseDiagnostics.shared.set("audio.activeHandlesLast", active == nil ? "0" : "1")
        BrowseDiagnostics.shared.set("audio.candidateHandlesLast", candidate == nil ? "0" : "1")
        BrowseDiagnostics.shared.set("audio.prewarmedHandlesLast", warmed == nil ? "0" : "1")
    }
    private func attachActive(_ handle: AudioHandle) {
        periodicObserver = handle.player.addPeriodicTimeObserver(forInterval: CMTime(seconds: 0.25, preferredTimescale: 600), queue: .main) { [weak self, weak handle] time in
            MainActor.assumeIsolated {
                guard let self, let handle, self.active === handle else { return }
                if self.position.pending == nil && time.seconds.isFinite { self.elapsed = min(self.duration, max(0, time.seconds)) }
                let length = handle.playableDuration(handle.player.currentItem?.duration.seconds ?? 0)
                if length.isFinite && length > 0 && self.duration != length { self.duration = length }
            }
        }
        handle.observations.append(handle.player.observe(\.timeControlStatus, options: [.new]) { [weak self, weak handle] player, _ in
            let playing = player.timeControlStatus == .playing
            Task { @MainActor in
                guard let self, let handle, self.active === handle else { return }
                self.isPlaying = playing; self.refreshAnalysis()
            }
        })
        if let item = handle.player.currentItem {
            handle.observations.append(item.observe(\.status, options: [.new]) { [weak self, weak handle] item, _ in
                let failed = item.status == .failed
                let message = item.error?.localizedDescription
                Task { @MainActor in
                    guard failed, let self, let handle, self.active === handle else { return }
                    self.recordInterruption(handle, message: message)
                }
            })
            handle.notifications.append(NotificationCenter.default.addObserver(forName: AVPlayerItem.didPlayToEndTimeNotification, object: item, queue: .main) { [weak self, weak handle] _ in
                MainActor.assumeIsolated {
                    guard let self, let handle, self.active === handle else { return }
                    self.isPlaying = false
                    self.onEnded?()
                }
            })
            handle.notifications.append(NotificationCenter.default.addObserver(forName: AVPlayerItem.failedToPlayToEndTimeNotification, object: item, queue: .main) { [weak self, weak handle] notification in
                let message = (notification.userInfo?[AVPlayerItemFailedToPlayToEndTimeErrorKey] as? Error)?.localizedDescription
                Task { @MainActor in
                    guard let self, let handle, self.active === handle else { return }
                    self.recordInterruption(handle, message: message)
                }
            })
        }
    }
    private func recordInterruption(_ handle: AudioHandle, message: String?) {
        handle.player.pause()
        isPlaying = false
        interruptedPosition[handle.track.id] = elapsed
        if let message { NSLog("Playback interrupted: %@", message) }
        let reason = "播放中断"
        recordFailure(handle.track.id, message: reason)
        notice = reason
    }
    func cancelCandidate() {
        let completion = attemptCompletion; attemptCompletion = nil
        let pending = candidate != nil || isLoading
        if pending { LyricsPerformanceDiagnostics.shared.outcome("candidateCancelled", token: diagnosticSwitch) }
        diagnosticSwitch = nil
        gate.cancel()
        resolution?.cancel(); resolution = nil
        candidate?.stop(); candidate = nil
        diagnosticHandles()
        isLoading = false; pendingID = nil
        if pending { onCandidateCancelled?() }; completion?(.cancelled)
    }
    private func fail(_ token: UInt64, message: String) {
        guard gate.accepts(token) else { return }
        LyricsPerformanceDiagnostics.shared.outcome("candidateFailed", token: diagnosticSwitch)
        let id = pendingID
        let completion = attemptCompletion; attemptCompletion = nil
        cancelCandidate()
        if let id { failures[id] = message }
        notice = message; completion?(.failed(message))
    }
    func recordFailure(_ id: String, message: String) { failures[id] = message }
    func clearFailures(_ ids: Set<String>) {
        failures = failures.filter { !ids.contains($0.key) }
        interruptedPosition = interruptedPosition.filter { !ids.contains($0.key) }
    }
    func setPlaying(_ playing: Bool, preservingPrewarm: Bool = false) {
        if !playing && !preservingPrewarm { onUserPause?() }
        cancelCandidate()
        guard let active else { return }
        if playing {
            if duration > 0 && elapsed >= duration - 0.1 { seek(0) }
            active.player.play()
        } else { position.pause(); active.player.pause(); isPlaying = false; refreshAnalysis() }
    }
    func toggle() {
        cancelCandidate()
        guard let active else { return }
        if active.player.rate != 0 || position.pending?.play == true { onUserPause?(); position.pause(); active.player.pause(); isPlaying = false; refreshAnalysis() }
        else {
            if duration > 0 && elapsed >= duration - 0.1 { seek(0) }
            active.player.play()
        }
    }
    func seek(_ seconds: Double, play: Bool = false) {
        guard seconds.isFinite else { return }
        onSeekRequested?(); cancelCandidate()
        guard let active else { return }
        let value = min(max(0, seconds), duration)
        let token = position.begin(value,play:play)
        active.player.cancelPendingPrerolls()
        active.player.currentItem?.cancelPendingSeeks()
        elapsed = value
        active.player.seek(to:CMTime(seconds:value,preferredTimescale:600),toleranceBefore:.zero,toleranceAfter:.zero) { [weak self, weak active] finished in
            Task { @MainActor in
                guard let self, let active, self.active === active,
                      let request = self.position.finish(token) else { return }
                if finished {
                    self.elapsed = request.target
                    if request.play { active.player.play() }
                }
            }
        }
    }
    private func detachActive() {
        position.cancel()
        if let periodicObserver, let active { active.player.removeTimeObserver(periodicObserver) }
        periodicObserver = nil
        active?.stop(); active = nil
        diagnosticHandles()
    }
    private var analysisEnabled = false
    func setAnalysisEnabled(_ enabled:Bool) { analysisEnabled = enabled; refreshAnalysis() }
    private func refreshAnalysis() {
        active?.analysis.setEnabled(analysisEnabled && isPlaying)
    }
    var audioSpectrum: SIMD4<Float> { isPlaying ? (active?.analysis.spectrum ?? .zero) : .zero }
    var audioEnergy: Float { isPlaying ? (active?.analysis.energy ?? 0) : 0 }
    var analyzedSampleCount: Int { active?.analysis.samples.load(ordering:.relaxed) ?? 0 }
    func preciseTime() -> Double {
        let offset = active?.trial?.lowerBound ?? 0
        if let target = pendingSeekTarget { return target + offset }
        let value = active?.player.currentTime().seconds ?? elapsed
        return (value.isFinite ? value : elapsed) + offset
    }
    func shutdown() { stopCurrent() }
    func stopCurrent() { cancelPrewarm(); cancelCandidate(); detachActive(); current = nil; isPlaying = false; elapsed = 0; duration = 0 }
}
