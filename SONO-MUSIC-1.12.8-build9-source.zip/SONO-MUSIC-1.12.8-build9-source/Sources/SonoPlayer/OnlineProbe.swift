#if !SONO_RELEASE_CANDIDATE
import Foundation
import AVFoundation

enum OnlineProbe {
    @MainActor static func run() async -> Bool {
        let client = NeteaseClient()
        var passed = true
        func report(_ name: String, _ body: () async throws -> String) async {
            do { print("PASS \(name): \(try await body())") }
            catch { passed = false; print("FAIL \(name): \(error.localizedDescription)") }
        }
        await report("QR key / eapi") {
            let result = try await client.request("/api/login/qrcode/unikey", ["type": "3"])
            guard !result["unikey"].string.isEmpty else { throw OnlineError.protocolFailure("missing key") }
            let status = try await client.request("/api/login/qrcode/client/login", ["key": result["unikey"].string, "type": "3"], cookie: result["cookie"].string)
            guard status["code"].int == 801 else { throw OnlineError.protocolFailure("new QR did not enter waiting state") }
            return "key and 801 waiting state received; macOS context preserved (key/cookies redacted)"
        }
        await report("Search / eapi") {
            let result = try await client.request("/api/cloudsearch/pc", ["s": "晴天", "type": "1", "limit": "3", "offset": "0", "total": "true"])
            guard !result["result"]["songs"].array.isEmpty else { throw OnlineError.protocolFailure("no songs") }
            return "\(result["result"]["songs"].array.count) songs"
        }
        await report("Playlist / eapi") {
            let result = try await client.request("/api/v6/playlist/detail", ["id": "3778678", "n": "3", "s": "0"])
            guard !result["playlist"]["trackIds"].array.isEmpty else { throw OnlineError.protocolFailure("no tracks") }
            return "\(result["playlist"]["trackIds"].array.count) IDs"
        }
        await report("Song detail / weapi") {
            let result = try await client.request("/api/v3/song/detail", ["c": "[{\"id\":186016}]"], weapi: true)
            guard result["songs"].array.first?["id"].string == "186016" else { throw OnlineError.protocolFailure("wrong song") }
            return "song 186016"
        }
        await report("Audio / xeapi + AVFoundation") {
            let url = try await client.audioURL("139774", cookie: "")
            let asset = AVURLAsset(url: url)
            guard try await asset.load(.isPlayable) else { throw OnlineError.protocolFailure("AVFoundation rejected stream") }
            let duration = try await asset.load(.duration).seconds
            let player = AVPlayer(url: url); player.volume = 0; player.play()
            defer { player.pause(); player.replaceCurrentItem(with: nil) }
            let deadline = Date().addingTimeInterval(15)
            while player.currentTime().seconds < 0.5 && Date() < deadline {
                try await Task.sleep(for: .milliseconds(100))
            }
            guard player.currentTime().seconds >= 0.5 else { throw OnlineError.protocolFailure("stream did not advance") }
            return "song 139774 HTTPS stream, \(Int(duration)) seconds, actual muted AVPlayer playback advanced; URL redacted"
        }
        return passed
    }
}
#endif
