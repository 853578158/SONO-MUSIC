window.SONO_NATIVE_COLORS = [
  {
    "symbol": "accent",
    "nativeOwner": "SonoStyle",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "brand:SonoStyle:brand-accent:强调色 · 设计已确认",
    "selection": {
      "type": "arco",
      "id": "primary-6"
    },
    "resolved": {
      "light": {
        "hex": "#FF375F",
        "alpha": 1
      },
      "dark": {
        "hex": "#FF375F",
        "alpha": 1
      }
    }
  },
  {
    "symbol": "favorite",
    "nativeOwner": "SonoStyle",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "brand:SonoStyle:brand-favorite:收藏色 · 设计已确认",
    "selection": {
      "type": "custom",
      "space": "sRGB",
      "shared": true,
      "values": {
        "light": {
          "hex": "#FC3D49",
          "alpha": 1
        },
        "dark": {
          "hex": "#FC3D49",
          "alpha": 1
        },
        "lightContrast": {
          "hex": "#FC3D49",
          "alpha": 1
        },
        "darkContrast": {
          "hex": "#FC3D49",
          "alpha": 1
        }
      }
    },
    "resolved": {
      "light": {
        "hex": "#FC3D49",
        "alpha": 1
      },
      "dark": {
        "hex": "#FC3D49",
        "alpha": 1
      }
    }
  },
  {
    "symbol": "pageBackground",
    "nativeOwner": "SonoStyle",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "home-background:SonoStyle:f0:浏览页背景 / 黑色",
    "selection": {
      "type": "arco",
      "id": "sono-page-background"
    },
    "resolved": {
      "light": {
        "hex": "#F0F0F2",
        "alpha": 1
      },
      "dark": {
        "hex": "#000000",
        "alpha": 1
      }
    }
  },
  {
    "symbol": "previewPlaceholder",
    "nativeOwner": "CarouselPreview",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "home-background:CarouselPreview:f6:封面预览占位底色",
    "selection": {
      "type": "arco",
      "id": "color-fill-2"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.04
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.04
      }
    }
  },
  {
    "symbol": "recommendationPanel",
    "nativeOwner": "RecommendationViews",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "home-background:RecommendationViews:f7:推荐风格选择面板背景",
    "selection": {
      "type": "arco",
      "id": "color-bg-2"
    },
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 1
      },
      "dark": {
        "hex": "#232325",
        "alpha": 1
      }
    }
  },
  {
    "symbol": "artistPanel",
    "nativeOwner": "ArtistChoiceView",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "home-background:ArtistChoiceView:f8:艺人选择背景",
    "selection": {
      "type": "arco",
      "id": "color-bg-2"
    },
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 1
      },
      "dark": {
        "hex": "#232325",
        "alpha": 1
      }
    }
  },
  {
    "symbol": "artworkPlaceholder",
    "nativeOwner": "NativeBrowseScene",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "home-background:NativeBrowseScene:f13:封面底色",
    "selection": {
      "type": "arco",
      "id": "color-fill-2"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.04
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.04
      }
    }
  },
  {
    "symbol": "artistClose",
    "nativeOwner": "ArtistChoiceView",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "home-background:ArtistChoiceView:o19:艺人关闭按钮",
    "selection": {
      "type": "arco",
      "id": "color-fill-3"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.08
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.08
      }
    }
  },
  {
    "symbol": "artistPlaceholder",
    "nativeOwner": "ArtistChoiceView",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "home-background:ArtistChoiceView:o19:头像占位",
    "selection": {
      "type": "arco",
      "id": "color-fill-2"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.04
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.04
      }
    }
  },
  {
    "symbol": "artistHover",
    "nativeOwner": "ArtistChoiceView",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "home-background:ArtistChoiceView:o19:悬停",
    "selection": {
      "type": "arco",
      "id": "color-fill-3"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.08
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.08
      }
    }
  },
  {
    "symbol": "primaryText",
    "nativeOwner": "LyricsAppearance",
    "policy": "candidate",
    "contrastSystemColor": "labelColor",
    "role": "text-colors:LyricsAppearance:f1:深色场景主要文字 / 白色",
    "selection": {
      "type": "arco",
      "id": "color-text-1"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.8
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.8
      }
    }
  },
  {
    "symbol": "artworkReason",
    "nativeOwner": "NativeBrowseScene",
    "policy": "candidate",
    "contrastSystemColor": "tertiaryLabelColor",
    "role": "text-colors:NativeBrowseScene:f15:封面原因文字",
    "selection": {
      "type": "arco",
      "id": "color-text-3"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.4
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.4
      }
    }
  },
  {
    "symbol": "noncenterTitle",
    "nativeOwner": "NativeBrowseScene",
    "policy": "candidate",
    "contrastSystemColor": "secondaryLabelColor",
    "role": "text-colors:NativeBrowseScene:f16:非中心标题",
    "selection": {
      "type": "arco",
      "id": "color-text-2"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.6
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.6
      }
    }
  },
  {
    "symbol": "noncenterArtist",
    "nativeOwner": "NativeBrowseScene",
    "policy": "candidate",
    "contrastSystemColor": "secondaryLabelColor",
    "role": "text-colors:NativeBrowseScene:f17:非中心艺人",
    "selection": {
      "type": "arco",
      "id": "color-text-2"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.6
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.6
      }
    }
  },
  {
    "symbol": "navigationText",
    "nativeOwner": "SonoPlayer",
    "policy": "candidate",
    "contrastSystemColor": "labelColor",
    "role": "text-colors:SonoPlayer:f20:普通导航文字",
    "selection": {
      "type": "arco",
      "id": "color-text-1"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.8
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.8
      }
    }
  },
  {
    "symbol": "settingsDescription",
    "nativeOwner": "SonoSettingsView",
    "policy": "applied",
    "contrastSystemColor": "secondaryLabelColor",
    "role": "text-colors:SonoPlayer:o4:设置说明",
    "selection": {
      "type": "arco",
      "id": "color-text-2"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.6
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.6
      }
    }
  },
  {
    "symbol": "footerText",
    "nativeOwner": "SonoPlayer",
    "policy": "candidate",
    "contrastSystemColor": "secondaryLabelColor",
    "role": "text-colors:SonoPlayer:o4:底部说明",
    "selection": {
      "type": "arco",
      "id": "color-text-2"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.6
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.6
      }
    }
  },
  {
    "symbol": "notificationText",
    "nativeOwner": "SonoPlayer",
    "policy": "candidate",
    "contrastSystemColor": "secondaryLabelColor",
    "role": "text-colors:SonoPlayer:o4:通知",
    "selection": {
      "type": "arco",
      "id": "color-text-2"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.6
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.6
      }
    }
  },
  {
    "symbol": "lyricsDarkSecondary",
    "nativeOwner": "LyricsAppearance",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "lyrics-colors:LyricsAppearance:f18:歌词暗底辅助文字",
    "selection": {
      "type": "arco",
      "id": "color-white-a60",
      "appearance": "dark"
    },
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 0.6
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.6
      }
    }
  },
  {
    "symbol": "resumeLyrics",
    "nativeOwner": "NativeLyricsView",
    "policy": "dynamic",
    "contrastSystemColor": null,
    "role": "lyrics-colors:NativeLyricsView:o14:返回当前歌词按钮",
    "selection": {
      "type": "arco",
      "id": "color-fill-2",
      "appearance": "light"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.04
      },
      "dark": {
        "hex": "#000000",
        "alpha": 0.04
      }
    }
  },
  {
    "symbol": "lyricsShadow",
    "nativeOwner": "LyricsPage",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "lyrics-colors:LyricsPage:o17:歌词面板阴影",
    "selection": {
      "type": "shadow",
      "id": "shadow2-center"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.1
      },
      "dark": {
        "hex": "#000000",
        "alpha": 0.1
      }
    }
  },
  {
    "symbol": "queueDragShadow",
    "nativeOwner": "LyricsPage",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "lyrics-colors:LyricsPage:o17:队列拖动行阴影",
    "selection": {
      "type": "shadow",
      "id": "shadow2-center"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.1
      },
      "dark": {
        "hex": "#000000",
        "alpha": 0.1
      }
    }
  },
  {
    "symbol": "collectionCapsule",
    "nativeOwner": "CollectionTitleCapsule",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "list-colors:CollectionTitleCapsule:f4:歌单标题胶囊背景",
    "selection": {
      "type": "arco",
      "id": "color-bg-2"
    },
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 1
      },
      "dark": {
        "hex": "#232325",
        "alpha": 1
      }
    }
  },
  {
    "symbol": "positionBadge",
    "nativeOwner": "QuickList",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "list-colors:QuickList:f5:歌单位置徽标",
    "selection": {
      "type": "arco",
      "id": "color-foreground-strong"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 1
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 1
      }
    }
  },
  {
    "symbol": "railTrack",
    "nativeOwner": "CarouselRail",
    "policy": "candidate",
    "contrastSystemColor": "separatorColor",
    "usage": "轮播分割线悬停40%，默认按1/2强度显示20%；两端渐隐。",
    "role": "list-colors:CarouselRail:f9:轮播轨道底色 / 高亮",
    "selection": {
      "type": "arco",
      "id": "color-border-4"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.4
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.4
      }
    }
  },
  {
    "symbol": "railThumb",
    "nativeOwner": "CarouselRail",
    "policy": "candidate",
    "contrastSystemColor": "separatorColor",
    "role": "list-colors:CarouselRail:f10:轮播轨道滑块",
    "selection": {
      "type": "arco",
      "id": "color-border-4"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.4
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.4
      }
    }
  },
  {
    "symbol": "railLabel",
    "nativeOwner": "CarouselRail",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "list-colors:CarouselRail:f11:轮播右侧文字底色",
    "selection": {
      "type": "arco",
      "id": "color-foreground-strong"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 1
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 1
      }
    }
  },
  {
    "symbol": "capsuleText",
    "nativeOwner": "CollectionTitleCapsule",
    "policy": "candidate",
    "contrastSystemColor": "labelColor",
    "role": "list-colors:CollectionTitleCapsule:f19:胶囊标题文字",
    "selection": {
      "type": "arco",
      "id": "color-text-1"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.8
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.8
      }
    }
  },
  {
    "symbol": "queuePin",
    "nativeOwner": "QueueRowMotion",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "list-colors:QueueRowMotion:s0:队列「置顶」背景",
    "selection": {
      "type": "arco",
      "id": "purple-6"
    },
    "resolved": {
      "light": {
        "hex": "#722ED1",
        "alpha": 1
      },
      "dark": {
        "hex": "#8E51DA",
        "alpha": 1
      }
    }
  },
  {
    "symbol": "queueDelete",
    "nativeOwner": "QueueRowMotion",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "list-colors:QueueRowMotion:s1:队列「删除」背景",
    "selection": {
      "type": "arco",
      "id": "red-6"
    },
    "resolved": {
      "light": {
        "hex": "#FF4245",
        "alpha": 1
      },
      "dark": {
        "hex": "#FF4245",
        "alpha": 1
      }
    }
  },
  {
    "symbol": "deleteLine",
    "nativeOwner": "QueueRowMotion",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "list-colors:QueueRowMotion:s2:删除动效线",
    "selection": {
      "type": "arco",
      "id": "red-6"
    },
    "resolved": {
      "light": {
        "hex": "#FF4245",
        "alpha": 1
      },
      "dark": {
        "hex": "#FF4245",
        "alpha": 1
      }
    }
  },
  {
    "symbol": "queueDrag",
    "nativeOwner": "QueueContent",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "list-colors:QueueContent:s3:队列拖动行背景",
    "selection": {
      "type": "arco",
      "id": "primary-6"
    },
    "resolved": {
      "light": {
        "hex": "#FF375F",
        "alpha": 1
      },
      "dark": {
        "hex": "#FF375F",
        "alpha": 1
      }
    }
  },
  {
    "symbol": "sourceText",
    "nativeOwner": "SourcePlaylistRow",
    "policy": "candidate",
    "contrastSystemColor": "secondaryLabelColor",
    "role": "list-colors:SourcePlaylistRow:o3:来源行文字",
    "selection": {
      "type": "arco",
      "id": "color-text-1"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.8
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.8
      }
    }
  },
  {
    "symbol": "sourceSelected",
    "nativeOwner": "SourcePlaylistRow",
    "policy": "candidate",
    "contrastSystemColor": "labelColor",
    "role": "list-colors:SourcePlaylistRow:o3:选中文字",
    "selection": {
      "type": "arco",
      "id": "color-foreground-strong"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 1
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 1
      }
    }
  },
  {
    "symbol": "queueSecondary",
    "nativeOwner": "QueueContent",
    "policy": "candidate",
    "contrastSystemColor": "secondaryLabelColor",
    "role": "list-colors:QueueContent:o5:队列辅助文字",
    "selection": {
      "type": "arco",
      "id": "color-text-2"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.6
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.6
      }
    }
  },
  {
    "symbol": "queueAction",
    "nativeOwner": "QueueContent",
    "policy": "candidate",
    "contrastSystemColor": "secondaryLabelColor",
    "role": "list-colors:QueueContent:o5:操作图标",
    "selection": {
      "type": "arco",
      "id": "color-black-a60",
      "appearance": "light"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.6
      },
      "dark": {
        "hex": "#000000",
        "alpha": 0.6
      }
    }
  },
  {
    "symbol": "queueTab",
    "nativeOwner": "QueueContent",
    "policy": "candidate",
    "contrastSystemColor": "secondaryLabelColor",
    "role": "list-colors:QueueContent:o5:未选标签",
    "selection": {
      "type": "arco",
      "id": "color-text-2"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.6
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.6
      }
    }
  },
  {
    "symbol": "dividerLight",
    "nativeOwner": "QueueContent",
    "policy": "candidate",
    "contrastSystemColor": "separatorColor",
    "role": "list-colors:QueueContent:o6:亮底分隔线",
    "selection": {
      "type": "arco",
      "id": "color-black-a20",
      "appearance": "light"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.2
      },
      "dark": {
        "hex": "#000000",
        "alpha": 0.2
      }
    }
  },
  {
    "symbol": "dividerDark",
    "nativeOwner": "QueueContent",
    "policy": "candidate",
    "contrastSystemColor": "separatorColor",
    "role": "list-colors:QueueContent:o6:暗底分隔线",
    "selection": {
      "type": "arco",
      "id": "color-white-a20",
      "appearance": "dark"
    },
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 0.2
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.2
      }
    }
  },
  {
    "symbol": "sourceSelection",
    "nativeOwner": "SourcePlaylistRow",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "list-colors:SourcePlaylistRow:o7:来源行选中",
    "selection": {
      "type": "role",
      "id": "brand:SonoStyle:brand-accent:强调色 · 设计已确认"
    },
    "resolved": {
      "light": {
        "hex": "#FF375F",
        "alpha": 1
      },
      "dark": {
        "hex": "#FF375F",
        "alpha": 1
      }
    }
  },
  {
    "symbol": "sourceHover",
    "nativeOwner": "SourcePlaylistRow",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "list-colors:SourcePlaylistRow:o7:悬停",
    "selection": {
      "type": "arco",
      "id": "color-black-a08",
      "appearance": "light"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.08
      },
      "dark": {
        "hex": "#000000",
        "alpha": 0.08
      }
    }
  },
  {
    "symbol": "quickHover",
    "nativeOwner": "QuickList",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "list-colors:QuickList:o9:快捷列表悬停",
    "selection": {
      "type": "arco",
      "id": "color-fill-3"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.08
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.08
      }
    }
  },
  {
    "symbol": "quickPlaceholder",
    "nativeOwner": "QuickList",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "list-colors:QuickList:o9:封面占位",
    "selection": {
      "type": "arco",
      "id": "color-fill-2"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.04
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.04
      }
    }
  },
  {
    "symbol": "scrollbarLight",
    "nativeOwner": "QuickList",
    "policy": "candidate",
    "contrastSystemColor": "separatorColor",
    "role": "list-colors:QuickList:o13:亮底滚动条",
    "selection": {
      "type": "arco",
      "id": "color-black-a40",
      "appearance": "light"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.4
      },
      "dark": {
        "hex": "#000000",
        "alpha": 0.4
      }
    }
  },
  {
    "symbol": "scrollbarDark",
    "nativeOwner": "QuickList",
    "policy": "candidate",
    "contrastSystemColor": "separatorColor",
    "role": "list-colors:QuickList:o13:暗底滚动条",
    "selection": {
      "type": "arco",
      "id": "color-white-a40",
      "appearance": "dark"
    },
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 0.4
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.4
      }
    }
  },
  {
    "symbol": "quickScrollbar",
    "nativeOwner": "QuickList",
    "policy": "candidate",
    "contrastSystemColor": "separatorColor",
    "role": "list-colors:QuickList:o13:快捷列表滚动条",
    "selection": {
      "type": "arco",
      "id": "color-border-4"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.4
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.4
      }
    }
  },
  {
    "symbol": "historyScrim",
    "nativeOwner": "QueueContent",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "list-colors:QueueContent:o15:历史封面",
    "selection": {
      "type": "arco",
      "id": "color-black-a40"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.4
      },
      "dark": {
        "hex": "#000000",
        "alpha": 0.4
      }
    }
  },
  {
    "symbol": "quickPlayScrim",
    "nativeOwner": "QueueContent",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "list-colors:QueueContent:o15:快捷列表悬停播放底色",
    "selection": {
      "type": "arco",
      "id": "color-black-a40"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.4
      },
      "dark": {
        "hex": "#000000",
        "alpha": 0.4
      }
    }
  },
  {
    "symbol": "sourceIcon",
    "nativeOwner": "SourcePlaylistRow",
    "policy": "candidate",
    "contrastSystemColor": "secondaryLabelColor",
    "role": "list-colors:SourcePlaylistRow:o20:来源图标默认",
    "selection": {
      "type": "arco",
      "id": "color-text-2"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.6
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.6
      }
    }
  },
  {
    "symbol": "sourceIconPressed",
    "nativeOwner": "SourcePlaylistRow",
    "policy": "candidate",
    "contrastSystemColor": "labelColor",
    "role": "list-colors:SourcePlaylistRow:o20:来源图标按下",
    "selection": {
      "type": "arco",
      "id": "color-foreground-strong"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 1
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 1
      }
    }
  },
  {
    "symbol": "suggestionText",
    "nativeOwner": "SearchSuggestionRow",
    "policy": "candidate",
    "contrastSystemColor": "secondaryLabelColor",
    "role": "search-colors:SearchSuggestionRow:o1:搜索建议文字",
    "selection": {
      "type": "arco",
      "id": "color-text-2"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.6
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.6
      }
    }
  },
  {
    "symbol": "suggestionMatch",
    "nativeOwner": "SearchSuggestionRow",
    "policy": "candidate",
    "contrastSystemColor": "labelColor",
    "role": "search-colors:SearchSuggestionRow:o1:匹配文字",
    "selection": {
      "type": "role",
      "id": "brand:SonoStyle:brand-accent:强调色 · 设计已确认"
    },
    "resolved": {
      "light": {
        "hex": "#FF375F",
        "alpha": 1
      },
      "dark": {
        "hex": "#FF375F",
        "alpha": 1
      }
    }
  },
  {
    "symbol": "suggestionIcon",
    "nativeOwner": "SearchSuggestionRow",
    "policy": "candidate",
    "contrastSystemColor": "tertiaryLabelColor",
    "role": "search-colors:SearchSuggestionRow:o1:类别图标",
    "selection": {
      "type": "arco",
      "id": "color-text-2"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.6
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.6
      }
    }
  },
  {
    "symbol": "searchPlaceholder",
    "nativeOwner": "BrowseSearchField",
    "policy": "candidate",
    "contrastSystemColor": "tertiaryLabelColor",
    "role": "search-colors:BrowseSearchField:o2:搜索占位文字",
    "selection": {
      "type": "arco",
      "id": "color-text-3"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.4
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.4
      }
    }
  },
  {
    "symbol": "suggestionSelection",
    "nativeOwner": "SearchSuggestionRow",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "search-colors:SearchSuggestionRow:o8:搜索建议选中",
    "selection": {
      "type": "arco",
      "id": "color-fill-3"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.08
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.08
      }
    }
  },
  {
    "symbol": "scopeSelection",
    "nativeOwner": "SearchScopeSelection",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "search-colors:SearchScopeSelection:o18:搜索范围选中",
    "selection": {
      "type": "role",
      "id": "brand:SonoStyle:brand-accent:强调色 · 设计已确认"
    },
    "resolved": {
      "light": {
        "hex": "#FF375F",
        "alpha": 1
      },
      "dark": {
        "hex": "#FF375F",
        "alpha": 1
      }
    }
  },
  {
    "symbol": "scopeHover",
    "nativeOwner": "SearchScopeSelection",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "search-colors:SearchScopeSelection:o18:搜索范围悬停",
    "selection": {
      "type": "arco",
      "id": "color-fill-3"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.08
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.08
      }
    }
  },
  {
    "symbol": "scopeIcon",
    "nativeOwner": "SearchScopeSelection",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "search-colors:SearchScopeSelection:o18:搜索范围图标默认",
    "selection": {
      "type": "arco",
      "id": "sono-gray-11"
    },
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 1
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 1
      }
    }
  },
  {
    "symbol": "scopeIconMuted",
    "nativeOwner": "SearchScopeSelection",
    "policy": "candidate",
    "contrastSystemColor": "tertiaryLabelColor",
    "role": "search-colors:SearchScopeSelection:o18:搜索范围图标弱化",
    "selection": {
      "type": "custom",
      "space": "sRGB",
      "shared": false,
      "values": {
        "light": {
          "hex": "#000000",
          "alpha": 0.8
        },
        "dark": {
          "hex": "#FFFFFF",
          "alpha": 0.8
        },
        "lightContrast": {
          "hex": "#000000",
          "alpha": 0.8
        },
        "darkContrast": {
          "hex": "#FFFFFF",
          "alpha": 0.8
        }
      }
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.8
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.8
      }
    }
  },
  {
    "symbol": "loadingIcon",
    "nativeOwner": "NativeBrowseScene",
    "policy": "candidate",
    "contrastSystemColor": "labelColor",
    "role": "control-colors:NativeBrowseScene:f14:加载图标",
    "selection": {
      "type": "arco",
      "id": "color-text-1"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.8
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.8
      }
    }
  },
  {
    "symbol": "inactiveIcon",
    "nativeOwner": "SonoPlayer",
    "policy": "candidate",
    "contrastSystemColor": null,
    "usage": "普通控制台默认浅色黑0号，深色使用consoleDefaultIconDark白10号；悬停8号、按下／选中100%、禁用4号，已收藏保留红色。",
    "role": "control-colors:SonoPlayer:f21:未选图标乘色",
    "selection": {
      "type": "arco",
      "id": "sono-gray-0",
      "appearance": "light"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 1
      },
      "dark": {
        "hex": "#000000",
        "alpha": 1
      }
    }
  },
  {
    "symbol": "toolIcon",
    "nativeOwner": "SonoPlayer",
    "policy": "candidate",
    "contrastSystemColor": "labelColor",
    "role": "control-colors:SonoPlayer:o0:工具图标",
    "selection": {
      "type": "arco",
      "id": "color-foreground-strong"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 1
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 1
      }
    }
  },
  {
    "symbol": "modeHover",
    "nativeOwner": "SonoPlayer",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "control-colors:SonoPlayer:o10:悬停",
    "selection": {
      "type": "arco",
      "id": "color-black-a08",
      "appearance": "light"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.08
      },
      "dark": {
        "hex": "#000000",
        "alpha": 0.08
      }
    }
  },
  {
    "symbol": "settingsPath",
    "nativeOwner": "SonoPlayer",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "control-colors:SonoPlayer:o11:设置路径底色",
    "selection": {
      "type": "arco",
      "id": "color-bg-4"
    },
    "resolved": {
      "light": {
        "hex": "#F0F0F2",
        "alpha": 1
      },
      "dark": {
        "hex": "#5F5F61",
        "alpha": 1
      }
    }
  },
  {
    "symbol": "localSource",
    "nativeOwner": "SonoPlayer",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "control-colors:SonoPlayer:o11:本地来源行容器",
    "selection": {
      "type": "arco",
      "id": "color-bg-2"
    },
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 1
      },
      "dark": {
        "hex": "#232325",
        "alpha": 1
      }
    }
  },
  {
    "symbol": "progressTrack",
    "nativeOwner": "SonoPlayer",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "control-colors:SonoPlayer:o12:播放进度底轨",
    "selection": {
      "type": "arco",
      "id": "color-progress-track"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.12
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.12
      }
    }
  },
  {
    "symbol": "volumeTrack",
    "nativeOwner": "SonoPlayer",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "control-colors:SonoPlayer:o12:音量底轨",
    "selection": {
      "type": "arco",
      "id": "color-progress-track"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.12
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.12
      }
    }
  },
  {
    "symbol": "glassShade",
    "nativeOwner": "SonoStyle",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "control-colors:SonoStyle:o21:浓厚玻璃附加底色",
    "selection": {
      "type": "custom",
      "space": "sRGB",
      "shared": true,
      "values": {
        "light": {
          "hex": "#000000",
          "alpha": 0.32
        },
        "dark": {
          "hex": "#000000",
          "alpha": 0.32
        },
        "lightContrast": {
          "hex": "#000000",
          "alpha": 0.32
        },
        "darkContrast": {
          "hex": "#000000",
          "alpha": 0.32
        }
      }
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.32
      },
      "dark": {
        "hex": "#000000",
        "alpha": 0.32
      }
    }
  },
  {
    "symbol": "artworkError",
    "nativeOwner": "NativeBrowseScene",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "feedback-colors:NativeBrowseScene:s4:封面错误文字",
    "selection": {
      "type": "custom",
      "space": "sRGB",
      "shared": true,
      "values": {
        "light": {
          "hex": "#FFF0EC",
          "alpha": 1
        },
        "dark": {
          "hex": "#FFF0EC",
          "alpha": 1
        },
        "lightContrast": {
          "hex": "#FFF0EC",
          "alpha": 1
        },
        "darkContrast": {
          "hex": "#FFF0EC",
          "alpha": 1
        }
      }
    },
    "resolved": {
      "light": {
        "hex": "#FFF0EC",
        "alpha": 1
      },
      "dark": {
        "hex": "#FFF0EC",
        "alpha": 1
      }
    }
  },
  {
    "symbol": "artworkErrorShade",
    "nativeOwner": "NativeBrowseScene",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "feedback-colors:NativeBrowseScene:s5:封面错误遮罩",
    "selection": {
      "type": "custom",
      "space": "sRGB",
      "shared": true,
      "values": {
        "light": {
          "hex": "#080B0D",
          "alpha": 0.65
        },
        "dark": {
          "hex": "#080B0D",
          "alpha": 0.65
        },
        "lightContrast": {
          "hex": "#080B0D",
          "alpha": 0.65
        },
        "darkContrast": {
          "hex": "#080B0D",
          "alpha": 0.65
        }
      }
    },
    "resolved": {
      "light": {
        "hex": "#080B0D",
        "alpha": 0.65
      },
      "dark": {
        "hex": "#080B0D",
        "alpha": 0.65
      }
    }
  },
  {
    "symbol": "artworkPlayScrim",
    "nativeOwner": "NativeBrowseScene",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "feedback-colors:NativeBrowseScene:o16:封面播放提示底色",
    "selection": {
      "type": "arco",
      "id": "color-black-a40"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.4
      },
      "dark": {
        "hex": "#000000",
        "alpha": 0.4
      }
    }
  },
  {
    "symbol": "lyricDarkStatic",
    "nativeOwner": "NativeLyricsView",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "lyrics-colors:NativeLyricsView:f1:主歌词暗底静态",
    "selection": {
      "type": "arco",
      "id": "color-lyrics-primary",
      "appearance": "dark"
    },
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 0.9
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.9
      }
    }
  },
  {
    "symbol": "lyricDarkIdle",
    "nativeOwner": "NativeLyricsView",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "lyrics-colors:NativeLyricsView:f1:主歌词暗底未选中",
    "selection": {
      "type": "arco",
      "id": "color-white-a40",
      "appearance": "dark"
    },
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 0.4
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.4
      }
    }
  },
  {
    "symbol": "lyricDarkSelected",
    "nativeOwner": "NativeLyricsView",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "lyrics-colors:NativeLyricsView:f1:主歌词暗底选中底层",
    "selection": {
      "type": "arco",
      "id": "color-white-a40",
      "appearance": "dark"
    },
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 0.4
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.4
      }
    }
  },
  {
    "symbol": "lyricLightStatic",
    "nativeOwner": "NativeLyricsView",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "lyrics-colors:NativeLyricsView:f1:主歌词亮底静态",
    "selection": {
      "type": "arco",
      "id": "color-lyrics-primary",
      "appearance": "light"
    },
    "resolved": {
      "light": {
        "hex": "#1A1A1A",
        "alpha": 1
      },
      "dark": {
        "hex": "#1A1A1A",
        "alpha": 1
      }
    }
  },
  {
    "symbol": "lyricLightIdle",
    "nativeOwner": "NativeLyricsView",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "lyrics-colors:NativeLyricsView:f1:主歌词亮底动态底层",
    "selection": {
      "type": "arco",
      "id": "color-black-a40",
      "appearance": "light"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.4
      },
      "dark": {
        "hex": "#000000",
        "alpha": 0.4
      }
    }
  },
  {
    "symbol": "lyricAuxIdle",
    "nativeOwner": "NativeLyricsView",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "lyrics-colors:NativeLyricsView:f1:辅助歌词暗底未选中",
    "selection": {
      "type": "arco",
      "id": "color-white-a40",
      "appearance": "dark"
    },
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 0.4
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.4
      }
    }
  },
  {
    "symbol": "lyricAuxSelected",
    "nativeOwner": "NativeLyricsView",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "lyrics-colors:NativeLyricsView:f1:辅助歌词暗底选中",
    "selection": {
      "type": "arco",
      "id": "color-white-a40",
      "appearance": "dark"
    },
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 0.4
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.4
      }
    }
  },
  {
    "symbol": "lyricAuxHover",
    "nativeOwner": "NativeLyricsView",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "lyrics-colors:NativeLyricsView:f1:辅助歌词暗底悬停",
    "selection": {
      "type": "arco",
      "id": "color-lyrics-primary",
      "appearance": "dark"
    },
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 0.9
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.9
      }
    }
  },
  {
    "symbol": "lyricsBackground",
    "nativeOwner": "LyricsMetalBackground",
    "policy": "dynamic",
    "contrastSystemColor": null,
    "role": "lyrics-colors:LyricsMetalBackground:lyrics-background:动态封面渐变／歌词背景",
    "selection": {
      "type": "current",
      "description": "动态提色与渲染规则；不能替换为单一实色"
    }
  },
  {
    "symbol": "sourceOrdinaryIcon",
    "nativeOwner": "SourcePlaylistRow",
    "policy": "candidate",
    "contrastSystemColor": "secondaryLabelColor",
    "role": "list-colors:SourcePlaylistRow:o3:普通图标",
    "selection": {
      "type": "arco",
      "id": "color-text-2"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.6
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.6
      }
    }
  },
  {
    "symbol": "lyricsProgressTrack",
    "nativeOwner": "SonoPlayer",
    "policy": "confirmed",
    "contrastSystemColor": null,
    "role": "lyrics-colors:SonoPlayer:lyrics-progress-track:歌词页音乐底轨",
    "selection": {
      "type": "arco",
      "id": "color-black-a20",
      "appearance": "light"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.2
      },
      "dark": {
        "hex": "#000000",
        "alpha": 0.2
      }
    }
  },
  {
    "symbol": "lyricsPanel",
    "nativeOwner": "LyricsPage",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "lyrics-colors:LyricsPage:f22:歌词页面板",
    "selection": {
      "type": "arco",
      "id": "color-bg-2",
      "appearance": "light"
    },
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 1
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 1
      }
    }
  },
  {
    "symbol": "lyricDarkHover",
    "nativeOwner": "NativeLyricsView",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "lyrics-colors:NativeLyricsView:f1:主歌词暗底悬停",
    "selection": {
      "type": "arco",
      "id": "color-lyrics-primary",
      "appearance": "dark"
    },
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 0.9
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.9
      }
    }
  },
  {
    "symbol": "lyricsLightSecondary",
    "nativeOwner": "LyricsAppearance",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "lyrics-colors:LyricsAppearance:f3:歌词亮底辅助文字",
    "selection": {
      "type": "arco",
      "id": "color-black-a60",
      "appearance": "light"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.6
      },
      "dark": {
        "hex": "#000000",
        "alpha": 0.6
      }
    }
  },
  {
    "symbol": "lyricsLightPrimary",
    "nativeOwner": "LyricsAppearance",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "lyrics-colors:LyricsAppearance:f2:歌词亮底主要文字",
    "selection": {
      "type": "arco",
      "id": "color-lyrics-primary",
      "appearance": "light"
    },
    "resolved": {
      "light": {
        "hex": "#1A1A1A",
        "alpha": 1
      },
      "dark": {
        "hex": "#1A1A1A",
        "alpha": 1
      }
    }
  },
  {
    "symbol": "lyricsVolumeTrack",
    "nativeOwner": "SonoPlayer",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "lyrics-colors:SonoPlayer:lyrics-volume-track:歌词页音量底轨",
    "selection": {
      "type": "arco",
      "id": "color-border-3",
      "appearance": "light"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.4
      },
      "dark": {
        "hex": "#000000",
        "alpha": 0.4
      }
    }
  },
  {
    "symbol": "lyricsDarkPrimary",
    "nativeOwner": "LyricsAppearance",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "lyrics-colors:LyricsAppearance:f2:歌词暗底主要文字",
    "selection": {
      "type": "arco",
      "id": "color-lyrics-primary",
      "appearance": "dark"
    },
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 0.9
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.9
      }
    }
  },
  {
    "symbol": "lyricLightUnselected",
    "nativeOwner": "NativeLyricsView",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "lyrics-colors:NativeLyricsView:f1:主歌词亮底未选中",
    "selection": {
      "type": "arco",
      "id": "color-black-a40",
      "appearance": "light"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.4
      },
      "dark": {
        "hex": "#000000",
        "alpha": 0.4
      }
    }
  },
  {
    "symbol": "lyricLightHover",
    "nativeOwner": "NativeLyricsView",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "lyrics-colors:NativeLyricsView:f1:主歌词亮底悬停",
    "selection": {
      "type": "arco",
      "id": "color-lyrics-primary",
      "appearance": "light"
    },
    "resolved": {
      "light": {
        "hex": "#1A1A1A",
        "alpha": 1
      },
      "dark": {
        "hex": "#1A1A1A",
        "alpha": 1
      }
    }
  },
  {
    "symbol": "lyricLightAuxIdle",
    "nativeOwner": "NativeLyricsView",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "lyrics-colors:NativeLyricsView:f1:辅助歌词亮底未选中",
    "selection": {
      "type": "arco",
      "id": "color-black-a40",
      "appearance": "light"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.4
      },
      "dark": {
        "hex": "#000000",
        "alpha": 0.4
      }
    }
  },
  {
    "symbol": "lyricLightAuxSelected",
    "nativeOwner": "NativeLyricsView",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "lyrics-colors:NativeLyricsView:f1:辅助歌词亮底选中",
    "selection": {
      "type": "arco",
      "id": "color-black-a40",
      "appearance": "light"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.4
      },
      "dark": {
        "hex": "#000000",
        "alpha": 0.4
      }
    }
  },
  {
    "symbol": "lyricLightAuxHover",
    "nativeOwner": "NativeLyricsView",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "lyrics-colors:NativeLyricsView:f1:辅助歌词亮底悬停",
    "selection": {
      "type": "arco",
      "id": "color-lyrics-primary",
      "appearance": "light"
    },
    "resolved": {
      "light": {
        "hex": "#1A1A1A",
        "alpha": 1
      },
      "dark": {
        "hex": "#1A1A1A",
        "alpha": 1
      }
    }
  },
  {
    "symbol": "lyricLightHighlight",
    "nativeOwner": "NativeLyricsView",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "lyrics-colors:NativeLyricsView:f1:歌词亮底高亮层",
    "selection": {
      "type": "role",
      "id": "lyrics-colors:LyricsAppearance:f2:歌词亮底主要文字"
    },
    "resolved": {
      "light": {
        "hex": "#1A1A1A",
        "alpha": 1
      },
      "dark": {
        "hex": "#1A1A1A",
        "alpha": 1
      }
    }
  },
  {
    "symbol": "lyricsLightTitleTransport",
    "nativeOwner": "LyricsAppearance",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "lyrics-colors:LyricsAppearance:title-transport:歌词亮底标题与播放控制",
    "selection": {
      "type": "arco",
      "id": "color-lyrics-primary",
      "appearance": "light"
    },
    "resolved": {
      "light": {
        "hex": "#1A1A1A",
        "alpha": 1
      },
      "dark": {
        "hex": "#1A1A1A",
        "alpha": 1
      }
    }
  },
  {
    "symbol": "lyricsDarkTitleTransport",
    "nativeOwner": "LyricsAppearance",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "lyrics-colors:LyricsAppearance:title-transport:歌词暗底标题与播放控制",
    "selection": {
      "type": "arco",
      "id": "color-lyrics-primary",
      "appearance": "dark"
    },
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 0.9
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.9
      }
    }
  },
  {
    "symbol": "lyricHighlight",
    "nativeOwner": "NativeLyricsView",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "lyrics-colors:NativeLyricsView:f1:歌词高亮层",
    "selection": {
      "type": "custom",
      "space": "sRGB",
      "shared": true,
      "values": {
        "light": {
          "hex": "#FFFFFF",
          "alpha": 1
        },
        "dark": {
          "hex": "#FFFFFF",
          "alpha": 1
        },
        "lightContrast": {
          "hex": "#FFFFFF",
          "alpha": 1
        },
        "darkContrast": {
          "hex": "#FFFFFF",
          "alpha": 1
        }
      }
    },
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 1
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 1
      }
    }
  },
  {
    "symbol": "resumeLyricsDark",
    "nativeOwner": "NativeLyricsView",
    "policy": "dynamic",
    "contrastSystemColor": null,
    "role": "lyrics-colors:NativeLyricsView:resume-dark:返回当前歌词按钮暗底填充",
    "selection": {
      "type": "arco",
      "id": "color-fill-2",
      "appearance": "dark"
    },
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 0.04
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.04
      }
    }
  },
  {
    "symbol": "lyricsVolumeTrackDark",
    "nativeOwner": "SonoPlayer",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "lyrics-colors:SonoPlayer:lyrics-volume-track-dark:歌词页音量底轨暗底",
    "selection": {
      "type": "arco",
      "id": "color-border-3",
      "appearance": "dark"
    },
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 0.4
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.4
      }
    }
  },
  {
    "symbol": "recommendationControlFill",
    "nativeOwner": "RecommendationViews",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "control-colors:RecommendationViews:recommendation-default-fill:推荐风格控件填充",
    "selection": {
      "type": "arco",
      "id": "color-fill-1"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.04
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.04
      }
    }
  },
  {
    "symbol": "recommendationPressedFill",
    "nativeOwner": "RecommendationViews",
    "policy": "candidate",
    "contrastSystemColor": null,
    "role": "control-colors:RecommendationViews:recommendation-pressed-fill:推荐按钮按下填充",
    "selection": {
      "type": "arco",
      "id": "color-fill-4"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.12
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.12
      }
    }
  },
  {
    "symbol": "capsuleSelectedIcon",
    "nativeOwner": "SonoPlayer",
    "policy": "confirmed",
    "contrastSystemColor": null,
    "role": "control-colors:SonoPlayer:capsule-selected-icon:侧栏选中图标",
    "selection": {
      "type": "role",
      "id": "brand:SonoStyle:brand-accent:强调色 · 设计已确认"
    },
    "resolved": {
      "light": {
        "hex": "#FF375F",
        "alpha": 1
      },
      "dark": {
        "hex": "#FF375F",
        "alpha": 1
      }
    }
  },
  {
    "symbol": "capsuleSelectedRing",
    "nativeOwner": "SonoPlayer",
    "policy": "confirmed",
    "contrastSystemColor": null,
    "role": "control-colors:SonoPlayer:capsule-selected-ring:侧栏封面选中环",
    "selection": {
      "type": "role",
      "id": "brand:SonoStyle:brand-accent:强调色 · 设计已确认"
    },
    "resolved": {
      "light": {
        "hex": "#FF375F",
        "alpha": 1
      },
      "dark": {
        "hex": "#FF375F",
        "alpha": 1
      }
    }
  },
  {
    "symbol": "sourceSelectedLight",
    "nativeOwner": "SourcePlaylistRow",
    "policy": "confirmed",
    "contrastSystemColor": null,
    "role": "list-colors:SourcePlaylistRow:drawer-selected-light:抽屉浅色选中前景",
    "selection": {
      "type": "role",
      "id": "list-colors:SourcePlaylistRow:o3:选中文字",
      "appearance": "dark"
    },
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 1
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 1
      }
    }
  },
  {
    "symbol": "lyricsProgressTrackDark",
    "nativeOwner": "SonoPlayer",
    "policy": "confirmed",
    "contrastSystemColor": null,
    "role": "lyrics-colors:SonoPlayer:lyrics-progress-track-dark:歌词页音乐底轨暗底",
    "selection": {
      "type": "arco",
      "id": "color-white-a20",
      "appearance": "dark"
    },
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 0.2
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.2
      }
    }
  },
  {
    "symbol": "lyricsDividerLight",
    "nativeOwner": "QueueContent",
    "policy": "confirmed",
    "contrastSystemColor": null,
    "role": "lyrics-colors:QueueContent:lyrics-divider-light:歌词页亮底分隔线",
    "selection": {
      "type": "role",
      "id": "list-colors:QueueContent:o6:亮底分隔线",
      "appearance": "light"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.2
      },
      "dark": {
        "hex": "#000000",
        "alpha": 0.2
      }
    }
  },
  {
    "symbol": "lyricsDividerDark",
    "nativeOwner": "QueueContent",
    "policy": "confirmed",
    "contrastSystemColor": null,
    "role": "lyrics-colors:QueueContent:lyrics-divider-dark:歌词页暗底分隔线",
    "selection": {
      "type": "role",
      "id": "list-colors:QueueContent:o6:暗底分隔线",
      "appearance": "dark"
    },
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 0.2
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.2
      }
    }
  },
  {
    "symbol": "lyricsQueueTabLight",
    "nativeOwner": "QueueContent",
    "policy": "confirmed",
    "contrastSystemColor": null,
    "role": "lyrics-colors:QueueContent:queue-tab-light:歌词页队列未选中页签亮底",
    "selection": {
      "type": "role",
      "id": "list-colors:QueueContent:queue-tab-light:普通队列浅色未选中页签",
      "appearance": "light"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.6
      },
      "dark": {
        "hex": "#000000",
        "alpha": 0.6
      }
    }
  },
  {
    "symbol": "lyricsQueueTabDark",
    "nativeOwner": "QueueContent",
    "policy": "confirmed",
    "contrastSystemColor": null,
    "role": "lyrics-colors:QueueContent:queue-tab-dark:歌词页队列未选中页签暗底",
    "selection": {
      "type": "role",
      "id": "list-colors:QueueContent:queue-tab-dark:普通队列深色未选中页签",
      "appearance": "dark"
    },
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 0.6
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.6
      }
    }
  },
  {
    "symbol": "lyricsQueueCloseLight",
    "nativeOwner": "QueueContent",
    "policy": "confirmed",
    "contrastSystemColor": null,
    "role": "lyrics-colors:QueueContent:queue-close-light:歌词页队列关闭图标亮底",
    "selection": {
      "type": "role",
      "id": "list-colors:QueueContent:queue-close-light:普通队列浅色关闭图标",
      "appearance": "light"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.6
      },
      "dark": {
        "hex": "#000000",
        "alpha": 0.6
      }
    }
  },
  {
    "symbol": "lyricsQueueCloseDark",
    "nativeOwner": "QueueContent",
    "policy": "confirmed",
    "contrastSystemColor": null,
    "role": "lyrics-colors:QueueContent:queue-close-dark:歌词页队列关闭图标暗底",
    "selection": {
      "type": "role",
      "id": "list-colors:QueueContent:queue-close-dark:普通队列深色关闭图标",
      "appearance": "dark"
    },
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 0.6
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.6
      }
    }
  },
  {
    "symbol": "lyricsQueueActionLight",
    "nativeOwner": "QueueContent",
    "policy": "confirmed",
    "contrastSystemColor": null,
    "role": "lyrics-colors:QueueContent:queue-action-light:歌词页队列操作图标亮底",
    "selection": {
      "type": "role",
      "id": "list-colors:QueueContent:o5:操作图标",
      "appearance": "light"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.6
      },
      "dark": {
        "hex": "#000000",
        "alpha": 0.6
      }
    }
  },
  {
    "symbol": "lyricsQueueActionDark",
    "nativeOwner": "QueueContent",
    "policy": "confirmed",
    "contrastSystemColor": null,
    "role": "lyrics-colors:QueueContent:queue-action-dark:歌词页队列操作图标暗底",
    "selection": {
      "type": "role",
      "id": "list-colors:QueueContent:queue-action-dark:普通队列深色操作图标",
      "appearance": "dark"
    },
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 0.6
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.6
      }
    }
  },
  {
    "symbol": "lyricsQueueScrollbarLight",
    "nativeOwner": "QueueContent",
    "policy": "confirmed",
    "contrastSystemColor": null,
    "role": "lyrics-colors:QueueContent:queue-scrollbar-light:歌词页队列滚动条亮底",
    "selection": {
      "type": "arco",
      "id": "color-black-a40",
      "appearance": "light"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.4
      },
      "dark": {
        "hex": "#000000",
        "alpha": 0.4
      }
    }
  },
  {
    "symbol": "lyricsQueueScrollbarDark",
    "nativeOwner": "QueueContent",
    "policy": "confirmed",
    "contrastSystemColor": null,
    "role": "lyrics-colors:QueueContent:queue-scrollbar-dark:歌词页队列滚动条暗底",
    "selection": {
      "type": "arco",
      "id": "color-white-a40",
      "appearance": "dark"
    },
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 0.4
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.4
      }
    }
  },
  {
    "symbol": "queueTabLight",
    "nativeOwner": "QueueContent",
    "policy": "confirmed",
    "contrastSystemColor": null,
    "role": "list-colors:QueueContent:queue-tab-light:普通队列浅色未选中页签",
    "selection": {
      "type": "arco",
      "id": "color-black-a60",
      "appearance": "light"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.6
      },
      "dark": {
        "hex": "#000000",
        "alpha": 0.6
      }
    }
  },
  {
    "symbol": "queueTabDark",
    "nativeOwner": "QueueContent",
    "policy": "confirmed",
    "contrastSystemColor": null,
    "role": "list-colors:QueueContent:queue-tab-dark:普通队列深色未选中页签",
    "selection": {
      "type": "arco",
      "id": "color-white-a60",
      "appearance": "dark"
    },
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 0.6
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.6
      }
    }
  },
  {
    "symbol": "queueCloseLight",
    "nativeOwner": "QueueContent",
    "policy": "confirmed",
    "contrastSystemColor": null,
    "role": "list-colors:QueueContent:queue-close-light:普通队列浅色关闭图标",
    "selection": {
      "type": "arco",
      "id": "color-black-a60",
      "appearance": "light"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.6
      },
      "dark": {
        "hex": "#000000",
        "alpha": 0.6
      }
    }
  },
  {
    "symbol": "queueCloseDark",
    "nativeOwner": "QueueContent",
    "policy": "confirmed",
    "contrastSystemColor": null,
    "role": "list-colors:QueueContent:queue-close-dark:普通队列深色关闭图标",
    "selection": {
      "type": "arco",
      "id": "color-white-a60",
      "appearance": "dark"
    },
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 0.6
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.6
      }
    }
  },
  {
    "symbol": "queueActionDark",
    "nativeOwner": "QueueContent",
    "policy": "confirmed",
    "contrastSystemColor": null,
    "role": "list-colors:QueueContent:queue-action-dark:普通队列深色操作图标",
    "selection": {
      "type": "arco",
      "id": "color-white-a60",
      "appearance": "dark"
    },
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 0.6
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.6
      }
    }
  },
  {
    "symbol": "searchFieldFill",
    "nativeOwner": "SonoPlayer",
    "policy": "applied",
    "contrastSystemColor": null,
    "role": "search-colors:SonoPlayer:field-fill:搜索框填充",
    "selection": {
      "type": "arco",
      "id": "color-fill-selected"
    },
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.18
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.18
      }
    }
  },
  {
    "symbol": "searchFocusRing",
    "nativeOwner": "SonoPlayer",
    "policy": "applied",
    "contrastSystemColor": null,
    "role": "search-colors:SonoPlayer:focus-ring:搜索框焦点外环",
    "selection": {
      "type": "role",
      "id": "brand:SonoStyle:brand-accent:强调色 · 设计已确认"
    },
    "resolved": {
      "light": {
        "hex": "#FF375F",
        "alpha": 1
      },
      "dark": {
        "hex": "#FF375F",
        "alpha": 1
      }
    }
  }
];
window.SONO_CONTROL_STATES = [
  {
    "role": "control-state:console-disabled",
    "label": "普通控制台 · 浅色禁用前景",
    "contrastSystemColor": null,
    "appearance": "light",
    "selection": {
      "type": "arco",
      "id": "color-black-a40",
      "appearance": "light"
    },
    "symbol": "consoleDisabledIcon",
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.4
      },
      "dark": {
        "hex": "#000000",
        "alpha": 0.4
      }
    },
    "stateColor": true,
    "nativeOwner": "SonoPlayer",
    "policy": "confirmed"
  },
  {
    "role": "control-state:console-hover",
    "label": "普通控制台 · 浅色悬停前景",
    "contrastSystemColor": null,
    "appearance": "light",
    "selection": {
      "type": "arco",
      "id": "color-black-a80",
      "appearance": "light"
    },
    "symbol": "consoleHoverIcon",
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.8
      },
      "dark": {
        "hex": "#000000",
        "alpha": 0.8
      }
    },
    "stateColor": true,
    "nativeOwner": "SonoPlayer",
    "policy": "confirmed"
  },
  {
    "contrastSystemColor": "disabledControlTextColor",
    "label": "全应用自定义控件 · 禁用前景",
    "role": "interface-color:interfaceDisabled",
    "policy": "applied",
    "selection": {
      "type": "arco",
      "id": "color-text-4"
    },
    "symbol": "interfaceDisabled",
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.4
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.4
      }
    },
    "stateColor": true,
    "nativeOwner": "SonoPlayer"
  },
  {
    "contrastSystemColor": "systemRed",
    "label": "普通页面及弹层 · 错误文字",
    "role": "interface-color:interfaceError",
    "policy": "applied",
    "selection": {
      "type": "arco",
      "id": "red-7"
    },
    "symbol": "interfaceError",
    "resolved": {
      "light": {
        "hex": "#D22931",
        "alpha": 1
      },
      "dark": {
        "hex": "#FF6663",
        "alpha": 1
      }
    },
    "stateColor": true,
    "nativeOwner": "SonoPlayer"
  },
  {
    "contrastSystemColor": "separatorColor",
    "label": "普通界面 · 分隔与轮廓",
    "role": "interface-color:interfaceBorder",
    "policy": "applied",
    "selection": {
      "type": "arco",
      "id": "color-border-1"
    },
    "symbol": "interfaceBorder",
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.2
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.2
      }
    },
    "stateColor": true,
    "nativeOwner": "SonoPlayer"
  },
  {
    "contrastSystemColor": "secondaryLabelColor",
    "label": "普通界面 · 占位图标",
    "role": "interface-color:interfacePlaceholderIcon",
    "policy": "applied",
    "selection": {
      "type": "arco",
      "id": "color-text-3"
    },
    "symbol": "interfacePlaceholderIcon",
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.4
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.4
      }
    },
    "stateColor": true,
    "nativeOwner": "SonoPlayer"
  },
  {
    "contrastSystemColor": null,
    "label": "弹层遮底与普通浮层阴影 · 复用已存黑30%",
    "role": "interface-color:interfaceBackdrop",
    "policy": "applied",
    "selection": {
      "type": "role",
      "id": "lyrics-colors:LyricsPage:o17:歌词面板阴影"
    },
    "symbol": "interfaceBackdrop",
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.1
      },
      "dark": {
        "hex": "#000000",
        "alpha": 0.1
      }
    },
    "stateColor": true,
    "nativeOwner": "SonoPlayer"
  },
  {
    "appearance": "dark",
    "contrastSystemColor": null,
    "label": "封面播放圆底／暗遮底操作前景 · 白90%",
    "role": "interface-color:artworkControlSurface",
    "policy": "applied",
    "selection": {
      "type": "arco",
      "id": "color-white-a90"
    },
    "symbol": "artworkControlSurface",
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 0.9
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.9
      }
    },
    "stateColor": true,
    "nativeOwner": "SonoPlayer"
  },
  {
    "appearance": "light",
    "contrastSystemColor": null,
    "label": "封面播放圆底内图标 · 保留场景深色前景",
    "role": "interface-color:artworkControlInk",
    "policy": "applied",
    "fixedValues": {
      "dark": {
        "hex": "#1D2129",
        "alpha": 1
      }
    },
    "note": "本轮仅更新浅色中性灰；深色封面按钮保留更新前固定浅色文字值，避免跨外观引用联动。",
    "selection": {
      "type": "arco",
      "id": "color-lyrics-primary",
      "appearance": "light"
    },
    "symbol": "artworkControlInk",
    "resolved": {
      "light": {
        "hex": "#1A1A1A",
        "alpha": 1
      },
      "dark": {
        "hex": "#1D2129",
        "alpha": 1
      }
    },
    "stateColor": true,
    "nativeOwner": "SonoPlayer"
  },
  {
    "contrastSystemColor": null,
    "label": "歌单折叠与队列控件 · 亮色悬停前景",
    "role": "interface-color:interfaceHoverForeground",
    "policy": "applied",
    "selection": {
      "type": "arco",
      "id": "color-black-a80",
      "appearance": "light"
    },
    "symbol": "interfaceHoverForeground",
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.8
      },
      "dark": {
        "hex": "#000000",
        "alpha": 0.8
      }
    },
    "stateColor": true,
    "nativeOwner": "SonoPlayer"
  },
  {
    "contrastSystemColor": null,
    "label": "歌单折叠与队列控件 · 暗色悬停前景",
    "role": "interface-color:interfaceHoverForegroundDark",
    "policy": "applied",
    "selection": {
      "type": "arco",
      "id": "color-white-a80",
      "appearance": "dark"
    },
    "symbol": "interfaceHoverForegroundDark",
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 0.8
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.8
      }
    },
    "stateColor": true,
    "nativeOwner": "SonoPlayer"
  },
  {
    "contrastSystemColor": null,
    "label": "我的歌单／收藏歌单折叠箭头 · 默认前景",
    "role": "interface-color:sourceSectionArrow",
    "policy": "applied",
    "selection": {
      "type": "arco",
      "id": "color-text-2"
    },
    "symbol": "sourceSectionArrow",
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.6
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.6
      }
    },
    "stateColor": true,
    "nativeOwner": "SonoPlayer"
  },
  {
    "contrastSystemColor": null,
    "label": "歌单行 · 暗色悬停填充",
    "role": "interface-color:sourceHoverDark",
    "policy": "applied",
    "selection": {
      "type": "arco",
      "id": "color-white-a08",
      "appearance": "dark"
    },
    "symbol": "sourceHoverDark",
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 0.08
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.08
      }
    },
    "stateColor": true,
    "nativeOwner": "SonoPlayer"
  },
  {
    "contrastSystemColor": null,
    "label": "小胶囊 · 暗色悬停背景",
    "role": "interface-color:modeHoverDark",
    "policy": "applied",
    "selection": {
      "type": "arco",
      "id": "color-white-a08",
      "appearance": "dark"
    },
    "symbol": "modeHoverDark",
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 0.08
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.08
      }
    },
    "stateColor": true,
    "nativeOwner": "SonoPlayer"
  },
  {
    "contrastSystemColor": null,
    "label": "普通队列歌曲名 · 浅色",
    "role": "interface-color:queueTitleLight",
    "policy": "applied",
    "selection": {
      "type": "arco",
      "id": "color-black-a80",
      "appearance": "light"
    },
    "symbol": "queueTitleLight",
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.8
      },
      "dark": {
        "hex": "#000000",
        "alpha": 0.8
      }
    },
    "stateColor": true,
    "nativeOwner": "SonoPlayer"
  },
  {
    "contrastSystemColor": null,
    "label": "普通队列歌曲名 · 深色",
    "role": "interface-color:queueTitleDark",
    "policy": "applied",
    "selection": {
      "type": "arco",
      "id": "color-white-a80",
      "appearance": "dark"
    },
    "symbol": "queueTitleDark",
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 0.8
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.8
      }
    },
    "stateColor": true,
    "nativeOwner": "SonoPlayer"
  },
  {
    "contrastSystemColor": null,
    "label": "普通队列歌手与来源 · 浅色",
    "role": "interface-color:queueTextSecondaryLight",
    "policy": "applied",
    "selection": {
      "type": "arco",
      "id": "color-black-a60",
      "appearance": "light"
    },
    "symbol": "queueTextSecondaryLight",
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.6
      },
      "dark": {
        "hex": "#000000",
        "alpha": 0.6
      }
    },
    "stateColor": true,
    "nativeOwner": "SonoPlayer"
  },
  {
    "contrastSystemColor": null,
    "label": "普通队列歌手与来源 · 深色",
    "role": "interface-color:queueTextSecondaryDark",
    "policy": "applied",
    "selection": {
      "type": "arco",
      "id": "color-white-a60",
      "appearance": "dark"
    },
    "symbol": "queueTextSecondaryDark",
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 0.6
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.6
      }
    },
    "stateColor": true,
    "nativeOwner": "SonoPlayer"
  },
  {
    "contrastSystemColor": null,
    "label": "普通队列已选中页签 · 浅色",
    "role": "interface-color:queueSelectedTabLight",
    "policy": "applied",
    "selection": {
      "type": "arco",
      "id": "sono-gray-0",
      "appearance": "light"
    },
    "symbol": "queueSelectedTabLight",
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 1
      },
      "dark": {
        "hex": "#000000",
        "alpha": 1
      }
    },
    "stateColor": true,
    "nativeOwner": "SonoPlayer"
  },
  {
    "contrastSystemColor": null,
    "label": "普通队列已选中页签 · 深色",
    "role": "interface-color:queueSelectedTabDark",
    "policy": "applied",
    "selection": {
      "type": "arco",
      "id": "sono-gray-11",
      "appearance": "dark"
    },
    "symbol": "queueSelectedTabDark",
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 1
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 1
      }
    },
    "stateColor": true,
    "nativeOwner": "SonoPlayer"
  },
  {
    "contrastSystemColor": null,
    "label": "队列控件 · 按下前景 · 浅色／亮底",
    "role": "interface-color:queuePressedLight",
    "policy": "applied",
    "selection": {
      "type": "arco",
      "id": "sono-gray-0",
      "appearance": "light"
    },
    "symbol": "queuePressedLight",
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 1
      },
      "dark": {
        "hex": "#000000",
        "alpha": 1
      }
    },
    "stateColor": true,
    "nativeOwner": "SonoPlayer"
  },
  {
    "contrastSystemColor": null,
    "label": "队列控件 · 按下前景 · 深色／暗底",
    "role": "interface-color:queuePressedDark",
    "policy": "applied",
    "selection": {
      "type": "arco",
      "id": "sono-gray-11",
      "appearance": "dark"
    },
    "symbol": "queuePressedDark",
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 1
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 1
      }
    },
    "stateColor": true,
    "nativeOwner": "SonoPlayer"
  },
  {
    "contrastSystemColor": null,
    "label": "队列控件 · 禁用前景 · 浅色／亮底",
    "role": "interface-color:queueDisabledLight",
    "policy": "applied",
    "selection": {
      "type": "arco",
      "id": "color-black-a40",
      "appearance": "light"
    },
    "symbol": "queueDisabledLight",
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.4
      },
      "dark": {
        "hex": "#000000",
        "alpha": 0.4
      }
    },
    "stateColor": true,
    "nativeOwner": "SonoPlayer"
  },
  {
    "contrastSystemColor": null,
    "label": "队列控件 · 禁用前景 · 深色／暗底",
    "role": "interface-color:queueDisabledDark",
    "policy": "applied",
    "selection": {
      "type": "arco",
      "id": "color-white-a40",
      "appearance": "dark"
    },
    "symbol": "queueDisabledDark",
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 0.4
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.4
      }
    },
    "stateColor": true,
    "nativeOwner": "SonoPlayer"
  },
  {
    "role": "interface-color:consoleDefaultIconDark",
    "label": "普通控制台 · 深色默认前景",
    "contrastSystemColor": null,
    "policy": "applied",
    "selection": {
      "type": "arco",
      "id": "sono-gray-11",
      "appearance": "dark"
    },
    "symbol": "consoleDefaultIconDark",
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 1
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 1
      }
    },
    "stateColor": true,
    "nativeOwner": "SonoPlayer"
  },
  {
    "role": "interface-color:consoleHoverIconDark",
    "label": "普通控制台 · 深色悬停前景",
    "contrastSystemColor": null,
    "policy": "applied",
    "selection": {
      "type": "arco",
      "id": "color-white-a80",
      "appearance": "dark"
    },
    "symbol": "consoleHoverIconDark",
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 0.8
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.8
      }
    },
    "stateColor": true,
    "nativeOwner": "SonoPlayer"
  },
  {
    "role": "interface-color:consoleDisabledIconDark",
    "label": "普通控制台 · 深色禁用前景",
    "contrastSystemColor": null,
    "policy": "applied",
    "selection": {
      "type": "arco",
      "id": "color-white-a40",
      "appearance": "dark"
    },
    "symbol": "consoleDisabledIconDark",
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 0.4
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.4
      }
    },
    "stateColor": true,
    "nativeOwner": "SonoPlayer"
  },
  {
    "role": "interface-color:consolePressedIconLight",
    "label": "普通控制台 · 浅色按下／选中前景",
    "contrastSystemColor": null,
    "policy": "applied",
    "selection": {
      "type": "arco",
      "id": "sono-gray-0",
      "appearance": "light"
    },
    "symbol": "consolePressedIconLight",
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 1
      },
      "dark": {
        "hex": "#000000",
        "alpha": 1
      }
    },
    "stateColor": true,
    "nativeOwner": "SonoPlayer"
  },
  {
    "role": "interface-color:consolePressedIconDark",
    "label": "普通控制台 · 深色按下／选中前景",
    "contrastSystemColor": null,
    "policy": "applied",
    "selection": {
      "type": "arco",
      "id": "sono-gray-11",
      "appearance": "dark"
    },
    "symbol": "consolePressedIconDark",
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 1
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 1
      }
    },
    "stateColor": true,
    "nativeOwner": "SonoPlayer"
  },
  {
    "role": "interface-color:progressChorusLight",
    "label": "播放进度条 · 副歌节点 · 浅色／亮底",
    "contrastSystemColor": null,
    "policy": "applied",
    "appearance": "light",
    "selection": {
      "type": "arco",
      "id": "color-black-a80",
      "appearance": "light"
    },
    "symbol": "progressChorusLight",
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.8
      },
      "dark": {
        "hex": "#000000",
        "alpha": 0.8
      }
    },
    "stateColor": true,
    "nativeOwner": "SonoPlayer"
  },
  {
    "role": "interface-color:progressChorusDark",
    "label": "播放进度条 · 副歌节点 · 深色／暗底",
    "contrastSystemColor": null,
    "policy": "applied",
    "appearance": "dark",
    "selection": {
      "type": "arco",
      "id": "color-white-a80",
      "appearance": "dark"
    },
    "symbol": "progressChorusDark",
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 0.8
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.8
      }
    },
    "stateColor": true,
    "nativeOwner": "SonoPlayer"
  },
  {
    "role": "interface-color:searchCategoryForeground",
    "label": "搜索／歌手分类页签 · 默认60%（悬停80%、按下100%、禁用40%共用控件状态）",
    "contrastSystemColor": "labelColor",
    "policy": "applied",
    "selection": {
      "type": "arco",
      "id": "color-text-2"
    },
    "symbol": "searchCategoryForeground",
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.6
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.6
      }
    },
    "stateColor": true,
    "nativeOwner": "SonoPlayer"
  },
  {
    "role": "interface-color:searchCategorySelectedForeground",
    "label": "搜索／歌手分类页签 · 已选中100%（悬停保持选中）",
    "contrastSystemColor": "labelColor",
    "policy": "applied",
    "selection": {
      "type": "arco",
      "id": "color-foreground-strong"
    },
    "symbol": "searchCategorySelectedForeground",
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 1
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 1
      }
    },
    "stateColor": true,
    "nativeOwner": "SonoPlayer"
  },
  {
    "role": "interface-color:settingsSurface",
    "label": "设置面板 · 一级容器",
    "contrastSystemColor": null,
    "policy": "applied",
    "selection": {
      "type": "arco",
      "id": "color-bg-2"
    },
    "symbol": "settingsSurface",
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 1
      },
      "dark": {
        "hex": "#232325",
        "alpha": 1
      }
    },
    "stateColor": true,
    "nativeOwner": "SonoPlayer"
  },
  {
    "role": "interface-color:settingsCard",
    "label": "设置分组卡片 · 二级容器",
    "contrastSystemColor": null,
    "policy": "applied",
    "selection": {
      "type": "arco",
      "id": "color-bg-3"
    },
    "symbol": "settingsCard",
    "resolved": {
      "light": {
        "hex": "#FAFAFC",
        "alpha": 1
      },
      "dark": {
        "hex": "#48484A",
        "alpha": 1
      }
    },
    "stateColor": true,
    "nativeOwner": "SonoPlayer"
  },
  {
    "role": "interface-color:settingsSidebar",
    "label": "设置侧栏 · 页面背景",
    "contrastSystemColor": null,
    "policy": "applied",
    "selection": {
      "type": "arco",
      "id": "color-bg-1"
    },
    "symbol": "settingsSidebar",
    "resolved": {
      "light": {
        "hex": "#F0F0F2",
        "alpha": 1
      },
      "dark": {
        "hex": "#000000",
        "alpha": 1
      }
    },
    "stateColor": true,
    "nativeOwner": "SonoPlayer"
  },
  {
    "role": "interface-color:settingsControlFill",
    "label": "设置下拉按钮 · 三级容器底色",
    "contrastSystemColor": null,
    "policy": "applied",
    "selection": {
      "type": "arco",
      "id": "color-bg-4"
    },
    "symbol": "settingsControlFill",
    "resolved": {
      "light": {
        "hex": "#F0F0F2",
        "alpha": 1
      },
      "dark": {
        "hex": "#5F5F61",
        "alpha": 1
      }
    },
    "stateColor": true,
    "nativeOwner": "SonoPlayer"
  },
  {
    "role": "interface-color:settingsControlHover",
    "label": "设置下拉按钮 · 悬停填充",
    "contrastSystemColor": null,
    "policy": "applied",
    "selection": {
      "type": "arco",
      "id": "color-fill-3"
    },
    "symbol": "settingsControlHover",
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.08
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.08
      }
    },
    "stateColor": true,
    "nativeOwner": "SonoPlayer"
  },
  {
    "role": "interface-color:settingsControlPressed",
    "label": "设置下拉按钮 · 按下填充",
    "contrastSystemColor": null,
    "policy": "applied",
    "selection": {
      "type": "arco",
      "id": "color-fill-4"
    },
    "symbol": "settingsControlPressed",
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.12
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.12
      }
    },
    "stateColor": true,
    "nativeOwner": "SonoPlayer"
  },
  {
    "contrastSystemColor": null,
    "label": "推荐风格 · 品牌按钮悬停",
    "role": "interface-color:recommendationAccentHover",
    "policy": "applied",
    "selection": {
      "type": "arco",
      "id": "primary-5"
    },
    "symbol": "recommendationAccentHover",
    "resolved": {
      "light": {
        "hex": "#FF5A76",
        "alpha": 1
      },
      "dark": {
        "hex": "#FF5A76",
        "alpha": 1
      }
    },
    "stateColor": true,
    "nativeOwner": "SonoPlayer"
  },
  {
    "contrastSystemColor": null,
    "label": "推荐风格 · 品牌按钮按下",
    "role": "interface-color:recommendationAccentPressed",
    "policy": "applied",
    "selection": {
      "type": "arco",
      "id": "primary-7"
    },
    "symbol": "recommendationAccentPressed",
    "resolved": {
      "light": {
        "hex": "#D2224B",
        "alpha": 1
      },
      "dark": {
        "hex": "#D2224B",
        "alpha": 1
      }
    },
    "stateColor": true,
    "nativeOwner": "SonoPlayer"
  },
  {
    "role": "interface-color:monochromeAccent",
    "label": "黑白主题色",
    "contrastSystemColor": null,
    "policy": "applied",
    "selection": {
      "type": "arco",
      "id": "sono-monochrome-accent"
    },
    "symbol": "monochromeAccent",
    "resolved": {
      "light": {
        "hex": "#000000",
        "alpha": 0.9
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.9
      }
    },
    "stateColor": true,
    "nativeOwner": "SonoPlayer"
  },
  {
    "role": "interface-color:monochromeOnAccent",
    "label": "黑白主题色上的前景",
    "contrastSystemColor": null,
    "policy": "applied",
    "selection": {
      "type": "arco",
      "id": "sono-monochrome-on-accent"
    },
    "symbol": "monochromeOnAccent",
    "resolved": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 1
      },
      "dark": {
        "hex": "#000000",
        "alpha": 1
      }
    },
    "stateColor": true,
    "nativeOwner": "SonoPlayer"
  }
];
window.SONO_CAPSULE_SELECTION_RING_WIDTH = 2;
window.SONO_NATIVE_DRAFT = {
  "version": 1,
  "selections": {
    "brand:SonoStyle:brand-accent:强调色 · 设计已确认": {
      "type": "arco",
      "id": "primary-6"
    },
    "brand:SonoStyle:brand-favorite:收藏色 · 设计已确认": {
      "type": "custom",
      "space": "sRGB",
      "shared": true,
      "values": {
        "light": {
          "hex": "#FC3D49",
          "alpha": 1
        },
        "dark": {
          "hex": "#FC3D49",
          "alpha": 1
        },
        "lightContrast": {
          "hex": "#FC3D49",
          "alpha": 1
        },
        "darkContrast": {
          "hex": "#FC3D49",
          "alpha": 1
        }
      }
    },
    "home-background:SonoStyle:f0:浏览页背景 / 黑色": {
      "type": "arco",
      "id": "sono-page-background"
    },
    "home-background:CarouselPreview:f6:封面预览占位底色": {
      "type": "arco",
      "id": "color-fill-2"
    },
    "home-background:RecommendationViews:f7:推荐风格选择面板背景": {
      "type": "arco",
      "id": "color-bg-2"
    },
    "home-background:ArtistChoiceView:f8:艺人选择背景": {
      "type": "arco",
      "id": "color-bg-2"
    },
    "home-background:NativeBrowseScene:f13:封面底色": {
      "type": "arco",
      "id": "color-fill-2"
    },
    "home-background:ArtistChoiceView:o19:艺人关闭按钮": {
      "type": "arco",
      "id": "color-fill-3"
    },
    "home-background:ArtistChoiceView:o19:头像占位": {
      "type": "arco",
      "id": "color-fill-2"
    },
    "home-background:ArtistChoiceView:o19:悬停": {
      "type": "arco",
      "id": "color-fill-3"
    },
    "text-colors:LyricsAppearance:f1:深色场景主要文字 / 白色": {
      "type": "arco",
      "id": "color-text-1"
    },
    "text-colors:NativeBrowseScene:f15:封面原因文字": {
      "type": "arco",
      "id": "color-text-3"
    },
    "text-colors:NativeBrowseScene:f16:非中心标题": {
      "type": "arco",
      "id": "color-text-2"
    },
    "text-colors:NativeBrowseScene:f17:非中心艺人": {
      "type": "arco",
      "id": "color-text-2"
    },
    "text-colors:SonoPlayer:f20:普通导航文字": {
      "type": "arco",
      "id": "color-text-1"
    },
    "text-colors:SonoPlayer:o4:设置说明": {
      "type": "arco",
      "id": "color-text-2"
    },
    "text-colors:SonoPlayer:o4:底部说明": {
      "type": "arco",
      "id": "color-text-2"
    },
    "text-colors:SonoPlayer:o4:通知": {
      "type": "arco",
      "id": "color-text-2"
    },
    "lyrics-colors:LyricsAppearance:f18:歌词暗底辅助文字": {
      "type": "arco",
      "id": "color-white-a60",
      "appearance": "dark"
    },
    "lyrics-colors:NativeLyricsView:o14:返回当前歌词按钮": {
      "type": "arco",
      "id": "color-fill-2",
      "appearance": "light"
    },
    "lyrics-colors:LyricsPage:o17:歌词面板阴影": {
      "type": "shadow",
      "id": "shadow2-center"
    },
    "lyrics-colors:LyricsPage:o17:队列拖动行阴影": {
      "type": "shadow",
      "id": "shadow2-center"
    },
    "list-colors:CollectionTitleCapsule:f4:歌单标题胶囊背景": {
      "type": "arco",
      "id": "color-bg-2"
    },
    "list-colors:QuickList:f5:歌单位置徽标": {
      "type": "arco",
      "id": "color-foreground-strong"
    },
    "list-colors:CarouselRail:f9:轮播轨道底色 / 高亮": {
      "type": "arco",
      "id": "color-border-4"
    },
    "list-colors:CarouselRail:f10:轮播轨道滑块": {
      "type": "arco",
      "id": "color-border-4"
    },
    "list-colors:CarouselRail:f11:轮播右侧文字底色": {
      "type": "arco",
      "id": "color-foreground-strong"
    },
    "list-colors:CollectionTitleCapsule:f19:胶囊标题文字": {
      "type": "arco",
      "id": "color-text-1"
    },
    "list-colors:QueueRowMotion:s0:队列「置顶」背景": {
      "type": "arco",
      "id": "purple-6"
    },
    "list-colors:QueueRowMotion:s1:队列「删除」背景": {
      "type": "arco",
      "id": "red-6"
    },
    "list-colors:QueueRowMotion:s2:删除动效线": {
      "type": "arco",
      "id": "red-6"
    },
    "list-colors:QueueContent:s3:队列拖动行背景": {
      "type": "arco",
      "id": "primary-6"
    },
    "list-colors:SourcePlaylistRow:o3:来源行文字": {
      "type": "arco",
      "id": "color-text-1"
    },
    "list-colors:SourcePlaylistRow:o3:选中文字": {
      "type": "arco",
      "id": "color-foreground-strong"
    },
    "list-colors:QueueContent:o5:队列辅助文字": {
      "type": "arco",
      "id": "color-text-2"
    },
    "list-colors:QueueContent:o5:操作图标": {
      "type": "arco",
      "id": "color-black-a60",
      "appearance": "light"
    },
    "list-colors:QueueContent:o5:未选标签": {
      "type": "arco",
      "id": "color-text-2"
    },
    "list-colors:QueueContent:o6:亮底分隔线": {
      "type": "arco",
      "id": "color-black-a20",
      "appearance": "light"
    },
    "list-colors:QueueContent:o6:暗底分隔线": {
      "type": "arco",
      "id": "color-white-a20",
      "appearance": "dark"
    },
    "list-colors:SourcePlaylistRow:o7:来源行选中": {
      "type": "role",
      "id": "brand:SonoStyle:brand-accent:强调色 · 设计已确认"
    },
    "list-colors:SourcePlaylistRow:o7:悬停": {
      "type": "arco",
      "id": "color-black-a08",
      "appearance": "light"
    },
    "list-colors:QuickList:o9:快捷列表悬停": {
      "type": "arco",
      "id": "color-fill-3"
    },
    "list-colors:QuickList:o9:封面占位": {
      "type": "arco",
      "id": "color-fill-2"
    },
    "list-colors:QuickList:o13:亮底滚动条": {
      "type": "arco",
      "id": "color-black-a40",
      "appearance": "light"
    },
    "list-colors:QuickList:o13:暗底滚动条": {
      "type": "arco",
      "id": "color-white-a40",
      "appearance": "dark"
    },
    "list-colors:QuickList:o13:快捷列表滚动条": {
      "type": "arco",
      "id": "color-border-4"
    },
    "list-colors:QueueContent:o15:历史封面": {
      "type": "arco",
      "id": "color-black-a40"
    },
    "list-colors:QueueContent:o15:快捷列表悬停播放底色": {
      "type": "arco",
      "id": "color-black-a40"
    },
    "list-colors:SourcePlaylistRow:o20:来源图标默认": {
      "type": "arco",
      "id": "color-text-2"
    },
    "list-colors:SourcePlaylistRow:o20:来源图标按下": {
      "type": "arco",
      "id": "color-foreground-strong"
    },
    "search-colors:SearchSuggestionRow:o1:搜索建议文字": {
      "type": "arco",
      "id": "color-text-2"
    },
    "search-colors:SearchSuggestionRow:o1:匹配文字": {
      "type": "role",
      "id": "brand:SonoStyle:brand-accent:强调色 · 设计已确认"
    },
    "search-colors:SearchSuggestionRow:o1:类别图标": {
      "type": "arco",
      "id": "color-text-2"
    },
    "search-colors:BrowseSearchField:o2:搜索占位文字": {
      "type": "arco",
      "id": "color-text-3"
    },
    "search-colors:SearchSuggestionRow:o8:搜索建议选中": {
      "type": "arco",
      "id": "color-fill-3"
    },
    "search-colors:SearchScopeSelection:o18:搜索范围选中": {
      "type": "role",
      "id": "brand:SonoStyle:brand-accent:强调色 · 设计已确认"
    },
    "search-colors:SearchScopeSelection:o18:搜索范围悬停": {
      "type": "arco",
      "id": "color-fill-3"
    },
    "search-colors:SearchScopeSelection:o18:搜索范围图标默认": {
      "type": "arco",
      "id": "sono-gray-11"
    },
    "search-colors:SearchScopeSelection:o18:搜索范围图标弱化": {
      "type": "custom",
      "space": "sRGB",
      "shared": false,
      "values": {
        "light": {
          "hex": "#000000",
          "alpha": 0.8
        },
        "dark": {
          "hex": "#FFFFFF",
          "alpha": 0.8
        },
        "lightContrast": {
          "hex": "#000000",
          "alpha": 0.8
        },
        "darkContrast": {
          "hex": "#FFFFFF",
          "alpha": 0.8
        }
      }
    },
    "control-colors:NativeBrowseScene:f14:加载图标": {
      "type": "arco",
      "id": "color-text-1"
    },
    "control-colors:SonoPlayer:f21:未选图标乘色": {
      "type": "arco",
      "id": "sono-gray-0",
      "appearance": "light"
    },
    "control-colors:SonoPlayer:o0:工具图标": {
      "type": "arco",
      "id": "color-foreground-strong"
    },
    "control-colors:SonoPlayer:o10:悬停": {
      "type": "arco",
      "id": "color-black-a08",
      "appearance": "light"
    },
    "control-colors:SonoPlayer:o11:设置路径底色": {
      "type": "arco",
      "id": "color-bg-4"
    },
    "control-colors:SonoPlayer:o11:本地来源行容器": {
      "type": "arco",
      "id": "color-bg-2"
    },
    "control-colors:SonoPlayer:o12:播放进度底轨": {
      "type": "arco",
      "id": "color-progress-track"
    },
    "control-colors:SonoPlayer:o12:音量底轨": {
      "type": "arco",
      "id": "color-progress-track"
    },
    "control-colors:SonoStyle:o21:浓厚玻璃附加底色": {
      "type": "custom",
      "space": "sRGB",
      "shared": true,
      "values": {
        "light": {
          "hex": "#000000",
          "alpha": 0.32
        },
        "dark": {
          "hex": "#000000",
          "alpha": 0.32
        },
        "lightContrast": {
          "hex": "#000000",
          "alpha": 0.32
        },
        "darkContrast": {
          "hex": "#000000",
          "alpha": 0.32
        }
      }
    },
    "feedback-colors:NativeBrowseScene:s4:封面错误文字": {
      "type": "custom",
      "space": "sRGB",
      "shared": true,
      "values": {
        "light": {
          "hex": "#FFF0EC",
          "alpha": 1
        },
        "dark": {
          "hex": "#FFF0EC",
          "alpha": 1
        },
        "lightContrast": {
          "hex": "#FFF0EC",
          "alpha": 1
        },
        "darkContrast": {
          "hex": "#FFF0EC",
          "alpha": 1
        }
      }
    },
    "feedback-colors:NativeBrowseScene:s5:封面错误遮罩": {
      "type": "custom",
      "space": "sRGB",
      "shared": true,
      "values": {
        "light": {
          "hex": "#080B0D",
          "alpha": 0.65
        },
        "dark": {
          "hex": "#080B0D",
          "alpha": 0.65
        },
        "lightContrast": {
          "hex": "#080B0D",
          "alpha": 0.65
        },
        "darkContrast": {
          "hex": "#080B0D",
          "alpha": 0.65
        }
      }
    },
    "feedback-colors:NativeBrowseScene:o16:封面播放提示底色": {
      "type": "arco",
      "id": "color-black-a40"
    },
    "lyrics-colors:NativeLyricsView:f1:主歌词暗底静态": {
      "type": "arco",
      "id": "color-lyrics-primary",
      "appearance": "dark"
    },
    "lyrics-colors:NativeLyricsView:f1:主歌词暗底未选中": {
      "type": "arco",
      "id": "color-white-a40",
      "appearance": "dark"
    },
    "lyrics-colors:NativeLyricsView:f1:主歌词暗底选中底层": {
      "type": "arco",
      "id": "color-white-a40",
      "appearance": "dark"
    },
    "lyrics-colors:NativeLyricsView:f1:主歌词亮底静态": {
      "type": "arco",
      "id": "color-lyrics-primary",
      "appearance": "light"
    },
    "lyrics-colors:NativeLyricsView:f1:主歌词亮底动态底层": {
      "type": "arco",
      "id": "color-black-a40",
      "appearance": "light"
    },
    "lyrics-colors:NativeLyricsView:f1:辅助歌词暗底未选中": {
      "type": "arco",
      "id": "color-white-a40",
      "appearance": "dark"
    },
    "lyrics-colors:NativeLyricsView:f1:辅助歌词暗底选中": {
      "type": "arco",
      "id": "color-white-a40",
      "appearance": "dark"
    },
    "lyrics-colors:NativeLyricsView:f1:辅助歌词暗底悬停": {
      "type": "arco",
      "id": "color-lyrics-primary",
      "appearance": "dark"
    },
    "lyrics-colors:LyricsMetalBackground:lyrics-background:动态封面渐变／歌词背景": {
      "type": "current",
      "description": "动态提色与渲染规则；不能替换为单一实色"
    },
    "list-colors:SourcePlaylistRow:o3:普通图标": {
      "type": "arco",
      "id": "color-text-2"
    },
    "lyrics-colors:SonoPlayer:lyrics-progress-track:歌词页音乐底轨": {
      "type": "arco",
      "id": "color-black-a20",
      "appearance": "light"
    },
    "lyrics-colors:LyricsPage:f22:歌词页面板": {
      "type": "arco",
      "id": "color-bg-2",
      "appearance": "light"
    },
    "lyrics-colors:NativeLyricsView:f1:主歌词暗底悬停": {
      "type": "arco",
      "id": "color-lyrics-primary",
      "appearance": "dark"
    },
    "lyrics-colors:LyricsAppearance:f3:歌词亮底辅助文字": {
      "type": "arco",
      "id": "color-black-a60",
      "appearance": "light"
    },
    "lyrics-colors:LyricsAppearance:f2:歌词亮底主要文字": {
      "type": "arco",
      "id": "color-lyrics-primary",
      "appearance": "light"
    },
    "lyrics-colors:SonoPlayer:lyrics-volume-track:歌词页音量底轨": {
      "type": "arco",
      "id": "color-border-3",
      "appearance": "light"
    },
    "lyrics-colors:LyricsAppearance:f2:歌词暗底主要文字": {
      "type": "arco",
      "id": "color-lyrics-primary",
      "appearance": "dark"
    },
    "lyrics-colors:NativeLyricsView:f1:主歌词亮底未选中": {
      "type": "arco",
      "id": "color-black-a40",
      "appearance": "light"
    },
    "lyrics-colors:NativeLyricsView:f1:主歌词亮底悬停": {
      "type": "arco",
      "id": "color-lyrics-primary",
      "appearance": "light"
    },
    "lyrics-colors:NativeLyricsView:f1:辅助歌词亮底未选中": {
      "type": "arco",
      "id": "color-black-a40",
      "appearance": "light"
    },
    "lyrics-colors:NativeLyricsView:f1:辅助歌词亮底选中": {
      "type": "arco",
      "id": "color-black-a40",
      "appearance": "light"
    },
    "lyrics-colors:NativeLyricsView:f1:辅助歌词亮底悬停": {
      "type": "arco",
      "id": "color-lyrics-primary",
      "appearance": "light"
    },
    "lyrics-colors:NativeLyricsView:f1:歌词亮底高亮层": {
      "type": "role",
      "id": "lyrics-colors:LyricsAppearance:f2:歌词亮底主要文字"
    },
    "lyrics-colors:LyricsAppearance:title-transport:歌词亮底标题与播放控制": {
      "type": "arco",
      "id": "color-lyrics-primary",
      "appearance": "light"
    },
    "lyrics-colors:LyricsAppearance:title-transport:歌词暗底标题与播放控制": {
      "type": "arco",
      "id": "color-lyrics-primary",
      "appearance": "dark"
    },
    "lyrics-colors:NativeLyricsView:f1:歌词高亮层": {
      "type": "custom",
      "space": "sRGB",
      "shared": true,
      "values": {
        "light": {
          "hex": "#FFFFFF",
          "alpha": 1
        },
        "dark": {
          "hex": "#FFFFFF",
          "alpha": 1
        },
        "lightContrast": {
          "hex": "#FFFFFF",
          "alpha": 1
        },
        "darkContrast": {
          "hex": "#FFFFFF",
          "alpha": 1
        }
      }
    },
    "lyrics-colors:NativeLyricsView:resume-dark:返回当前歌词按钮暗底填充": {
      "type": "arco",
      "id": "color-fill-2",
      "appearance": "dark"
    },
    "lyrics-colors:SonoPlayer:lyrics-volume-track-dark:歌词页音量底轨暗底": {
      "type": "arco",
      "id": "color-border-3",
      "appearance": "dark"
    },
    "control-colors:RecommendationViews:recommendation-default-fill:推荐风格控件填充": {
      "type": "arco",
      "id": "color-fill-1"
    },
    "control-colors:RecommendationViews:recommendation-pressed-fill:推荐按钮按下填充": {
      "type": "arco",
      "id": "color-fill-4"
    },
    "control-colors:SonoPlayer:capsule-selected-icon:侧栏选中图标": {
      "type": "role",
      "id": "brand:SonoStyle:brand-accent:强调色 · 设计已确认"
    },
    "control-colors:SonoPlayer:capsule-selected-ring:侧栏封面选中环": {
      "type": "role",
      "id": "brand:SonoStyle:brand-accent:强调色 · 设计已确认"
    },
    "list-colors:SourcePlaylistRow:drawer-selected-light:抽屉浅色选中前景": {
      "type": "role",
      "id": "list-colors:SourcePlaylistRow:o3:选中文字",
      "appearance": "dark"
    },
    "control-state:console-disabled": {
      "type": "arco",
      "id": "color-black-a40",
      "appearance": "light"
    },
    "control-state:console-hover": {
      "type": "arco",
      "id": "color-black-a80",
      "appearance": "light"
    },
    "interface-color:interfaceDisabled": {
      "type": "arco",
      "id": "color-text-4"
    },
    "interface-color:interfaceError": {
      "type": "arco",
      "id": "red-7"
    },
    "interface-color:interfaceBorder": {
      "type": "arco",
      "id": "color-border-1"
    },
    "interface-color:interfacePlaceholderIcon": {
      "type": "arco",
      "id": "color-text-3"
    },
    "interface-color:interfaceBackdrop": {
      "type": "role",
      "id": "lyrics-colors:LyricsPage:o17:歌词面板阴影"
    },
    "interface-color:artworkControlSurface": {
      "type": "arco",
      "id": "color-white-a90"
    },
    "interface-color:artworkControlInk": {
      "type": "arco",
      "id": "color-lyrics-primary",
      "appearance": "light"
    },
    "lyrics-colors:SonoPlayer:lyrics-progress-track-dark:歌词页音乐底轨暗底": {
      "type": "arco",
      "id": "color-white-a20",
      "appearance": "dark"
    },
    "lyrics-colors:QueueContent:lyrics-divider-light:歌词页亮底分隔线": {
      "type": "role",
      "id": "list-colors:QueueContent:o6:亮底分隔线",
      "appearance": "light"
    },
    "lyrics-colors:QueueContent:lyrics-divider-dark:歌词页暗底分隔线": {
      "type": "role",
      "id": "list-colors:QueueContent:o6:暗底分隔线",
      "appearance": "dark"
    },
    "lyrics-colors:QueueContent:queue-tab-light:歌词页队列未选中页签亮底": {
      "type": "role",
      "id": "list-colors:QueueContent:queue-tab-light:普通队列浅色未选中页签",
      "appearance": "light"
    },
    "lyrics-colors:QueueContent:queue-tab-dark:歌词页队列未选中页签暗底": {
      "type": "role",
      "id": "list-colors:QueueContent:queue-tab-dark:普通队列深色未选中页签",
      "appearance": "dark"
    },
    "lyrics-colors:QueueContent:queue-close-light:歌词页队列关闭图标亮底": {
      "type": "role",
      "id": "list-colors:QueueContent:queue-close-light:普通队列浅色关闭图标",
      "appearance": "light"
    },
    "lyrics-colors:QueueContent:queue-close-dark:歌词页队列关闭图标暗底": {
      "type": "role",
      "id": "list-colors:QueueContent:queue-close-dark:普通队列深色关闭图标",
      "appearance": "dark"
    },
    "lyrics-colors:QueueContent:queue-action-light:歌词页队列操作图标亮底": {
      "type": "role",
      "id": "list-colors:QueueContent:o5:操作图标",
      "appearance": "light"
    },
    "lyrics-colors:QueueContent:queue-action-dark:歌词页队列操作图标暗底": {
      "type": "role",
      "id": "list-colors:QueueContent:queue-action-dark:普通队列深色操作图标",
      "appearance": "dark"
    },
    "lyrics-colors:QueueContent:queue-scrollbar-light:歌词页队列滚动条亮底": {
      "type": "arco",
      "id": "color-black-a40",
      "appearance": "light"
    },
    "lyrics-colors:QueueContent:queue-scrollbar-dark:歌词页队列滚动条暗底": {
      "type": "arco",
      "id": "color-white-a40",
      "appearance": "dark"
    },
    "list-colors:QueueContent:queue-tab-light:普通队列浅色未选中页签": {
      "type": "arco",
      "id": "color-black-a60",
      "appearance": "light"
    },
    "list-colors:QueueContent:queue-tab-dark:普通队列深色未选中页签": {
      "type": "arco",
      "id": "color-white-a60",
      "appearance": "dark"
    },
    "list-colors:QueueContent:queue-close-light:普通队列浅色关闭图标": {
      "type": "arco",
      "id": "color-black-a60",
      "appearance": "light"
    },
    "list-colors:QueueContent:queue-close-dark:普通队列深色关闭图标": {
      "type": "arco",
      "id": "color-white-a60",
      "appearance": "dark"
    },
    "list-colors:QueueContent:queue-action-dark:普通队列深色操作图标": {
      "type": "arco",
      "id": "color-white-a60",
      "appearance": "dark"
    },
    "interface-color:interfaceHoverForeground": {
      "type": "arco",
      "id": "color-black-a80",
      "appearance": "light"
    },
    "interface-color:interfaceHoverForegroundDark": {
      "type": "arco",
      "id": "color-white-a80",
      "appearance": "dark"
    },
    "interface-color:sourceSectionArrow": {
      "type": "arco",
      "id": "color-text-2"
    },
    "interface-color:sourceHoverDark": {
      "type": "arco",
      "id": "color-white-a08",
      "appearance": "dark"
    },
    "interface-color:modeHoverDark": {
      "type": "arco",
      "id": "color-white-a08",
      "appearance": "dark"
    },
    "interface-color:queueTitleLight": {
      "type": "arco",
      "id": "color-black-a80",
      "appearance": "light"
    },
    "interface-color:queueTitleDark": {
      "type": "arco",
      "id": "color-white-a80",
      "appearance": "dark"
    },
    "interface-color:queueTextSecondaryLight": {
      "type": "arco",
      "id": "color-black-a60",
      "appearance": "light"
    },
    "interface-color:queueTextSecondaryDark": {
      "type": "arco",
      "id": "color-white-a60",
      "appearance": "dark"
    },
    "interface-color:queueSelectedTabLight": {
      "type": "arco",
      "id": "sono-gray-0",
      "appearance": "light"
    },
    "interface-color:queueSelectedTabDark": {
      "type": "arco",
      "id": "sono-gray-11",
      "appearance": "dark"
    },
    "interface-color:queuePressedLight": {
      "type": "arco",
      "id": "sono-gray-0",
      "appearance": "light"
    },
    "interface-color:queuePressedDark": {
      "type": "arco",
      "id": "sono-gray-11",
      "appearance": "dark"
    },
    "interface-color:queueDisabledLight": {
      "type": "arco",
      "id": "color-black-a40",
      "appearance": "light"
    },
    "interface-color:queueDisabledDark": {
      "type": "arco",
      "id": "color-white-a40",
      "appearance": "dark"
    },
    "interface-color:consoleDefaultIconDark": {
      "type": "arco",
      "id": "sono-gray-11",
      "appearance": "dark"
    },
    "interface-color:consoleHoverIconDark": {
      "type": "arco",
      "id": "color-white-a80",
      "appearance": "dark"
    },
    "interface-color:consoleDisabledIconDark": {
      "type": "arco",
      "id": "color-white-a40",
      "appearance": "dark"
    },
    "interface-color:consolePressedIconLight": {
      "type": "arco",
      "id": "sono-gray-0",
      "appearance": "light"
    },
    "interface-color:consolePressedIconDark": {
      "type": "arco",
      "id": "sono-gray-11",
      "appearance": "dark"
    },
    "interface-color:progressChorusLight": {
      "type": "arco",
      "id": "color-black-a80",
      "appearance": "light"
    },
    "interface-color:progressChorusDark": {
      "type": "arco",
      "id": "color-white-a80",
      "appearance": "dark"
    },
    "interface-color:searchCategoryForeground": {
      "type": "arco",
      "id": "color-text-2"
    },
    "interface-color:searchCategorySelectedForeground": {
      "type": "arco",
      "id": "color-foreground-strong"
    },
    "interface-color:settingsSurface": {
      "type": "arco",
      "id": "color-bg-2"
    },
    "interface-color:settingsCard": {
      "type": "arco",
      "id": "color-bg-3"
    },
    "interface-color:settingsSidebar": {
      "type": "arco",
      "id": "color-bg-1"
    },
    "interface-color:settingsControlFill": {
      "type": "arco",
      "id": "color-bg-4"
    },
    "interface-color:settingsControlHover": {
      "type": "arco",
      "id": "color-fill-3"
    },
    "interface-color:settingsControlPressed": {
      "type": "arco",
      "id": "color-fill-4"
    },
    "interface-color:recommendationAccentHover": {
      "type": "arco",
      "id": "primary-5"
    },
    "interface-color:recommendationAccentPressed": {
      "type": "arco",
      "id": "primary-7"
    },
    "interface-color:monochromeAccent": {
      "type": "arco",
      "id": "sono-monochrome-accent"
    },
    "interface-color:monochromeOnAccent": {
      "type": "arco",
      "id": "sono-monochrome-on-accent"
    },
    "search-colors:SonoPlayer:field-fill:搜索框填充": {
      "type": "arco",
      "id": "color-fill-selected"
    },
    "search-colors:SonoPlayer:focus-ring:搜索框焦点外环": {
      "type": "role",
      "id": "brand:SonoStyle:brand-accent:强调色 · 设计已确认"
    }
  },
  "tokens": {},
  "primary": "#FF375F",
  "refinementRevision": 4,
  "lyricsTrackReferenceRevision": 1
};
window.SONO_NATIVE_SOURCE_REVISION = "83304e7101f7cd3d";
