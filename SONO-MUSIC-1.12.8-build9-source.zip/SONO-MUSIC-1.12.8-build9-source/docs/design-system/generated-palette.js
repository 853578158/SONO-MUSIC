// Generated from colors.json; do not edit.
window.ARCO_COLORS = [
  {
    "group": "文字与图标",
    "id": "color-text-1",
    "name": "主要文字",
    "sono": true,
    "alias": true,
    "references": {
      "light": "color-black-a80",
      "dark": "color-white-a80"
    },
    "displayName": "主标题／歌曲名／图标悬停",
    "values": {
      "light": {
        "hex": "#000000",
        "alpha": 0.8
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.8
      }
    }
  },
  {
    "group": "文字与图标",
    "id": "color-text-2",
    "name": "辅助文字／普通图标",
    "sono": true,
    "alias": true,
    "references": {
      "light": "color-black-a60",
      "dark": "color-white-a60"
    },
    "displayName": "副标题／歌手／辅助文字／普通图标",
    "values": {
      "light": {
        "hex": "#000000",
        "alpha": 0.6
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.6
      }
    }
  },
  {
    "group": "文字与图标",
    "id": "color-text-3",
    "name": "弱化／占位文字",
    "sono": true,
    "alias": true,
    "references": {
      "light": "color-black-a40",
      "dark": "color-white-a40"
    },
    "displayWith": "color-text-4",
    "values": {
      "light": {
        "hex": "#000000",
        "alpha": 0.4
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.4
      }
    }
  },
  {
    "group": "文字与图标",
    "id": "color-text-4",
    "name": "禁用前景",
    "sono": true,
    "alias": true,
    "references": {
      "light": "color-black-a40",
      "dark": "color-white-a40"
    },
    "displayName": "禁用／弱化／占位文字与图标",
    "values": {
      "light": {
        "hex": "#000000",
        "alpha": 0.4
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.4
      }
    }
  },
  {
    "group": "边框色",
    "id": "color-border-1",
    "name": "分隔线",
    "sono": true,
    "alias": true,
    "references": {
      "light": "color-black-a20",
      "dark": "color-white-a20"
    },
    "displayName": "分隔线／默认边框",
    "values": {
      "light": {
        "hex": "#000000",
        "alpha": 0.2
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.2
      }
    }
  },
  {
    "group": "边框色",
    "id": "color-border-2",
    "name": "默认边框",
    "sono": true,
    "alias": true,
    "references": {
      "light": "color-black-a20",
      "dark": "color-white-a20"
    },
    "displayWith": "color-border-1",
    "values": {
      "light": {
        "hex": "#000000",
        "alpha": 0.2
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.2
      }
    }
  },
  {
    "group": "边框色",
    "id": "color-border-3",
    "name": "强调边框／轨道",
    "sono": true,
    "alias": true,
    "references": {
      "light": "color-black-a40",
      "dark": "color-white-a40"
    },
    "displayWith": "color-border-4",
    "values": {
      "light": {
        "hex": "#000000",
        "alpha": 0.4
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.4
      }
    }
  },
  {
    "group": "边框色",
    "id": "color-border-4",
    "name": "重边框／滚动条",
    "sono": true,
    "alias": true,
    "references": {
      "light": "color-black-a40",
      "dark": "color-white-a40"
    },
    "displayName": "强调边框／轨道／滚动条",
    "values": {
      "light": {
        "hex": "#000000",
        "alpha": 0.4
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.4
      }
    }
  },
  {
    "group": "控件背景与状态填充",
    "id": "color-fill-1",
    "name": "轻填充",
    "sono": true,
    "alias": true,
    "references": {
      "light": "color-black-a04",
      "dark": "color-white-a04"
    },
    "displayWith": "color-fill-2",
    "values": {
      "light": {
        "hex": "#000000",
        "alpha": 0.04
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.04
      }
    }
  },
  {
    "group": "控件背景与状态填充",
    "id": "color-fill-2",
    "name": "默认填充",
    "sono": true,
    "alias": true,
    "references": {
      "light": "color-black-a04",
      "dark": "color-white-a04"
    },
    "displayName": "轻填充／默认填充",
    "values": {
      "light": {
        "hex": "#000000",
        "alpha": 0.04
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.04
      }
    }
  },
  {
    "group": "控件背景与状态填充",
    "id": "color-fill-3",
    "name": "悬停填充",
    "sono": true,
    "alias": true,
    "references": {
      "light": "color-black-a08",
      "dark": "color-white-a08"
    },
    "values": {
      "light": {
        "hex": "#000000",
        "alpha": 0.08
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.08
      }
    }
  },
  {
    "group": "控件背景与状态填充",
    "id": "color-fill-4",
    "name": "按下填充",
    "sono": true,
    "alias": true,
    "references": {
      "light": "color-black-a12",
      "dark": "color-white-a12"
    },
    "values": {
      "light": {
        "hex": "#000000",
        "alpha": 0.12
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.12
      }
    }
  },
  {
    "group": "背景色",
    "id": "color-bg-1",
    "name": "页面背景",
    "sono": true,
    "alias": true,
    "references": {
      "light": "sono-gray-9",
      "dark": "sono-gray-0"
    },
    "displayName": "页面背景",
    "values": {
      "light": {
        "hex": "#F0F0F2",
        "alpha": 1
      },
      "dark": {
        "hex": "#000000",
        "alpha": 1
      }
    }
  },
  {
    "group": "背景色",
    "id": "color-bg-2",
    "name": "容器背景",
    "sono": true,
    "alias": true,
    "references": {
      "light": "sono-gray-11",
      "dark": "sono-gray-2"
    },
    "values": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 1
      },
      "dark": {
        "hex": "#232325",
        "alpha": 1
      }
    }
  },
  {
    "group": "背景色",
    "id": "color-bg-3",
    "name": "二级容器",
    "sono": true,
    "alias": true,
    "references": {
      "light": "sono-gray-10",
      "dark": "sono-gray-3"
    },
    "values": {
      "light": {
        "hex": "#FAFAFC",
        "alpha": 1
      },
      "dark": {
        "hex": "#48484A",
        "alpha": 1
      }
    }
  },
  {
    "group": "背景色",
    "id": "color-bg-4",
    "name": "三级容器",
    "sono": true,
    "alias": true,
    "references": {
      "light": "sono-gray-9",
      "dark": "sono-gray-4"
    },
    "values": {
      "light": {
        "hex": "#F0F0F2",
        "alpha": 1
      },
      "dark": {
        "hex": "#5F5F61",
        "alpha": 1
      }
    }
  },
  {
    "group": "背景色",
    "id": "color-bg-5",
    "name": "浮层背景",
    "sono": true,
    "alias": true,
    "references": {
      "light": "sono-gray-11",
      "dark": "sono-gray-3"
    },
    "values": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 1
      },
      "dark": {
        "hex": "#48484A",
        "alpha": 1
      }
    }
  },
  {
    "group": "背景色",
    "id": "sono-page-background",
    "name": "页面背景",
    "sono": true,
    "alias": true,
    "references": {
      "light": "sono-gray-9",
      "dark": "sono-gray-0"
    },
    "displayWith": "color-bg-1",
    "values": {
      "light": {
        "hex": "#F0F0F2",
        "alpha": 1
      },
      "dark": {
        "hex": "#000000",
        "alpha": 1
      }
    }
  },
  {
    "group": "主色",
    "id": "primary-1",
    "name": "浅底悬停",
    "sono": true,
    "values": {
      "light": {
        "hex": "#FFE8E9",
        "alpha": 1
      },
      "dark": {
        "hex": "#FFE8E9",
        "alpha": 1
      }
    }
  },
  {
    "group": "主色",
    "id": "primary-2",
    "name": "文字禁用",
    "sono": true,
    "values": {
      "light": {
        "hex": "#FFC5C9",
        "alpha": 1
      },
      "dark": {
        "hex": "#FFC5C9",
        "alpha": 1
      }
    }
  },
  {
    "group": "主色",
    "id": "primary-3",
    "name": "一般禁用",
    "sono": true,
    "values": {
      "light": {
        "hex": "#FFA1AB",
        "alpha": 1
      },
      "dark": {
        "hex": "#FFA1AB",
        "alpha": 1
      }
    }
  },
  {
    "group": "主色",
    "id": "primary-4",
    "name": "特殊场景",
    "sono": true,
    "values": {
      "light": {
        "hex": "#FF7E8F",
        "alpha": 1
      },
      "dark": {
        "hex": "#FF7E8F",
        "alpha": 1
      }
    }
  },
  {
    "group": "主色",
    "id": "primary-5",
    "name": "悬停",
    "sono": true,
    "values": {
      "light": {
        "hex": "#FF5A76",
        "alpha": 1
      },
      "dark": {
        "hex": "#FF5A76",
        "alpha": 1
      }
    }
  },
  {
    "group": "主色",
    "id": "primary-6",
    "name": "常规",
    "sono": true,
    "values": {
      "light": {
        "hex": "#FF375F",
        "alpha": 1
      },
      "dark": {
        "hex": "#FF375F",
        "alpha": 1
      }
    }
  },
  {
    "group": "主色",
    "id": "primary-7",
    "name": "按下",
    "sono": true,
    "values": {
      "light": {
        "hex": "#D2224B",
        "alpha": 1
      },
      "dark": {
        "hex": "#D2224B",
        "alpha": 1
      }
    }
  },
  {
    "group": "主色",
    "id": "primary-8",
    "name": "强调 8",
    "sono": true,
    "values": {
      "light": {
        "hex": "#A61239",
        "alpha": 1
      },
      "dark": {
        "hex": "#A61239",
        "alpha": 1
      }
    }
  },
  {
    "group": "主色",
    "id": "primary-9",
    "name": "强调 9",
    "sono": true,
    "values": {
      "light": {
        "hex": "#790729",
        "alpha": 1
      },
      "dark": {
        "hex": "#790729",
        "alpha": 1
      }
    }
  },
  {
    "group": "主色",
    "id": "primary-10",
    "name": "强调 10",
    "sono": true,
    "values": {
      "light": {
        "hex": "#4D0019",
        "alpha": 1
      },
      "dark": {
        "hex": "#4D0019",
        "alpha": 1
      }
    }
  },
  {
    "group": "主色",
    "id": "color-primary-light-1",
    "name": "主色浅填充 1",
    "sono": true,
    "values": {
      "light": {
        "hex": "#FF375F",
        "alpha": 0.08
      },
      "dark": {
        "hex": "#FF375F",
        "alpha": 0.08
      }
    }
  },
  {
    "group": "主色",
    "id": "color-primary-light-2",
    "name": "主色浅填充 2",
    "sono": true,
    "values": {
      "light": {
        "hex": "#FF375F",
        "alpha": 0.16
      },
      "dark": {
        "hex": "#FF375F",
        "alpha": 0.16
      }
    }
  },
  {
    "group": "主色",
    "id": "color-primary-light-3",
    "name": "主色浅填充 3",
    "sono": true,
    "values": {
      "light": {
        "hex": "#FF375F",
        "alpha": 0.24
      },
      "dark": {
        "hex": "#FF375F",
        "alpha": 0.24
      }
    }
  },
  {
    "group": "主色",
    "id": "color-primary-light-4",
    "name": "主色浅填充 4",
    "sono": true,
    "values": {
      "light": {
        "hex": "#FF375F",
        "alpha": 0.4
      },
      "dark": {
        "hex": "#FF375F",
        "alpha": 0.4
      }
    }
  },
  {
    "group": "暗夜紫",
    "id": "purple-1",
    "name": "暗夜紫 1",
    "sourceUrl": "https://cdn.jsdelivr.net/npm/@arco-design/color@0.4.0/src/index.js",
    "values": {
      "light": {
        "hex": "#F5E8FF",
        "alpha": 1
      },
      "dark": {
        "hex": "#16004D",
        "alpha": 1
      }
    }
  },
  {
    "group": "暗夜紫",
    "id": "purple-2",
    "name": "暗夜紫 2",
    "sourceUrl": "https://cdn.jsdelivr.net/npm/@arco-design/color@0.4.0/src/index.js",
    "values": {
      "light": {
        "hex": "#DDBEF6",
        "alpha": 1
      },
      "dark": {
        "hex": "#27066E",
        "alpha": 1
      }
    }
  },
  {
    "group": "暗夜紫",
    "id": "purple-3",
    "name": "暗夜紫 3",
    "sourceUrl": "https://cdn.jsdelivr.net/npm/@arco-design/color@0.4.0/src/index.js",
    "values": {
      "light": {
        "hex": "#C396ED",
        "alpha": 1
      },
      "dark": {
        "hex": "#3E138F",
        "alpha": 1
      }
    }
  },
  {
    "group": "暗夜紫",
    "id": "purple-4",
    "name": "暗夜紫 4",
    "sourceUrl": "https://cdn.jsdelivr.net/npm/@arco-design/color@0.4.0/src/index.js",
    "values": {
      "light": {
        "hex": "#A871E3",
        "alpha": 1
      },
      "dark": {
        "hex": "#5A25B0",
        "alpha": 1
      }
    }
  },
  {
    "group": "暗夜紫",
    "id": "purple-5",
    "name": "暗夜紫 5",
    "sourceUrl": "https://cdn.jsdelivr.net/npm/@arco-design/color@0.4.0/src/index.js",
    "values": {
      "light": {
        "hex": "#8D4EDA",
        "alpha": 1
      },
      "dark": {
        "hex": "#7B3DD1",
        "alpha": 1
      }
    }
  },
  {
    "group": "暗夜紫",
    "id": "purple-6",
    "name": "暗夜紫 6",
    "sourceUrl": "https://cdn.jsdelivr.net/npm/@arco-design/color@0.4.0/src/index.js",
    "values": {
      "light": {
        "hex": "#722ED1",
        "alpha": 1
      },
      "dark": {
        "hex": "#8E51DA",
        "alpha": 1
      }
    }
  },
  {
    "group": "暗夜紫",
    "id": "purple-7",
    "name": "暗夜紫 7",
    "sourceUrl": "https://cdn.jsdelivr.net/npm/@arco-design/color@0.4.0/src/index.js",
    "values": {
      "light": {
        "hex": "#551DB0",
        "alpha": 1
      },
      "dark": {
        "hex": "#A974E3",
        "alpha": 1
      }
    }
  },
  {
    "group": "暗夜紫",
    "id": "purple-8",
    "name": "暗夜紫 8",
    "sourceUrl": "https://cdn.jsdelivr.net/npm/@arco-design/color@0.4.0/src/index.js",
    "values": {
      "light": {
        "hex": "#3C108F",
        "alpha": 1
      },
      "dark": {
        "hex": "#C59AED",
        "alpha": 1
      }
    }
  },
  {
    "group": "暗夜紫",
    "id": "purple-9",
    "name": "暗夜紫 9",
    "sourceUrl": "https://cdn.jsdelivr.net/npm/@arco-design/color@0.4.0/src/index.js",
    "values": {
      "light": {
        "hex": "#27066E",
        "alpha": 1
      },
      "dark": {
        "hex": "#DFC2F6",
        "alpha": 1
      }
    }
  },
  {
    "group": "暗夜紫",
    "id": "purple-10",
    "name": "暗夜紫 10",
    "sourceUrl": "https://cdn.jsdelivr.net/npm/@arco-design/color@0.4.0/src/index.js",
    "values": {
      "light": {
        "hex": "#16004D",
        "alpha": 1
      },
      "dark": {
        "hex": "#F7EDFF",
        "alpha": 1
      }
    }
  },
  {
    "group": "青春紫",
    "id": "pinkpurple-1",
    "name": "青春紫 1",
    "sourceUrl": "https://cdn.jsdelivr.net/npm/@arco-design/color@0.4.0/src/index.js",
    "values": {
      "light": {
        "hex": "#FFE8FB",
        "alpha": 1
      },
      "dark": {
        "hex": "#42004D",
        "alpha": 1
      }
    }
  },
  {
    "group": "青春紫",
    "id": "pinkpurple-2",
    "name": "青春紫 2",
    "sourceUrl": "https://cdn.jsdelivr.net/npm/@arco-design/color@0.4.0/src/index.js",
    "values": {
      "light": {
        "hex": "#F7BAEF",
        "alpha": 1
      },
      "dark": {
        "hex": "#650370",
        "alpha": 1
      }
    }
  },
  {
    "group": "青春紫",
    "id": "pinkpurple-3",
    "name": "青春紫 3",
    "sourceUrl": "https://cdn.jsdelivr.net/npm/@arco-design/color@0.4.0/src/index.js",
    "values": {
      "light": {
        "hex": "#F08EE6",
        "alpha": 1
      },
      "dark": {
        "hex": "#8A0D93",
        "alpha": 1
      }
    }
  },
  {
    "group": "青春紫",
    "id": "pinkpurple-4",
    "name": "青春紫 4",
    "sourceUrl": "https://cdn.jsdelivr.net/npm/@arco-design/color@0.4.0/src/index.js",
    "values": {
      "light": {
        "hex": "#E865DF",
        "alpha": 1
      },
      "dark": {
        "hex": "#B01BB6",
        "alpha": 1
      }
    }
  },
  {
    "group": "青春紫",
    "id": "pinkpurple-5",
    "name": "青春紫 5",
    "sourceUrl": "https://cdn.jsdelivr.net/npm/@arco-design/color@0.4.0/src/index.js",
    "values": {
      "light": {
        "hex": "#E13EDB",
        "alpha": 1
      },
      "dark": {
        "hex": "#D92ED9",
        "alpha": 1
      }
    }
  },
  {
    "group": "青春紫",
    "id": "pinkpurple-6",
    "name": "青春紫 6",
    "sourceUrl": "https://cdn.jsdelivr.net/npm/@arco-design/color@0.4.0/src/index.js",
    "values": {
      "light": {
        "hex": "#D91AD9",
        "alpha": 1
      },
      "dark": {
        "hex": "#E13DDB",
        "alpha": 1
      }
    }
  },
  {
    "group": "青春紫",
    "id": "pinkpurple-7",
    "name": "青春紫 7",
    "sourceUrl": "https://cdn.jsdelivr.net/npm/@arco-design/color@0.4.0/src/index.js",
    "values": {
      "light": {
        "hex": "#B010B6",
        "alpha": 1
      },
      "dark": {
        "hex": "#E866DF",
        "alpha": 1
      }
    }
  },
  {
    "group": "青春紫",
    "id": "pinkpurple-8",
    "name": "青春紫 8",
    "sourceUrl": "https://cdn.jsdelivr.net/npm/@arco-design/color@0.4.0/src/index.js",
    "values": {
      "light": {
        "hex": "#8A0993",
        "alpha": 1
      },
      "dark": {
        "hex": "#F092E6",
        "alpha": 1
      }
    }
  },
  {
    "group": "青春紫",
    "id": "pinkpurple-9",
    "name": "青春紫 9",
    "sourceUrl": "https://cdn.jsdelivr.net/npm/@arco-design/color@0.4.0/src/index.js",
    "values": {
      "light": {
        "hex": "#650370",
        "alpha": 1
      },
      "dark": {
        "hex": "#F7C1F0",
        "alpha": 1
      }
    }
  },
  {
    "group": "青春紫",
    "id": "pinkpurple-10",
    "name": "青春紫 10",
    "sourceUrl": "https://cdn.jsdelivr.net/npm/@arco-design/color@0.4.0/src/index.js",
    "values": {
      "light": {
        "hex": "#42004D",
        "alpha": 1
      },
      "dark": {
        "hex": "#FFF2FD",
        "alpha": 1
      }
    }
  },
  {
    "group": "浪漫红",
    "id": "red-1",
    "name": "浪漫红 1",
    "sono": true,
    "sourceLabel": "Sono 自定义红色梯度 · 6号 #FF4245",
    "sourceUrl": "assets/sono-red-ramp-20261116.svg",
    "values": {
      "light": {
        "hex": "#FFEBE8",
        "alpha": 1
      },
      "dark": {
        "hex": "#4D000E",
        "alpha": 1
      }
    }
  },
  {
    "group": "浪漫红",
    "id": "red-2",
    "name": "浪漫红 2",
    "sono": true,
    "sourceLabel": "Sono 自定义红色梯度 · 6号 #FF4245",
    "sourceUrl": "assets/sono-red-ramp-20261116.svg",
    "values": {
      "light": {
        "hex": "#FFCDC7",
        "alpha": 1
      },
      "dark": {
        "hex": "#700616",
        "alpha": 1
      }
    }
  },
  {
    "group": "浪漫红",
    "id": "red-3",
    "name": "浪漫红 3",
    "sono": true,
    "sourceLabel": "Sono 自定义红色梯度 · 6号 #FF4245",
    "sourceUrl": "assets/sono-red-ramp-20261116.svg",
    "values": {
      "light": {
        "hex": "#FFADA6",
        "alpha": 1
      },
      "dark": {
        "hex": "#940F1F",
        "alpha": 1
      }
    }
  },
  {
    "group": "浪漫红",
    "id": "red-4",
    "name": "浪漫红 4",
    "sono": true,
    "sourceLabel": "Sono 自定义红色梯度 · 6号 #FF4245",
    "sourceUrl": "assets/sono-red-ramp-20261116.svg",
    "values": {
      "light": {
        "hex": "#FF8B84",
        "alpha": 1
      },
      "dark": {
        "hex": "#B81D29",
        "alpha": 1
      }
    }
  },
  {
    "group": "浪漫红",
    "id": "red-5",
    "name": "浪漫红 5",
    "sono": true,
    "sourceLabel": "Sono 自定义红色梯度 · 6号 #FF4245",
    "sourceUrl": "assets/sono-red-ramp-20261116.svg",
    "values": {
      "light": {
        "hex": "#FF6663",
        "alpha": 1
      },
      "dark": {
        "hex": "#DB2D36",
        "alpha": 1
      }
    }
  },
  {
    "group": "浪漫红",
    "id": "red-6",
    "name": "浪漫红 6",
    "sono": true,
    "sourceLabel": "Sono 自定义红色梯度 · 6号 #FF4245",
    "sourceUrl": "assets/sono-red-ramp-20261116.svg",
    "values": {
      "light": {
        "hex": "#FF4245",
        "alpha": 1
      },
      "dark": {
        "hex": "#FF4245",
        "alpha": 1
      }
    }
  },
  {
    "group": "浪漫红",
    "id": "red-7",
    "name": "浪漫红 7",
    "sono": true,
    "sourceLabel": "Sono 自定义红色梯度 · 6号 #FF4245",
    "sourceUrl": "assets/sono-red-ramp-20261116.svg",
    "values": {
      "light": {
        "hex": "#D22931",
        "alpha": 1
      },
      "dark": {
        "hex": "#FF6663",
        "alpha": 1
      }
    }
  },
  {
    "group": "浪漫红",
    "id": "red-8",
    "name": "浪漫红 8",
    "sono": true,
    "sourceLabel": "Sono 自定义红色梯度 · 6号 #FF4245",
    "sourceUrl": "assets/sono-red-ramp-20261116.svg",
    "values": {
      "light": {
        "hex": "#A61521",
        "alpha": 1
      },
      "dark": {
        "hex": "#FF8B84",
        "alpha": 1
      }
    }
  },
  {
    "group": "浪漫红",
    "id": "red-9",
    "name": "浪漫红 9",
    "sono": true,
    "sourceLabel": "Sono 自定义红色梯度 · 6号 #FF4245",
    "sourceUrl": "assets/sono-red-ramp-20261116.svg",
    "values": {
      "light": {
        "hex": "#790815",
        "alpha": 1
      },
      "dark": {
        "hex": "#FFADA6",
        "alpha": 1
      }
    }
  },
  {
    "group": "浪漫红",
    "id": "red-10",
    "name": "浪漫红 10",
    "sono": true,
    "sourceLabel": "Sono 自定义红色梯度 · 6号 #FF4245",
    "sourceUrl": "assets/sono-red-ramp-20261116.svg",
    "values": {
      "light": {
        "hex": "#4D000B",
        "alpha": 1
      },
      "dark": {
        "hex": "#FFCDC7",
        "alpha": 1
      }
    }
  },
  {
    "group": "中性灰",
    "id": "sono-gray-0",
    "name": "实色灰阶 0 · 纯黑",
    "sono": true,
    "values": {
      "light": {
        "hex": "#000000",
        "alpha": 1
      },
      "dark": {
        "hex": "#000000",
        "alpha": 1
      }
    },
    "counterpart": "sono-gray-11"
  },
  {
    "group": "中性灰",
    "id": "sono-gray-1",
    "name": "实色灰阶 1",
    "sono": true,
    "values": {
      "light": {
        "hex": "#171719",
        "alpha": 1
      },
      "dark": {
        "hex": "#171719",
        "alpha": 1
      }
    }
  },
  {
    "group": "中性灰",
    "id": "sono-gray-2",
    "name": "实色灰阶 2",
    "sono": true,
    "values": {
      "light": {
        "hex": "#232325",
        "alpha": 1
      },
      "dark": {
        "hex": "#232325",
        "alpha": 1
      }
    }
  },
  {
    "group": "中性灰",
    "id": "sono-gray-3",
    "name": "实色灰阶 3",
    "sono": true,
    "values": {
      "light": {
        "hex": "#48484A",
        "alpha": 1
      },
      "dark": {
        "hex": "#48484A",
        "alpha": 1
      }
    }
  },
  {
    "group": "中性灰",
    "id": "sono-gray-4",
    "name": "实色灰阶 4",
    "sono": true,
    "values": {
      "light": {
        "hex": "#5F5F61",
        "alpha": 1
      },
      "dark": {
        "hex": "#5F5F61",
        "alpha": 1
      }
    }
  },
  {
    "group": "中性灰",
    "id": "sono-gray-5",
    "name": "实色灰阶 5",
    "sono": true,
    "values": {
      "light": {
        "hex": "#78787A",
        "alpha": 1
      },
      "dark": {
        "hex": "#78787A",
        "alpha": 1
      }
    }
  },
  {
    "group": "中性灰",
    "id": "sono-gray-6",
    "name": "实色灰阶 6",
    "sono": true,
    "values": {
      "light": {
        "hex": "#929294",
        "alpha": 1
      },
      "dark": {
        "hex": "#929294",
        "alpha": 1
      }
    }
  },
  {
    "group": "中性灰",
    "id": "sono-gray-7",
    "name": "实色灰阶 7",
    "sono": true,
    "values": {
      "light": {
        "hex": "#B5B5B7",
        "alpha": 1
      },
      "dark": {
        "hex": "#B5B5B7",
        "alpha": 1
      }
    }
  },
  {
    "group": "中性灰",
    "id": "sono-gray-8",
    "name": "实色灰阶 8",
    "sono": true,
    "values": {
      "light": {
        "hex": "#DFDFE1",
        "alpha": 1
      },
      "dark": {
        "hex": "#DFDFE1",
        "alpha": 1
      }
    }
  },
  {
    "group": "中性灰",
    "id": "sono-gray-9",
    "name": "实色灰阶 9",
    "sono": true,
    "values": {
      "light": {
        "hex": "#F0F0F2",
        "alpha": 1
      },
      "dark": {
        "hex": "#F0F0F2",
        "alpha": 1
      }
    }
  },
  {
    "group": "中性灰",
    "id": "sono-gray-10",
    "name": "实色灰阶 10",
    "sono": true,
    "values": {
      "light": {
        "hex": "#FAFAFC",
        "alpha": 1
      },
      "dark": {
        "hex": "#FAFAFC",
        "alpha": 1
      }
    }
  },
  {
    "group": "中性灰",
    "id": "sono-gray-11",
    "name": "实色灰阶 11 · 纯白",
    "sono": true,
    "values": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 1
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 1
      }
    },
    "counterpart": "sono-gray-0"
  },
  {
    "group": "黑白透明色阶",
    "id": "color-black-a04",
    "name": "纯黑 4%",
    "sono": true,
    "counterpart": "color-white-a04",
    "values": {
      "light": {
        "hex": "#000000",
        "alpha": 0.04
      },
      "dark": {
        "hex": "#000000",
        "alpha": 0.04
      }
    }
  },
  {
    "group": "黑白透明色阶",
    "id": "color-black-a08",
    "name": "纯黑 8%",
    "sono": true,
    "counterpart": "color-white-a08",
    "values": {
      "light": {
        "hex": "#000000",
        "alpha": 0.08
      },
      "dark": {
        "hex": "#000000",
        "alpha": 0.08
      }
    }
  },
  {
    "group": "黑白透明色阶",
    "id": "color-black-a12",
    "name": "纯黑 12%",
    "sono": true,
    "counterpart": "color-white-a12",
    "values": {
      "light": {
        "hex": "#000000",
        "alpha": 0.12
      },
      "dark": {
        "hex": "#000000",
        "alpha": 0.12
      }
    }
  },
  {
    "group": "黑白透明色阶",
    "id": "color-black-a18",
    "name": "纯黑 18%",
    "sono": true,
    "counterpart": "color-white-a18",
    "values": {
      "light": {
        "hex": "#000000",
        "alpha": 0.18
      },
      "dark": {
        "hex": "#000000",
        "alpha": 0.18
      }
    }
  },
  {
    "group": "黑白透明色阶",
    "id": "color-black-a20",
    "name": "纯黑 20%",
    "sono": true,
    "counterpart": "color-white-a20",
    "values": {
      "light": {
        "hex": "#000000",
        "alpha": 0.2
      },
      "dark": {
        "hex": "#000000",
        "alpha": 0.2
      }
    }
  },
  {
    "group": "黑白透明色阶",
    "id": "color-black-a40",
    "name": "纯黑 40%",
    "sono": true,
    "counterpart": "color-white-a40",
    "values": {
      "light": {
        "hex": "#000000",
        "alpha": 0.4
      },
      "dark": {
        "hex": "#000000",
        "alpha": 0.4
      }
    }
  },
  {
    "group": "黑白透明色阶",
    "id": "color-black-a60",
    "name": "纯黑 60%",
    "sono": true,
    "counterpart": "color-white-a60",
    "values": {
      "light": {
        "hex": "#000000",
        "alpha": 0.6
      },
      "dark": {
        "hex": "#000000",
        "alpha": 0.6
      }
    }
  },
  {
    "group": "黑白透明色阶",
    "id": "color-black-a68",
    "name": "纯黑 68%",
    "sono": true,
    "counterpart": "color-white-a68",
    "values": {
      "light": {
        "hex": "#000000",
        "alpha": 0.68
      },
      "dark": {
        "hex": "#000000",
        "alpha": 0.68
      }
    }
  },
  {
    "group": "黑白透明色阶",
    "id": "color-black-a80",
    "name": "纯黑 80%",
    "sono": true,
    "counterpart": "color-white-a80",
    "values": {
      "light": {
        "hex": "#000000",
        "alpha": 0.8
      },
      "dark": {
        "hex": "#000000",
        "alpha": 0.8
      }
    }
  },
  {
    "group": "黑白透明色阶",
    "id": "color-black-a90",
    "name": "纯黑 90%",
    "sono": true,
    "counterpart": "color-white-a90",
    "values": {
      "light": {
        "hex": "#000000",
        "alpha": 0.9
      },
      "dark": {
        "hex": "#000000",
        "alpha": 0.9
      }
    }
  },
  {
    "group": "黑白透明色阶",
    "id": "color-white-a04",
    "name": "纯白 4%",
    "sono": true,
    "counterpart": "color-black-a04",
    "values": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 0.04
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.04
      }
    }
  },
  {
    "group": "黑白透明色阶",
    "id": "color-white-a08",
    "name": "纯白 8%",
    "sono": true,
    "counterpart": "color-black-a08",
    "values": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 0.08
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.08
      }
    }
  },
  {
    "group": "黑白透明色阶",
    "id": "color-white-a12",
    "name": "纯白 12%",
    "sono": true,
    "counterpart": "color-black-a12",
    "values": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 0.12
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.12
      }
    }
  },
  {
    "group": "黑白透明色阶",
    "id": "color-white-a18",
    "name": "纯白 18%",
    "sono": true,
    "counterpart": "color-black-a18",
    "values": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 0.18
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.18
      }
    }
  },
  {
    "group": "黑白透明色阶",
    "id": "color-white-a20",
    "name": "纯白 20%",
    "sono": true,
    "counterpart": "color-black-a20",
    "values": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 0.2
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.2
      }
    }
  },
  {
    "group": "黑白透明色阶",
    "id": "color-white-a40",
    "name": "纯白 40%",
    "sono": true,
    "counterpart": "color-black-a40",
    "values": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 0.4
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.4
      }
    }
  },
  {
    "group": "黑白透明色阶",
    "id": "color-white-a60",
    "name": "纯白 60%",
    "sono": true,
    "counterpart": "color-black-a60",
    "values": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 0.6
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.6
      }
    }
  },
  {
    "group": "黑白透明色阶",
    "id": "color-white-a68",
    "name": "纯白 68%",
    "sono": true,
    "counterpart": "color-black-a68",
    "values": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 0.68
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.68
      }
    }
  },
  {
    "group": "黑白透明色阶",
    "id": "color-white-a80",
    "name": "纯白 80%",
    "sono": true,
    "counterpart": "color-black-a80",
    "values": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 0.8
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.8
      }
    }
  },
  {
    "group": "黑白透明色阶",
    "id": "color-white-a90",
    "name": "纯白 90%",
    "sono": true,
    "counterpart": "color-black-a90",
    "values": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 0.9
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.9
      }
    }
  },
  {
    "id": "color-fill-selected",
    "group": "控件背景与状态填充",
    "name": "中性选中填充",
    "sono": true,
    "alias": true,
    "references": {
      "light": "color-black-a18",
      "dark": "color-white-a18"
    },
    "values": {
      "light": {
        "hex": "#000000",
        "alpha": 0.18
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.18
      }
    }
  },
  {
    "id": "color-lyrics-primary",
    "group": "场景前景",
    "name": "歌词标题／静态前景 · 保留现有效果",
    "alias": true,
    "sono": true,
    "values": {
      "light": {
        "hex": "#1A1A1A",
        "alpha": 1
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.9
      }
    }
  },
  {
    "id": "color-foreground-strong",
    "group": "文字与图标",
    "name": "按下／选中前景",
    "sono": true,
    "alias": true,
    "references": {
      "light": "sono-gray-0",
      "dark": "sono-gray-11"
    },
    "displayName": "控制台与顶部图标默认／按下／选中",
    "values": {
      "light": {
        "hex": "#000000",
        "alpha": 1
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 1
      }
    }
  },
  {
    "id": "color-progress-track",
    "group": "边框色",
    "name": "弱底轨",
    "sono": true,
    "alias": true,
    "references": {
      "light": "color-black-a12",
      "dark": "color-white-a12"
    },
    "values": {
      "light": {
        "hex": "#000000",
        "alpha": 0.12
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.12
      }
    }
  },
  {
    "id": "sono-monochrome-accent",
    "name": "黑白主题色",
    "group": "主色",
    "sono": true,
    "alias": true,
    "references": {
      "light": "color-black-a90",
      "dark": "color-white-a90"
    },
    "values": {
      "light": {
        "hex": "#000000",
        "alpha": 0.9
      },
      "dark": {
        "hex": "#FFFFFF",
        "alpha": 0.9
      }
    }
  },
  {
    "id": "sono-monochrome-on-accent",
    "name": "黑白主题色上的前景",
    "group": "主色",
    "sono": true,
    "alias": true,
    "references": {
      "light": "sono-gray-11",
      "dark": "sono-gray-0"
    },
    "values": {
      "light": {
        "hex": "#FFFFFF",
        "alpha": 1
      },
      "dark": {
        "hex": "#000000",
        "alpha": 1
      }
    }
  }
];
window.SONO_NEUTRAL_MIGRATION = {"previousDraft": {"version": 1, "selections": {"brand:SonoStyle:brand-accent:强调色 · 设计已确认": {"type": "arco", "id": "primary-6"}, "brand:SonoStyle:brand-favorite:收藏色 · 设计已确认": {"type": "custom", "space": "sRGB", "shared": true, "values": {"light": {"hex": "#FC3D49", "alpha": 1}, "dark": {"hex": "#FC3D49", "alpha": 1}, "lightContrast": {"hex": "#FC3D49", "alpha": 1}, "darkContrast": {"hex": "#FC3D49", "alpha": 1}}}, "home-background:SonoStyle:f0:浏览页背景 / 黑色": {"type": "custom", "space": "sRGB", "shared": false, "values": {"light": {"hex": "#F0F0F2", "alpha": 1}, "dark": {"hex": "#000000", "alpha": 1}, "lightContrast": {"hex": "#F0F0F2", "alpha": 1}, "darkContrast": {"hex": "#000000", "alpha": 1}}}, "home-background:CarouselPreview:f6:封面预览占位底色": {"type": "arco", "id": "color-fill-2"}, "home-background:RecommendationViews:f7:推荐风格选择面板背景": {"type": "arco", "id": "color-bg-2"}, "home-background:ArtistChoiceView:f8:艺人选择背景": {"type": "arco", "id": "color-bg-2"}, "home-background:NativeBrowseScene:f13:封面底色": {"type": "arco", "id": "color-fill-2"}, "home-background:ArtistChoiceView:o19:艺人关闭按钮": {"type": "arco", "id": "color-fill-3"}, "home-background:ArtistChoiceView:o19:头像占位": {"type": "arco", "id": "color-fill-2"}, "home-background:ArtistChoiceView:o19:悬停": {"type": "arco", "id": "color-fill-3"}, "text-colors:LyricsAppearance:f1:深色场景主要文字 / 白色": {"type": "arco", "id": "color-text-1"}, "text-colors:NativeBrowseScene:f15:封面原因文字": {"type": "arco", "id": "color-text-3"}, "text-colors:NativeBrowseScene:f16:非中心标题": {"type": "arco", "id": "color-text-2"}, "text-colors:NativeBrowseScene:f17:非中心艺人": {"type": "arco", "id": "color-text-2"}, "text-colors:SonoPlayer:f20:普通导航文字": {"type": "arco", "id": "color-text-1"}, "text-colors:SonoPlayer:o4:设置说明": {"type": "arco", "id": "color-text-2"}, "text-colors:SonoPlayer:o4:底部说明": {"type": "arco", "id": "color-text-2"}, "text-colors:SonoPlayer:o4:通知": {"type": "arco", "id": "color-text-2"}, "lyrics-colors:LyricsAppearance:f18:歌词暗底辅助文字": {"type": "arco", "id": "color-fill-white-6", "appearance": "dark"}, "lyrics-colors:NativeLyricsView:o14:返回当前歌词按钮": {"type": "arco", "id": "color-fill-2", "appearance": "light"}, "lyrics-colors:LyricsPage:o17:歌词面板阴影": {"type": "shadow", "id": "shadow2-center"}, "lyrics-colors:LyricsPage:o17:队列拖动行阴影": {"type": "shadow", "id": "shadow2-center"}, "list-colors:CollectionTitleCapsule:f4:歌单标题胶囊背景": {"type": "arco", "id": "color-bg-2"}, "list-colors:QuickList:f5:歌单位置徽标": {"type": "arco", "id": "color-bg-2"}, "list-colors:CarouselRail:f9:轮播轨道底色 / 高亮": {"type": "arco", "id": "color-border-4"}, "list-colors:CarouselRail:f10:轮播轨道滑块": {"type": "arco", "id": "color-border-4"}, "list-colors:CarouselRail:f11:轮播右侧文字底色": {"type": "arco", "id": "color-bg-2"}, "list-colors:CollectionTitleCapsule:f19:胶囊标题文字": {"type": "arco", "id": "color-text-1"}, "list-colors:QueueRowMotion:s0:队列「置顶」背景": {"type": "arco", "id": "purple-6"}, "list-colors:QueueRowMotion:s1:队列「删除」背景": {"type": "arco", "id": "red-6"}, "list-colors:QueueRowMotion:s2:删除动效线": {"type": "arco", "id": "red-6"}, "list-colors:QueueContent:s3:队列拖动行背景": {"type": "arco", "id": "color-primary-light-4"}, "list-colors:SourcePlaylistRow:o3:来源行文字": {"type": "arco", "id": "color-text-1"}, "list-colors:SourcePlaylistRow:o3:选中文字": {"type": "arco", "id": "color-text-1"}, "list-colors:QueueContent:o5:队列辅助文字": {"type": "arco", "id": "color-text-2"}, "list-colors:QueueContent:o5:操作图标": {"type": "arco", "id": "color-fill-black-6", "appearance": "light"}, "list-colors:QueueContent:o5:未选标签": {"type": "arco", "id": "color-text-2"}, "list-colors:QueueContent:o6:亮底分隔线": {"type": "arco", "id": "color-fill-black-2", "appearance": "light"}, "list-colors:QueueContent:o6:暗底分隔线": {"type": "arco", "id": "color-fill-white-2", "appearance": "dark"}, "list-colors:SourcePlaylistRow:o7:来源行选中": {"type": "role", "id": "brand:SonoStyle:brand-accent:强调色 · 设计已确认"}, "list-colors:SourcePlaylistRow:o7:悬停": {"type": "arco", "id": "color-fill-black-1", "appearance": "light"}, "list-colors:QuickList:o9:快捷列表悬停": {"type": "arco", "id": "color-fill-3"}, "list-colors:QuickList:o9:封面占位": {"type": "arco", "id": "color-fill-2"}, "list-colors:QuickList:o13:亮底滚动条": {"type": "arco", "id": "color-fill-black-4", "appearance": "light"}, "list-colors:QuickList:o13:暗底滚动条": {"type": "arco", "id": "color-fill-white-4", "appearance": "dark"}, "list-colors:QuickList:o13:快捷列表滚动条": {"type": "arco", "id": "color-border-4"}, "list-colors:QueueContent:o15:历史封面": {"type": "arco", "id": "color-fill-black-4"}, "list-colors:QueueContent:o15:快捷列表悬停播放底色": {"type": "arco", "id": "color-fill-black-4"}, "list-colors:SourcePlaylistRow:o20:来源图标默认": {"type": "arco", "id": "color-text-2"}, "list-colors:SourcePlaylistRow:o20:来源图标按下": {"type": "arco", "id": "color-text-1"}, "search-colors:SearchSuggestionRow:o1:搜索建议文字": {"type": "arco", "id": "color-text-2"}, "search-colors:SearchSuggestionRow:o1:匹配文字": {"type": "arco", "id": "color-text-1"}, "search-colors:SearchSuggestionRow:o1:类别图标": {"type": "arco", "id": "color-text-3"}, "search-colors:BrowseSearchField:o2:搜索占位文字": {"type": "arco", "id": "color-text-3"}, "search-colors:SearchSuggestionRow:o8:搜索建议选中": {"type": "arco", "id": "color-fill-3"}, "search-colors:SearchScopeSelection:o18:搜索范围选中": {"type": "arco", "id": "color-fill-4"}, "search-colors:SearchScopeSelection:o18:搜索范围悬停": {"type": "arco", "id": "color-fill-3"}, "search-colors:SearchScopeSelection:o18:搜索范围图标默认": {"type": "arco", "id": "color-text-1"}, "search-colors:SearchScopeSelection:o18:搜索范围图标弱化": {"type": "arco", "id": "color-text-1"}, "control-colors:NativeBrowseScene:f14:加载图标": {"type": "arco", "id": "color-text-1"}, "control-colors:SonoPlayer:f21:未选图标乘色": {"type": "arco", "id": "color-fill-black-0", "appearance": "light"}, "control-colors:SonoPlayer:o0:工具图标": {"type": "arco", "id": "color-text-1"}, "control-colors:SonoPlayer:o10:悬停": {"type": "arco", "id": "color-fill-black-1", "appearance": "light"}, "control-colors:SonoPlayer:o11:设置路径底色": {"type": "arco", "id": "color-fill-2"}, "control-colors:SonoPlayer:o11:本地来源行容器": {"type": "arco", "id": "color-bg-2"}, "control-colors:SonoPlayer:o12:播放进度底轨": {"type": "arco", "id": "color-border-3"}, "control-colors:SonoPlayer:o12:音量底轨": {"type": "arco", "id": "color-border-3"}, "control-colors:SonoStyle:o21:浓厚玻璃附加底色": {"type": "custom", "space": "sRGB", "shared": true, "values": {"light": {"hex": "#000000", "alpha": 0.32}, "dark": {"hex": "#000000", "alpha": 0.32}, "lightContrast": {"hex": "#000000", "alpha": 0.32}, "darkContrast": {"hex": "#000000", "alpha": 0.32}}}, "feedback-colors:NativeBrowseScene:s4:封面错误文字": {"type": "custom", "space": "sRGB", "shared": true, "values": {"light": {"hex": "#FFF0EC", "alpha": 1}, "dark": {"hex": "#FFF0EC", "alpha": 1}, "lightContrast": {"hex": "#FFF0EC", "alpha": 1}, "darkContrast": {"hex": "#FFF0EC", "alpha": 1}}}, "feedback-colors:NativeBrowseScene:s5:封面错误遮罩": {"type": "custom", "space": "sRGB", "shared": true, "values": {"light": {"hex": "#080B0D", "alpha": 0.65}, "dark": {"hex": "#080B0D", "alpha": 0.65}, "lightContrast": {"hex": "#080B0D", "alpha": 0.65}, "darkContrast": {"hex": "#080B0D", "alpha": 0.65}}}, "feedback-colors:NativeBrowseScene:o16:封面播放提示底色": {"type": "arco", "id": "color-fill-black-4"}, "lyrics-colors:NativeLyricsView:f1:主歌词暗底静态": {"type": "arco", "id": "color-text-1", "appearance": "dark"}, "lyrics-colors:NativeLyricsView:f1:主歌词暗底未选中": {"type": "arco", "id": "color-fill-white-4", "appearance": "dark"}, "lyrics-colors:NativeLyricsView:f1:主歌词暗底选中底层": {"type": "arco", "id": "color-fill-white-4", "appearance": "dark"}, "lyrics-colors:NativeLyricsView:f1:主歌词亮底静态": {"type": "arco", "id": "color-text-1", "appearance": "light"}, "lyrics-colors:NativeLyricsView:f1:主歌词亮底动态底层": {"type": "arco", "id": "color-fill-black-4", "appearance": "light"}, "lyrics-colors:NativeLyricsView:f1:辅助歌词暗底未选中": {"type": "arco", "id": "color-fill-white-4", "appearance": "dark"}, "lyrics-colors:NativeLyricsView:f1:辅助歌词暗底选中": {"type": "arco", "id": "color-fill-white-4", "appearance": "dark"}, "lyrics-colors:NativeLyricsView:f1:辅助歌词暗底悬停": {"type": "arco", "id": "color-text-1", "appearance": "dark"}, "lyrics-colors:LyricsMetalBackground:lyrics-background:动态封面渐变／歌词背景": {"type": "current", "description": "动态提色与渲染规则；不能替换为单一实色"}, "list-colors:SourcePlaylistRow:o3:普通图标": {"type": "arco", "id": "color-text-1"}, "lyrics-colors:SonoPlayer:lyrics-progress-track:歌词页音乐底轨": {"type": "arco", "id": "color-fill-black-2", "appearance": "light"}, "lyrics-colors:LyricsPage:f22:歌词页面板": {"type": "arco", "id": "color-bg-2", "appearance": "light"}, "lyrics-colors:NativeLyricsView:f1:主歌词暗底悬停": {"type": "arco", "id": "color-text-1", "appearance": "dark"}, "lyrics-colors:LyricsAppearance:f3:歌词亮底辅助文字": {"type": "arco", "id": "color-fill-black-6", "appearance": "light"}, "lyrics-colors:LyricsAppearance:f2:歌词亮底主要文字": {"type": "arco", "id": "color-text-1", "appearance": "light"}, "lyrics-colors:SonoPlayer:lyrics-volume-track:歌词页音量底轨": {"type": "arco", "id": "color-border-3", "appearance": "light"}, "lyrics-colors:LyricsAppearance:f2:歌词暗底主要文字": {"type": "arco", "id": "color-text-1", "appearance": "dark"}, "lyrics-colors:NativeLyricsView:f1:主歌词亮底未选中": {"type": "arco", "id": "color-fill-black-4", "appearance": "light"}, "lyrics-colors:NativeLyricsView:f1:主歌词亮底悬停": {"type": "arco", "id": "color-text-1", "appearance": "light"}, "lyrics-colors:NativeLyricsView:f1:辅助歌词亮底未选中": {"type": "arco", "id": "color-fill-black-4", "appearance": "light"}, "lyrics-colors:NativeLyricsView:f1:辅助歌词亮底选中": {"type": "arco", "id": "color-fill-black-4", "appearance": "light"}, "lyrics-colors:NativeLyricsView:f1:辅助歌词亮底悬停": {"type": "arco", "id": "color-text-1", "appearance": "light"}, "lyrics-colors:NativeLyricsView:f1:歌词亮底高亮层": {"type": "role", "id": "lyrics-colors:LyricsAppearance:f2:歌词亮底主要文字"}, "lyrics-colors:LyricsAppearance:title-transport:歌词亮底标题与播放控制": {"type": "arco", "id": "color-text-1", "appearance": "light"}, "lyrics-colors:LyricsAppearance:title-transport:歌词暗底标题与播放控制": {"type": "arco", "id": "color-text-1", "appearance": "dark"}, "lyrics-colors:NativeLyricsView:f1:歌词高亮层": {"type": "custom", "space": "sRGB", "shared": true, "values": {"light": {"hex": "#FFFFFF", "alpha": 1}, "dark": {"hex": "#FFFFFF", "alpha": 1}, "lightContrast": {"hex": "#FFFFFF", "alpha": 1}, "darkContrast": {"hex": "#FFFFFF", "alpha": 1}}}, "lyrics-colors:NativeLyricsView:resume-dark:返回当前歌词按钮暗底填充": {"type": "arco", "id": "color-fill-2", "appearance": "dark"}, "lyrics-colors:SonoPlayer:lyrics-volume-track-dark:歌词页音量底轨暗底": {"type": "arco", "id": "color-border-3", "appearance": "dark"}, "control-colors:RecommendationViews:recommendation-default-fill:推荐风格控件填充": {"type": "arco", "id": "color-fill-1"}, "control-colors:RecommendationViews:recommendation-pressed-fill:推荐按钮按下填充": {"type": "arco", "id": "color-fill-4"}, "control-colors:SonoPlayer:capsule-selected-icon:侧栏选中图标": {"type": "role", "id": "brand:SonoStyle:brand-accent:强调色 · 设计已确认"}, "control-colors:SonoPlayer:capsule-selected-ring:侧栏封面选中环": {"type": "role", "id": "brand:SonoStyle:brand-accent:强调色 · 设计已确认"}, "list-colors:SourcePlaylistRow:drawer-selected-light:抽屉浅色选中前景": {"type": "role", "id": "list-colors:SourcePlaylistRow:o3:选中文字", "appearance": "dark"}, "control-state:console-disabled": {"type": "arco", "id": "color-fill-black-4", "appearance": "light"}, "control-state:console-hover": {"type": "arco", "id": "color-fill-black-8", "appearance": "light"}, "interface-color:interfaceDisabled": {"type": "arco", "id": "color-text-4"}, "interface-color:interfaceError": {"type": "arco", "id": "red-7"}, "interface-color:interfaceBorder": {"type": "arco", "id": "color-border-1"}, "interface-color:interfacePlaceholderIcon": {"type": "arco", "id": "color-text-3"}, "interface-color:interfaceBackdrop": {"type": "role", "id": "lyrics-colors:LyricsPage:o17:歌词面板阴影"}, "interface-color:artworkControlSurface": {"type": "arco", "id": "color-text-1"}, "interface-color:artworkControlInk": {"type": "arco", "id": "color-text-1"}, "lyrics-colors:SonoPlayer:lyrics-progress-track-dark:歌词页音乐底轨暗底": {"type": "arco", "id": "color-fill-white-2", "appearance": "dark"}, "lyrics-colors:QueueContent:lyrics-divider-light:歌词页亮底分隔线": {"type": "role", "id": "list-colors:QueueContent:o6:亮底分隔线", "appearance": "light"}, "lyrics-colors:QueueContent:lyrics-divider-dark:歌词页暗底分隔线": {"type": "role", "id": "list-colors:QueueContent:o6:暗底分隔线", "appearance": "dark"}, "lyrics-colors:QueueContent:queue-tab-light:歌词页队列未选中页签亮底": {"type": "role", "id": "list-colors:QueueContent:queue-tab-light:普通队列浅色未选中页签", "appearance": "light"}, "lyrics-colors:QueueContent:queue-tab-dark:歌词页队列未选中页签暗底": {"type": "role", "id": "list-colors:QueueContent:queue-tab-dark:普通队列深色未选中页签", "appearance": "dark"}, "lyrics-colors:QueueContent:queue-close-light:歌词页队列关闭图标亮底": {"type": "role", "id": "list-colors:QueueContent:queue-close-light:普通队列浅色关闭图标", "appearance": "light"}, "lyrics-colors:QueueContent:queue-close-dark:歌词页队列关闭图标暗底": {"type": "role", "id": "list-colors:QueueContent:queue-close-dark:普通队列深色关闭图标", "appearance": "dark"}, "lyrics-colors:QueueContent:queue-action-light:歌词页队列操作图标亮底": {"type": "role", "id": "list-colors:QueueContent:o5:操作图标", "appearance": "light"}, "lyrics-colors:QueueContent:queue-action-dark:歌词页队列操作图标暗底": {"type": "role", "id": "list-colors:QueueContent:queue-action-dark:普通队列深色操作图标", "appearance": "dark"}, "lyrics-colors:QueueContent:queue-scrollbar-light:歌词页队列滚动条亮底": {"type": "arco", "id": "color-fill-black-4", "appearance": "light"}, "lyrics-colors:QueueContent:queue-scrollbar-dark:歌词页队列滚动条暗底": {"type": "arco", "id": "color-fill-white-4", "appearance": "dark"}, "list-colors:QueueContent:queue-tab-light:普通队列浅色未选中页签": {"type": "arco", "id": "color-fill-black-6", "appearance": "light"}, "list-colors:QueueContent:queue-tab-dark:普通队列深色未选中页签": {"type": "arco", "id": "color-fill-white-6", "appearance": "dark"}, "list-colors:QueueContent:queue-close-light:普通队列浅色关闭图标": {"type": "arco", "id": "color-fill-black-6", "appearance": "light"}, "list-colors:QueueContent:queue-close-dark:普通队列深色关闭图标": {"type": "arco", "id": "color-fill-white-6", "appearance": "dark"}, "list-colors:QueueContent:queue-action-dark:普通队列深色操作图标": {"type": "arco", "id": "color-fill-white-6", "appearance": "dark"}, "interface-color:interfaceHoverForeground": {"type": "arco", "id": "color-fill-black-8", "appearance": "light"}, "interface-color:interfaceHoverForegroundDark": {"type": "arco", "id": "color-fill-white-8", "appearance": "dark"}, "interface-color:sourceSectionArrow": {"type": "arco", "id": "color-text-2"}, "interface-color:sourceHoverDark": {"type": "arco", "id": "color-fill-white-1", "appearance": "dark"}, "interface-color:modeHoverDark": {"type": "arco", "id": "color-fill-white-1", "appearance": "dark"}, "interface-color:queueTitleLight": {"type": "arco", "id": "color-fill-black-8", "appearance": "light"}, "interface-color:queueTitleDark": {"type": "arco", "id": "color-fill-white-8", "appearance": "dark"}, "interface-color:queueTextSecondaryLight": {"type": "arco", "id": "color-fill-black-6", "appearance": "light"}, "interface-color:queueTextSecondaryDark": {"type": "arco", "id": "color-fill-white-6", "appearance": "dark"}, "interface-color:queueSelectedTabLight": {"type": "arco", "id": "color-fill-black-0", "appearance": "light"}, "interface-color:queueSelectedTabDark": {"type": "arco", "id": "color-fill-white-10", "appearance": "dark"}, "interface-color:queuePressedLight": {"type": "arco", "id": "color-fill-black-0", "appearance": "light"}, "interface-color:queuePressedDark": {"type": "arco", "id": "color-fill-white-10", "appearance": "dark"}, "interface-color:queueDisabledLight": {"type": "arco", "id": "color-fill-black-4", "appearance": "light"}, "interface-color:queueDisabledDark": {"type": "arco", "id": "color-fill-white-4", "appearance": "dark"}, "interface-color:consoleDefaultIconDark": {"type": "arco", "id": "color-fill-white-10", "appearance": "dark"}, "interface-color:consoleHoverIconDark": {"type": "arco", "id": "color-fill-white-8", "appearance": "dark"}, "interface-color:consoleDisabledIconDark": {"type": "arco", "id": "color-fill-white-4", "appearance": "dark"}, "interface-color:consolePressedIconLight": {"type": "arco", "id": "color-fill-black-0", "appearance": "light"}, "interface-color:consolePressedIconDark": {"type": "arco", "id": "color-fill-white-10", "appearance": "dark"}, "interface-color:progressChorusLight": {"type": "arco", "id": "color-fill-black-8", "appearance": "light"}, "interface-color:progressChorusDark": {"type": "arco", "id": "color-fill-white-8", "appearance": "dark"}}, "tokens": {}, "primary": "#FF375F", "refinementRevision": 4, "lyricsTrackReferenceRevision": 1}, "tokenIDs": {"color-fill-black-0": "sono-gray-0", "color-fill-black-1": "color-black-a08", "color-fill-black-2": "color-black-a20", "color-fill-black-4": "color-black-a40", "color-fill-black-6": "color-black-a60", "color-fill-black-8": "color-black-a80", "color-fill-white-1": "color-white-a08", "color-fill-white-2": "color-white-a20", "color-fill-white-4": "color-white-a40", "color-fill-white-6": "color-white-a60", "color-fill-white-8": "color-white-a80", "color-fill-white-10": "sono-gray-11"}};
