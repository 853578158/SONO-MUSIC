window.SONO_LYRICS_ROLE_PAIRS = [
  {
    "id": "lyrics-colors:LyricsAppearance:f2:歌词亮底主要文字",
    "name": "歌词亮底主要文字",
    "displayName": "歌词亮底主要文字",
    "scene": "light",
    "order": 0,
    "symbol": "lyricsLightPrimary",
    "counterpart": "lyrics-colors:LyricsAppearance:f2:歌词暗底主要文字",
    "default": {
      "type": "arco",
      "id": "color-lyrics-primary",
      "appearance": "light"
    }
  },
  {
    "id": "lyrics-colors:LyricsAppearance:f2:歌词暗底主要文字",
    "name": "歌词暗底主要文字",
    "displayName": "歌词暗底主要文字",
    "scene": "dark",
    "order": 0,
    "symbol": "lyricsDarkPrimary",
    "counterpart": "lyrics-colors:LyricsAppearance:f2:歌词亮底主要文字",
    "default": {
      "type": "arco",
      "id": "color-lyrics-primary",
      "appearance": "dark"
    }
  },
  {
    "id": "lyrics-colors:LyricsAppearance:f3:歌词亮底辅助文字",
    "name": "歌词亮底辅助文字",
    "displayName": "歌词亮底辅助文字",
    "scene": "light",
    "order": 1,
    "symbol": "lyricsLightSecondary",
    "counterpart": "lyrics-colors:LyricsAppearance:f18:歌词暗底辅助文字",
    "default": {
      "type": "arco",
      "id": "color-black-a60",
      "appearance": "light"
    }
  },
  {
    "id": "lyrics-colors:LyricsAppearance:f18:歌词暗底辅助文字",
    "name": "歌词暗底辅助文字",
    "displayName": "歌词暗底辅助文字",
    "scene": "dark",
    "order": 1,
    "symbol": "lyricsDarkSecondary",
    "counterpart": "lyrics-colors:LyricsAppearance:f3:歌词亮底辅助文字",
    "default": {
      "type": "arco",
      "id": "color-white-a60",
      "appearance": "dark"
    }
  },
  {
    "id": "lyrics-colors:NativeLyricsView:f1:主歌词亮底静态",
    "name": "主歌词亮底静态",
    "displayName": "主歌词亮底静态",
    "scene": "light",
    "order": 2,
    "symbol": "lyricLightStatic",
    "counterpart": "lyrics-colors:NativeLyricsView:f1:主歌词暗底静态",
    "default": {
      "type": "arco",
      "id": "color-lyrics-primary",
      "appearance": "light"
    }
  },
  {
    "id": "lyrics-colors:NativeLyricsView:f1:主歌词暗底静态",
    "name": "主歌词暗底静态",
    "displayName": "主歌词暗底静态",
    "scene": "dark",
    "order": 2,
    "symbol": "lyricDarkStatic",
    "counterpart": "lyrics-colors:NativeLyricsView:f1:主歌词亮底静态",
    "default": {
      "type": "arco",
      "id": "color-lyrics-primary",
      "appearance": "dark"
    }
  },
  {
    "id": "lyrics-colors:NativeLyricsView:f1:主歌词亮底未选中",
    "name": "主歌词亮底未选中",
    "displayName": "主歌词亮底未选中",
    "scene": "light",
    "order": 3,
    "symbol": "lyricLightUnselected",
    "counterpart": "lyrics-colors:NativeLyricsView:f1:主歌词暗底未选中",
    "default": {
      "type": "arco",
      "id": "color-black-a40",
      "appearance": "light"
    }
  },
  {
    "id": "lyrics-colors:NativeLyricsView:f1:主歌词暗底未选中",
    "name": "主歌词暗底未选中",
    "displayName": "主歌词暗底未选中",
    "scene": "dark",
    "order": 3,
    "symbol": "lyricDarkIdle",
    "counterpart": "lyrics-colors:NativeLyricsView:f1:主歌词亮底未选中",
    "default": {
      "type": "arco",
      "id": "color-white-a40",
      "appearance": "dark"
    }
  },
  {
    "id": "lyrics-colors:NativeLyricsView:f1:主歌词亮底动态底层",
    "name": "主歌词亮底动态底层",
    "displayName": "主歌词亮底选中底层",
    "scene": "light",
    "order": 4,
    "symbol": "lyricLightIdle",
    "counterpart": "lyrics-colors:NativeLyricsView:f1:主歌词暗底选中底层",
    "default": {
      "type": "arco",
      "id": "color-black-a40",
      "appearance": "light"
    }
  },
  {
    "id": "lyrics-colors:NativeLyricsView:f1:主歌词暗底选中底层",
    "name": "主歌词暗底选中底层",
    "displayName": "主歌词暗底选中底层",
    "scene": "dark",
    "order": 4,
    "symbol": "lyricDarkSelected",
    "counterpart": "lyrics-colors:NativeLyricsView:f1:主歌词亮底动态底层",
    "default": {
      "type": "arco",
      "id": "color-white-a40",
      "appearance": "dark"
    }
  },
  {
    "id": "lyrics-colors:NativeLyricsView:f1:主歌词亮底悬停",
    "name": "主歌词亮底悬停",
    "displayName": "主歌词亮底悬停",
    "scene": "light",
    "order": 5,
    "symbol": "lyricLightHover",
    "counterpart": "lyrics-colors:NativeLyricsView:f1:主歌词暗底悬停",
    "default": {
      "type": "arco",
      "id": "color-lyrics-primary",
      "appearance": "light"
    }
  },
  {
    "id": "lyrics-colors:NativeLyricsView:f1:主歌词暗底悬停",
    "name": "主歌词暗底悬停",
    "displayName": "主歌词暗底悬停",
    "scene": "dark",
    "order": 5,
    "symbol": "lyricDarkHover",
    "counterpart": "lyrics-colors:NativeLyricsView:f1:主歌词亮底悬停",
    "default": {
      "type": "arco",
      "id": "color-lyrics-primary",
      "appearance": "dark"
    }
  },
  {
    "id": "lyrics-colors:NativeLyricsView:f1:辅助歌词亮底未选中",
    "name": "辅助歌词亮底未选中",
    "displayName": "辅助歌词亮底未选中",
    "scene": "light",
    "order": 6,
    "symbol": "lyricLightAuxIdle",
    "counterpart": "lyrics-colors:NativeLyricsView:f1:辅助歌词暗底未选中",
    "default": {
      "type": "arco",
      "id": "color-black-a40",
      "appearance": "light"
    }
  },
  {
    "id": "lyrics-colors:NativeLyricsView:f1:辅助歌词暗底未选中",
    "name": "辅助歌词暗底未选中",
    "displayName": "辅助歌词暗底未选中",
    "scene": "dark",
    "order": 6,
    "symbol": "lyricAuxIdle",
    "counterpart": "lyrics-colors:NativeLyricsView:f1:辅助歌词亮底未选中",
    "default": {
      "type": "arco",
      "id": "color-white-a40",
      "appearance": "dark"
    }
  },
  {
    "id": "lyrics-colors:NativeLyricsView:f1:辅助歌词亮底选中",
    "name": "辅助歌词亮底选中",
    "displayName": "辅助歌词亮底选中",
    "scene": "light",
    "order": 7,
    "symbol": "lyricLightAuxSelected",
    "counterpart": "lyrics-colors:NativeLyricsView:f1:辅助歌词暗底选中",
    "default": {
      "type": "arco",
      "id": "color-black-a40",
      "appearance": "light"
    }
  },
  {
    "id": "lyrics-colors:NativeLyricsView:f1:辅助歌词暗底选中",
    "name": "辅助歌词暗底选中",
    "displayName": "辅助歌词暗底选中",
    "scene": "dark",
    "order": 7,
    "symbol": "lyricAuxSelected",
    "counterpart": "lyrics-colors:NativeLyricsView:f1:辅助歌词亮底选中",
    "default": {
      "type": "arco",
      "id": "color-white-a40",
      "appearance": "dark"
    }
  },
  {
    "id": "lyrics-colors:NativeLyricsView:f1:辅助歌词亮底悬停",
    "name": "辅助歌词亮底悬停",
    "displayName": "辅助歌词亮底悬停",
    "scene": "light",
    "order": 8,
    "symbol": "lyricLightAuxHover",
    "counterpart": "lyrics-colors:NativeLyricsView:f1:辅助歌词暗底悬停",
    "default": {
      "type": "arco",
      "id": "color-lyrics-primary",
      "appearance": "light"
    }
  },
  {
    "id": "lyrics-colors:NativeLyricsView:f1:辅助歌词暗底悬停",
    "name": "辅助歌词暗底悬停",
    "displayName": "辅助歌词暗底悬停",
    "scene": "dark",
    "order": 8,
    "symbol": "lyricAuxHover",
    "counterpart": "lyrics-colors:NativeLyricsView:f1:辅助歌词亮底悬停",
    "default": {
      "type": "arco",
      "id": "color-lyrics-primary",
      "appearance": "dark"
    }
  },
  {
    "id": "lyrics-colors:NativeLyricsView:f1:歌词亮底高亮层",
    "name": "歌词亮底高亮层",
    "displayName": "歌词亮底高亮层",
    "scene": "light",
    "order": 9,
    "symbol": "lyricLightHighlight",
    "counterpart": "lyrics-colors:NativeLyricsView:f1:歌词高亮层",
    "default": {
      "type": "role",
      "id": "lyrics-colors:LyricsAppearance:f2:歌词亮底主要文字"
    }
  },
  {
    "id": "lyrics-colors:NativeLyricsView:f1:歌词高亮层",
    "name": "歌词高亮层",
    "displayName": "歌词暗底高亮层",
    "scene": "dark",
    "order": 9,
    "symbol": "lyricHighlight",
    "counterpart": "lyrics-colors:NativeLyricsView:f1:歌词亮底高亮层",
    "default": {
      "type": "custom",
      "space": "sRGB",
      "shared": true,
      "values": {
        "light": {
          "hex": "#FFFFFF",
          "alpha": 1
        },
        "dark": {
          "hex": "#FFFFFF",
          "alpha": 1
        },
        "lightContrast": {
          "hex": "#FFFFFF",
          "alpha": 1
        },
        "darkContrast": {
          "hex": "#FFFFFF",
          "alpha": 1
        }
      }
    }
  },
  {
    "id": "lyrics-colors:LyricsAppearance:title-transport:歌词亮底标题与播放控制",
    "name": "歌词亮底标题与播放控制",
    "displayName": "歌词亮底标题与播放控制",
    "scene": "light",
    "order": 0.5,
    "symbol": "lyricsLightTitleTransport",
    "counterpart": "lyrics-colors:LyricsAppearance:title-transport:歌词暗底标题与播放控制",
    "default": {
      "type": "arco",
      "id": "color-lyrics-primary",
      "appearance": "light"
    },
    "inheritFrom": "lyrics-colors:LyricsAppearance:f2:歌词亮底主要文字"
  },
  {
    "id": "lyrics-colors:LyricsAppearance:title-transport:歌词暗底标题与播放控制",
    "name": "歌词暗底标题与播放控制",
    "displayName": "歌词暗底标题与播放控制",
    "scene": "dark",
    "order": 0.5,
    "symbol": "lyricsDarkTitleTransport",
    "counterpart": "lyrics-colors:LyricsAppearance:title-transport:歌词亮底标题与播放控制",
    "default": {
      "type": "arco",
      "id": "color-lyrics-primary",
      "appearance": "dark"
    },
    "inheritFrom": "lyrics-colors:LyricsAppearance:f2:歌词暗底主要文字"
  },
  {
    "id": "lyrics-colors:NativeLyricsView:o14:返回当前歌词按钮",
    "name": "返回当前歌词按钮亮底填充",
    "displayName": "返回当前歌词按钮 · 亮底",
    "scene": "light",
    "order": 11,
    "symbol": "resumeLyrics",
    "counterpart": "lyrics-colors:NativeLyricsView:resume-dark:返回当前歌词按钮暗底填充",
    "default": {
      "type": "arco",
      "id": "color-fill-2",
      "appearance": "light"
    },
    "inheritFrom": null,
    "matchScene": true,
    "location": "歌词页右下方恢复跟随按钮背景"
  },
  {
    "id": "lyrics-colors:NativeLyricsView:resume-dark:返回当前歌词按钮暗底填充",
    "name": "返回当前歌词按钮暗底填充",
    "displayName": "返回当前歌词按钮 · 暗底",
    "scene": "dark",
    "order": 11,
    "symbol": "resumeLyricsDark",
    "counterpart": "lyrics-colors:NativeLyricsView:o14:返回当前歌词按钮",
    "default": {
      "type": "arco",
      "id": "color-fill-2",
      "appearance": "dark"
    },
    "inheritFrom": "lyrics-colors:NativeLyricsView:o14:返回当前歌词按钮",
    "matchScene": true,
    "location": "歌词页右下方恢复跟随按钮背景"
  },
  {
    "id": "lyrics-colors:SonoPlayer:lyrics-volume-track:歌词页音量底轨",
    "name": "歌词页音量底轨亮底",
    "displayName": "歌词页音量底轨 · 亮底",
    "scene": "light",
    "order": 12,
    "symbol": "lyricsVolumeTrack",
    "counterpart": "lyrics-colors:SonoPlayer:lyrics-volume-track-dark:歌词页音量底轨暗底",
    "default": {
      "type": "arco",
      "id": "color-border-3",
      "appearance": "light"
    },
    "inheritFrom": null,
    "matchScene": true,
    "location": "歌词页底部音量图标展开后的底轨"
  },
  {
    "id": "lyrics-colors:SonoPlayer:lyrics-volume-track-dark:歌词页音量底轨暗底",
    "name": "歌词页音量底轨暗底",
    "displayName": "歌词页音量底轨 · 暗底",
    "scene": "dark",
    "order": 12,
    "symbol": "lyricsVolumeTrackDark",
    "counterpart": "lyrics-colors:SonoPlayer:lyrics-volume-track:歌词页音量底轨",
    "default": {
      "type": "arco",
      "id": "color-border-3",
      "appearance": "dark"
    },
    "inheritFrom": "lyrics-colors:SonoPlayer:lyrics-volume-track:歌词页音量底轨",
    "matchScene": true,
    "location": "歌词页底部音量图标展开后的底轨"
  },
  {
    "id": "lyrics-colors:SonoPlayer:lyrics-progress-track:歌词页音乐底轨",
    "name": "歌词页音乐底轨亮底",
    "displayName": "歌词页音乐底轨 · 亮底",
    "scene": "light",
    "order": 13,
    "symbol": "lyricsProgressTrack",
    "counterpart": "lyrics-colors:SonoPlayer:lyrics-progress-track-dark:歌词页音乐底轨暗底",
    "default": {
      "type": "arco",
      "id": "color-black-a20",
      "appearance": "light"
    },
    "matchScene": true,
    "location": "歌词页底部音乐进度条未播放部分（独立于首页与音量底轨）"
  },
  {
    "id": "lyrics-colors:SonoPlayer:lyrics-progress-track-dark:歌词页音乐底轨暗底",
    "name": "歌词页音乐底轨暗底",
    "displayName": "歌词页音乐底轨 · 暗底",
    "scene": "dark",
    "order": 13,
    "symbol": "lyricsProgressTrackDark",
    "counterpart": "lyrics-colors:SonoPlayer:lyrics-progress-track:歌词页音乐底轨",
    "default": {
      "type": "arco",
      "id": "color-white-a20",
      "appearance": "dark"
    },
    "matchScene": true,
    "location": "歌词页底部音乐进度条未播放部分（独立于首页与音量底轨）"
  },
  {
    "id": "lyrics-colors:QueueContent:lyrics-divider-light:歌词页亮底分隔线",
    "name": "歌词页亮底分隔线",
    "displayName": "歌词页队列分隔线 · 亮底",
    "scene": "light",
    "order": 14,
    "symbol": "lyricsDividerLight",
    "counterpart": "lyrics-colors:QueueContent:lyrics-divider-dark:歌词页暗底分隔线",
    "default": {
      "type": "role",
      "id": "list-colors:QueueContent:o6:亮底分隔线",
      "appearance": "light"
    },
    "matchScene": true,
    "location": "歌词页内播放队列／历史记录，各歌曲行底部分隔线（独立于普通队列）"
  },
  {
    "id": "lyrics-colors:QueueContent:lyrics-divider-dark:歌词页暗底分隔线",
    "name": "歌词页暗底分隔线",
    "displayName": "歌词页队列分隔线 · 暗底",
    "scene": "dark",
    "order": 14,
    "symbol": "lyricsDividerDark",
    "counterpart": "lyrics-colors:QueueContent:lyrics-divider-light:歌词页亮底分隔线",
    "default": {
      "type": "role",
      "id": "list-colors:QueueContent:o6:暗底分隔线",
      "appearance": "dark"
    },
    "matchScene": true,
    "location": "歌词页内播放队列／历史记录，各歌曲行底部分隔线（独立于普通队列）"
  },
  {
    "id": "lyrics-colors:QueueContent:queue-tab-light:歌词页队列未选中页签亮底",
    "name": "歌词页队列未选中页签亮底",
    "displayName": "歌词页队列未选中页签 · 亮底",
    "scene": "light",
    "order": 15,
    "symbol": "lyricsQueueTabLight",
    "counterpart": "lyrics-colors:QueueContent:queue-tab-dark:歌词页队列未选中页签暗底",
    "default": {
      "type": "role",
      "id": "list-colors:QueueContent:queue-tab-light:普通队列浅色未选中页签",
      "appearance": "light"
    },
    "matchScene": true,
    "location": "歌词页队列顶部未选中的播放队列／历史记录"
  },
  {
    "id": "lyrics-colors:QueueContent:queue-tab-dark:歌词页队列未选中页签暗底",
    "name": "歌词页队列未选中页签暗底",
    "displayName": "歌词页队列未选中页签 · 暗底",
    "scene": "dark",
    "order": 15,
    "symbol": "lyricsQueueTabDark",
    "counterpart": "lyrics-colors:QueueContent:queue-tab-light:歌词页队列未选中页签亮底",
    "default": {
      "type": "role",
      "id": "list-colors:QueueContent:queue-tab-dark:普通队列深色未选中页签",
      "appearance": "dark"
    },
    "matchScene": true,
    "location": "歌词页队列顶部未选中的播放队列／历史记录"
  },
  {
    "id": "lyrics-colors:QueueContent:queue-close-light:歌词页队列关闭图标亮底",
    "name": "歌词页队列关闭图标亮底",
    "displayName": "歌词页队列关闭图标 · 亮底",
    "scene": "light",
    "order": 16,
    "symbol": "lyricsQueueCloseLight",
    "counterpart": "lyrics-colors:QueueContent:queue-close-dark:歌词页队列关闭图标暗底",
    "default": {
      "type": "role",
      "id": "list-colors:QueueContent:queue-close-light:普通队列浅色关闭图标",
      "appearance": "light"
    },
    "matchScene": true,
    "location": "歌词页队列右上关闭图标"
  },
  {
    "id": "lyrics-colors:QueueContent:queue-close-dark:歌词页队列关闭图标暗底",
    "name": "歌词页队列关闭图标暗底",
    "displayName": "歌词页队列关闭图标 · 暗底",
    "scene": "dark",
    "order": 16,
    "symbol": "lyricsQueueCloseDark",
    "counterpart": "lyrics-colors:QueueContent:queue-close-light:歌词页队列关闭图标亮底",
    "default": {
      "type": "role",
      "id": "list-colors:QueueContent:queue-close-dark:普通队列深色关闭图标",
      "appearance": "dark"
    },
    "matchScene": true,
    "location": "歌词页队列右上关闭图标"
  },
  {
    "id": "lyrics-colors:QueueContent:queue-action-light:歌词页队列操作图标亮底",
    "name": "歌词页队列操作图标亮底",
    "displayName": "歌词页队列操作图标 · 亮底",
    "scene": "light",
    "order": 17,
    "symbol": "lyricsQueueActionLight",
    "counterpart": "lyrics-colors:QueueContent:queue-action-dark:歌词页队列操作图标暗底",
    "default": {
      "type": "role",
      "id": "list-colors:QueueContent:o5:操作图标",
      "appearance": "light"
    },
    "matchScene": true,
    "location": "歌词页队列定位当前、清空待播默认、歌曲更多操作"
  },
  {
    "id": "lyrics-colors:QueueContent:queue-action-dark:歌词页队列操作图标暗底",
    "name": "歌词页队列操作图标暗底",
    "displayName": "歌词页队列操作图标 · 暗底",
    "scene": "dark",
    "order": 17,
    "symbol": "lyricsQueueActionDark",
    "counterpart": "lyrics-colors:QueueContent:queue-action-light:歌词页队列操作图标亮底",
    "default": {
      "type": "role",
      "id": "list-colors:QueueContent:queue-action-dark:普通队列深色操作图标",
      "appearance": "dark"
    },
    "matchScene": true,
    "location": "歌词页队列定位当前、清空待播默认、歌曲更多操作"
  },
  {
    "id": "lyrics-colors:QueueContent:queue-scrollbar-light:歌词页队列滚动条亮底",
    "name": "歌词页队列滚动条亮底",
    "displayName": "歌词页队列滚动条 · 亮底",
    "scene": "light",
    "order": 18,
    "symbol": "lyricsQueueScrollbarLight",
    "counterpart": "lyrics-colors:QueueContent:queue-scrollbar-dark:歌词页队列滚动条暗底",
    "default": {
      "type": "arco",
      "id": "color-black-a40",
      "appearance": "light"
    },
    "matchScene": true,
    "location": "歌词页队列右侧滚动滑块"
  },
  {
    "id": "lyrics-colors:QueueContent:queue-scrollbar-dark:歌词页队列滚动条暗底",
    "name": "歌词页队列滚动条暗底",
    "displayName": "歌词页队列滚动条 · 暗底",
    "scene": "dark",
    "order": 18,
    "symbol": "lyricsQueueScrollbarDark",
    "counterpart": "lyrics-colors:QueueContent:queue-scrollbar-light:歌词页队列滚动条亮底",
    "default": {
      "type": "arco",
      "id": "color-white-a40",
      "appearance": "dark"
    },
    "matchScene": true,
    "location": "歌词页队列右侧滚动滑块"
  }
];
