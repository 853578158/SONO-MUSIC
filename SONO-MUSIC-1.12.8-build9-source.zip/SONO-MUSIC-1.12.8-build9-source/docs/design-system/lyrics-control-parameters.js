window.SONO_LYRICS_PARAMETERS = [
  {
    "id": "lyrics-panel-shadow-blur",
    "name": "歌词页面板阴影模糊",
    "symbol": "lyricsPanelShadowBlur",
    "value": 32,
    "min": 0,
    "max": 100,
    "step": 1,
    "unit": "px",
    "component": "blur"
  },
  {
    "id": "lyrics-panel-shadow-x",
    "name": "歌词页面板阴影水平偏移",
    "symbol": "lyricsPanelShadowX",
    "value": 0,
    "min": -100,
    "max": 100,
    "step": 1,
    "unit": "px",
    "component": "x"
  },
  {
    "id": "lyrics-panel-shadow-y",
    "name": "歌词页面板阴影垂直偏移",
    "symbol": "lyricsPanelShadowY",
    "value": 6,
    "min": -100,
    "max": 100,
    "step": 1,
    "unit": "px",
    "component": "y"
  }
];
window.ARCO_SHADOWS = [
  {
    "id": "shadow-special",
    "value": "0 0 1px rgba(0, 0, 0, 0.3)",
    "description": "特殊阴影",
    "x": 0,
    "y": 0,
    "blur": 1,
    "hex": "#000000",
    "alpha": 0.3
  },
  {
    "id": "shadow1-center",
    "value": "0 -2px 5px rgba(0, 0, 0, 0.1)",
    "description": "阴影样式1",
    "x": 0,
    "y": -2,
    "blur": 5,
    "hex": "#000000",
    "alpha": 0.1
  },
  {
    "id": "shadow2-center",
    "value": "0 0 10px rgba(0, 0, 0, 0.1)",
    "description": "阴影样式2",
    "x": 0,
    "y": 0,
    "blur": 10,
    "hex": "#000000",
    "alpha": 0.1
  },
  {
    "id": "shadow3-center",
    "value": "0 0 20px rgba(0, 0, 0, 0.1)",
    "description": "阴影样式3",
    "x": 0,
    "y": 0,
    "blur": 20,
    "hex": "#000000",
    "alpha": 0.1
  }
];
